<?php

/**
 * YunxiAdmin 后台美化
 *
 * 后台美化与天气工作台：50 米街道级定位、实时天气与气象预警、台风动态轨迹与登陆预估、免费交通路况、页面性能看板，电脑端与手机端独立布局。
 *
 * @package YunxiAdmin
 * @author Yunxi
 * @version 2.2.0.2
 */

namespace TypechoPlugin\YunxiAdmin;

use Typecho\Plugin\PluginInterface;
use Typecho\Widget;
use Typecho\Widget\Helper\Form;
use Typecho\Config;
use Widget\Options;
use Utils\Helper;
use Widget\User;
use Typecho\Common;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Plugin implements PluginInterface
{

    const VERSION = '2.2.0.2';

    private static $weatherCache = null;
    private static $locCache = null;

    private static $charsetDone = false;

    private static $spriteDone = false;

    private static function spriteInline()
    {
        if (self::$spriteDone) {
            return '';
        }
        self::$spriteDone = true;
        $file = __DIR__ . '/assets/img/icons.svg';
        $svg = is_file($file) ? (string) @file_get_contents($file) : '';
        if ($svg !== '' && preg_match('/<svg[\s\S]*<\/svg>/i', $svg, $m)) {
            return '<div class="yx-sprite" aria-hidden="true" style="position:absolute;width:0;height:0;overflow:hidden;line-height:0">'
                . preg_replace('/<\?xml[\s\S]*?\?>/i', '', $m[0]) . '</div>';
        }
        return '';
    }

    public static function activate()
    {
        \Typecho\Plugin::factory('admin/header.php')->header_15 = __CLASS__ . '::render';
        \Typecho\Plugin::factory('admin/footer.php')->begin_15 = __CLASS__ . '::footerjs';
        \Typecho\Plugin::factory('admin/menu.php')->navBar_15 = __CLASS__ . '::remenu';
        \Typecho\Plugin::factory('index.php')->end = __CLASS__ . '::trackVisit';
        \Typecho\Plugin::factory('index.php')->begin = __CLASS__ . '::beginRequest';
        \Typecho\Plugin::factory('Widget_Abstract_Comments')->gravatar = __CLASS__ . '::pltx';
        \Typecho\Plugin::factory('Widget_Abstract_Comments')->filter = __CLASS__ . '::urlfilter';
        self::ensureVisitTable();
        self::ensureConfig();

        try {
            require_once __DIR__ . '/weather/shared/load.php';
            \YxWeather\AccountLocation::ensure();
            \YxWeather\CrawlLog::ensure();
            \YxWeather\Metrics::ensure();
        } catch (\Throwable $e) {
        }
        return _t('YunxiAdmin 已启用：50 米街道级定位、实时预警、台风轨迹与登陆预估、免费交通路况、性能看板，双端独立布局。');
    }

    public static function deactivate()
    {
    }

    public static function config(Form $form)
    {
        $theme = new Form\Element\Radio('theme', array(
            'system' => _t('跟随系统'),
            'light'  => _t('始终白天'),
            'dark'   => _t('始终夜间')
        ), 'system', _t('默认外观'), _t('全局默认外观；设为“跟随系统”时随操作系统自动切换明暗，无需手动操作。'));
        $form->addInput($theme);

        $accent = new Form\Element\Text('accent', NULL, '#0f6f68', _t('主题色'), _t('点击色块选择，自定义主色调会应用到导航、按钮等所有强调色'));
        $accent->input->setAttribute('type', 'color');
        $accent->input->setAttribute('id', 'yxaccent');
        $form->addInput($accent);

        $presets = new Form\Element\Text('presets', NULL, NULL, _t('推荐配色'), _t('点击快速套用'));
        $presets->input->setAttribute('id', 'yxpresets');
        $form->addInput($presets);

        $logo = new Form\Element\Text('logo', NULL, NULL, _t('站点 LOGO'), _t('填写图片地址，留空则显示管理员头像'));
        $logo->input->setAttribute('id', 'yxlogo');
        $form->addInput($logo);

        $bg = new Form\Element\Text('bg', NULL, NULL, _t('侧栏背景图'), _t('仅电脑端生效，移动端不显示'));
        $bg->input->setAttribute('id', 'yxbg');
        $form->addInput($bg);

        $bglj = new Form\Element\Radio('bglj', array('0' => _t('关闭'), '1' => _t('开启')), '0', _t('背景图毛玻璃'), _t('侧栏有背景图时叠加磨砂效果'));
        $bglj->setAttribute('id', 'yxbglj');
        $form->addInput($bglj);

        $loginstyle = new Form\Element\Radio('loginstyle', array('0' => _t('关闭'), '1' => _t('开启')), '0', _t('美化登录/注册页'), _t('开启后重做 Typecho 登录与注册页面，并支持日夜模式'));
        $form->addInput($loginstyle);

        $dlbg = new Form\Element\Text('dlbg', NULL, NULL, _t('登录页背景图'), _t('留空使用内置纯色背景，需开启上方的美化功能'));
        $dlbg->input->setAttribute('id', 'yxdlbg');
        $form->addInput($dlbg);

        $weather = new Form\Element\Radio('weather', array('1' => _t('显示'), '0' => _t('隐藏')), '1', _t('顶栏天气'), _t('在后台顶栏显示实时天气与城市，数据来自 open-meteo 与 ipapi.co，结果缓存 30 分钟，取不到时自动隐藏'));
        $form->addInput($weather);

        $weatherCity = new Form\Element\Text('weatherCity', NULL, NULL, _t('天气城市'), _t('填写城市名（如 杭州）固定定位；留空则按服务器 IP 自动定位'));
        $weatherCity->input->setAttribute('id', 'yxWeatherCity');
        $form->addInput($weatherCity);

        $amapKey = new Form\Element\Text('amapKey', NULL, NULL, _t('高德地图 Key'), _t('用于「交通情况」卡的实时路况（交通态势 API）。留空则卡片提示未配置，不会报错。密钥仅服务端使用，不会暴露到前端。'));
        $amapKey->input->setAttribute('id', 'yxAmapKey');
        $form->addInput($amapKey);

        $loginTime = new Form\Element\Radio('loginTime', array('1' => _t('显示'), '0' => _t('隐藏')), '1', _t('登录时长'), _t('在顶栏显示本次管理员登录已经持续的时长'));
        $form->addInput($loginTime);

        $animation = new Form\Element\Radio('animation', array(
            '0' => _t('无动画'),
            'fade' => _t('淡入'),
            'slideup' => _t('上滑'),
            'pop' => _t('放大')
        ), '0', _t('页面切换动画'), _t('需要浏览器支持 View Transitions，Chrome 111+ / Safari 18+'));
        $form->addInput($animation);

        $urlfilter = new Form\Element\Radio('urlfilter', array(
            '0' => _t('不处理'),
            '1' => _t('隐藏评论网址'),
            '2' => _t('隐藏 15 天前'),
            '3' => _t('隐藏 30 天前'),
            '5' => _t('隐藏 60 天前')
        ), '0', _t('评论网址管控'), _t('久远的评论网址可能失效或已被用于违规站点，可将其隐藏'));
        $form->addInput($urlfilter);

        $gravatars = new Form\Element\Select('gravatars', array(
            'weavatar.com/avatar'       => _t('weavatar [建议]'),
            'cn.cravatar.com/avatar'     => _t('Cravatar [推荐]'),
            'cdn.v2ex.com/gravatar'      => _t('v2ex [建议]'),
            'cdn.helingqi.com/avatar'    => _t('禾令奇 [建议]'),
            'www.gravatar.com/avatar'    => _t('Gravatar www 源'),
            'cn.gravatar.com/avatar'     => _t('Gravatar cn 源'),
            'secure.gravatar.com/avatar' => _t('Gravatar secure 源'),
            'sdn.geekzu.org/avatar'      => _t('极客族'),
            'gravatar.loli.net/avatar'   => _t('loli.net 源')
        ), 'weavatar.com/avatar', _t('邮箱头像源'), _t('用于评论列表与用户头像'));
        $form->addInput($gravatars);

        $updateNotice = new Form\Element\Radio('updateNotice', array('0' => _t('不屏蔽'), '1' => _t('屏蔽')), '0', _t('屏蔽 Typecho 更新提醒'));
        $form->addInput($updateNotice);

        $speed = new Form\Element\Radio('speed', array(
            '0' => _t('不加速'),
            '1' => _t('加速'),
            '2' => _t('超级加速')
        ), '0', _t('后台加速'), _t('预加载后台页面以加快切换。超级加速更耗服务器资源，当前浏览器支持情况：<span id="YxTip"></span>'));
        $form->addInput($speed);

        $logPath = new Form\Element\Text('log_path', NULL, NULL, _t('访问日志路径'), _t('Web 服务器访问日志的绝对路径，如 /var/log/nginx/access.log。留空则自动探测常见位置。用于「采集」访客与蜘蛛数据（实实在在的访问记录）。'));
        $logPath->input->setAttribute('id', 'yxlogpath');
        $form->addInput($logPath);

        $collectDays = new Form\Element\Text('collect_days', NULL, '30', _t('采集天数'), _t('从访问日志回填最近多少天的数据（默认 30，建议 ≥7 以覆盖近 7 天面板）。'));
        $collectDays->input->setAttribute('type', 'number');
        $collectDays->input->setAttribute('id', 'yxcollectdays');
        $form->addInput($collectDays);

        $collectOnLoad = new Form\Element\Radio('collect_on_load', array('1' => _t('开启'), '0' => _t('关闭')), '1', _t('打开工作台自动采集'), _t('进入工作台时自动从访问日志回填访问数据（每 30 分钟最多一次，避免重复解析大日志）。'));
        $collectOnLoad->setAttribute('id', 'yxcollectonload');
        $form->addInput($collectOnLoad);
    }

    public static function personalConfig(Form $form)
    {

    }

    private static $yxConfCache = null;

    public static function conf()
    {
        try {
            $opts = Options::alloc();
            $cfg = $opts->plugin('YunxiAdmin');

            if ($cfg instanceof Config && $cfg->isEmpty()) {
                self::ensureConfig();
                return self::yxConfFallback();
            }
            return $cfg;
        } catch (\Throwable $e) {
            self::ensureConfig();
            return self::yxConfFallback();
        }
    }

    private static function yxConfFallback(): Config
    {
        if (!(self::$yxConfCache instanceof Config)) {
            self::$yxConfCache = new Config(self::defaults());
        }
        return self::$yxConfCache;
    }

    public static function defaults(): array
    {
        return array(
            'theme' => 'system',
            'accent' => '#0f6f68',
            'presets' => null,
            'logo' => null,
            'bg' => null,
            'bglj' => '0',
            'loginstyle' => '0',
            'dlbg' => null,
            'weather' => '1',
            'weatherCity' => null,
            'amapKey' => null,
            'loginTime' => '1',
            'animation' => '0',
            'urlfilter' => '0',
            'gravatars' => 'weavatar.com/avatar',
            'updateNotice' => '0',
            'speed' => '0',
            'log_path' => null,
            'collect_days' => '30',
            'collect_on_load' => '1',
        );
    }

    public static function ensureConfig()
    {
        try {
            $db = \Typecho\Db::get();
            $name = 'plugin:YunxiAdmin';
            $rows = $db->query($db->select('name', 'value', 'user')->from('table.options')->where('name = ?', $name))->fetchAll();
            if (empty($rows)) {
                $db->query($db->insert('table.options')->rows(array(
                    'name' => $name,
                    'value' => serialize(self::defaults()),
                    'user' => 0,
                )));
                return true;
            }

            $changed = false;
            foreach ($rows as $row) {
                if ((int) $row['user'] !== 0) {
                    continue;
                }
                $raw = isset($row['value']) ? (string) $row['value'] : '';
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {

                    $db->query($db->update('table.options')
                        ->rows(array('value' => serialize($decoded)))
                        ->where('name = ?', $name)
                        ->where('user = ?', 0));
                    $changed = true;
                    continue;
                }
                $ok = @unserialize($raw);
                if ($ok === false && trim($raw) !== serialize(false)) {
                    $db->query($db->update('table.options')
                        ->rows(array('value' => serialize(self::defaults())))
                        ->where('name = ?', $name)
                        ->where('user = ?', 0));
                    $changed = true;
                }
            }
            return $changed;
        } catch (\Throwable $e) {
            return false;
        }
    }

    public static function timeHm($text)
    {
        $text = (string) $text;
        return strlen($text) >= 16 ? substr($text, 11, 5) : ($text !== '' ? $text : '—');
    }

    private static function isMysql($db)
    {
        try {
            return stripos((string) $db->getAdapterName(), 'mysql') !== false;
        } catch (\Throwable $e) {
            return false;
        }
    }

    private static function charsetUtf8mb4()
    {
        if (self::$charsetDone) {
            return;
        }
        self::$charsetDone = true;
        try {
            $db = \Typecho\Db::get();
            if (self::isMysql($db)) {
                $db->query('SET NAMES utf8mb4');
            }
        } catch (\Throwable $e) {
        }
    }

    private static function ensureUtf8mb4()
    {
        $flag = '';
        try {
            $flag = sys_get_temp_dir() . '/yx-utf8mb4-' . md5((string) \Widget\Options::alloc()->siteUrl);
            if (is_file($flag) && time() - (int) @filemtime($flag) < 86400) {
                return;
            }
        } catch (\Throwable $e) {
        }

        try {
            $db = \Typecho\Db::get();
            if (!self::isMysql($db)) {
                return;
            }

            self::charsetUtf8mb4();
            $prefix = $db->getPrefix();

            $col = $db->fetchRow($db->query("SHOW FULL COLUMNS FROM `{$prefix}options` LIKE 'value'"));
            if (is_array($col)) {
                $type = strtolower((string) (isset($col['Type']) ? $col['Type'] : (isset($col['type']) ? $col['type'] : '')));
                if ($type === '' || strpos($type, 'longtext') === false) {
                    try {
                        $db->query("ALTER TABLE `{$prefix}options` MODIFY `value` LONGTEXT", \Typecho\Db::WRITE);
                    } catch (\Throwable $e) {
                    }
                }
            }

            $rows = $db->fetchAll($db->query('SHOW TABLE STATUS'));
            $tables = array();
            if (is_array($rows)) {
                foreach ($rows as $row) {
                    $name = (string) (isset($row['Name']) ? $row['Name'] : (isset($row['name']) ? $row['name'] : ''));
                    if ($name === '' || strpos($name, $prefix) !== 0) {
                        continue;
                    }
                    $coll = strtolower((string) (isset($row['Collation']) ? $row['Collation'] : (isset($row['collation']) ? $row['collation'] : '')));
                    $tables[$name] = $coll;
                }
            }

            foreach ($tables as $name => $coll) {
                if ($coll === '' || strpos($coll, 'utf8mb4') === 0) {
                    continue;
                }
                try {
                    $db->query("ALTER TABLE `{$name}` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci", \Typecho\Db::WRITE);
                } catch (\Throwable $e) {
                }
            }
        } catch (\Throwable $e) {
        }

        if ($flag !== '') {
            @touch($flag);
        }
    }

    public static function beginRequest()
    {
        self::charsetUtf8mb4();
    }

    public static function emojiAssets()
    {
        try {
            $options = \Widget\Options::alloc();
            $themeDir = rtrim((string) __TYPECHO_ROOT_DIR__, '/') . '/usr/themes/' . (string) $options->theme;
            if (!is_dir($themeDir . '/static/img/emoji')) {
                return array();
            }

            $out = array(
                'base' => rtrim((string) $options->themeUrl, '/') . '/static/img/emoji/',
                'wx'   => array()
            );

            $js = @file_get_contents($themeDir . '/static/pc/js/emoji.js');
            if (is_string($js) && preg_match('/var\s+WX_NAMES\s*=\s*\[(.*?)\]\s*;/s', $js, $m)
                && preg_match_all("/'([^']*)'/", $m[1], $mm)) {
                foreach ($mm[1] as $i => $name) {
                    $out['wx'][$name] = (string) $i;
                }
            }

            return $out;
        } catch (\Throwable $e) {
            return array();
        }
    }

    private static function emojiSrc($name, $base)
    {
        if ($base === '') {
            return '';
        }
        if (strpos($name, 'a_') === 0) {
            return $base . 'pack/a/' . $name . '.webp';
        }
        if (strpos($name, 'bilibili_') === 0) {
            return $base . 'pack/bilibili/' . $name . '.webp';
        }
        if (strpos($name, 'blobcat') === 0) {
            return $base . 'pack/blobcat/' . $name . '.webp';
        }
        if (strpos($name, 'wb_') === 0) {
            return $base . 'weibo/' . $name . '.webp';
        }
        if (strpos($name, 'tb_') === 0) {
            return $base . 'tieba/' . $name . '.webp';
        }
        if (strpos($name, 'ca_') === 0) {
            return $base . 'coolapk/' . $name . '.webp';
        }
        $i = strpos($name, '_');
        if ($i !== false && $i > 0) {
            return $base . substr($name, 0, $i) . '/' . $name . '.svg';
        }
        return $base . $name . '.svg';
    }

    private static function emojiImg($label, $src)
    {
        $label = htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
        return '<img class="yx-emoji" src="' . htmlspecialchars($src, ENT_QUOTES, 'UTF-8')
            . '" alt="' . $label . '" title="' . $label . '" loading="lazy">';
    }

    public static function emojiPreview($text, $max = 28)
    {
        $assets = self::emojiAssets();
        $text = trim(preg_replace('/\s+/u', ' ', strip_tags((string) $text)));
        if (!$assets) {
            return htmlspecialchars(mb_substr($text, 0, $max), ENT_QUOTES, 'UTF-8');
        }

        $base = $assets['base'];
        $wx = isset($assets['wx']) ? $assets['wx'] : array();
        $max = max(1, (int) $max);
        $parts = preg_split('/(\[emoji:[A-Za-z0-9_]+\]|\[[^\[\]\n]{1,10}\])/u', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
        $out = '';
        $used = 0;

        foreach ((array) $parts as $p) {
            if ($p === '' || $p === null) {
                continue;
            }
            if ($used >= $max) {
                $out .= '…';
                break;
            }
            if (preg_match('/^\[emoji:([A-Za-z0-9_]+)\]$/', $p, $m)) {
                $out .= self::emojiImg('[' . $m[1] . ']', self::emojiSrc($m[1], $base));
                $used++;
                continue;
            }
            if (preg_match('/^\[([^\[\]\n]{1,10})\]$/u', $p, $m) && isset($wx[$m[1]])) {
                $out .= self::emojiImg($p, $base . 'wx/' . $wx[$m[1]] . '.webp');
                $used++;
                continue;
            }
            $len = mb_strlen($p);
            $take = min($len, $max - $used);
            $out .= htmlspecialchars(mb_substr($p, 0, $take), ENT_QUOTES, 'UTF-8');
            $used += $take;
            if ($take < $len) {
                $out .= '…';
                break;
            }
        }

        return $out;
    }

    public static function render($header)
    {
        self::charsetUtf8mb4();
        self::ensureUtf8mb4();

        if (!defined('YX_VERSION')) {
            define('YX_VERSION', self::VERSION);
        }

        \Widget\Options::alloc()->to($options);
        \Widget\User::alloc()->to($user);
        \Widget\Menu::alloc()->to($menu);

        $curMenu = $menu->getCurrentMenu();
        if ($user->hasLogin() && !defined('YX_DASH') && $curMenu && strpos((string) $curMenu[2], 'index.php') !== false) {
            if (self::isMobile()) {
                require __DIR__ . '/dashboard-mobile.php';
            } else {
                require __DIR__ . '/dashboard.php';
            }
            exit;
        }

        $plugin = self::conf();
        $url = Helper::options()->pluginUrl . '/YunxiAdmin/assets/';
        $ver = self::VERSION;
        $script = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));

        if (!defined('__TYPECHO_GRAVATAR_PREFIX__')) {
            define('__TYPECHO_GRAVATAR_PREFIX__', '//' . self::gravatarHost($plugin->gravatars) . '/');
        }

        if (!User::alloc()->hasLogin()) {
            return self::renderLogin($header, $url, $ver, $plugin);
        }

        $theme = $plugin->theme ?: 'system';
        if (!in_array($theme, array('light', 'dark', 'system'), true)) {
            $theme = 'system';
        }
        $accent = self::sanitizeColor($plugin->accent, '#0f6f68');
        $isSetting = $script === 'options-plugin.php' && strpos((string) ($_SERVER['REQUEST_URI'] ?? ''), 'config=YunxiAdmin') !== false;
        $isProfile = $script === 'profile.php';
        $isUsers = $script === 'manage-users.php';
        $isMedia = $script === 'manage-medias.php';
        $isEditor = $script === 'write-post.php' || $script === 'write-page.php';

        $html = '<meta name="format-detection" content="telephone=no">'
            . '<meta name="theme-color" media="(prefers-color-scheme: light)" content="#f3f4f6">'
            . '<meta name="theme-color" media="(prefers-color-scheme: dark)" content="#0b0c0e">'
            . '<script>(function(){try{var s=null;try{s=localStorage.getItem("yx-theme");}catch(e){}var m=(s==="light"||s==="dark")?s:"' . $theme . '";var d=m==="system"?(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"):m;document.documentElement.setAttribute("data-theme",d);document.documentElement.setAttribute("data-theme-mode",m);}catch(e){}})();</script>'
            . '<style>:root{--yx-accent:' . $accent . ';--yx-accent-h:' . $accent . ';--yx-accent-soft:' . $accent . '1f;--yx-accent-line:' . $accent . '66;--yx-focus:' . $accent . '2e;}</style>'
            . '<link rel="preconnect" href="https://api.open-meteo.com">'
            . '<link rel="preconnect" href="https://ip-api.com">'
            . '<link rel="preconnect" href="https://www.nmc.cn">'
            . '<link rel="preconnect" href="//' . htmlspecialchars(self::gravatarHost($plugin->gravatars)) . '">'
            . '<script>' . self::nativeKillJs()
            . 'var k=window.YXKillNative,b=function(){try{k();}catch(e){}};'
            . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",b);}else{b();}'
            . 'window.addEventListener("load",b);setTimeout(b,800);</script>';

        if ($plugin->animation && $plugin->animation !== '0') {
            $anim = $plugin->animation;
            $kf = 'from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}';
            if ($anim === 'slideup') {
                $kf = 'from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}';
            } elseif ($anim === 'pop') {
                $kf = 'from{opacity:0;transform:scale(.985)}to{opacity:1;transform:none}';
            }
            $html .= '<style>@keyframes yx-in{' . $kf . '}html{animation:yx-in .28s var(--yx-ease)}</style>';
        }

        $isMobile = self::isMobile();
        $html .= '<link rel="stylesheet" href="' . $url . 'css/tokens.css?v=' . $ver . '">';
        if ($isMobile) {
            $html .= '<link rel="stylesheet" href="' . $url . 'css/shell-mobile.css?v=' . $ver . '.'
                . (int) @filemtime(__DIR__ . '/assets/css/shell-mobile.css') . '">';
        } else {
            $html .= '<link rel="stylesheet" href="' . $url . 'css/shell.css?v=' . $ver . '">';
        }
        $html .= '<link rel="stylesheet" href="' . $url . 'css/page.css?v=' . $ver . '">';

        if (defined('YX_DASH')) {
            if ($isMobile) {
                $html .= '<link rel="stylesheet" href="' . $url . 'css/dashboard-mobile.css?v=' . $ver . '">';

                $html .= '<link rel="stylesheet" href="' . $url . 'css/weather-mobile.css?v=' . $ver . '.' . (int) @filemtime(__DIR__ . '/assets/css/weather-mobile.css') . '">';
            } else {
                $html .= '<link rel="stylesheet" href="' . $url . 'css/dashboard.css?v=' . $ver . '">';

                $html .= '<link rel="stylesheet" href="' . $url . 'css/weather-desktop.css?v=' . $ver . '.' . (int) @filemtime(__DIR__ . '/assets/css/weather-desktop.css') . '">';
            }
            $html .= '<link rel="stylesheet" href="' . $url . 'css/ui-apple.css?v=' . $ver . '">';
        }

        if ($isEditor) {
            $html .= '<link rel="stylesheet" href="' . $url . 'css/editor.css?v=' . $ver . '">';
        }

        if ($isUsers) {
            try {
                $usersDel = \Widget\Security::alloc()->getIndex('/action/users-edit?do=delete');
                $html .= '<script>window.YX_USERS_DEL=' . json_encode($usersDel, JSON_UNESCAPED_UNICODE) . ';</script>';
            } catch (\Exception $e) {
            }
        }

        return $header . $html . '<style id="yx-native-reset">'
            . '.typecho-head-nav,.operate{background:transparent!important;border:0!important;box-shadow:none!important;position:static!important;display:block!important;float:none!important;width:auto!important;height:auto!important;min-height:0!important;padding:0!important;margin:0!important;overflow:visible!important;z-index:auto!important}'
            . '.menu-bar,#typecho-nav-list,.typecho-head-nav .operate>*:not(.yx-shell):not(.yx-drawer):not(.yx-scrim),.typecho-head-nav>*:not(.operate):not(.yx-shell):not(.yx-drawer):not(.yx-scrim),a.author,a.exit{display:none!important;visibility:hidden!important;width:0!important;height:0!important;overflow:hidden!important}'
            . '.yx-main>.yx-wrap>a:not([class]),.yx-main>.yx-wrap>a.author,.yx-main>.yx-wrap>a.exit{display:none!important;visibility:hidden!important;width:0!important;height:0!important;overflow:hidden!important}'
            . '</style>';
    }

    private static function renderLogin($header, $url, $ver, $plugin)
    {
        $html = '<meta name="format-detection" content="telephone=no">'
            . '<meta name="theme-color" media="(prefers-color-scheme: light)" content="#f3f4f6">'
            . '<meta name="theme-color" media="(prefers-color-scheme: dark)" content="#0b0c0e">'
            . '<script>(function(){try{var s=null;try{s=localStorage.getItem("yx-theme");}catch(e){}var m=(s==="light"||s==="dark")?s:"system";var d=m==="system"?(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"):m;document.documentElement.setAttribute("data-theme",d);document.documentElement.setAttribute("data-theme-mode",m);}catch(e){}})();</script>';

        if (!$plugin->loginstyle) {
            return $header . $html;
        }

        $accent = self::sanitizeColor($plugin->accent, '#0f6f68');
        $html .= '<style>:root{--yx-accent:' . $accent . ';--yx-accent-h:' . $accent . ';--yx-accent-soft:' . $accent . '1f;--yx-accent-line:' . $accent . '66;--yx-focus:' . $accent . '2e;}</style>';

        $html .= '<link rel="stylesheet" href="' . $url . 'css/tokens.css?v=' . $ver . '">'
            . '<link rel="stylesheet" href="' . $url . 'css/shell.css?v=' . $ver . '">'
            . '<link rel="stylesheet" href="' . $url . 'css/login.css?v=' . $ver . '">';

        $html .= '<script>(function(){function f(){try{document.body.classList.add("yx-login");}catch(e){}}'
            . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",f);}else{f();}})();</script>';

        if ($plugin->dlbg) {

            $dlbgSafe = self::safeCssUrl($plugin->dlbg);
            if ($dlbgSafe !== '') {
                $html .= '<style>body.yx-login{background-image:url("' . $dlbgSafe . '")}</style>';
            }
        }

        return $html . $header;
    }

    private static function safeCssUrl($u)
    {
        $u = trim((string) $u);
        if ($u === '') {
            return '';
        }

        $ok = preg_match('#^https?://[^\s"\'<>\\\\]+$#i', $u)
            || preg_match('#^/[^\s"\'<>\\\\]*$#', $u);
        if (!$ok) {
            return '';
        }

        $u = str_replace(
            array('\\', '"', "'", '(', ')', ';', '{', '}', '/*', '*/', "\r", "\n"),
            array('\\\\', '%22', '%27', '%28', '%29', '%3B', '%7B', '%7D', '', '', '', ''),
            $u
        );
        return $u;
    }

    private static function nativeKillJs()
    {
        return 'window.YXKillNative=function(){'
            . 'try{'
            . 'var body=document.body;if(!body){return;}'
            . 'var rm=function(n){if(n&&n.parentNode){try{n.parentNode.removeChild(n);}catch(e){}}};'
            . 'var isOurs=function(el){if(!el||el.nodeType!==1){return false;}'
            . 'if(el.classList&&(el.classList.contains("yx-shell")||el.classList.contains("yx-drawer")||el.classList.contains("yx-scrim"))){return true;}'
            . 'return String(el.className||"").indexOf("yx-")===0;};'
            . 'var isNativeLink=function(el){return el.nodeType===1&&el.tagName==="A"&&(!el.className||/(^|\s)(author|exit)(\s|$)/.test(el.className));};'
            . '["yx-shell","yx-drawer","yx-scrim"].forEach(function(c){Array.prototype.slice.call(document.getElementsByClassName(c)).forEach(function(el){if(el.parentNode!==body){body.appendChild(el);}});});'
            . 'Array.prototype.slice.call(document.querySelectorAll(".menu-bar,#typecho-nav-list,a.author,a.exit")).forEach(rm);'
            . 'Array.prototype.slice.call(document.querySelectorAll(".typecho-head-nav .operate,.menu-bar .operate")).forEach(function(op){'
            . 'if(op.closest&&op.closest(".typecho-list-operate")){return;}'
            . 'Array.prototype.slice.call(op.childNodes).forEach(function(c){if(c.nodeType===1&&isOurs(c)){return;}rm(c);});rm(op);});'
            . 'Array.prototype.slice.call(document.querySelectorAll(".typecho-head-nav")).forEach(function(h){if(!h.querySelector(".yx-shell,.yx-drawer,.yx-scrim")){rm(h);}});'
            . 'var wrap=document.querySelector(".yx-main>.yx-wrap")||document.querySelector(".yx-wrap");'
            . 'if(wrap){var n=wrap.firstChild,g=0;while(n&&g<400){g++;var nx=n.nextSibling,kill=false;'
            . 'if(isNativeLink(n)){kill=true;}else if(n.nodeType===3&&/^\s*https?:\/\/\S+\s*$/i.test(n.nodeValue||"")){kill=true;}'
            . 'if(kill){rm(n);}n=nx;}}'
            . '["yx-dhead","yx-dfoot","yx-dbody","yx-pop","yx-topbar","yx-mtop","yx-rail-head"].forEach(function(c){Array.prototype.slice.call(document.getElementsByClassName(c)).forEach(function(root){'
            . 'var w=document.createTreeWalker(root,4),t,hits=[];'
            . 'while((t=w.nextNode())){if(/^\s*https?:\/\/\S+\s*$/i.test(t.nodeValue||"")){hits.push(t);}}hits.forEach(rm);});});'
            . 'var w2=document.createTreeWalker(body,4),t2,hits2=[];'
            . 'while((t2=w2.nextNode())){var p=t2.parentNode;if(!p){continue;}'
            . 'if(/^(SCRIPT|STYLE|TITLE|TEXTAREA|OPTION|A|TEMPLATE|NOSCRIPT)$/.test(p.nodeName)){continue;}'
            . 'if(/^\s*https?:\/\/\S+\s*$/i.test(t2.nodeValue||"")){hits2.push(t2);}}hits2.forEach(rm);'
            . 'var s=document.querySelector(".operate>.yx-shell")||document.querySelector(".yx-shell");'
            . 'if(s){s.style.setProperty("visibility","visible","important");}'
            . '}catch(e){}};'
            . 'if(!window.__yxKillObs&&window.MutationObserver){try{'
            . 'var started=Date.now(),queued=false;'
            . 'window.__yxKillObs=new MutationObserver(function(ms){'
            . 'if(queued){return;}'
            . 'if(Date.now()-started>20000){try{this.disconnect();}catch(e){}return;}'
            . 'var rel=false;for(var i=0;i<ms.length;i++){if(ms[i].addedNodes&&ms[i].addedNodes.length){rel=true;break;}}'
            . 'if(!rel){return;}queued=true;'
            . 'setTimeout(function(){queued=false;try{window.YXKillNative();}catch(e){}},60);});'
            . 'window.__yxKillObs.observe(document.documentElement,{childList:true,subtree:true});'
            . '}catch(e){}}';
    }

    private static function weatherScope()
    {
        $end = self::isMobile() ? 'mobile' : 'desktop';
        $uid = 0;
        try {
            $uid = (int) \Widget\User::alloc()->uid;
        } catch (\Throwable $e) {
        }
        return $end . '-' . $uid;
    }

    private static function weatherCacheFile($city)
    {
        return sys_get_temp_dir() . '/yx-weather-' . self::weatherScope() . '-'
            . md5(trim((string) $city) === '' ? 'auto' : trim((string) $city)) . '.json';
    }

    public static function weather()
    {
        if (self::$weatherCache !== null) {
            return self::$weatherCache;
        }

        $plugin = self::conf();
        if (isset($plugin->weather) && !$plugin->weather) {
            self::$weatherCache = array();
            return self::$weatherCache;
        }

        $city = isset($plugin->weatherCity) ? trim((string) $plugin->weatherCity) : '';
        $cacheFile = self::weatherCacheFile($city);

        if (is_file($cacheFile) && (time() - (int) filemtime($cacheFile)) < 1800) {
            $cached = json_decode((string) @file_get_contents($cacheFile), true);
            if (is_array($cached) && !empty($cached['city'])) {
                self::$weatherCache = $cached;
                return $cached;
            }
        }

        $lat = null;
        $lon = null;
        $cityLabel = $city;
        $regionLabel = '';
        if ($city !== '') {
            $geo = self::geocode($city);
            if (!empty($geo['ok'])) {
                $lat = $geo['lat'];
                $lon = $geo['lon'];
                $cityLabel = $geo['city'] !== '' ? $geo['city'] : $city;
                $regionLabel = $geo['region'];
            }
        } else {
            $loc = self::locate();
            if (!empty($loc['ok'])) {
                $lat = $loc['lat'];
                $lon = $loc['lon'];
                $cityLabel = $loc['city'] !== '' ? $loc['city'] : $loc['region'];
                $regionLabel = $loc['region'];
            }
        }

        if ($lat === null || $lon === null) {
            self::$weatherCache = array();
            return self::$weatherCache;
        }

        $keep = self::buildWeatherData($lat, $lon, $cityLabel, $regionLabel);
        if (empty($keep['city'])) {
            self::$weatherCache = array();
            return self::$weatherCache;
        }

        @file_put_contents($cacheFile, json_encode($keep, JSON_UNESCAPED_UNICODE));

        self::$weatherCache = $keep;
        return $keep;
    }

    public static function weatherCached()
    {
        $plugin = self::conf();
        if (isset($plugin->weather) && !$plugin->weather) {
            return array();
        }
        $city = isset($plugin->weatherCity) ? trim((string) $plugin->weatherCity) : '';

        $files = array(self::weatherCacheFile($city));
        foreach ($files as $f) {
            if (is_file($f)) {
                $cached = json_decode((string) @file_get_contents($f), true);
                if (is_array($cached) && !empty($cached['city'])) {
                    return $cached;
                }
            }
        }
        return array();
    }

    public static function weatherByCity($city)
    {
        $city = trim((string) $city);
        if ($city === '') {
            return self::weather();
        }
        $cacheFile = self::weatherCacheFile($city);
        if (is_file($cacheFile) && (time() - (int) filemtime($cacheFile)) < 1800) {
            $cached = json_decode((string) @file_get_contents($cacheFile), true);
            if (is_array($cached) && !empty($cached['city'])) {
                return $cached;
            }
        }
        $geo = self::geocode($city);
        if (empty($geo['ok'])) {
            return array();
        }
        $keep = self::buildWeatherData($geo['lat'], $geo['lon'], $geo['city'] !== '' ? $geo['city'] : $city, $geo['region']);
        if (!empty($keep['city'])) {
            @file_put_contents($cacheFile, json_encode($keep, JSON_UNESCAPED_UNICODE));
        }
        return $keep;
    }

    private static function fetchJson($url, $timeout = 5)
    {
        $raw = self::fetchUrl($url, $timeout);
        if ($raw === '') {
            return null;
        }
        $d = json_decode($raw, true);
        return is_array($d) ? $d : null;
    }

    private static function ipIsPrivate($ip)
    {
        if ($ip === '' || $ip === 'unknown' || $ip === '::1') {
            return true;
        }
        if (strpos($ip, ':') !== false) {
            return true;
        }
        $long = ip2long($ip);
        if ($long === false) {
            return true;
        }
        $private = array(
            array('10.0.0.0', '10.255.255.255'),
            array('127.0.0.0', '127.255.255.255'),
            array('169.254.0.0', '169.254.255.255'),
            array('172.16.0.0', '172.31.255.255'),
            array('192.168.0.0', '192.168.255.255'),
            array('0.0.0.0', '0.255.255.255')
        );
        foreach ($private as $r) {
            if ($long >= ip2long($r[0]) && $long <= ip2long($r[1])) {
                return true;
            }
        }
        return false;
    }

    private static function locateFull($ip, $fast = false)
    {
        $base = array(
            'ip' => $ip, 'ok' => false, 'country' => '', 'province' => '', 'city' => '',
            'district' => '', 'isp' => '', 'org' => '', 'lat' => null, 'lon' => null,
            'timezone' => '', 'source' => ''
        );
        if (self::ipIsPrivate($ip)) {
            $base['country'] = '内网';
            $base['province'] = '局域网';
            $base['city'] = '本地地址';
            $base['isp'] = '内网保留地址';
            return $base;
        }

        $cacheFile = sys_get_temp_dir() . '/yx-ip-' . md5($ip) . '.json';
        if (is_file($cacheFile) && (time() - (int) filemtime($cacheFile)) < 86400 * 7) {
            $cached = json_decode((string) @file_get_contents($cacheFile), true);
            if (is_array($cached) && isset($cached['ip'])) {
                return $cached;
            }
        }

        $timeout = $fast ? 2.5 : 4;
        $d = self::fetchJson('http://ip-api.com/json/' . rawurlencode($ip)
            . '?fields=status,message,country,regionName,city,district,lat,lon,isp,org,timezone,query&lang=zh-CN', $timeout);
        if (is_array($d) && !empty($d['status']) && $d['status'] === 'success') {
            $base['ok'] = true;
            $base['source'] = 'ip-api.com';
            $base['country'] = (string) ($d['country'] ?? '');
            $base['province'] = (string) ($d['regionName'] ?? '');
            $base['city'] = (string) ($d['city'] ?? '');
            $base['district'] = (string) ($d['district'] ?? '');
            $base['isp'] = (string) ($d['isp'] ?? '');
            $base['org'] = (string) ($d['org'] ?? '');
            $base['timezone'] = (string) ($d['timezone'] ?? '');
            if (isset($d['lat'])) {
                $base['lat'] = (float) $d['lat'];
            }
            if (isset($d['lon'])) {
                $base['lon'] = (float) $d['lon'];
            }
            @file_put_contents($cacheFile, json_encode($base, JSON_UNESCAPED_UNICODE));
            return $base;
        }

        if (!$fast) {
            $d = self::fetchJson('https://ipwho.is/' . rawurlencode($ip) . '?lang=zh-CN', 2.5);
            if (is_array($d) && !empty($d['success'])) {
                $base['ok'] = true;
                $base['source'] = 'ipwho.is';
                $base['country'] = (string) ($d['country'] ?? '');
                $base['province'] = (string) ($d['region'] ?? '');
                $base['city'] = (string) ($d['city'] ?? '');
                $base['isp'] = (string) ($d['connection']['isp'] ?? '');
                $base['org'] = (string) ($d['connection']['org'] ?? '');
                $base['timezone'] = (string) ($d['timezone']['id'] ?? '');
                if (isset($d['latitude'])) {
                    $base['lat'] = (float) $d['latitude'];
                }
                if (isset($d['longitude'])) {
                    $base['lon'] = (float) $d['longitude'];
                }
                @file_put_contents($cacheFile, json_encode($base, JSON_UNESCAPED_UNICODE));
                return $base;
            }
        }

        return $base;
    }

    private static function placeText($loc)
    {
        if (empty($loc['ok'])) {
            return $loc['country'] !== '' ? $loc['country'] : '未知位置';
        }
        $parts = array();
        foreach (array('country', 'province', 'city', 'district') as $k) {
            $v = (string) ($loc[$k] ?? '');
            if ($v === '') {
                continue;
            }
            $dup = false;
            foreach ($parts as $p) {
                if ($p === $v || mb_strpos($p, $v) !== false) {
                    $dup = true;
                    break;
                }
            }
            if (!$dup) {
                $parts[] = $v;
            }
        }
        return implode(' · ', array_slice($parts, 0, 3));
    }

    private static function distanceKm($aLat, $aLon, $bLat, $bLon)
    {
        if ($aLat === null || $bLat === null) {
            return null;
        }
        $r = 6371.0;
        $dLat = deg2rad($bLat - $aLat);
        $dLon = deg2rad($bLon - $aLon);
        $a = sin($dLat / 2) * sin($dLat / 2)
            + cos(deg2rad($aLat)) * cos(deg2rad($bLat)) * sin($dLon / 2) * sin($dLon / 2);
        return round(2 * $r * asin(min(1, sqrt($a))));
    }

    public static function geoInfo()
    {
        $ip = self::clientIp();

        $cacheFile = sys_get_temp_dir() . '/yx-geo-' . md5($ip) . '.json';
        if (is_file($cacheFile) && (time() - (int) filemtime($cacheFile)) < 60) {
            $cached = json_decode((string) @file_get_contents($cacheFile), true);
            if (is_array($cached) && !empty($cached['status'])) {
                return $cached;
            }
        }

        $deadline = microtime(true) + 3.5;

        $db = \Typecho\Db::get();
        $visitor = self::locateFull($ip);

        $serverIp = '';
        if (!empty($_SERVER['SERVER_ADDR']) && !self::ipIsPrivate($_SERVER['SERVER_ADDR'])) {
            $serverIp = (string) $_SERVER['SERVER_ADDR'];
        }
        $server = array('ip' => $serverIp, 'ok' => false,
            'place' => $serverIp === '' ? '未获取到公网地址' : '与本机同源',
            'city' => '', 'province' => '', 'isp' => '', 'lat' => null, 'lon' => null);
        if ($serverIp !== '' && $serverIp !== $ip) {
            $sl = self::locateFull($serverIp, true);
            $server = array('ip' => $serverIp, 'ok' => !empty($sl['ok']), 'place' => self::placeText($sl),
                'city' => (string) $sl['city'], 'province' => (string) $sl['province'],
                'isp' => (string) $sl['isp'], 'lat' => $sl['lat'], 'lon' => $sl['lon']);
        }

        $rows = $db->fetchAll($db->select('ip', 'author', 'created')
            ->from('table.comments')->order('created', \Typecho\Db::SORT_DESC)->limit(80));

        $agg = array();
        foreach ($rows as $r) {
            $cip = trim((string) $r['ip']);
            if (self::ipIsPrivate($cip) || !preg_match('/^\d{1,3}(\.\d{1,3}){3}$/', $cip)) {
                continue;
            }
            if (!isset($agg[$cip])) {
                $agg[$cip] = array('ip' => $cip, 'count' => 0, 'created' => (int) $r['created'], 'author' => (string) $r['author']);
            }
            $agg[$cip]['count']++;
            if ((int) $r['created'] > $agg[$cip]['created']) {
                $agg[$cip]['created'] = (int) $r['created'];
            }
            if (count($agg) >= 10) {
                break;
            }
        }

        $originLat = $visitor['lat'];
        $originLon = $visitor['lon'];
        if ($originLat === null) {
            $originLat = $server['lat'];
            $originLon = $server['lon'];
        }

        $peers = array();
        foreach ($agg as $r) {
            if (microtime(true) >= $deadline) {

                $peers[] = array(
                    'ip' => $r['ip'], 'ok' => false, 'place' => '—',
                    'province' => '', 'city' => '', 'isp' => '',
                    'distance' => null,
                    'comments' => (int) $r['count'], 'author' => $r['author'],
                    'date' => date('Y-m-d H:i', (int) $r['created'])
                );
                continue;
            }
            $loc = self::locateFull($r['ip'], true);
            $peers[] = array(
                'ip' => $r['ip'], 'ok' => !empty($loc['ok']), 'place' => self::placeText($loc),
                'province' => (string) $loc['province'], 'city' => (string) $loc['city'],
                'isp' => (string) $loc['isp'],
                'distance' => self::distanceKm($originLat, $originLon, $loc['lat'], $loc['lon']),
                'comments' => (int) $r['count'], 'author' => $r['author'],
                'date' => date('Y-m-d H:i', (int) $r['created'])
            );
        }
        usort($peers, function ($a, $b) {
            $da = $a['distance'] === null ? 1e9 : $a['distance'];
            $dbv = $b['distance'] === null ? 1e9 : $b['distance'];
            if ($da === $dbv) {
                return strcmp($b['date'], $a['date']);
            }
            return $da - $dbv;
        });

        $out = array(
            'status' => true,
            'time' => date('Y-m-d H:i:s'),
            'visitor' => array(
                'ip' => $ip, 'ok' => !empty($visitor['ok']), 'place' => self::placeText($visitor),
                'country' => (string) $visitor['country'], 'province' => (string) $visitor['province'],
                'city' => (string) $visitor['city'], 'district' => (string) $visitor['district'],
                'isp' => (string) $visitor['isp'], 'org' => (string) $visitor['org'],
                'timezone' => (string) $visitor['timezone'], 'source' => (string) $visitor['source']
            ),
            'server' => $server,
            'nearby' => self::nearbyPlaces($originLat, $originLon, (string) $visitor['city'], $deadline),
            'peers' => array_slice($peers, 0, 8)
        );
        @file_put_contents($cacheFile, json_encode($out, JSON_UNESCAPED_UNICODE));

        @file_put_contents(sys_get_temp_dir() . '/yx-region-last.json', json_encode(array(
            'province' => (string) $visitor['province'],
            'city' => (string) $visitor['city'],
            'country' => (string) $visitor['country'],
            'at' => time()
        ), JSON_UNESCAPED_UNICODE));
        return $out;
    }

    private static function normCity($city)
    {
        $c = trim((string) $city);
        if ($c === '') {
            return '';
        }
        $c = preg_replace('/\s+/u', '', $c);
        if (strpos($c, '特别行政区') !== false) {
            $c = str_replace('特别行政区', '', $c);
        }
        if (strpos($c, '自治州') !== false) {
            $c = preg_replace('/自治州.*$/u', '', $c);
        } elseif (strpos($c, '市') !== false) {

            $c = preg_replace('/市.*$/u', '', $c);
        }
        $c = preg_replace('/(省|县|区|盟|地区|行政区)$/u', '', $c);
        return (string) $c;
    }

    private static function landmarksFor($city)
    {
        $norm = self::normCity($city);
        if ($norm === '') {
            return array();
        }
        $table = self::cityLandmarks();
        if (isset($table[$norm])) {
            return $table[$norm];
        }
        foreach ($table as $k => $list) {
            if (mb_strlen($k) >= 2 && (mb_strpos($norm, $k) === 0 || mb_strpos($k, $norm) === 0)) {
                return $list;
            }
        }
        return array();
    }

    private static function cityLandmarks()
    {
        return array(
            '佛山' => array('祖庙', '岭南天地', '西樵山', '清晖园', '南海观音'),
            '北京' => array('故宫', '天安门', '天坛', '颐和园', '八达岭长城'),
            '上海' => array('外滩', '东方明珠', '南京路', '豫园', '陆家嘴'),
            '广州' => array('广州塔', '陈家祠', '沙面岛', '白云山', '珠江夜游'),
            '深圳' => array('世界之窗', '深圳湾', '莲花山', '大梅沙', '华侨城'),
            '成都' => array('宽窄巷子', '大熊猫基地', '武侯祠', '锦里', '都江堰'),
            '杭州' => array('西湖', '灵隐寺', '河坊街', '西溪湿地', '雷峰塔'),
            '西安' => array('兵马俑', '大雁塔', '钟鼓楼', '回民街', '华清池'),
            '南京' => array('夫子庙', '中山陵', '总统府', '玄武湖', '秦淮河'),
            '武汉' => array('黄鹤楼', '东湖', '武汉大学', '户部巷', '江汉路'),
            '重庆' => array('洪崖洞', '解放碑', '磁器口', '李子坝', '长江索道'),
            '苏州' => array('拙政园', '平江路', '虎丘', '金鸡湖', '寒山寺'),
            '天津' => array('天津之眼', '古文化街', '五大道', '意式风情区', '海河'),
            '青岛' => array('栈桥', '八大关', '崂山', '啤酒博物馆', '金沙滩'),
            '厦门' => array('鼓浪屿', '厦门大学', '南普陀寺', '曾厝垵', '环岛路'),
            '长沙' => array('橘子洲', '岳麓山', '太平老街', '岳麓书院', '文和友'),
            '郑州' => array('二七塔', '少林寺', '河南博物院', '只有河南', '黄河景区'),
            '济南' => array('趵突泉', '大明湖', '千佛山', '芙蓉街', '曲水亭街'),
            '福州' => array('三坊七巷', '鼓山', '烟台山', '西湖公园', '螺洲古镇'),
            '昆明' => array('滇池', '翠湖公园', '石林', '斗南花市', '东川红土地'),
            '贵阳' => array('青岩古镇', '甲秀楼', '黔灵山', '花溪公园', '天河潭'),
            '南宁' => array('青秀山', '三街两巷', '德天瀑布', '民族博物馆', '邕江'),
            '海口' => array('骑楼老街', '假日海滩', '火山公园', '骑楼小吃街', '万绿园'),
            '桂林' => array('漓江', '象鼻山', '阳朔西街', '银子岩', '两江四湖'),
            '珠海' => array('情侣路', '渔女', '圆明新园', '日月贝', '长隆海洋王国'),
            '东莞' => array('可园', '虎门销烟池', '鸦片战争博物馆', '观音山', '南社古村'),
            '中山' => array('孙中山故居', '岐江', '孙文西路', '紫马岭', '金钟水库'),
            '惠州' => array('惠州西湖', '罗浮山', '巽寮湾', '红花湖', '水东街'),
            '汕头' => array('南澳岛', '礐石风景区', '潮汕美食街', '老市区骑楼', '方特欢乐世界'),
            '潮州' => array('广济桥', '牌坊街', '韩文公祠', '开元寺', '己略黄公祠'),
            '揭阳' => array('进贤门', '双峰寺', '黄岐山', '钓台', '京明温泉'),
            '洛阳' => array('龙门石窟', '白马寺', '洛邑古城', '老君山', '应天门'),
            '开封' => array('清明上河园', '龙亭公园', '大相国寺', '铁塔', '鼓楼'),
            '敦煌' => array('莫高窟', '鸣沙山月牙泉', '玉门关', '阳关', '雅丹地质公园'),
            '大理' => array('洱海', '崇圣寺三塔', '大理古城', '喜洲古镇', '苍山'),
            '丽江' => array('丽江古城', '玉龙雪山', '束河古镇', '拉市海', '蓝月谷'),
            '黄山' => array('黄山风景区', '屯溪老街', '宏村', '西递', '徽州古城'),
            '张家界' => array('天门山', '张家界森林公园', '大峡谷玻璃桥', '黄龙洞', '凤凰古城'),
            '西宁' => array('塔尔寺', '青海湖', '东关清真大寺', '互助土族故土园', '门源油菜花'),
            '兰州' => array('黄河铁桥', '白塔山', '甘肃省博物馆', '兴隆山', '兰州老街'),
            '银川' => array('西夏王陵', '镇北堡影视城', '贺兰山岩画', '南关清真寺', '鼓楼'),
            '乌鲁木齐' => array('国际大巴扎', '天山天池', '南山牧场', '新疆博物馆', '喀纳斯'),
            '拉萨' => array('布达拉宫', '大昭寺', '八廓街', '色拉寺', '羊卓雍措'),
            '泉州' => array('开元寺', '洛阳桥', '西街', '崇武古城', '蟳埔古村'),
            '金华' => array('横店影视城', '双龙洞', '婺州古城', '诸葛村', '义乌商贸城'),
            '绍兴' => array('鲁迅故里', '沈园', '东湖', '仓桥直街', '柯岩风景区'),
            '扬州' => array('瘦西湖', '个园', '东关街', '何园', '大明寺'),
            '镇江' => array('西津渡', '金山寺', '焦山', '盐湖城', '梦溪园'),
            '湖州' => array('太湖古镇', '南浔古镇', '莫干山', '安吉竹海', '飞英塔'),
            '嘉兴' => array('南湖红船', '西塘古镇', '乌镇', '南湖烟雨楼', '濮院古镇'),
            '台州' => array('天台山', '神仙居', '临海古城', '温岭石塘', '仙居'),
            '丽水' => array('缙云仙都', '松阳古村', '瓯江帆影', '黄帝鼎', '云和梯田'),
            '温州' => array('雁荡山', '楠溪江', '五马街', '南麂列岛', '江心屿'),
            '宁波' => array('天一阁', '老外滩', '象山影视城', '东钱湖', '鼓楼'),
            '济宁' => array('曲阜三孔', '太白楼', '微山湖', '汶上宝相寺', '兖州博物馆'),
            '泰安' => array('泰山', '岱庙', '天颐湖', '徂徕山', '大汶河'),
            '威海' => array('刘公岛', '成山头', '国际海水浴场', '华夏城', '那香海'),
            '烟台' => array('蓬莱阁', '烟台山', '养马岛', '南山', '张裕酒窖'),
            '潍坊' => array('十笏园', '风筝广场', '青州古城', '安丘青云山', '寒亭固堤'),
            '临沂' => array('蒙山', '银雀山', '琅琊台', '沂州古城', '压油沟'),
            '菏泽' => array('曹州牡丹园', '水浒好汉城', '黄河故道', '孙膑故里', '定陶古城'),
            '枣庄' => array('台儿庄古城', '微山湖湿地', '抱犊崮', '墨子故里', '台儿庄大战纪念馆'),
            '聊城' => array('东昌湖', '光岳楼', '山陕会馆', '古运河', '江北水城'),
            '滨州' => array('黄河故道', '杜受田故居', '孙子兵法城', '无棣古城', '范公故里'),
            '东营' => array('黄河口湿地', '胜利油田纪念馆', '孙子故里', '孙武湖', '红口湿地'),
            '日照' => array('万平口海滨', '五莲山', '吴家台', '海滨森林公园', '涛雎小镇'),
            '淄博' => array('齐盛湖', '海岱楼', '周村古商城', '陶瓷琉璃馆', '潭溪山'),
            '平顶山' => array('尧山', '中原大佛', '香山寺', '叶县县衙', '郏县美食'),
            '安阳' => array('殷墟', '中国文字博物馆', '红旗渠', '太行大峡谷', '岳飞庙'),
            '鹤壁' => array('云梦山', '淇河', '大伾山', '浚县古庙会', '中原石窟'),
            '新乡' => array('万仙山', '八里营', '比干庙', '潞王陵', '黄河故道森林公园'),
            '焦作' => array('云台山', '青天河', '神农山', '陈家沟', '影视城'),
            '濮阳' => array('戚城文物景区', '杂技文化园', '西水寨', '帝颛顼陵', '中华第一龙'),
            '许昌' => array('曹丞相府', '春秋楼', '灞陵桥', '钧官窑址', '白居易墓'),
            '三门峡' => array('函谷关', '老鸦岔', '天鹅湖湿地', '地坑院', '黄河三峡'),
            '南阳' => array('内乡县衙', '恐龙蛋化石馆', '武侯祠', '丹江大观苑', '独山玉器'),
            '商丘' => array('芒砀山', '应天书院', '商丘古城', '商丘博物馆', '梁园'),
            '信阳' => array('鸡公山', '南湾湖', '金兰山', '浉河港', '灵山寺'),
            '周口' => array('太昊陵', '大运河', '老子故里', '淮阳荷花', '水城荷花节'),
            '驻马店' => array('嵖岈山', '南海禅寺', '铜山湖', '薄山湖', '天中山'),
            '济源' => array('王屋山', '黄河三峡', '五龙口', '黄河湿地', '阳台宫'),
            '石家庄' => array('正定古城', '河北博物院', '西柏坡', '赵州桥', '毗卢寺'),
            '太原' => array('晋祠', '钟楼街', '汾河公园', '双塔寺', '蒙山大佛'),
            '大同' => array('云冈石窟', '悬空寺', '华严寺', '九龙壁', '善化寺'),
            '运城' => array('解州关帝庙', '盐湖', '永乐宫', '舜帝陵', '鹳雀楼'),
            '临汾' => array('壶口瀑布', '广胜寺', '洪洞大槐树', '尧庙', '平遥古城'),
            '长治' => array('上党门', '老顶山', '黎城大院', '炎帝陵', '仙堂山'),
            '晋中' => array('平遥古城', '乔家大院', '绵山', '乌镇晋中', '常家庄园'),
            '忻州' => array('五台山', '忻州古城', '雁门关', '芦芽山', '禹王洞'),
            '延安' => array('宝塔山', '枣园', '杨家岭', '延安革命纪念馆', '清凉山'),
            '汉中' => array('古汉台', '诸葛古镇', '青木川', '拜将台', '石门栈道'),
            '襄阳' => array('古隆中', '唐城', '黄家湾', '习家池', '汉江夜景'),
            '宜昌' => array('三峡大坝', '清江画廊', '三峡人家', '屈原故里', '西陵峡'),
            '荆州' => array('荆州古城', '关帝庙', '楚国文化', '洪湖蓝田', '洈水'),
            '十堰' => array('武当山', '丹江口', '神农架', '青龙泉', '东风汽车'),
            '芜湖' => array('赭山公园', '方特梦幻王国', '鸠兹古镇', '镜湖', '李白故居'),
            '蚌埠' => array('龙子湖', '涂山禹王庙', '明皇文化园', '淮河老街', '花鼓灯嘉年华'),
            '合肥' => array('包公园', '三河古镇', '安徽博物院', '逍遥津', '大蜀山'),
            '滁州' => array('琅琊山', '醉翁亭', '明中都', '南谯古楼', '丰乐湖'),
            '南昌' => array('滕王阁', '八一起义纪念馆', '梅岭', '绳金塔', '秋水广场'),
            '九江' => array('庐山', '浔阳楼', '石钟山', '白鹿洞书院', '东林寺'),
            '景德镇' => array('陶阳里', '古窑民俗博览区', '中国陶瓷博物馆', '三闾庙', '御窑厂'),
            '赣州' => array('郁孤台', '通天寨', '八境台', '客家文化城', '南康家具城'),
            '上饶' => array('三清山', '婺源篁岭', '婺源油菜花', '鹅湖', '葛仙山'),
            '吉安' => array('井冈山', '武功山', '吉州窑', '白鹭洲书院', '渼陂古村'),
            '宜春' => array('明月山', '铜鼓汤里', '古海镇', '天沐温泉', '宜春学院'),
            '萍乡' => array('安源红五军', '杨岐寺', '孽龙洞', '武功山', '安源石城'),
            '株洲' => array('炎帝陵', '醴陵陶瓷', '渌江书院', '云阳山', '株洲老街'),
            '湘潭' => array('韶山冲', '窑湾古街', '万楼', '齐白石纪念馆', '昭山'),
            '衡阳' => array('南岳衡山', '岳麓书院', '回雁峰', '石鼓书院', '雁峰寺'),
            '常德' => array('桃花源', '柳叶湖', '诗墙', '德山乾明寺', '壶瓶山'),
            '郴州' => array('东江湖', '莽山', '苏仙岭', '仰天湖', '高椅岭'),
            '永州' => array('九嶷山', '柳子庙', '阳明山', '舜皇陵', '东安狮岩'),
            '怀化' => array('洪江古商城', '芷江龙津风雨桥', '矮寨大峡谷', '芙蓉楼', '侗族鼓楼'),
            '邵阳' => array('崀山', '南岳宫', '黄桑', '宝庆古城', '高洲温泉'),
            '广安' => array('邓小平故里', '华蓥山', '白塔', '宝箴塞', '渠江'),
            '泸州' => array('老窖窖池', '忠山', '张坝桂圆林', '尧坝古镇', '方山'),
            '南充' => array('阆中古城', '凌云山', '朱德故居', '灵山寺', '阆中古城风水'),
            '宜宾' => array('三江口', '李庄古镇', '蜀南竹海', '五粮液老窖', '夕佳山'),
            '乐山' => array('乐山大佛', '峨眉山', '东方佛都', '嘉定坊', '沫若故居'),
            '自贡' => array('恐龙博物馆', '盐都历史博物馆', '中华彩灯大世界', '仙市古镇', '荣县大佛'),
            '绵阳' => array('越王楼', '西山公园', '方特绵阳', '北川羌城', '窦圌山'),
            '德阳' => array('三星堆', '绵竹年画', '诸葛双忠祠', '孝泉古镇', '旌湖'),
            '广元' => array('剑门关', '皇泽寺', '千佛崖', '昭化古城', '唐家河'),
            '遂宁' => array('灵泉寺', '广德寺', '陈子昂读书台', '临仙山', '安居古城'),
            '内江' => array('张大千纪念馆', '圣水寺', '东兴山', '隆昌古宇湖', '资中重龙山'),
            '眉山' => array('三苏祠', '青神中岩寺', '柳江古镇', '老瓦山', '彭祖山'),
            '遵义' => array('遵义会议会址', '娄山关', '乌江渡', '茅台古镇', '梵净山'),
            '安顺' => array('黄果树瀑布', '龙宫', '屯堡', '格凸河', '夜郎洞'),
            '毕节' => array('百里杜鹃', '织金洞', '奢香九驿', '威宁草海', '七星关'),
            '六盘水' => array('乌蒙大草原', '梅花山', '水城古镇', '玉舍森林', '妥乐古银杏'),
            '凯里' => array('下司古镇', '西江千户苗寨', '苗侗风情园', '云谷田园', '朗德上寨'),
            '铜仁' => array('梵净山', '中南门古城', '乌江大峡谷', '九龙洞', '寨沙侗寨'),
            '兴义' => array('万峰林', '马岭河峡谷', '贵州醇景区', '万峰湖', '何应钦故居'),
            '西双版纳' => array('告庄西双景', '野象谷', '中科院植物园', '曼听公园', '基诺山寨'),
            '迪庆' => array('普达措', '松赞林寺', '独克宗古城', '虎跳峡', '纳帕海'),
            '楚雄' => array('紫溪山', '彝人古镇', '元谋人博物馆', '禄丰恐龙谷', '石羊古镇'),
            '玉溪' => array('抚仙湖', '禄充', '红塔山', '聂耳故居', '龙马山'),
            '曲靖' => array('麒麟区', '爨乡', '珠江源', '会泽古城', '九龙瀑布'),
            '保山' => array('腾冲火山', '和顺古镇', '银杏村', '滇西抗战纪念馆', '高黎贡山'),
            '普洱' => array('景迈山', '太阳河森林公园', '北回归线标志园', '那柯里', '茶马古道'),
            '临沧' => array('翁丁古村', '沧源崖画', '五老山', '南美拉祜族', '孟定允景'),
            '昭通' => array('大山包', '豆沙关', '朱提山', '水富瀑布', '龙头山'),
            '香港' => array('太平山顶', '维多利亚港', '星光大道', '天星小轮', '九龙维港'),
            '澳门' => array('大三巴牌坊', '妈阁庙', '威尼斯人', '渔人码头', '东望洋炮台'),
            '台北' => array('台北101', '国父纪念馆', '故宫博物院', '士林夜市', '阳明山'),
            '呼和浩特' => array('大召寺', '希拉穆仁草原', '敕勒川', '五塔寺', '赛罕塔拉'),
            '包头' => array('五当召', '赛罕塔拉', '南海湿地', '白云鄂博', '钢铁公园'),
            '鄂尔多斯' => array('成吉思汗陵', '响沙湾', '银坑', '苏泊罕大草原', '九城宫'),
            '呼伦贝尔' => array('呼伦湖', '金帐汗', '额尔古纳湿地', '室韦俄罗斯民族乡', '达尔汗罗京'),
            '赤峰' => array('克什克腾旗', '乌兰布统', '阿斯哈图石林', '辽上京', '红山文化'), '乌兰察布' => array('辉腾锡勒草原', '黄花沟', '岱海', '乌兰哈达火山', '察尔湖'),
            '伊春' => array('小兴安岭', '汤旺河石林', '五营国家森林公园', '梅花山', '嘉荫恐龙'),
            '齐齐哈尔' => array('扎龙自然保护区', '龙沙公园', '大乘寺', '昂昂溪罗西亚大街', '讷河'),
            '哈尔滨' => array('中央大街', '索菲亚教堂', '松花江', '冰雪大世界', '亚布力'),
            '长春' => array('伪满皇宫', '净月潭', '南湖公园', '长春动植物园', '孔子文化园'),
            '吉林' => array('雾凇岛', '松花湖', '北山公园', '朱雀山', '拉法山'),
            '沈阳' => array('张氏帅府', '沈阳故宫', '中街', '北陵公园', '东陵公园'),
            '大连' => array('星海广场', '老虎滩', '滨海路', '金石滩', '旅顺军港'),
            '鞍山' => array('千山', '玉佛苑', '钢都夜景', '汤岗子温泉', '南果公园'),
            '抚顺' => array('雷台', '高尔山', '赫图阿拉城', '中华满族风情园', '天丰塔'),
            '本溪' => array('五女山', '关门山', '本溪水洞', '铁刹山', '望天洞'),
            '丹东' => array('虎山长城', '鸭绿江断桥', '凤凰山', '五龙背', '抗美援朝纪念馆'),
            '锦州' => array('古塔公园', '奉国寺', '笔架山', '北普陀山', '凌河夜市'),
            '营口' => array('鲅鱼圈', '西炮台', '辽河老街', '楞严寺', '熊岳镇'),
            '盘锦' => array('红海滩', '苇田', '双台子河口', '楞严寺', '辽河油田'),
            '白山' => array('长白山', '松花江湖', '靖宇县', '杨靖宇烈士陵园', '临江'),
            '通化' => array('高句丽遗址', '鸭江江岛', '集安', '五女峰', '玉皇山'), '晋城' => array('皇城相府', '珏山', '郭峪古城', '砥洎城', '蟒河'),
            '阳泉' => array('娘子关', '泉城', '藏山', '石门山', '大汖古村'),
            '朔州' => array('应县木塔', '崇福寺', '平鲁', '杀虎口', '老城'),
            '吕梁' => array('碛口古镇', '北武当山', '云丘山', '汾酒博物馆', '庞山沟'),
            '克拉玛依' => array('魔鬼城', '九龙湖', '乌尔禾', '世界魔鬼城', '雅丹'),
            '吐鲁番' => array('葡萄沟', '火焰山', '交河故城', '坎儿井', '天湖'),
            '喀什' => array('喀什老城', '艾提尕尔清真寺', '白沙湖', '香妃园', '帕米尔'),
            '伊宁' => array('六星街', '薰衣草基地', '喀赞其', '果子沟', '伊犁河'),
            '哈密' => array('巴里坤草原', '魔鬼城', '回王墓', '东天山', '淖毛湖'),
            '嘉峪关' => array('嘉峪关关城', '悬壁长城', '第一墩', '讨赖河', '新城草湖'),
            '金昌' => array('镍都', '金川公园', '圣容寺', '骊靬古长城', '红水沟'),
            '庆阳' => array('岐山周公庙', '南梁红色旅游区', '秦汉古窑址', '子午岭', '庆阳博物馆'),
            '临夏' => array('八坊十三巷', '河州牡丹文化公园', '炳灵寺石窟', '刘家峡', '大墩峡'),
            '甘南' => array('拉卜楞寺', '郎木寺', '扎尕那', '尕海湖', '米拉日巴佛阁'),
            '石嘴山' => array('沙湖', '北武当', '黄河楼', '大武口森林公园', '贺兰山岩画'),
            '吴忠' => array('黄河楼', '青铜峡黄河大峡谷', '中华黄河楼', '董府', '罗山'),
            '中卫' => array('沙坡头', '寺口子', '高庙', '腾格里沙漠', '青铜峡'),
            '乌海' => array('金沙湾', '东达山', '蒙古族俗文化村', '甘德尔山', '当代中国书法艺术馆'),
            '巴彦淖尔' => array('乌梁素海', '五原黄河', '阴山岩画', '黄河河套', '红星美凯龙'),
            '昌吉' => array('天山天池', '奇台硅化木', '江布拉克', '北庭故城', '回族博物馆'),
            '伊犁' => array('那拉提', '喀拉峻', '果子沟', '霍城薰衣草', '白哈巴'),
            '塔城' => array('塔尔巴哈台', '白哈巴', '果子沟', '库鲁斯台草原', '阿拉山口'),
            '阿勒泰' => array('喀纳斯', '禾木', '白哈巴', '可可托海', '魔鬼城'),
            '和田' => array('玉龙喀什河', '千年核桃王', '艾提尕尔', '沙漠公路', '罗布人村寨'),
            '阿克苏' => array('库车大峡谷', '克孜尔千佛洞', '白沙湖', '苏马什里克', '刀郎纪念馆'),
            '昌都' => array('然乌湖', '来古冰川', '强巴佛殿', '芒康', '邦达草原'),
            '日喀则' => array('扎什伦布寺', '珠峰大本营', '白居寺', '萨迦寺', '卡若遗址'),
            '林芝' => array('南迦巴瓦', '雅鲁藏布大峡谷', '波密', '然乌湖', '尼洋河'),
            '山南' => array('雍布拉康', '羊卓雍措', '桑耶寺', '敏珠林寺', '加查核桃'),
        );
    }

    private static function nearbyPlaces($lat, $lon, $city = '', $deadline = 0)
    {
        $static = array();
        $list = self::landmarksFor($city);
        foreach ($list as $n) {
            $static[] = array('name' => $n, 'distance' => null);
        }

        if (!empty($static)) {
            return array_slice($static, 0, 6);
        }

        if ($lat === null || $lon === null) {
            return array();
        }

        if ($deadline > 0 && microtime(true) > $deadline - 2.5) {
            return array();
        }
        $lat = round((float) $lat, 3);
        $lon = round((float) $lon, 3);
        $cacheFile = sys_get_temp_dir() . '/yx-near-' . md5($lat . '|' . $lon) . '.json';
        if (is_file($cacheFile) && (time() - (int) filemtime($cacheFile)) < 86400) {
            $cached = json_decode((string) @file_get_contents($cacheFile), true);
            if (is_array($cached)) {
                return self::mergeNearby($static, $cached);
            }
        }

        $q = '[out:json][timeout:5];'
            . '('
            . 'node(around:20000,' . $lat . ',' . $lon . ')["tourism"~"^(attraction|artwork|museum|gallery)$"];'
            . 'node(around:20000,' . $lat . ',' . $lon . ')["historic"~"^(monument|memorial|castle|ruins|temple|city_gate)$"];'
            . ');out center 20;';

        $net = array();
        foreach (array(
            'https://overpass-api.de/api/interpreter?data=',
            'https://overpass.kumi.systems/api/interpreter?data='
        ) as $ep) {
            $d = self::fetchJson($ep . rawurlencode($q), 3);
            if (!is_array($d) || empty($d['elements']) || !is_array($d['elements'])) {
                continue;
            }
            foreach ($d['elements'] as $el) {
                if (empty($el['tags']['name'])) {
                    continue;
                }
                $name = (string) ($el['tags']['name:zh'] ?? $el['tags']['name']);
                if ($name === '' || mb_strlen($name) > 12) {
                    continue;
                }
                $plat = isset($el['lat']) ? $el['lat'] : ($el['center']['lat'] ?? null);
                $plon = isset($el['lon']) ? $el['lon'] : ($el['center']['lon'] ?? null);
                $dist = self::distanceKm($lat, $lon, $plat, $plon);
                $net[] = array(
                    'name' => $name,
                    'distance' => $dist === null ? null : round((float) $dist, 1)
                );
            }
            if ($net) {
                break;
            }
        }

        if (!empty($net)) {
            usort($net, function ($a, $b) {
                $da = $a['distance'] === null ? 1e9 : $a['distance'];
                $dbv = $b['distance'] === null ? 1e9 : $b['distance'];
                return $da - $dbv;
            });
            @file_put_contents($cacheFile, json_encode(array_slice($net, 0, 8), JSON_UNESCAPED_UNICODE));
        }

        return self::mergeNearby($static, $net);
    }

    private static function mergeNearby($static, $net)
    {
        $seen = array();
        $out = array();
        foreach (array_merge($static, (array) $net) as $n) {
            $name = (string) ($n['name'] ?? '');
            if ($name === '' || isset($seen[$name])) {
                continue;
            }
            $seen[$name] = 1;
            $out[] = array('name' => $name, 'distance' => $n['distance'] ?? null);
            if (count($out) >= 6) {
                break;
            }
        }
        return $out;
    }

    private static function parseNmTime($s)
    {
        $s = trim((string) $s);
        if ($s === '') {
            return null;
        }
        $s = str_replace('/', '-', $s);
        $s = str_replace('T', ' ', $s);
        $s = trim(preg_replace('/\s+/', ' ', $s));
        foreach (array('Y-m-d H:i:s', 'Y-m-d H:i', 'Y-m-d') as $fmt) {
            $dt = \DateTime::createFromFormat($fmt, $s);
            if ($dt !== false) {
                return $dt->getTimestamp();
            }
        }
        $ts = strtotime($s);
        return $ts === false ? null : (int) $ts;
    }

    private static function provinceVariants($p)
    {
        $p = trim((string) $p);
        $out = array();
        if ($p === '') {
            return $out;
        }
        $out[] = $p;
        $s = preg_replace('/(省|市|特别行政区)$/u', '', $p);
        if ($s !== '' && !in_array($s, $out, true)) {
            $out[] = $s;
        }
        $s2 = preg_replace('/(维吾尔|壮族|回族|自治区|特别行政区)/u', '', $p);
        $s2 = preg_replace('/(省|市)$/u', '', $s2);
        if ($s2 !== '' && !in_array($s2, $out, true)) {
            $out[] = $s2;
        }
        return $out;
    }

    public static function lastRegion()
    {
        $f = sys_get_temp_dir() . '/yx-region-last.json';
        if (!is_file($f) || (time() - (int) filemtime($f)) > 1800) {
            return array();
        }
        $d = json_decode((string) @file_get_contents($f), true);
        return is_array($d) ? $d : array();
    }

    public static function alerts($province = '', $city = '')
    {
        $province = (string) $province;
        $city = (string) $city;

        if ($province === '' && $city === '') {
            $last = self::lastRegion();
            $province = (string) ($last['province'] ?? '');
            $city = (string) ($last['city'] ?? '');
        }

        $cacheFile = sys_get_temp_dir() . '/yx-alerts-v3-' . md5($province . '|' . $city) . '.json';
        if (is_file($cacheFile) && (time() - (int) filemtime($cacheFile)) < 900) {
            $cached = json_decode((string) @file_get_contents($cacheFile), true);
            if (is_array($cached) && isset($cached['status'])) {
                return $cached;
            }
        }

        $variants = $province !== '' ? self::provinceVariants($province) : ($city !== '' ? array($city) : array());

        $list = null;
        $scoped = false;
        foreach (array('https', 'http') as $scheme) {
            $base = $scheme . '://www.nmc.cn/rest/findAlarm?pageNo=1&pageSize=60&signaltype=&signallevel=';
            $urls = array();
            foreach ($variants as $v) {
                $urls[] = $base . '&province=' . rawurlencode($v);
            }
            $urls[] = $base . '&province=';

            foreach ($urls as $u) {
                $d = self::fetchJson($u, 7);
                if (!is_array($d)) {
                    continue;
                }
                if (!empty($d['data']['page']['list']) && is_array($d['data']['page']['list'])) {
                    $list = $d['data']['page']['list'];
                    $scoped = substr($u, -10) !== '&province=';
                    break 2;
                }
                if (!empty($d['data']['list']) && is_array($d['data']['list'])) {
                    $list = $d['data']['list'];
                    $scoped = substr($u, -10) !== '&province=';
                    break 2;
                }
            }
        }

        if (!is_array($list)) {
            $qk = self::quakeList();
            $ty = self::typhoonList();
            return array(
                'status' => false,
                'message' => '预警服务暂时不可用',
                'items' => array(),
                'quakes' => isset($qk['quakes']) ? $qk['quakes'] : array(),
                'typhoons' => isset($ty['typhoons']) ? $ty['typhoons'] : array()
            );
        }

        $items = array();
        foreach ($list as $it) {
            if (!is_array($it)) {
                continue;
            }
            $title = (string) ($it['title'] ?? '');
            $lvl = (string) ($it['signallevel'] ?? '');
            if ($lvl === '' && preg_match('/(红色|橙色|黄色|蓝色)预警/u', $title, $mm)) {
                $lvl = $mm[1];
            }
            $type = (string) ($it['signaltype'] ?? '');
            if ($type === '' && preg_match('/发布(.{1,6}?)(红色|橙色|黄色|蓝色)预警/u', $title, $mm2)) {
                $type = $mm2[1];
            }
            $content = (string) ($it['issueContent'] ?? ($it['content'] ?? ''));
            $issueTime = (string) ($it['issuetime'] ?? '');

            $ts = self::parseNmTime($issueTime);
            if ($ts !== null && $ts < time() - 3 * 86400) {
                continue;
            }

            if (!$scoped && !empty($variants)) {
                $hay = $title . ' ' . $content;
                $hit = false;
                foreach ($variants as $v) {
                    if ($v !== '' && mb_strpos($hay, $v) !== false) {
                        $hit = true;
                        break;
                    }
                }
                if (!$hit) {
                    continue;
                }
            }

            $items[] = array(
                'title' => $title,
                'type' => $type,
                'level' => $lvl,
                'issueTime' => $issueTime,
                'timestamp' => $ts,
                'content' => mb_strlen($content) > 110 ? mb_substr($content, 0, 110) . '…' : $content,
                'url' => (string) ($it['url'] ?? '')
            );
        }

        $lvOrder = array('红色' => 1, '橙色' => 2, '黄色' => 3, '蓝色' => 4);
        usort($items, function ($a, $b) use ($lvOrder) {
            $la = isset($lvOrder[$a['level']]) ? $lvOrder[$a['level']] : 9;
            $lb = isset($lvOrder[$b['level']]) ? $lvOrder[$b['level']] : 9;
            if ($la !== $lb) {
                return $la - $lb;
            }
            return strcmp($b['issueTime'], $a['issueTime']);
        });

        $qk = self::quakeList();
        $ty = self::typhoonList();
        $out = array(
            'status' => true,
            'province' => $province,
            'city' => $city,
            'region' => $province !== '' ? $province : $city,
            'days' => 3,
            'count' => count($items),
            'items' => array_slice($items, 0, 20),
            'quakes' => isset($qk['quakes']) ? $qk['quakes'] : array(),
            'typhoons' => isset($ty['typhoons']) ? $ty['typhoons'] : array(),
            'source' => '中央气象台 nmc.cn'
        );
        @file_put_contents($cacheFile, json_encode($out, JSON_UNESCAPED_UNICODE));
        return $out;
    }

    public static function quakeList($limit = 6)
    {
        $cacheFile = sys_get_temp_dir() . '/yx-quake-v1.json';
        if (is_file($cacheFile) && (time() - (int) filemtime($cacheFile)) < 300) {
            $cached = json_decode((string) @file_get_contents($cacheFile), true);
            if (is_array($cached) && isset($cached['quakes'])) {
                return $cached;
            }
        }
        $data = self::fetchJson('https://api.wolfx.jp/cenc_eqlist.json', 8);
        $quakes = array();
        if (is_array($data)) {
            foreach ($data as $k => $q) {
                if (!is_array($q) || !isset($q['time']) || !isset($q['magnitude'])) {
                    continue;
                }
                $mag = (float) $q['magnitude'];
                if ($mag <= 0) {
                    continue;
                }
                $quakes[] = array(
                    'time' => (string) ($q['time'] ?? ''),
                    'timestamp' => self::parseNmTime((string) ($q['time'] ?? '')),
                    'location' => (string) ($q['location'] ?? ($q['placeName'] ?? '')),
                    'magnitude' => $mag,
                    'depth' => (float) ($q['depth'] ?? 0),
                    'intensity' => (string) ($q['intensity'] ?? ''),
                    'lat' => (float) ($q['latitude'] ?? 0),
                    'lon' => (float) ($q['longitude'] ?? 0),
                    'type' => (string) ($q['type'] ?? '')
                );
            }
        }
        usort($quakes, function ($a, $b) {
            return (int) ($b['timestamp'] ?? 0) - (int) ($a['timestamp'] ?? 0);
        });
        $quakes = array_slice($quakes, 0, (int) $limit);
        $out = array(
            'status' => true,
            'count' => count($quakes),
            'quakes' => $quakes,
            'source' => '中国地震台网 CENC · Wolfx'
        );
        @file_put_contents($cacheFile, json_encode($out, JSON_UNESCAPED_UNICODE));
        return $out;
    }

    public static function typhoonList($limit = 4)
    {
        $cacheFile = sys_get_temp_dir() . '/yx-typhoon-v1.json';
        if (is_file($cacheFile) && (time() - (int) filemtime($cacheFile)) < 1800) {
            $cached = json_decode((string) @file_get_contents($cacheFile), true);
            if (is_array($cached) && isset($cached['typhoons'])) {
                return $cached;
            }
        }
        $raw = self::fetchUrl('https://typhoon.nmc.cn/weatherservice/typhoon/jsons/list_default', 8);
        $list = array();
        if ($raw !== '') {
            $json = null;
            $first = strpos($raw, '{');
            $last = strrpos($raw, '}');
            if ($first !== false && $last !== false && $last > $first) {
                $json = json_decode(substr($raw, $first, $last - $first + 1), true);
            }
            if (!is_array($json)) {
                $json = json_decode($raw, true);
            }
            if (is_array($json) && isset($json['typhoonList']) && is_array($json['typhoonList'])) {
                foreach ($json['typhoonList'] as $t) {
                    if (!is_array($t) || count($t) < 8) {
                        continue;
                    }
                    if ((string) ($t[7] ?? '') !== 'start') {
                        continue;
                    }
                    $cn = (string) ($t[6] ?: $t[2] ?: '');
                    if ($cn === '') {
                        continue;
                    }
                    $list[] = array(
                        'id' => (string) ($t[0] ?? ''),
                        'enName' => (string) ($t[1] ?? ''),
                        'name' => $cn,
                        'status' => 'active',
                        'statusText' => '活动中（生成 / 临近登陆）'
                    );
                }
            }
        }
        $list = array_slice($list, 0, (int) $limit);
        $out = array(
            'status' => true,
            'count' => count($list),
            'typhoons' => $list,
            'source' => '中央气象台 nmc.cn'
        );
        @file_put_contents($cacheFile, json_encode($out, JSON_UNESCAPED_UNICODE));
        return $out;
    }

    private static function amapKey()
    {
        $plugin = self::conf();
        $key = trim((string) ($plugin->amapKey ?? ''));
        if ($key !== '') {
            return $key;
        }
        foreach (array('AMAP_KEY', 'AMAP_WEB_KEY', 'GAODE_KEY') as $name) {
            $v = trim((string) getenv($name));
            if ($v !== '') {
                return $v;
            }
        }
        if (defined('YX_AMAP_KEY')) {
            $v = trim((string) constant('YX_AMAP_KEY'));
            if ($v !== '') {
                return $v;
            }
        }
        foreach (array(__DIR__ . '/amap.key', __DIR__ . '/data/amap.key') as $file) {
            if (is_file($file)) {
                $v = trim((string) @file_get_contents($file));
                if ($v !== '') {
                    return $v;
                }
            }
        }
        return '';
    }

    public static function trafficStatus($city = '', $lat = null, $lon = null)
    {
        $key = self::amapKey();
        if ($key === '') {
            return array(
                'status' => false,
                'configured' => false,
                'message' => '交通服务未授权，填写高德地图 Key 后自动启用。',
                'roads' => array()
            );
        }

        $city = trim((string) $city);
        $lat = is_numeric($lat) ? (float) $lat : null;
        $lon = is_numeric($lon) ? (float) $lon : null;
        if ($city === '' && $lat === null) {
            $region = self::lastRegion();
            $city = (string) ($region['city'] ?? '');
            $prov = (string) ($region['province'] ?? '');
            if ($city === '' && $prov !== '') {
                $city = $prov;
            }
        }
        if ($city === '' && $lat === null) {
            $city = '北京';
        }

        $cacheKey = $lat !== null && $lon !== null
            ? sprintf('%.3f,%.3f', $lat, $lon) : $city;
        $cacheFile = sys_get_temp_dir() . '/yx-traffic-v2-' . md5($cacheKey . '|' . $key) . '.json';
        if (is_file($cacheFile) && (time() - (int) filemtime($cacheFile)) < 120) {
            $cached = json_decode((string) @file_get_contents($cacheFile), true);
            if (is_array($cached) && isset($cached['status'])) {
                return $cached;
            }
        }

        if ($lat !== null && $lon !== null) {
            $lng = $lon;
        } else {
            $geo = self::fetchJson('https://restapi.amap.com/v3/geocode/geo?key=' . urlencode($key)
                . '&address=' . urlencode($city) . '&city=' . urlencode($city), 8);
            $loc = null;
            if (is_array($geo) && !empty($geo['geocodes'][0]['location'])) {
                $loc = (string) $geo['geocodes'][0]['location'];
            }
            $lng = $lat = null;
            if ($loc !== null) {
                $parts = explode(',', $loc);
                if (count($parts) === 2 && is_numeric(trim($parts[0])) && is_numeric(trim($parts[1]))) {
                    $lng = (float) trim($parts[0]);
                    $lat = (float) trim($parts[1]);
                } else {
                    $loc = null;
                }
            }
            if ($loc === null) {
                $out = array('status' => false, 'configured' => true, 'message' => '无法定位「' . $city . '」的坐标', 'city' => $city, 'roads' => array());
                @file_put_contents($cacheFile, json_encode($out, JSON_UNESCAPED_UNICODE));
                return $out;
            }
        }
        $rect = sprintf('%.5f,%.5f;%.5f,%.5f', $lng - 0.02, $lat - 0.012, $lng + 0.02, $lat + 0.012);

        $ti = self::fetchJson('https://restapi.amap.com/v3/traffic/status/rectangle?key=' . urlencode($key)
            . '&level=5&extensions=all&rectangle=' . urlencode($rect), 8);
        if (!is_array($ti) || !isset($ti['trafficinfo'])) {
            $out = array('status' => false, 'configured' => true, 'message' => '高德交通态势接口未返回数据', 'city' => $city, 'roads' => array());
            @file_put_contents($cacheFile, json_encode($out, JSON_UNESCAPED_UNICODE));
            return $out;
        }

        $info = $ti['trafficinfo'];
        $eval = isset($info['evaluation']) ? $info['evaluation'] : array();
        $statusMap = array(1 => '畅通', 2 => '缓行', 3 => '拥堵', 4 => '严重拥堵');
        $status = (int) (isset($eval['status']) ? $eval['status'] : ($info['status'] ?? 0));
        $roads = array();
        if (!empty($info['roads']) && is_array($info['roads'])) {
            foreach ($info['roads'] as $r) {
                $rs = (int) ($r['status'] ?? 0);
                $roads[] = array(
                    'name' => (string) ($r['name'] ?? ''),
                    'status' => $rs,
                    'statusText' => isset($statusMap[$rs]) ? $statusMap[$rs] : '未知',
                    'speed' => (float) ($r['speed'] ?? 0),
                    'direction' => (string) ($r['direction'] ?? '')
                );
            }
            usort($roads, function ($a, $b) { return $b['status'] - $a['status']; });
            $roads = array_slice($roads, 0, 6);
        }

        $out = array(
            'status' => true,
            'configured' => true,
            'city' => $city,
            'statusCode' => $status,
            'statusText' => isset($statusMap[$status]) ? $statusMap[$status] : '未知',
            'description' => (string) (isset($info['description']) ? $info['description'] : ($eval['description'] ?? '')),
            'ratio' => array(
                '畅通' => (float) ($eval['expedite'] ?? 0),
                '缓行' => (float) ($eval['congested'] ?? 0),
                '拥堵' => (float) ($eval['blocked'] ?? 0),
                '未知' => (float) ($eval['unknown'] ?? 0)
            ),
            'roads' => $roads,
            'source' => '高德地图'
        );
        @file_put_contents($cacheFile, json_encode($out, JSON_UNESCAPED_UNICODE));
        return $out;
    }

    public static function trafficForecast($live = false)
    {
        $cacheFile = sys_get_temp_dir() . '/yx-traffic-nmc.json';
        $lastFile = sys_get_temp_dir() . '/yx-traffic-nmc-last.json';
        if (is_file($cacheFile) && (time() - (int) filemtime($cacheFile)) < 7200) {
            $c = json_decode((string) @file_get_contents($cacheFile), true);
            if (is_array($c) && !empty($c['date']) && !empty($c['items'])) {
                return $c;
            }
        }
        if (!$live) {
            if (is_file($lastFile)) {
                $l = json_decode((string) @file_get_contents($lastFile), true);
                if (is_array($l) && !empty($l['date']) && !empty($l['items'])) {
                    $l['stale'] = true;
                    return $l;
                }
            }
            return array('date' => '', 'summary' => '', 'items' => array(), 'note' => '', 'source' => '中央气象台 · 交通运输部', 'url' => 'https://www.nmc.cn/f/p-423', 'empty' => true);
        }
        $html = self::fetchUrl('https://m.nmc.cn/publish/traffic.html', 8);
        $out = self::parseTrafficHtml($html);
        if (!empty($out['date']) && !empty($out['items'])) {
            @file_put_contents($cacheFile, json_encode($out, JSON_UNESCAPED_UNICODE));
            @file_put_contents($lastFile, json_encode($out, JSON_UNESCAPED_UNICODE));
            return $out;
        }
        if (is_file($lastFile)) {
            $l = json_decode((string) @file_get_contents($lastFile), true);
            if (is_array($l) && !empty($l['date']) && !empty($l['items'])) {
                $l['stale'] = true;
                return $l;
            }
        }
        return array('date' => '', 'summary' => '', 'items' => array(), 'note' => '', 'source' => '中央气象台 · 交通运输部', 'url' => 'https://www.nmc.cn/f/p-423', 'empty' => true);
    }

    private static function parseTrafficHtml($html)
    {
        $out = array('date' => '', 'summary' => '', 'items' => array(), 'note' => '', 'source' => '中央气象台 · 交通运输部', 'url' => 'https://www.nmc.cn/f/p-423');
        if (!is_string($html) || $html === '') {
            return $out;
        }
        if (stripos($html, 'charset="gb') !== false || stripos($html, 'charset=gb') !== false) {
            $conv = @iconv('gb2312', 'utf-8//IGNORE', $html);
            if ($conv !== false && $conv !== '') {
                $html = $conv;
            }
        }
        if (!preg_match_all('/<p[^>]*>(.*?)<\/p>/is', $html, $m)) {
            return $out;
        }
        $cur = null;
        $idx = -1;
        foreach ($m[1] as $raw) {
            $t = trim(strip_tags($raw));
            if ($t === '') {
                continue;
            }
            if (preg_match('/联合发布全国主要公路气象预报/u', $t)) {
                if (preg_match('/(\d{4})年(\d{1,2})月(\d{1,2})日/u', $t, $dm)) {
                    $out['date'] = $dm[1] . '年' . $dm[2] . '月' . $dm[3] . '日';
                }
                continue;
            }
            if (preg_match('/\d{1,2}月\d{1,2}日\d{1,2}时.*?\d{1,2}日\d{1,2}时/u', $t, $sm)) {
                $sum = preg_replace('/^[^0-9]*(\d{1,2}月\d{1,2}日)/u', '$1', $t);
                if ($out['date'] === '' && preg_match('/(\d{1,2})月(\d{1,2})日\d{1,2}时/u', $sum, $dm)) {
                    $out['date'] = date('Y') . '年' . $dm[1] . '月' . $dm[2] . '日';
                }
                $out['summary'] = $sum;
                $cur = null;
                continue;
            }
            if (preg_match('/^另外[，,]?(.*)$/u', $t, $nm)) {
                $out['note'] = $nm[1];
                $cur = null;
                continue;
            }
            if (preg_match('/^受(.+?)影响的主要路段有[：:]/u', $t, $hm)) {
                $idx++;
                $out['items'][$idx] = array('type' => trim($hm[1]), 'roads' => array());
                $cur = &$out['items'][$idx];
                continue;
            }
            if ($cur !== null) {
                foreach (preg_split('/[、，,]/u', $t) as $p) {
                    $p = trim($p);
                    if ($p !== '' && !in_array($p, $cur['roads'], true)) {
                        $cur['roads'][] = $p;
                    }
                }
            }
        }
        return $out;
    }

    public static function trafficForecastHtml($d)
    {
        if (!is_array($d) || empty($d['date']) || empty($d['items'])) {
            return '<div class="yd-tf-empty">暂未获取到交通气象预报，后台会持续抓取</div>';
        }
        $h = '';
        $h .= '<div class="yd-tf-date">' . htmlspecialchars($d['date']) . ' 发布'
            . ' · <a href="' . htmlspecialchars($d['url'] ?: 'https://www.nmc.cn/f/p-423') . '" target="_blank" rel="noopener">完整预报</a></div>';
        if (!empty($d['summary'])) {
            $sum = $d['summary'];
            $h .= '<p class="yd-tf-sum">' . htmlspecialchars(mb_substr($sum, 0, 140)) . (mb_strlen($sum) > 140 ? '…' : '') . '</p>';
        }
        if (!empty($d['note'])) {
            $h .= '<p class="yd-tf-note">' . htmlspecialchars($d['note']) . '</p>';
        }
        $h .= '<div class="yd-tf-grps">';
        $typeMap = array('雪' => 'snow', '冰' => 'snow', '冻' => 'snow', '雷' => 'storm', '暴' => 'storm', '雨' => 'rain', '雾' => 'fog', '霾' => 'fog', '沙' => 'sand', '尘' => 'sand');
        foreach ($d['items'] as $it) {
            $cls = 'oth';
            $tp = (string) ($it['type'] ?? '');
            foreach ($typeMap as $kw => $v) {
                if (mb_strpos($tp, $kw) !== false) {
                    $cls = $v;
                    break;
                }
            }
            $roads = isset($it['roads']) && is_array($it['roads']) ? $it['roads'] : array();
            $h .= '<div class="yd-tf-grp yd-tf-' . $cls . '">';
            $h .= '<div class="yd-tf-grp-h"><span class="tg"></span>' . htmlspecialchars($tp)
                . ' <em>' . count($roads) . ' 条受影响路段</em></div>';
            $h .= '<div class="yd-tf-roads">';
            foreach (array_slice($roads, 0, 12) as $r) {
                $h .= '<span class="rd">' . htmlspecialchars($r) . '</span>';
            }
            if (count($roads) > 12) {
                $h .= '<span class="rd more">+' . (count($roads) - 12) . '</span>';
            }
            $h .= '</div></div>';
        }
        $h .= '</div>';
        $h .= '<div class="yd-tf-src">数据来源：' . htmlspecialchars($d['source'] ?: '中央气象台 · 交通运输部')
            . (!empty($d['stale']) ? ' · 缓存' : '') . '</div>';
        return $h;
    }

    private static function fetchUrl($url, $timeout = 5)
    {

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, min(4, $timeout));
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
            curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_USERAGENT, 'YunxiAdmin/' . self::VERSION);
            $raw = (string) curl_exec($ch);
            curl_close($ch);
            return $raw;
        }
        $ctx = stream_context_create(array(
            'http' => array(
                'timeout' => $timeout,
                'user_agent' => 'YunxiAdmin/' . self::VERSION,
                'follow_location' => 1,
                'max_redirects' => 3
            ),
            'ssl' => array(
                'verify_peer' => true,
                'verify_peer_name' => true,
                'allow_self_signed' => false
            )
        ));
        return (string) @file_get_contents($url, false, $ctx);
    }

    private static function clientIp()
    {
        $keys = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        foreach ($keys as $k) {
            if (empty($_SERVER[$k])) {
                continue;
            }
            $v = trim((string) $_SERVER[$k]);
            if ($v === '') {
                continue;
            }
            if (strpos($v, ',') !== false) {
                $parts = explode(',', $v);
                $v = trim($parts[0]);
            }
            if (preg_match('/^\d{1,3}(\.\d{1,3}){3}$/', $v)) {
                return $v;
            }
        }
        return '';
    }

    private static function locate()
    {
        if (self::$locCache !== null) {
            return self::$locCache;
        }
        $ip = self::clientIp();
        $out = array('ok' => false, 'city' => '', 'region' => '', 'lat' => null, 'lon' => null, 'ip' => $ip, 'source' => '');
        if ($ip === '') {
            self::$locCache = $out;
            return $out;
        }
        foreach (array('https://ipapi.co/' . $ip . '/json/', 'https://ipwho.is/' . $ip) as $u) {
            $d = json_decode(self::fetchUrl($u, 4), true);
            if (!is_array($d)) {
                continue;
            }
            if (strpos($u, 'ipapi.co') !== false) {
                if (!empty($d['latitude']) && !empty($d['longitude']) && empty($d['error'])) {
                    $out = array('ok' => true, 'ip' => $ip, 'city' => (string) ($d['city'] ?? ''),
                        'region' => (string) ($d['region'] ?? ''), 'lat' => (float) $d['latitude'],
                        'lon' => (float) $d['longitude'], 'source' => 'ipapi.co');
                    break;
                }
            } elseif (!empty($d['success']) && !empty($d['latitude']) && !empty($d['longitude'])) {
                $out = array('ok' => true, 'ip' => $ip, 'city' => (string) ($d['city'] ?? ''),
                    'region' => (string) ($d['region'] ?? ''), 'lat' => (float) $d['latitude'],
                    'lon' => (float) $d['longitude'], 'source' => 'ipwho.is');
                break;
            }
        }
        self::$locCache = $out;
        return $out;
    }

    private static function geocode($city)
    {
        $url = 'https://geocoding-api.open-meteo.com/v1/search?name=' . rawurlencode($city)
            . '&count=1&language=zh&format=json';
        $d = json_decode(self::fetchUrl($url, 5), true);
        if (is_array($d) && !empty($d['results'][0])) {
            $r = $d['results'][0];
            return array('ok' => true, 'city' => (string) ($r['name'] ?? $city),
                'region' => (string) ($r['admin1'] ?? ''), 'lat' => (float) $r['latitude'], 'lon' => (float) $r['longitude']);
        }
        return array('ok' => false);
    }

    private static function buildWeatherData($lat, $lon, $cityLabel, $regionLabel)
    {
        $url = 'https://api.open-meteo.com/v1/forecast?latitude=' . rawurlencode($lat)
            . '&longitude=' . rawurlencode($lon)
            . '&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m,surface_pressure,visibility,uv_index'
            . '&daily=weather_code,temperature_2m_max,temperature_2m_min,uv_index_max,precipitation_probability_max,wind_speed_10m_max'
            . '&timezone=auto&forecast_days=4';
        $data = json_decode(self::fetchUrl($url, 6), true);
        if (!is_array($data) || empty($data['current'])) {
            return array('city' => '');
        }
        $cur = $data['current'];
        $wtext = self::wmoText(isset($cur['weather_code']) ? (int) $cur['weather_code'] : 0);
        $wd = isset($cur['wind_direction_10m']) ? (float) $cur['wind_direction_10m'] : null;
        $ws = isset($cur['wind_speed_10m']) ? (float) $cur['wind_speed_10m'] : null;

        $forecast = array();
        $daily = isset($data['daily']) ? $data['daily'] : array();
        $dates = isset($daily['time']) ? $daily['time'] : array();
        $wcodes = isset($daily['weather_code']) ? $daily['weather_code'] : array();
        $tmax = isset($daily['temperature_2m_max']) ? $daily['temperature_2m_max'] : array();
        $tmin = isset($daily['temperature_2m_min']) ? $daily['temperature_2m_min'] : array();
        $uvmax = isset($daily['uv_index_max']) ? $daily['uv_index_max'] : array();
        $popmax = isset($daily['precipitation_probability_max']) ? $daily['precipitation_probability_max'] : array();
        $wmax = isset($daily['wind_speed_10m_max']) ? $daily['wind_speed_10m_max'] : array();
        $weekMap = array('日', '一', '二', '三', '四', '五', '六');
        $n = min(count($dates), 4);
        for ($i = 0; $i < $n; $i++) {
            $ts = strtotime((string) $dates[$i]);
            $forecast[] = array(
                'date' => date('n/j', $ts),
                'week' => '周' . $weekMap[(int) date('w', $ts)],
                'weather_day' => self::wmoText(isset($wcodes[$i]) ? (int) $wcodes[$i] : 0),
                'temp_min' => isset($tmin[$i]) ? (string) round($tmin[$i]) : '',
                'temp_max' => isset($tmax[$i]) ? (string) round($tmax[$i]) : '',
                'uv_max' => isset($uvmax[$i]) && is_numeric($uvmax[$i]) ? round((float) $uvmax[$i], 1) : null,
                'pop_max' => isset($popmax[$i]) && is_numeric($popmax[$i]) ? (int) $popmax[$i] : null,
                'wind_max' => isset($wmax[$i]) && is_numeric($wmax[$i]) ? round((float) $wmax[$i], 1) : null
            );
        }

        $keep = array(
            'city' => (string) $cityLabel,
            'province' => (string) $regionLabel,
            'district' => '',
            'weather' => $wtext,
            'temperature' => isset($cur['temperature_2m']) ? round($cur['temperature_2m'], 1) : null,
            'wind_direction' => $wd !== null ? self::windDir($wd) : '',
            'wind_power' => $ws !== null ? self::windLevel($ws) : '',
            'humidity' => isset($cur['relative_humidity_2m']) ? (int) $cur['relative_humidity_2m'] : null,
            'feels_like' => isset($cur['apparent_temperature']) ? round($cur['apparent_temperature'], 1) : null,
            'aqi' => null,
            'aqi_category' => '',
            'visibility' => isset($cur['visibility']) ? round($cur['visibility'] / 1000, 1) : null,
            'pressure' => isset($cur['surface_pressure']) ? round($cur['surface_pressure']) : null,
            'uv_index' => isset($cur['uv_index']) && is_numeric($cur['uv_index']) ? round((float) $cur['uv_index'], 1) : null,
            'pop' => isset($popmax[0]) && is_numeric($popmax[0]) ? (int) $popmax[0] : null,
            'wind_max' => isset($wmax[0]) && is_numeric($wmax[0]) ? round((float) $wmax[0], 1) : null,
            'report_time' => date('Y-m-d H:i:s'),
            'temp_min' => !empty($tmin) ? round($tmin[0], 1) : null,
            'temp_max' => !empty($tmax) ? round($tmax[0], 1) : null,
            'forecast' => $forecast
        );
        $keep['place'] = self::weatherPlace($keep);
        $keep['icon'] = self::weatherIcon($wtext);
        $keep['wind'] = trim((string) $keep['wind_direction'] . ' ' . (string) $keep['wind_power']);
        $keep['time'] = substr((string) $keep['report_time'], 11, 5);
        return $keep;
    }

    private static function wmoText($code)
    {
        $map = array(
            0 => '晴', 1 => '大部晴朗', 2 => '局部多云', 3 => '阴',
            45 => '雾', 48 => '雾凇',
            51 => '小毛雨', 53 => '毛毛雨', 55 => '浓毛毛雨',
            56 => '冻毛雨', 57 => '浓冻毛雨',
            61 => '小雨', 63 => '中雨', 65 => '大雨',
            66 => '冻小雨', 67 => '冻大雨',
            71 => '小雪', 73 => '中雪', 75 => '大雪', 77 => '雪粒',
            80 => '小阵雨', 81 => '阵雨', 82 => '强阵雨',
            85 => '小阵雪', 86 => '大阵雪',
            95 => '雷暴', 96 => '雷暴伴小冰雹', 99 => '雷暴伴大冰雹'
        );
        return isset($map[(int) $code]) ? $map[(int) $code] : '多云';
    }

    private static function windDir($deg)
    {
        $dirs = array('北', '东北', '东', '东南', '南', '西南', '西', '西北');
        $i = (int) round(((float) $deg % 360) / 45) % 8;
        return $dirs[$i] . '风';
    }

    private static function windLevel($ms)
    {
        $limits = array(0.3, 1.6, 3.4, 5.5, 8.0, 10.8, 13.9, 17.2, 20.8, 24.5, 28.5, 32.7);
        $n = 0;
        foreach ($limits as $lim) {
            if ((float) $ms <= $lim) {
                break;
            }
            $n++;
        }
        return $n . '级';
    }

    private static function weatherPlace($w)
    {
        $city = (string) ($w['city'] ?? '');
        $district = (string) ($w['district'] ?? '');
        if ($district !== '' && ($city === '' || mb_strpos($city, $district) === false)) {
            return $city !== '' ? $city . ' · ' . $district : $district;
        }
        return $city !== '' ? $city : (string) ($w['province'] ?? '');
    }

    private static function weatherIcon($text)
    {
        $t = (string) $text;
        if (mb_strpos($t, '雷') !== false) {
            return 'i-w-thunder';
        }
        if (mb_strpos($t, '雪') !== false) {
            return 'i-w-snow';
        }
        if (mb_strpos($t, '雨') !== false) {
            return 'i-w-rain';
        }
        if (preg_match('/雾|霾|沙|尘/u', $t)) {
            return 'i-w-fog';
        }
        if (preg_match('/阴|云/u', $t)) {
            return 'i-w-cloud';
        }
        return 'i-w-sun';
    }

    private static function weatherGrid($w)
    {
        $cells = array();
        $cells[] = array('体感', is_numeric($w['feels_like'] ?? null) ? round($w['feels_like']) . '°' : '—');
        $cells[] = array('湿度', is_numeric($w['humidity'] ?? null) ? $w['humidity'] . '%' : '—');
        if (is_numeric($w['aqi'] ?? null)) {
            $cells[] = array('空气', trim((string) ($w['aqi_category'] ?? '') . ' ' . $w['aqi']));
        } elseif (is_numeric($w['visibility'] ?? null)) {
            $cells[] = array('能见度', $w['visibility'] . 'km');
        } else {
            $cells[] = array('气压', is_numeric($w['pressure'] ?? null) ? $w['pressure'] . 'hPa' : '—');
        }

        $html = '';
        foreach ($cells as $c) {
            $html .= '<div><i>' . htmlspecialchars($c[0]) . '</i><b>' . htmlspecialchars($c[1]) . '</b></div>';
        }
        return $html;
    }

    private static function weatherForecast($w)
    {
        if (empty($w['forecast']) || !is_array($w['forecast'])) {
            return '';
        }
        $html = '';
        foreach ($w['forecast'] as $f) {
            if (!is_array($f)) {
                continue;
            }
            $day = (($f['week'] ?? '') !== '') ? $f['week'] : ($f['date'] ?? '');
            $html .= '<div><b>' . htmlspecialchars((string) $day) . '</b>'
                . htmlspecialchars((string) ($f['weather_day'] ?? '')) . '<br>'
                . htmlspecialchars((string) ($f['temp_min'] ?? '')) . '° ~ ' . htmlspecialchars((string) ($f['temp_max'] ?? '')) . '°</div>';
        }
        return $html;
    }

    private static function weatherWidgetData()
    {
        try {
            require_once __DIR__ . '/weather/shared/load.php';
            $uid = (int) \Widget\User::alloc()->uid;
            $loc = \YxWeather\AccountLocation::sync($uid, \YxWeather\AccountLocation::clientIp());
            if (!$loc) {
                return array();
            }
            $mobile = self::isMobile();
            $place = \YxWeather\AccountLocation::decorate($loc);
            $nw = \YxWeather\WeatherSource::current(
                (float) $loc['lat'], (float) $loc['lon'], $place,
                $mobile ? 'mobile-weather' : 'desktop-weather', $mobile ? 180 : 300
            );
            if (!empty($nw['status'])) {
                return $nw;
            }
        } catch (\Throwable $e) {
        }
        return array();
    }

    private static function weatherWidget($icons)
    {
        $w = self::weatherWidgetData();
        $has = !empty($w['city']);

        $place = $has ? self::weatherPlace($w) : '定位中';
        $temp = ($has && is_numeric($w['temperature'] ?? null)) ? round($w['temperature']) . '°' : '--';
        $icon = $has ? self::weatherIcon($w['weather']) : 'i-cloud';
        $wind = trim((string) ($w['wind_direction'] ?? '') . ' ' . (string) ($w['wind_power'] ?? ''));
        $time = $has ? substr((string) $w['report_time'], 11, 5) : '—';

        $html = '<div class="yx-weather"' . ($has ? '' : ' data-empty="1"') . '>';
        $html .= '<button type="button" class="yx-weather-btn" aria-label="天气详情">';
        $html .= '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#' . $icon . '"></use></svg>';
        $html .= '<span class="t" data-w-temp>' . htmlspecialchars($temp) . '</span>';
        $html .= '<span class="c" data-w-city>' . htmlspecialchars($place) . '</span>';
        $html .= '</button>';

        $html .= '<div class="yx-wp" data-yx-wp>';
        $html .= '<div class="yx-wp-top">';
        $html .= '<div class="yx-wp-city"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-loc"></use></svg><span data-w-loc>' . htmlspecialchars($place) . '</span></div>';
        $html .= '<div class="yx-wp-time" data-w-time>' . htmlspecialchars($time) . ' 更新</div>';
        $html .= '</div>';
        $html .= '<div class="yx-wp-now">';
        $html .= '<div><div class="big" data-w-temp-big>' . ($has && is_numeric($w['temperature'] ?? null) ? round($w['temperature']) : '--') . '<sup>°C</sup></div></div>';
        $html .= '<div class="meta" data-w-meta>' . ($has ? htmlspecialchars((string) $w['weather']) . ($wind !== '' ? '<br>' . htmlspecialchars($wind) : '') : '等待定位') . '</div>';
        $html .= '<svg class="ic" data-w-icon viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#' . $icon . '"></use></svg>';
        $html .= '</div>';
        $html .= '<div class="yx-wp-grid" data-w-grid>' . self::weatherGrid($w) . '</div>';
        $html .= '<div class="yx-wp-fc" data-w-fc>' . self::weatherForecast($w) . '</div>';
        $html .= '<div class="yx-wp-city-row"><input type="text" placeholder="输入城市名后回车切换" aria-label="切换城市"><button type="button">切换</button></div>';
        $html .= '<div class="yx-wp-hint" data-w-hint></div>';
        $html .= '</div></div>';

        return $html;
    }

    public static function weatherCardHtml()
    {
        $w = self::weatherCached();
        if (empty($w['city'])) {
            return '<div class="yd-load err"><i></i>天气尚未获取'
                . '<button type="button" class="yd-retry" onclick="location.reload()">重新获取</button></div>';
        }
        $icon = self::weatherIcon($w['weather']);
        $temp = is_numeric($w['temperature'] ?? null) ? round($w['temperature']) : '--';
        $wind = trim((string) ($w['wind_direction'] ?? '') . ' ' . (string) ($w['wind_power'] ?? ''));
        $h = '<div class="yd-wxc">';
        $h .= '<div class="yx-wxc-top"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#' . $icon . '"></use></svg>'
            . '<b>' . htmlspecialchars($temp) . '°</b><span>' . htmlspecialchars($w['weather'] ?? '') . '</span></div>';
        $h .= '<div class="yd-wxc-place">' . htmlspecialchars(self::weatherPlace($w)) . '</div>';
        $h .= '<div class="yd-wxc-meta">';
        if (is_numeric($w['feels_like'] ?? null)) {
            $h .= '<span>体感 ' . round($w['feels_like']) . '°</span>';
        }
        if ($wind !== '') {
            $h .= '<span>' . htmlspecialchars($wind) . '</span>';
        }
        if (is_numeric($w['humidity'] ?? null)) {
            $h .= '<span>湿度 ' . $w['humidity'] . '%</span>';
        }
        $h .= '</div>';
        if (!empty($w['forecast']) && is_array($w['forecast'])) {
            $h .= '<div class="yd-wxc-fc">';
            foreach (array_slice($w['forecast'], 0, 4) as $f) {
                if (!is_array($f)) {
                    continue;
                }
                $h .= '<div><b>' . htmlspecialchars((string) (($f['week'] ?? '') !== '' ? $f['week'] : ($f['date'] ?? ''))) . '</b>'
                    . htmlspecialchars((string) ($f['weather_day'] ?? '')) . '<br>'
                    . htmlspecialchars((string) ($f['temp_min'] ?? '')) . '~' . htmlspecialchars((string) ($f['temp_max'] ?? '')) . '°</div>';
            }
            $h .= '</div>';
        }
        $h .= '</div>';
        return $h;
    }

    public static function lifeIndex($w)
    {
        if (!is_array($w) || empty($w['city'])) {
            return array();
        }
        $t = is_numeric($w['temperature'] ?? null) ? (float) $w['temperature'] : null;
        $feels = is_numeric($w['feels_like'] ?? null) ? (float) $w['feels_like'] : $t;
        $rh = is_numeric($w['humidity'] ?? null) ? (float) $w['humidity'] : null;
        $uv = is_numeric($w['uv_index'] ?? null) ? (float) $w['uv_index'] : null;
        $pop = is_numeric($w['pop'] ?? null) ? (int) $w['pop'] : null;
        $wind = is_numeric($w['wind_max'] ?? null) ? (float) $w['wind_max'] : null;
        $wtext = (string) ($w['weather'] ?? '');
        $hasRain = (bool) preg_match('/雨|雪|雹|霰/', $wtext);
        $hasFog = (bool) preg_match('/雾|霾|沙|尘/', $wtext);
        $out = array();

        if ($feels !== null) {
            if ($feels >= 32) {
                $dress = array('炎热', 'c-red', 'i-w-sun', '短袖、短裤、裙装等清凉透气的衣物，注意防暑降温多补水');
            } elseif ($feels >= 27) {
                $dress = array('热', 'c-orange', 'i-w-sun', '短袖、薄T恤、透气裤装，户外注意防晒');
            } elseif ($feels >= 22) {
                $dress = array('舒适', 'c-green', 'i-w-sun', '短袖或薄长袖，长裤或裙装均可，体感舒适');
            } elseif ($feels >= 18) {
                $dress = array('微凉', 'c-green', 'i-w-cloud', '长袖衬衫、薄外套或针织衫，早晚可加一件');
            } elseif ($feels >= 14) {
                $dress = array('凉', 'c-cyan', 'i-w-cloud', '夹克、风衣、薄毛衣，注意保暖别着凉');
            } elseif ($feels >= 9) {
                $dress = array('冷', 'c-blue', 'i-w-cloud', '厚外套、毛衣加马甲，围巾手套可备上');
            } elseif ($feels >= 3) {
                $dress = array('较冷', 'c-blue', 'i-w-snow', '棉服或薄羽绒服，注意头部和手脚保暖');
            } elseif ($feels >= -4) {
                $dress = array('很冷', 'c-purple', 'i-w-snow', '羽绒服、厚棉服，减少长时间户外暴露');
            } else {
                $dress = array('寒冷', 'c-purple', 'i-w-snow', '厚羽绒服加保暖内搭，谨防冻伤和失温');
            }
            $out[] = array('key' => 'dress', 'name' => '穿衣', 'level' => $dress[0], 'cls' => $dress[1],
                'icon' => $dress[2], 'advice' => $dress[3]);
        }

        if ($uv !== null) {
            if ($uv >= 11) {
                $uvL = array('极强', 'c-red', '尽量避免外出，必须出门请做好全面硬防晒');
            } elseif ($uv >= 8) {
                $uvL = array('很强', 'c-red', '避免长时间暴晒，防晒霜 + 遮阳伞 + 墨镜');
            } elseif ($uv >= 6) {
                $uvL = array('强', 'c-orange', '涂抹 SPF30+ 防晒霜，戴帽子或打伞');
            } elseif ($uv >= 3) {
                $uvL = array('中等', 'c-amber', '外出涂防晒霜，戴遮阳帽');
            } else {
                $uvL = array('弱', 'c-green', '无需特殊防护，可安心进行户外活动');
            }
            $out[] = array('key' => 'uv', 'name' => '紫外线', 'level' => $uvL[0], 'cls' => $uvL[1],
                'icon' => 'i-sun', 'advice' => $uvL[2]);
        }

        if ($pop !== null || $hasRain) {
            $p = $pop === null ? ($hasRain ? 80 : 10) : $pop;
            if ($p >= 70 || $hasRain) {
                $car = array('不宜', 'c-red', '有降水，洗车后很快会被弄脏，建议改期');
            } elseif ($p >= 40) {
                $car = array('较不宜', 'c-amber', '降水概率较高，洗车后短时间内容易脏');
            } elseif ($p >= 20) {
                $car = array('较适宜', 'c-cyan', '降水概率较低，可以洗车，注意短时变化');
            } else {
                $car = array('适宜', 'c-green', '无明显降水，适合洗车，能保持较久');
            }
            $out[] = array('key' => 'car', 'name' => '洗车', 'level' => $car[0], 'cls' => $car[1],
                'icon' => 'i-w-rain', 'advice' => $car[2]);
        }

        if ($feels !== null) {
            $bad = '';
            if ($feels >= 33) {
                $bad = '气温过高，容易中暑，建议改为室内运动';
            } elseif ($feels <= -6) {
                $bad = '气温过低，户外运动易冻伤，建议改为室内';
            } elseif ($hasRain && ($pop === null || $pop >= 50)) {
                $bad = '有降水，路面湿滑，不适宜户外运动';
            } elseif ($wind !== null && $wind >= 40) {
                $bad = '风力较大，不适宜户外剧烈运动';
            } elseif ($uv !== null && $uv >= 8) {
                $bad = '紫外线很强，户外运动请避开正午时段';
            } elseif ($hasFog) {
                $bad = '能见度较差或空气质量欠佳，建议改为室内运动';
            }
            if ($bad !== '') {
                $out[] = array('key' => 'sport', 'name' => '运动', 'level' => '较不宜', 'cls' => 'c-amber',
                    'icon' => 'i-run', 'advice' => $bad);
            } else {
                $out[] = array('key' => 'sport', 'name' => '运动', 'level' => '适宜', 'cls' => 'c-green',
                    'icon' => 'i-run', 'advice' => '天气条件良好，适合跑步、骑行等户外运动');
            }
        }

        if ($feels !== null && $rh !== null) {
            $thi = $feels - (0.55 - 0.0055 * $rh) * ($feels - 14.5);
            if ($thi >= 28) {
                $com = array('很热', 'c-red', '体感闷热难受，注意通风降温');
            } elseif ($thi >= 25) {
                $com = array('热', 'c-orange', '体感偏热，注意补水');
            } elseif ($thi >= 21) {
                $com = array('舒适', 'c-green', '体感舒适，最适宜工作与休息');
            } elseif ($thi >= 17) {
                $com = array('微凉', 'c-cyan', '体感微凉，可适当添衣');
            } elseif ($thi >= 12) {
                $com = array('凉', 'c-blue', '体感偏凉，注意保暖');
            } elseif ($thi >= 5) {
                $com = array('冷', 'c-blue', '体感冷，注意防寒');
            } else {
                $com = array('很冷', 'c-purple', '体感很冷，注意防寒防冻');
            }
            $out[] = array('key' => 'comfort', 'name' => '舒适度', 'level' => $com[0], 'cls' => $com[1],
                'icon' => 'i-heart', 'advice' => $com[2]);
        }

        if ($feels !== null) {
            $cold = 0;
            if ($feels <= 0 || $feels >= 30) {
                $cold += 2;
            } elseif ($feels <= 8 || $feels >= 27) {
                $cold += 1;
            }
            if ($hasRain) {
                $cold += 2;
            } elseif ($hasFog) {
                $cold += 1;
            }
            if ($wind !== null && $wind >= 30) {
                $cold += 1;
            }
            if ($rh !== null && ($rh >= 85 || $rh <= 25)) {
                $cold += 1;
            }
            if ($cold >= 4) {
                $cl = array('极易发', 'c-red', '感冒极易发生，请注意保暖、勤洗手、少去人群密集处');
            } elseif ($cold >= 2) {
                $cl = array('较易发', 'c-amber', '感冒较易发生，注意增减衣物、规律作息');
            } else {
                $cl = array('少发', 'c-green', '感冒少发，保持正常作息与通风即可');
            }
            $out[] = array('key' => 'cold', 'name' => '感冒', 'level' => $cl[0], 'cls' => $cl[1],
                'icon' => 'i-shield', 'advice' => $cl[2]);
        }

        return $out;
    }

    public static function lifeIndexHtml($w)
    {
        $items = self::lifeIndex($w);
        if (empty($items)) {
            return '<div class="yd-load"><i></i>生活指数获取中…</div>';
        }
        $h = '<div class="yd-life">';
        foreach ($items as $it) {
            $h .= '<div class="yd-life-i ' . htmlspecialchars($it['cls']) . '">';
            $h .= '<span class="tp"><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><use href="#'
                . htmlspecialchars($it['icon']) . '"></use></svg></span>';
            $h .= '<span class="tx"><b>' . htmlspecialchars($it['name']) . '</b><em>' . htmlspecialchars($it['level']) . '</em></span>';
            $h .= '<p class="ad">' . htmlspecialchars($it['advice']) . '</p>';
            $h .= '</div>';
        }
        $h .= '</div>';
        return $h;
    }

    private static function isMobile()
    {
        if (defined('YX_MOBILE')) {
            return (bool) YX_MOBILE;
        }
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
        if ($ua === '') {
            return false;
        }
        $ua = strtolower($ua);
        $keys = array('android', 'iphone', 'ipod', 'ipad', 'windows phone', 'blackberry', 'bb10', 'mini', 'mobile', 'mobi', 'symbian', 'harmonyos', 'hongmeng');
        foreach ($keys as $k) {
            if (strpos($ua, $k) !== false) {
                return true;
            }
        }
        if (strpos($ua, 'ipad') !== false || strpos($ua, 'tablet') !== false) {
            return true;
        }
        return false;
    }

    public static function remenu()
    {
        if (defined('YX_MENU')) {
            return;
        }
        define('YX_MENU', 1);

        \Widget\Options::alloc()->to($options);
        \Widget\User::alloc()->to($user);

        $plugin = self::conf();
        $menu = self::buildMenu();
        $current = self::currentKey();
        $icons = '';
        $name = htmlspecialchars($user->screenName);
        $siteTitle = htmlspecialchars($options->title);
        $siteIcon = self::siteIcon($plugin, $options);
        $siteLetter = htmlspecialchars(mb_substr($options->title, 0, 1));

        $bg = $plugin->bg ? trim($plugin->bg) : '';
        $railClass = 'yx-rail' . ($bg ? ' has-bg' : '') . (($plugin->bglj && $bg) ? ' has-blur' : '');
        $bgStyle = $bg ? ' style="--yx-rail-img:url(' . htmlspecialchars($bg) . ')"' : '';

        $menuHtml = self::menuMarkup($menu, $current, $icons);

        $title = self::pageTitle();

        $hour = (int) date('G');
        $greet = $hour < 5 ? '夜深了' : ($hour < 9 ? '早上好' : ($hour < 12 ? '上午好' : ($hour < 14 ? '中午好' : ($hour < 18 ? '下午好' : '晚上好'))));
        $weekMap = array('日', '一', '二', '三', '四', '五', '六');
        $dateStr = date('Y年n月j日') . ' 星期' . $weekMap[(int) date('w')];

        $showWeather = !isset($plugin->weather) || $plugin->weather;
        $showLogin = !isset($plugin->loginTime) || $plugin->loginTime;

        $dbx = \Typecho\Db::get();
        $waitingCmt = (int) $dbx->fetchObject(
            $dbx->select('COUNT(coid) AS num')->from('table.comments')->where('status = ?', 'waiting')
        )->num;
        $bellTip = $waitingCmt > 0
            ? '有 <b>' . $waitingCmt . '</b> 条评论等待审核'
            : '暂时没有待处理的审核';

        echo '</li></menu></nav></header>';

        echo self::spriteInline();
        $mobile = self::isMobile();

        $yxSiteUrl = rtrim((string) $options->siteUrl, '/') . '/';
        $yxLogoutUrl = (string) $options->logoutUrl;

        $frontLink = '<a class="yx-ico-btn" data-yx-front href="' . htmlspecialchars($yxSiteUrl, ENT_QUOTES) . '" target="_blank" rel="noopener" aria-label="查看前台" title="查看前台（在新窗口打开站点前台）">'
            . '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-link"></use></svg></a>';
        $logoutLink = '<a class="yx-ico-btn danger" data-yx-logout href="' . htmlspecialchars($yxLogoutUrl, ENT_QUOTES) . '" aria-label="退出后台" title="退出后台（退出当前管理员登录）">'
            . '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-out"></use></svg></a>';

        if ($mobile) {
            echo '<div class="yx-shell yx-shell-m">';
            echo '<div class="yx-stage">';
            echo '<div class="yx-mtop">';
            echo '<button type="button" class="yx-mburger" aria-label="打开菜单"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-menu"></use></svg></button>';
            echo '<h1>' . $title . '</h1>';
            echo '<div class="yx-mtools">';
            echo '<button type="button" class="yx-ico-btn yx-theme-btn" data-yx-theme-btn aria-label="切换白天 / 夜间模式" title="切换白天 / 夜间模式">'
                . '<svg class="i-moon" viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-moon"></use></svg>'
                . '<svg class="i-sun" viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-sun"></use></svg>'
                . '</button>';
            if ($showLogin) {
                echo '<span class="yx-chip yx-login yx-login-mini" data-yx-login data-yx-uid="' . (int) $user->uid . '">'
                    . '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-clock"></use></svg>'
                    . '<span data-yx-login-txt>—</span></span>';
            }
            if ($showWeather && !$mobile) {
                echo self::weatherWidget($icons);
            }
            echo '</div>';
            echo '</div>';
            echo '<main class="yx-main"><div class="yx-wrap">';
            return;
        }

        echo '<div class="yx-shell">';
        echo '<aside class="' . $railClass . '"' . $bgStyle . '>';
        echo '<div class="yx-rail-head">';
        echo '<div class="yx-logo"><img class="ic" src="' . htmlspecialchars($siteIcon) . '" alt=""'
            . ' onerror="this.classList.add(\'off\');this.parentNode.classList.add(\'noimg\');">'
            . '<span class="fb">' . $siteLetter . '</span></div>';
        echo '<div class="yx-site"><strong>' . $siteTitle . '</strong><span>YunxiAdmin</span></div>';
        echo '</div>';
        echo '<nav class="yx-nav">' . $menuHtml . '</nav>';
        echo '</aside>';

        echo '<div class="yx-stage">';
        echo '<header class="yx-topbar">';
        echo '<span class="yx-crumb">' . $title . '<span class="yx-greet">' . $greet . '，' . $name . '</span></span>';
        echo '<div class="yx-top-tools">';

        echo '<span class="yx-chip yx-date"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-calendar"></use></svg>' . $dateStr . '</span>';

        echo '<button type="button" class="yx-ico-btn yx-search-btn" data-yx-search aria-label="搜索后台与内容" title="搜索菜单 / 文章 / 用户（Ctrl+K）">'
            . '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-search"></use></svg>'
            . '</button>';

        if ($showWeather) {
            echo self::weatherWidget($icons);
        }

        if ($showLogin) {
            echo '<span class="yx-chip yx-login" data-yx-login data-yx-uid="' . (int) $user->uid . '">'
                . '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-clock"></use></svg>'
                . '<span data-yx-login-txt>已登录 —</span></span>';
        }

        echo '<button type="button" class="yx-ico-btn yx-theme-btn" data-yx-theme-btn aria-label="切换白天 / 夜间模式">'
            . '<svg class="i-moon" viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-moon"></use></svg>'
            . '<svg class="i-sun" viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-sun"></use></svg>'
            . '</button>';

        echo '<button type="button" class="yx-ico-btn yx-bell" data-yx-toast="' . $bellTip . '" aria-label="通知">'
            . '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-bell"></use></svg>'
            . ($waitingCmt > 0 ? '<span class="dot">' . ($waitingCmt > 99 ? '99+' : $waitingCmt) . '</span>' : '')
            . '</button>';

        echo $frontLink;
        echo $logoutLink;

        echo '</div></header>';

        echo '<main class="yx-main"><div class="yx-wrap">';
    }

    private static function menuMarkup($menu, $current, $icons)
    {
        $html = '';
        foreach ($menu as $node) {
            if (!$node['count']) {
                continue;
            }
            $html .= '<div class="yx-sec">';
            $html .= '<div class="yx-sec-t">' . $node['title'] . '</div>';
            foreach ($node['children'] as $child) {
                $nm = htmlspecialchars((string) $child['name']);
                $tip = htmlspecialchars((string) $node['title'] . ' · ' . $child['name']);
                $html .= '<a class="yx-mitem' . ($child['on'] ? ' on' : '') . '" href="' . $child['url'] . '" data-tip="' . $tip . '" aria-label="' . $nm . '">';
                $html .= '<span class="yx-ico"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#' . $child['icon'] . '"></use></svg></span>';
                $html .= '<span class="yx-lab">' . $child['name'] . '</span>';
                if (!empty($child['badge'])) {
                    $html .= '<span class="yx-tag">' . $child['badge'] . '</span>';
                }
                $html .= '</a>';
            }
            $html .= '</div>';
        }
        return $html;
    }

    public static function siteIcon($plugin, $options)
    {
        $icon = $plugin->logo ? trim($plugin->logo) : '';
        if ($icon === '') {
            $icon = rtrim((string) $options->siteUrl, '/') . '/favicon.ico';
        }
        return $icon;
    }

    public static function levelInfo($group)
    {
        $levels = array(
            'administrator' => array(
                'name' => '管理员', 'short' => '管理员', 'cls' => 'lv-admin',
                'desc' => '站点最高权限，可管理用户、插件、主题、备份与全部设置。'
            ),
            'editor' => array(
                'name' => '编辑', 'short' => '编辑', 'cls' => 'lv-editor',
                'desc' => '可撰写并管理全站的文章、页面、分类、标签与文件，不能改动站点设置。'
            ),
            'contributor' => array(
                'name' => '贡献者', 'short' => '贡献者', 'cls' => 'lv-contrib',
                'desc' => '可撰写与管理自己的文章，并参与评论审核。'
            ),
            'subscriber' => array(
                'name' => '订阅者', 'short' => '订阅者', 'cls' => 'lv-sub',
                'desc' => '仅可查看后台概要与维护个人资料。'
            )
        );

        $group = (string) $group;
        if (isset($levels[$group])) {
            return $levels[$group];
        }
        return array(
            'name' => '访客', 'short' => '访客', 'cls' => 'lv-sub',
            'desc' => '尚未分配后台权限，请联系管理员调整用户组。'
        );
    }

    public static function footerjs()
    {
        if (defined('YX_FOOTER')) {
            return;
        }
        define('YX_FOOTER', 1);

        $plugin = self::conf();
        \Widget\Options::alloc()->to($options);
        \Widget\User::alloc()->to($user);

        $url = $options->pluginUrl . '/YunxiAdmin/assets/';
        $api = self::sameOriginUrl($options->pluginUrl . '/YunxiAdmin/api.php');
        $icons = '';

        $yxSiteUrl = rtrim((string) $options->siteUrl, '/') . '/';
        $yxLogoutUrl = (string) $options->logoutUrl;
        $script = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
        $mobile = self::isMobile();
        $shellJs = $mobile ? 'shell-mobile.js' : 'shell.js';

        if (!User::alloc()->hasLogin()) {
            echo '<script src="' . $url . 'js/' . $shellJs . '?v=' . self::VERSION . '"></script>';
            return;
        }

        echo '</main></div></div></div>';

        echo self::spriteInline();

        echo '<script>(function(){var k=window.YXKillNative;if(k){try{k();}catch(e){}}})();</script>';

        echo '<aside class="yx-drawer">';
        echo '<div class="yx-dhead">';
        echo '<div class="yx-logo"><img class="ic" src="' . htmlspecialchars(self::siteIcon($plugin, $options)) . '" alt=""'
            . ' onerror="this.classList.add(\'off\');this.parentNode.classList.add(\'noimg\');">'
            . '<span class="fb">' . htmlspecialchars(mb_substr($options->title, 0, 1)) . '</span></div>';
        echo '<div class="yx-site"><strong>' . htmlspecialchars($options->title) . '</strong><span>YunxiAdmin</span></div>';
        echo '<button type="button" class="yx-dclose" aria-label="关闭菜单"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-x"></use></svg></button>';
        echo '</div>';
        echo '<div class="yx-dbody">';
        echo self::menuMarkup(self::buildMenu(), self::currentKey(), $icons);
        echo '</div>';
        echo '<div class="yx-dfoot">';
        echo '<a data-yx-front href="' . htmlspecialchars($yxSiteUrl, ENT_QUOTES) . '" target="_blank" rel="noopener" title="查看前台" aria-label="查看前台"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-link"></use></svg><span class="tx">查看前台</span></a>';
        echo '<a class="danger" data-yx-logout href="' . htmlspecialchars($yxLogoutUrl, ENT_QUOTES) . '" title="退出后台" aria-label="退出后台"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="' . $icons . '#i-out"></use></svg><span class="tx">退出后台</span></a>';
        echo '</div></aside>';
        echo '<div class="yx-scrim"></div>';

        if ($plugin->speed) {
            $mode = $plugin->speed == 1 ? 'moderate' : 'eager';
            $dir = __TYPECHO_ADMIN_DIR__;
            $pages = array('', 'profile.php', 'plugins.php', 'themes.php', 'backup.php', 'extending.php',
                'write-post.php', 'write-page.php', 'manage-posts.php', 'manage-pages.php',
                'manage-comments.php', 'manage-categories.php', 'manage-tags.php', 'manage-medias.php',
                'manage-users.php', 'options-general.php', 'options-discussion.php', 'options-reading.php',
                'options-permalink.php', 'options-plugin.php', 'theme-editor.php', 'options-theme.php',
                'category.php', 'media.php', 'user.php');

            $rules = array();
            foreach ($pages as $p) {
                $rules[] = '{"where":{"href_matches":["' . $dir . $p . '"]},"eagerness":"' . $mode . '"}';
            }

            echo '<script type="speculationrules">{"prefetch":[' . implode(',', $rules) . ']}</script>';
        }

        $isEditor = $script === 'write-post.php' || $script === 'write-page.php';
        $isSetting = $script === 'options-plugin.php' && strpos((string) ($_SERVER['REQUEST_URI'] ?? ''), 'config=YunxiAdmin') !== false;
        $needPage = in_array($script, array('profile.php', 'manage-users.php', 'manage-medias.php', 'plugins.php',
            'manage-posts.php', 'manage-pages.php', 'manage-comments.php', 'manage-categories.php', 'manage-tags.php'), true)
            || $isSetting;

        $pluginBase = rtrim((string) $options->pluginUrl, '/') . '/YunxiAdmin/';
        echo '<script>window.YX_ICONS=' . json_encode($icons) . ',window.YX_API=' . json_encode($api) . ','
            . 'window.YX_WEATHER_END=' . json_encode($mobile ? 'mobile' : 'desktop') . ','
            . 'window.YX_WEATHER_DESKTOP_API=' . json_encode(self::sameOriginUrl($pluginBase . 'api-desktop.php')) . ','
            . 'window.YX_WEATHER_MOBILE_API=' . json_encode(self::sameOriginUrl($pluginBase . 'api-mobile.php')) . ','
            . 'window.YX_CFG=' . json_encode(array(
                'adminUrl' => rtrim($options->adminUrl, '/') . '/',
                'siteUrl' => rtrim($options->siteUrl, '/') . '/',
                'logoutUrl' => (string) $options->logoutUrl,
                'version' => self::VERSION
            ), JSON_UNESCAPED_UNICODE) . ';</script>';

        if ($script === 'manage-comments.php') {
            $emoji = self::emojiAssets();
            if ($emoji) {
                echo '<script>window.YX_EMOJI=' . json_encode($emoji, JSON_UNESCAPED_UNICODE) . ';</script>';
            }
        }

        echo '<script src="' . $url . 'js/' . $shellJs . '?v=' . self::VERSION . '"></script>';

        if ($isEditor) {
            echo '<script src="' . $url . 'js/editor.js?v=' . self::VERSION . '"></script>';
        }
        if ($needPage) {
            echo '<script src="' . $url . 'js/page.js?v=' . self::VERSION . '"></script>';
        }
        if (defined('YX_DASH')) {
            echo '<script src="' . $url . 'js/run.js?v=' . self::VERSION . '"></script>';

            $wxJs = 'weather-' . ($mobile ? 'mobile' : 'desktop') . '.js';
            echo '<script src="' . $url . 'js/' . $wxJs . '?v=' . self::VERSION . '.'
                . (int) @filemtime(__DIR__ . '/assets/js/' . $wxJs) . '"></script>';
        }

        echo '<script>(function(){var k=window.YXKillNative,b=function(){try{k&&k();}catch(e){}};b();'
            . 'document.addEventListener("DOMContentLoaded",b);window.addEventListener("load",b);'
            . 'setTimeout(b,900);})();</script>';
    }

    private static function buildMenu()
    {
        \Widget\Menu::alloc()->to($menu);
        \Widget\Options::alloc()->to($options);
        \Widget\User::alloc()->to($user);

        $current = self::currentKey();

        $waitingCmt = 0;
        if ($user->pass('contributor', true)) {
            $dbx = \Typecho\Db::get();
            $waitingCmt = (int) $dbx->fetchObject(
                $dbx->select('COUNT(coid) AS num')->from('table.comments')->where('status = ?', 'waiting')
            )->num;
        }

        $groups = array(
            'write' => array('title' => _t('撰写'), 'icon' => 'i-write'),
            'manage' => array('title' => _t('管理'), 'icon' => 'i-file'),
            'setting' => array('title' => _t('设置'), 'icon' => 'i-gear')
        );

        $items = array(
            'index' => array('name' => _t('概要'), 'url' => 'index.php', 'icon' => 'i-home', 'access' => 'subscriber'),
            'profile' => array('name' => _t('个人设置'), 'url' => 'profile.php', 'icon' => 'i-user', 'access' => 'subscriber'),
            'plugins' => array('name' => _t('插件管理'), 'url' => 'plugins.php', 'icon' => 'i-plug', 'access' => 'administrator'),
            'themes' => array('name' => _t('网站外观'), 'url' => 'themes.php', 'icon' => 'i-paint', 'access' => 'administrator'),
            'backup' => array('name' => _t('备份'), 'url' => 'backup.php', 'icon' => 'i-shield', 'access' => 'administrator'),
            'write-post' => array('name' => _t('撰写文章'), 'url' => 'write-post.php', 'icon' => 'i-write', 'access' => 'contributor'),
            'write-page' => array('name' => _t('创建页面'), 'url' => 'write-page.php', 'icon' => 'i-page', 'access' => 'editor'),
            'manage-posts' => array('name' => _t('文章'), 'url' => 'manage-posts.php', 'icon' => 'i-post', 'access' => 'contributor'),
            'manage-pages' => array('name' => _t('独立页面'), 'url' => 'manage-pages.php', 'icon' => 'i-page', 'access' => 'editor'),
            'manage-comments' => array('name' => _t('评论'), 'url' => 'manage-comments.php', 'icon' => 'i-cmt', 'access' => 'contributor'),
            'manage-categories' => array('name' => _t('分类'), 'url' => 'manage-categories.php', 'icon' => 'i-cat', 'access' => 'editor'),
            'manage-tags' => array('name' => _t('标签'), 'url' => 'manage-tags.php', 'icon' => 'i-tag', 'access' => 'editor'),
            'manage-medias' => array('name' => _t('文件'), 'url' => 'manage-medias.php', 'icon' => 'i-file', 'access' => 'editor'),
            'manage-users' => array('name' => _t('用户'), 'url' => 'manage-users.php', 'icon' => 'i-users', 'access' => 'administrator'),
            'options-general' => array('name' => _t('基本设置'), 'url' => 'options-general.php', 'icon' => 'i-gear', 'access' => 'administrator'),
            'options-discussion' => array('name' => _t('评论设置'), 'url' => 'options-discussion.php', 'icon' => 'i-cmt', 'access' => 'administrator'),
            'options-reading' => array('name' => _t('阅读设置'), 'url' => 'options-reading.php', 'icon' => 'i-post', 'access' => 'administrator'),
            'options-permalink' => array('name' => _t('永久链接'), 'url' => 'options-permalink.php', 'icon' => 'i-link', 'access' => 'administrator')
        );

        $map = array(
            'write' => array('write-post', 'write-page'),
            'manage' => array('manage-posts', 'manage-pages', 'manage-comments', 'manage-categories', 'manage-tags', 'manage-medias', 'manage-users'),
            'setting' => array('plugins', 'themes', 'backup', 'options-general', 'options-discussion', 'options-reading', 'options-permalink')
        );

        $result = array();
        foreach ($map as $key => $keys) {
            $group = $groups[$key];
            $children = array();
            $count = 0;
            $isParent = false;

            foreach ($keys as $itemKey) {
                $item = $items[$itemKey];
                if (!$user->pass($item['access'], true)) {
                    continue;
                }
                $count++;
                if ($current === $itemKey) {
                    $isParent = true;
                }
                $children[] = array(
                    'name' => $item['name'],
                    'url' => Common::url($item['url'], $options->adminUrl),
                    'icon' => $item['icon'],
                    'on' => $current === $itemKey,
                    'badge' => ($itemKey === 'manage-comments' && $waitingCmt > 0)
                        ? ($waitingCmt > 99 ? '99+' : $waitingCmt)
                        : ''
                );
            }

            if (!$count) {
                continue;
            }

            $result[$key] = array(
                'title' => $group['title'],
                'icon' => $group['icon'],
                'count' => $count,
                'parent' => $isParent,
                'children' => $children
            );
        }

        if ($user->pass('subscriber', true)) {
            array_unshift($result, array(
                'title' => _t('控制台'),
                'icon' => 'i-user',
                'count' => 2,
                'parent' => in_array($current, array('index', 'profile'), true),
                'children' => array(
                    array(
                        'name' => _t('概要'),
                        'url' => Common::url('index.php', $options->adminUrl),
                        'icon' => 'i-home',
                        'on' => $current === 'index',
                        'badge' => ''
                    ),
                    array(
                        'name' => _t('个人设置'),
                        'url' => Common::url('profile.php', $options->adminUrl),
                        'icon' => 'i-user',
                        'on' => $current === 'profile',
                        'badge' => ''
                    )
                )
            ));
        }

        return $result;
    }

    private static function currentKey()
    {
        $path = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
        $key = $path === '' ? 'index' : preg_replace('/\.php$/', '', $path);
        if (!isset($_GET['cid']) && !isset($_GET['mid']) && !isset($_GET['uid']) && !isset($_GET['config'])) {
            return $key;
        }

        if (isset($_GET['cid'])) {
            return $key === 'write-page' ? 'write-page' : 'write-post';
        }
        if (isset($_GET['mid'])) {
            return isset($_GET['type']) && $_GET['type'] === 'tag' ? 'manage-tags' : 'manage-categories';
        }
        if (isset($_GET['uid'])) {
            return $key === 'user' ? 'user' : 'manage-users';
        }
        return $key;
    }

    private static function pageTitle()
    {
        $map = array(
            'index' => '工作台',
            'profile' => '个人设置',
            'plugins' => '插件管理',
            'themes' => '网站外观',
            'backup' => '备份',
            'welcome' => '欢迎使用',
            'write-post' => '撰写文章',
            'write-page' => '创建页面',
            'manage-posts' => '管理文章',
            'manage-pages' => '管理页面',
            'manage-comments' => '管理评论',
            'manage-categories' => '管理分类',
            'manage-tags' => '管理标签',
            'manage-medias' => '媒体库',
            'manage-users' => '管理用户',
            'user' => '用户',
            'category' => '分类',
            'media' => '媒体',
            'options-general' => '基本设置',
            'options-discussion' => '评论设置',
            'options-reading' => '阅读设置',
            'options-permalink' => '永久链接设置',
            'options-plugin' => '插件设置',
            'options-theme' => '外观设置',
            'theme-editor' => '主题编辑',
            'extending' => '扩展设置'
        );

        $key = self::currentKey();
        $name = $map[$key] ?? '后台';
        return '<b>' . htmlspecialchars($name) . '</b>';
    }

    public static function pltx($size, $rating, $default, $obj)
    {
        try {
            $email = isset($obj->mail) ? (string) $obj->mail : '';
            $menu = null;
            $inCommentAdmin = false;
            try {
                \Widget\Menu::alloc()->to($menu);
                $cur = $menu->getCurrentMenu();
                if (is_array($cur) && isset($cur[2]) && is_string($cur[2])) {
                    $inCommentAdmin = strpos($cur[2], 'manage-comments.php') !== false;
                }
            } catch (\Throwable $e) {
                $inCommentAdmin = false;
            }

            if ($email && $inCommentAdmin) {
                $url = self::avatarUrl($email, 'blank');
            } else {
                $url = Common::gravatarUrl($email, 220, 'X', $default, $obj->request->isSecure());
            }
            $url = htmlspecialchars((string) $url, ENT_QUOTES);
            $author = htmlspecialchars((string) (isset($obj->author) ? $obj->author : ''), ENT_QUOTES);
            $size = (int) $size;

            if ($menu && !empty($menu->title) && $inCommentAdmin) {
                echo '<span class="zx-double"><img class="avatar a" src="' . $url . '" alt="' . $author
                    . '" width="' . $size . '" height="' . $size . '" />'
                    . '<img class="avatar b" src="' . htmlspecialchars(self::letterAvatar($author), ENT_QUOTES) . '" alt="' . $author
                    . '" width="' . $size . '" height="' . $size . '" /></span>';
            } else {
                echo '<img class="avatar" loading="lazy" decoding="async" src="' . $url . '" alt="' . $author
                    . '" width="' . $size . '" height="' . $size . '" />';
            }
        } catch (\Throwable $e) {
        }
    }

    public static function urlfilter($val, $obj)
    {
        try {
            if (!is_array($val)) {
                return $val;
            }
            $plugin = self::conf();
            if ($plugin->urlfilter > 1) {
                $days = ($plugin->urlfilter - 1) * 15;
                if (isset($val['created']) && $val['created'] < time() - ($days * 86400)) {
                    $val['url'] = '';
                }
            } elseif ($plugin->urlfilter == 1) {
                $val['url'] = '';
            }
        } catch (\Throwable $e) {
        }
        return $val;
    }

    public static function gravatarHost($v = null)
    {
        if ($v === null) {
            try {
                $v = self::conf()->gravatars;
            } catch (\Throwable $e) {
                $v = '';
            }
        }
        if (is_array($v)) {
            $v = (string) reset($v);
        }
        $v = trim((string) $v);
        $v = preg_replace('#^[a-z]+://#i', '', $v);
        $v = preg_replace('#^//#', '', $v);
        $v = trim($v, '/ ');
        if ($v === '' || !preg_match('#^[A-Za-z0-9.\-:]+$#', $v)) {
            $v = 'weavatar.com/avatar';
        }
        return $v;
    }

    private static function sanitizeColor($color, $default)
    {
        $color = trim((string) $color);
        if (preg_match('/^#[0-9a-fA-F]{3}$/', $color) || preg_match('/^#[0-9a-fA-F]{6}$/', $color)) {
            return $color;
        }
        return $default;
    }

    public static function avatarUrl($mail, $type = 'mm')
    {
        \Widget\Options::alloc()->to($options);
        $mail = strtolower((string) $mail);
        $qq = str_replace('@qq.com', '', $mail);
        if (strstr($mail, 'qq.com') && is_numeric($qq) && strlen($qq) < 11 && strlen($qq) > 4) {
            return 'https://q2.qlogo.cn/headimg_dl?dst_uin=' . $qq . '&spec=640';
        }
        return Common::gravatarUrl($mail, 220, 'X', $type, $options->request->isSecure());
    }

    private static function letterAvatar($text)
    {
        $hue = unpack('L', hash('adler32', (string) $text, true))[1] % 360;
        list($r, $g, $b) = self::hsv2rgb($hue / 360, 0.32, 0.88);

        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'
            . '<rect fill="rgb(' . $r . ',' . $g . ',' . $b . ')" width="100" height="100"/>'
            . '<text x="50" y="50" font-family="-apple-system,sans-serif" font-size="46" font-weight="500"'
            . ' fill="#fff" text-anchor="middle" dominant-baseline="central">'
            . htmlspecialchars(mb_strtoupper(mb_substr((string) $text, 0, 1)))
            . '</text></svg>';

        return 'data:image/svg+xml;base64,' . base64_encode($svg);
    }

    private static function hsv2rgb($h, $s, $v)
    {
        $i = floor($h * 6);
        $f = $h * 6 - $i;
        $p = $v * (1 - $s);
        $q = $v * (1 - $f * $s);
        $t = $v * (1 - (1 - $f) * $s);

        switch ($i % 6) {
            case 0: $rgb = array($v, $t, $p); break;
            case 1: $rgb = array($q, $v, $p); break;
            case 2: $rgb = array($p, $v, $t); break;
            case 3: $rgb = array($p, $q, $v); break;
            case 4: $rgb = array($t, $p, $q); break;
            default: $rgb = array($v, $p, $q); break;
        }

        return array(
            (int) floor($rgb[0] * 255),
            (int) floor($rgb[1] * 255),
            (int) floor($rgb[2] * 255)
        );
    }

    private static function ensureVisitTable()
    {
        try {
            $db = \Typecho\Db::get();
            $prefix = $db->getPrefix();

            $mysql = 'CREATE TABLE IF NOT EXISTS `' . $prefix . 'yx_visits` ('
                . '`day` date NOT NULL,'
                . '`kind` varchar(20) NOT NULL DEFAULT \'\','
                . '`hits` int(10) unsigned NOT NULL DEFAULT 0,'
                . '`updated` int(10) unsigned NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`day`,`kind`),'
                . 'KEY `updated` (`updated`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';

            $sqlite = 'CREATE TABLE IF NOT EXISTS `' . $prefix . 'yx_visits` ('
                . '`day` TEXT NOT NULL,'
                . '`kind` TEXT NOT NULL DEFAULT \'\','
                . '`hits` INTEGER NOT NULL DEFAULT 0,'
                . '`updated` INTEGER NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`day`,`kind`))';
            try {
                $db->query($mysql);
            } catch (\Throwable $e) {

                try {
                    $db->query($sqlite);
                } catch (\Throwable $e2) {
                    $db->query(str_replace('utf8mb4', 'utf8', $mysql));
                }
            }
        } catch (\Throwable $e) {
        }
    }

    public static function uaKind($ua)
    {
        $ua = (string) $ua;
        $kinds = array(
            'baidu' => array('Baiduspider'),
            'google' => array('Googlebot', 'Google-InspectionTool', 'AdsBot-Google', 'Storebot-Google', 'GoogleOther', 'Mediapartners-Google', 'Google-Read-Aloud', 'APIs-Google'),
            'bing' => array('bingbot', 'BingPreview', 'adidxbot', 'msnbot'),
            'sogou' => array('Sogou', 'SogouPicSpider', 'SogouNews'),
            'so' => array('360Spider', 'HaoSouSpider', 'HaosouSpider'),
            'yandex' => array('YandexBot', 'YandexImages', 'YandexMobileBot', 'YandexAccessibilityBot'),
            'duck' => array('DuckDuckBot', 'DuckDuckGo-Favicons'),
            'bytes' => array('Bytespider', 'ByteSpider')
        );
        foreach ($kinds as $kind => $needles) {
            foreach ($needles as $needle) {
                if (stripos($ua, $needle) !== false) {
                    return $kind;
                }
            }
        }
        $named = array('YisouSpider', 'PetalBot', 'AspiegelBot', 'Quark', 'AhrefsBot', 'SemrushBot',
            'MJ12bot', 'DotBot', 'Screaming Frog', 'SEOkicksBot', 'BLEXBot', 'DataForSeoBot', 'MegaIndex',
            'serpstatbot', 'LinkpadBot', 'SISTRIX', 'OnCrawl', 'Botify', 'Lumar', 'ClaudeBot', 'GPTBot',
            'CCBot', 'PerplexityBot', 'Amazonbot', 'Applebot', 'NaverBot', 'facebookexternalhit',
            'Twitterbot', 'LinkedInBot', 'Discordbot', 'TelegramBot', 'WhatsApp', 'Slackbot',
            'Pinterest', 'redditbot', 'vkShare', 'Embedly', 'Iframely', 'Feedly', 'Feedbin',
            'Feedfetcher', 'Superfeedr', 'W3C_Validator', 'Wget', 'curl', 'python-requests',
            'Python-urllib', 'Go-http-client', 'Java/', 'okhttp', 'Apache-HttpClient', 'libwww-perl',
            'axios', 'node-fetch', 'undici', 'Scrapy', 'HTTPie', 'Postman', 'insomnia');
        foreach ($named as $needle) {
            if (stripos($ua, $needle) !== false) {
                $k = self::cleanSpiderKind($needle);
                if ($k !== '') {
                    return $k;
                }
            }
        }
        if (preg_match('/bot|spider|crawler|slurp|scraper|archiver|fetcher/i', $ua)) {
            if (preg_match('/([a-z0-9]*(?:bot|spider|crawler|slurp|scraper|archiver)[a-z0-9]*)/i', $ua, $mm)) {
                $k = self::cleanSpiderKind($mm[1]);
                if ($k !== '') {
                    return $k;
                }
            }
            return 'other';
        }
        return 'visit';
    }

    private static function cleanSpiderKind($name)
    {
        $name = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) $name);
        return (string) substr($name, 0, 20);
    }

    public static function dashLive()
    {
        $out = array(
            'status' => true,
            'updated' => date('H:i:s'),
            'advice' => array(),
            'counts' => array('high' => 0, 'mid' => 0, 'low' => 0),
            'pct' => 100,
            'week' => array('rows' => array(), 'total' => array('visit' => 0, 'spider' => 0, 'post' => 0, 'cmt' => 0, 'sum' => 0), 'avg' => array('visit' => 0, 'spider' => 0, 'post' => 0, 'cmt' => 0))
        );

        try {
            $db = \Typecho\Db::get();
            $options = \Widget\Options::alloc();
            $SORT_DESC = \Typecho\Db::SORT_DESC;

            try {
                $cfg = self::conf();
                if ((string) $cfg->collect_on_load !== '0') {
                    $out['collect'] = self::collectVisitsFromLog(false);
                }
            } catch (\Exception $e) {
                $out['collect'] = array('status' => false, 'reason' => '采集异常：' . $e->getMessage());
            }

            try {
                self::autoSeoSetup();
            } catch (\Exception $e) {
            }

            $postsNum = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.contents')->where('type = ? AND status = ?', 'post', 'publish'))->num;
            $draftNum = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.contents')->where('type = ? AND status = ?', 'post', 'draft'))->num;
            $cmtWaiting = (int) $db->fetchObject($db->select('COUNT(coid) AS num')->from('table.comments')->where('status = ?', 'waiting'))->num;
            $cmtSpam = (int) $db->fetchObject($db->select('COUNT(coid) AS num')->from('table.comments')->where('status = ?', 'spam'))->num;

            $seoTitle = trim((string) $options->title);
            $seoDesc = trim((string) $options->description);
            $seoHttps = stripos((string) $options->siteUrl, 'https://') === 0;
            $seoRewrite = !empty($options->rewrite);
            $root = rtrim((string) __TYPECHO_ROOT_DIR__, '/');
            $seoRobots = is_file($root . '/robots.txt');
            $seoSitemap = is_file($root . '/sitemap.xml');
            $seoDescNum = 0;
            try {
                $seoDescNum = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.fields')->where('name = ?', 'description'))->num;
            } catch (\Exception $e) {
            }
            $seoDescCov = $postsNum > 0 ? min(100, (int) round($seoDescNum * 100 / $postsNum)) : 0;

            $opcacheOn = extension_loaded('Zend OPcache') && ini_get('opcache.enable') ? 1 : 0;

            $keys = array();
            $visit = array();
            $spider = array();
            $post = array();
            $cmt = array();
            for ($i = 6; $i >= 0; $i--) {
                $k = date('Y-m-d', strtotime('-' . $i . ' days'));
                $keys[$k] = array('visit' => 0, 'spider' => 0, 'post' => 0, 'cmt' => 0);
            }
            try {
                $vRows = $db->fetchAll($db->select('day', 'kind', 'hits')->from('table.yx_visits')->where('day >= ?', date('Y-m-d', strtotime('-6 days'))));
                foreach ($vRows as $vr) {
                    $d = (string) $vr['day'];
                    if (!isset($keys[$d])) {
                        continue;
                    }
                    if ((string) $vr['kind'] === 'visit') {
                        $keys[$d]['visit'] += (int) $vr['hits'];
                    } else {
                        $keys[$d]['spider'] += (int) $vr['hits'];
                    }
                }
            } catch (\Exception $e) {
            }
            try {
                $pRows = $db->fetchAll($db->select('created')->from('table.contents')->where('type = ? AND status = ? AND created >= ?', 'post', 'publish', strtotime('-6 days')));
                foreach ($pRows as $pr) {
                    $d = date('Y-m-d', (int) $pr['created']);
                    if (isset($keys[$d])) {
                        $keys[$d]['post']++;
                    }
                }
            } catch (\Exception $e) {
            }
            try {
                $cRows = $db->fetchAll($db->select('created')->from('table.comments')->where('created >= ?', strtotime('-6 days')));
                foreach ($cRows as $cr) {
                    $d = date('Y-m-d', (int) $cr['created']);
                    if (isset($keys[$d])) {
                        $keys[$d]['cmt']++;
                    }
                }
            } catch (\Exception $e) {
            }

            $weekNames = array('日', '一', '二', '三', '四', '五', '六');
            $todayKey = date('Y-m-d');
            $total = array('visit' => 0, 'spider' => 0, 'post' => 0, 'cmt' => 0, 'sum' => 0);
            $maxSum = 0;
            $rows = array();
            foreach ($keys as $k => $v) {
                $sum = $v['visit'] + $v['spider'] + $v['post'] + $v['cmt'];
                $maxSum = max($maxSum, $sum);
                $total['visit'] += $v['visit'];
                $total['spider'] += $v['spider'];
                $total['post'] += $v['post'];
                $total['cmt'] += $v['cmt'];
                $total['sum'] += $sum;
                $ts = strtotime($k);
                $rows[] = array(
                    'date' => date('m-d', $ts),
                    'week' => '周' . $weekNames[(int) date('w', $ts)],
                    'visit' => $v['visit'],
                    'spider' => $v['spider'],
                    'post' => $v['post'],
                    'cmt' => $v['cmt'],
                    'sum' => $sum,
                    'today' => $k === $todayKey
                );
            }
            foreach ($rows as &$r) {
                $r['heat'] = $maxSum > 0 ? max($r['sum'] > 0 ? 6 : 0, (int) round($r['sum'] * 100 / $maxSum)) : 0;
            }
            unset($r);
            $out['week'] = array(
                'rows' => $rows,
                'total' => $total,
                'avg' => array(
                    'visit' => (int) round($total['visit'] / 7),
                    'spider' => (int) round($total['spider'] / 7),
                    'post' => (int) round($total['post'] / 7),
                    'cmt' => (int) round($total['cmt'] / 7)
                )
            );

            $advice = array();

            $add = function ($pri, $tag, $tone, $icon, $title, $desc, $metric, $url, $action, $fix = '') use (&$advice) {
                $advice[] = array(
                    'pri' => $pri,
                    'tag' => $tag,
                    'tone' => $tone,
                    'icon' => $icon,
                    'title' => $title,
                    'desc' => $desc,
                    'metric' => $metric,
                    'url' => $url,
                    'action' => $action,
                    'fix' => $fix
                );
            };

            if (!$seoHttps) {
                $add('high', '安全', 'red', 'i-shield', '开启全站 HTTPS',
                    '未加密的 HTTP 会被浏览器标记「不安全」，影响收录与信任',
                    '当前状态：未启用', 'options-general.php', '自动修复', 'https');
            }
            if ($cmtWaiting > 0) {
                $add('high', '互动', 'orange', 'i-cmt', '审核待审评论',
                    '留言得不到及时回应，互动氛围会慢慢冷下来',
                    '当前待审 ' . $cmtWaiting . ' 条', 'manage-comments.php?status=waiting', '自动放行', 'cmt');
            }
            if ($cmtSpam > 0) {
                $add('mid', '互动', 'orange', 'i-trash', '清理垃圾评论',
                    '垃圾外链可能拖累站点质量评定，建议及时清理',
                    '垃圾箱 ' . $cmtSpam . ' 条', 'manage-comments.php?status=spam', '自动清理', 'spam');
            }
            if (!$seoRewrite) {
                $add('mid', 'SEO', 'cyan', 'i-link', '开启友好链接',
                    '静态网址更利于收录与分享，在固定链接设置中开启',
                    '当前状态：未开启', 'options-permalink.php', '自动修复', 'rewrite');
            }
            if (mb_strlen($seoDesc) < 30) {
                $add('mid', 'SEO', 'cyan', 'i-search', '完善站点描述',
                    '建议 30-80 字，清晰表达站点定位与核心内容',
                    $seoDesc !== '' ? '当前 ' . mb_strlen($seoDesc) . ' 字' : '当前未设置', 'options-general.php', '自动修复', 'desc');
            }
            if ($seoDescCov < 60) {
                $add('mid', 'SEO', 'cyan', 'i-file', '提高描述覆盖率',
                    '补充描述后搜索摘要更精准，点击率会明显提升',
                    '当前覆盖率 ' . $seoDescCov . '%', 'manage-posts.php', '自动补齐', 'desccov');
            }
            if (!$seoRobots) {
                $add('mid', 'SEO', 'cyan', 'i-spider', '创建 robots.txt',
                    '在网站根目录放置 robots.txt，引导搜索引擎抓取',
                    '当前状态：缺失', '', '自动生成', 'robots');
            }
            if (!$seoSitemap) {
                $add('mid', 'SEO', 'cyan', 'i-globe', '生成 sitemap.xml',
                    '站点地图帮助搜索引擎发现并抓取全部页面',
                    '当前状态：缺失', '', '自动生成', 'sitemap');
            }
            if (!$opcacheOn) {
                $add('mid', '性能', 'blue', 'i-server', '开启 OPcache',
                    'PHP 字节码缓存，页面响应耗时可降 30% 以上',
                    '当前状态：未开启', '', '需主机开启');
            }
            if ($postsNum < 10) {
                $add('low', '内容', 'green', 'i-post', '积累基础内容',
                    '文章达到 10 篇以上更利于收录与站点权重稳定',
                    '已发布 ' . $postsNum . ' 篇', 'write-post.php', '写文章');
            }
            if ($draftNum > 0) {
                $add('low', '内容', 'green', 'i-write', '处理草稿箱',
                    '挑几篇接近完成的先发出去，发布后即可参与收录',
                    '草稿 ' . $draftNum . ' 篇', 'manage-posts.php?status=draft', '去看看');
            }
            $spider7 = 0;
            foreach ($rows as $r) {
                $spider7 += $r['spider'];
            }
            if ($spider7 <= 0) {
                $add('low', 'SEO', 'cyan', 'i-spider', '等待蜘蛛到访',
                    '可主动到搜索平台提交网址，加快首次抓取',
                    '近 7 天抓取 0 次', '', '自主处理');
            }

            $priOrder = array('high' => 0, 'mid' => 1, 'low' => 2);
            usort($advice, function ($a, $b) use ($priOrder) {
                return $priOrder[$a['pri']] - $priOrder[$b['pri']];
            });
            $advice = array_slice($advice, 0, 8);

            $counts = array('high' => 0, 'mid' => 0, 'low' => 0);
            foreach ($advice as $a) {
                $counts[$a['pri']]++;
            }

            $interaction = ($cmtWaiting > 0 ? 1 : 0) + ($cmtSpam > 0 ? 1 : 0);
            $baseTotal = 8;
            $baseMiss = max(0, $counts['high'] + $counts['mid'] - $interaction);
            $baseDone = max(0, min($baseTotal, $baseTotal - $baseMiss));
            $out['advice'] = $advice;

            foreach ($out['advice'] as &$ai) {
                $ai['go'] = $ai['url'] !== '' ? $options->adminUrl($ai['url'], true) : '';
            }
            unset($ai);
            $out['counts'] = $counts;
            $out['pct'] = (int) round($baseDone * 100 / $baseTotal);
            $out['pending'] = count($advice);
        } catch (\Exception $e) {
            $out['status'] = true;
        }

        return $out;
    }

    public static function trackVisit()
    {
        try {
            $ua = isset($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
            if ($ua === '') {
                return;
            }
            $kind = self::uaKind($ua);
            $kind = self::cleanSpiderKind($kind);
            if ($kind === '') {
                $kind = 'other';
            }
            $db = \Typecho\Db::get();
            $prefix = $db->getPrefix();
            $day = date('Y-m-d');
            $now = time();

            $sqlMy = 'INSERT INTO `' . $prefix . 'yx_visits` (`day`,`kind`,`hits`,`updated`)'
                . ' VALUES (\'' . $day . '\',\'' . $kind . '\',1,' . $now . ')'
                . ' ON DUPLICATE KEY UPDATE `hits` = `hits` + 1, `updated` = ' . $now;

            $sqlSqlite = 'INSERT INTO `' . $prefix . 'yx_visits` (`day`,`kind`,`hits`,`updated`)'
                . ' VALUES (\'' . $day . '\',\'' . $kind . '\',1,' . $now . ')'
                . ' ON CONFLICT(`day`,`kind`) DO UPDATE SET `hits` = `hits` + 1, `updated` = ' . $now;
            try {
                $db->query($sqlMy);
            } catch (\Throwable $e) {
                try {
                    $db->query($sqlSqlite);
                } catch (\Throwable $e2) {
                    self::ensureVisitTable();
                    try {
                        $db->query($sqlMy);
                    } catch (\Throwable $e4) {
                        $db->query($sqlSqlite);
                    }
                }
            }

            try {
                require_once __DIR__ . '/weather/shared/load.php';
                $crawlKind = \YxWeather\CrawlLog::kind($ua);
                if ($crawlKind !== '') {
                    \YxWeather\CrawlLog::record((string) ($_SERVER['REQUEST_URI'] ?? '/'), $crawlKind);
                }
                $t0 = isset($_SERVER['REQUEST_TIME_FLOAT'])
                    ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : microtime(true);
                \YxWeather\Metrics::record(self::isMobile() ? 'mobile' : 'desktop', 'page',
                    'front', (microtime(true) - $t0) * 1000, true);
            } catch (\Throwable $e3) {
            }
        } catch (\Throwable $e) {
        }
    }

    private static function tmpTag()
    {
        static $tag = null;
        if ($tag === null) {
            try {
                $tag = substr(md5((string) \Widget\Options::alloc()->siteUrl), 0, 8);
            } catch (\Throwable $e) {
                $tag = 'default';
            }
        }
        return $tag;
    }

    public static function collectVisitsFromLog($force = false)
    {
        $plugin = self::conf();
        $days = (int) $plugin->collect_days;
        if ($days < 1) {
            $days = 30;
        }
        $cacheFile = sys_get_temp_dir() . '/yx-collect-' . self::tmpTag() . '.flag';
        if (!$force && is_file($cacheFile) && (time() - (int) @filemtime($cacheFile)) < 1800) {
            return array('status' => true, 'skipped' => true, 'reason' => '30 分钟内已采集，使用缓存', 'path' => '');
        }

        $logPath = trim((string) $plugin->log_path);
        if ($logPath === '') {
            $logPath = self::detectAccessLog();
        }
        if ($logPath === '' || !is_file($logPath) || !is_readable($logPath)) {
            @touch($cacheFile);
            return array('status' => false, 'reason' => '未找到可读的访问日志，请在插件设置中填写日志路径', 'path' => $logPath);
        }

        $minTs = strtotime('-' . $days . ' days');
        $agg = array();
        $lines = 0;
        $matched = 0;
        $isGz = (strtolower(substr($logPath, -3)) === '.gz');
        $fh = $isGz ? @gzopen($logPath, 'r') : @fopen($logPath, 'r');
        if ($fh === false) {
            return array('status' => false, 'reason' => '日志文件无法打开（权限不足？）', 'path' => $logPath);
        }
        if (!$isGz) {
            $size = @filesize($logPath);
            $budget = 268435456;
            if (is_int($size) && $size > $budget) {
                if (@fseek($fh, $size - $budget, SEEK_SET) === 0) {
                    @fgets($fh);
                }
            }
        }

        $staticRe = '/\.(css|js|png|jpe?g|gif|ico|svg|webp|woff2?|ttf|eot|map|mp3|mp4|webm|otf)(\?|$)/i';
        while (($line = ($isGz ? @gzgets($fh) : fgets($fh))) !== false) {
            if (++$lines > 3000000) {
                break;
            }

            if (!preg_match('/\[([^\]]+)\]/', $line, $tm)) {
                continue;
            }
            $timeStr = $tm[1];

            if (!preg_match('/"([A-Z]+)\s+(\S+)\s+[^"]*"\s+(\d{3})/', $line, $req)) {
                continue;
            }
            $method = $req[1];
            $url = $req[2];
            $status = (int) $req[3];

            $ua = '';
            if (preg_match_all('/"([^"]*)"/', $line, $qs)) {
                $strs = $qs[1];
                for ($i = count($strs) - 1; $i >= 0; $i--) {
                    $s = trim($strs[$i]);
                    if ($s !== '' && !preg_match('#^(GET|POST|HEAD|PUT|DELETE|OPTIONS|HTTP/|/)#i', $s)) {
                        $ua = $s;
                        break;
                    }
                }
            }
            $dt = \DateTime::createFromFormat('d/M/Y:H:i:s O', $timeStr);
            if ($dt === false) {
                continue;
            }
            $ts = $dt->getTimestamp();
            if ($ts < $minTs) {
                continue;
            }
            if ($method !== 'GET' || $status < 200 || $status >= 400) {
                continue;
            }
            if (preg_match($staticRe, $url)) {
                continue;
            }
            $ua = trim($ua);
            if ($ua === '') {
                continue;
            }
            $day = $dt->format('Y-m-d');
            if (!isset($agg[$day])) {
                $agg[$day] = array('visit' => 0, 'spider' => array());
            }
            $kind = self::uaKind($ua);
            if ($kind === 'visit') {
                $agg[$day]['visit']++;
            } else {
                if (!isset($agg[$day]['spider'][$kind])) {
                    $agg[$day]['spider'][$kind] = 0;
                }
                $agg[$day]['spider'][$kind]++;
            }
            $matched++;
        }
        if ($isGz) { @gzclose($fh); } else { fclose($fh); }

        $db = \Typecho\Db::get();
        $prefix = $db->getPrefix();
        $daysList = array_keys($agg);
        if (!empty($daysList)) {
            $in = array();
            foreach ($daysList as $d) {
                $in[] = "'" . str_replace("'", "''", (string) $d) . "'";
            }
            try {
                $db->query('DELETE FROM `' . $prefix . 'yx_visits` WHERE `day` IN (' . implode(',', $in) . ')');
            } catch (\Exception $e) {
                self::ensureVisitTable();
            }
        }
        $totalVisit = 0;
        $totalSpider = 0;
        foreach ($agg as $day => $d) {
            $v = (int) $d['visit'];
            $totalVisit += $v;
            if ($v > 0) {
                self::upsertVisit($day, 'visit', $v);
            }
            foreach ($d['spider'] as $kind => $c) {
                $totalSpider += $c;
                self::upsertVisit($day, $kind, $c);
            }
        }
        @touch($cacheFile);
        return array(
            'status' => true,
            'path' => $logPath,
            'lines' => $lines,
            'matched' => $matched,
            'days' => count($agg),
            'visit' => $totalVisit,
            'spider' => $totalSpider
        );
    }

    private static function upsertVisit($day, $kind, $hits)
    {
        try {
            $db = \Typecho\Db::get();
            $now = time();
            $table = '`' . $db->getPrefix() . 'yx_visits`';
            $mysql = 'INSERT INTO ' . $table . ' (`day`,`kind`,`hits`,`updated`)'
                . ' VALUES (\'' . $day . '\',\'' . $kind . '\',' . (int) $hits . ',' . $now . ')'
                . ' ON DUPLICATE KEY UPDATE `hits` = ' . (int) $hits . ', `updated` = ' . $now;

            $sqlite = 'INSERT INTO ' . $table . ' (`day`,`kind`,`hits`,`updated`)'
                . ' VALUES (\'' . $day . '\',\'' . $kind . '\',' . (int) $hits . ',' . $now . ')'
                . ' ON CONFLICT(`day`,`kind`) DO UPDATE SET `hits` = ' . (int) $hits . ', `updated` = ' . $now;
            try {
                $db->query($mysql);
            } catch (\Throwable $e) {
                $db->query($sqlite);
            }
        } catch (\Throwable $e) {
        }
    }

    private static function detectAccessLog()
    {
        $candidates = array(
            '/var/log/nginx/access.log',
            '/usr/local/var/log/nginx/access.log',
            '/opt/homebrew/var/log/nginx/access.log',
            '/var/log/apache2/access.log',
            '/var/log/httpd/access_log',
            '/usr/local/var/log/apache2/access_log',
            '/www/wwwlogs/access.log',
            '/var/www/logs/access.log',
            '/var/log/caddy/access.log'
        );

        try {
            $host = parse_url((string) \Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
            if ($host) {
                $candidates[] = '/www/wwwlogs/' . $host . '.log';
                $candidates[] = '/www/sites/' . $host . '/log/access.log';
                $candidates[] = '/opt/1panel/www/sites/' . $host . '/log/access.log';
            }
        } catch (\Throwable $e) {
        }
        foreach ($candidates as $c) {
            if (is_file($c) && is_readable($c)) {
                return $c;
            }
        }

        foreach (array('/www/wwwlogs', '/var/log/nginx', '/usr/local/var/log/nginx', '/var/log/apache2', '/var/log/caddy') as $dir) {
            if (is_dir($dir) && is_readable($dir)) {
                $files = @glob($dir . '/*.log');
                if (is_array($files)) {
                    foreach ($files as $f) {
                        if (is_file($f) && is_readable($f) && filesize($f) > 0) {
                            return $f;
                        }
                    }
                }
            }
        }
        return '';
    }

    public static function autoSeoSetup()
    {
        $flag = sys_get_temp_dir() . '/yx-seo-setup-' . self::tmpTag() . '.flag';
        if (is_file($flag) && (time() - (int) @filemtime($flag)) < 1800) {
            return;
        }
        try {
            $options = \Widget\Options::alloc();
            $root = rtrim((string) __TYPECHO_ROOT_DIR__, '/');

            // 1) robots.txt
            $robots = $root . '/robots.txt';
            if (!is_file($robots) && is_writable($root)) {
                $site = rtrim((string) $options->siteUrl, '/') . '/';
                $body = "User-agent: *\n"
                    . "Allow: /\n"
                    . "Disallow: /admin/\n"
                    . "Disallow: /usr/plugins/\n"
                    . "Disallow: /usr/themes/\n\n"
                    . "Sitemap: " . $site . "sitemap.xml\n";
                if (@file_put_contents($robots, $body) !== false) {
                    @chmod($robots, 0644);
                }
            }

            // 2) sitemap.xml
            $sitemap = $root . '/sitemap.xml';
            if (!is_file($sitemap) && is_writable($root)) {
                self::writeAutoSitemap($root, $options);
            }

            $desc = trim((string) $options->description);
            if (mb_strlen($desc) < 30) {
                $new = self::presetSiteDesc($options);
                if ($new !== '') {
                    self::setOption('description', $new);
                }
            }
        } catch (\Exception $e) {
        }
        @touch($flag);
    }

    private static function setOption($name, $value)
    {
        try {
            $db = \Typecho\Db::get();
            $old = $db->fetchRow($db->select('name')->from('table.options')->where('name = ? AND user = ?', $name, 0)->limit(1));
            if ($old) {
                $db->query($db->update('table.options')->rows(array('value' => (string) $value))->where('name = ? AND user = ?', $name, 0));
            } else {
                $db->query($db->insert('table.options')->rows(array('name' => $name, 'user' => 0, 'value' => (string) $value)));
            }
        } catch (\Exception $e) {
        }
    }

    public static function presetSiteDesc($options)
    {
        $title = trim((string) $options->title);
        if ($title === '') {
            $title = '本站';
        }
        $cats = array();
        $tags = array();
        try {
            $db = \Typecho\Db::get();
            $rs = $db->fetchAll($db->select('name')->from('table.metas')->where('type = ?', 'category')->order('count', \Typecho\Db::SORT_DESC)->limit(3));
            foreach ($rs as $r) {
                $cats[] = (string) $r['name'];
            }
            $rs = $db->fetchAll($db->select('name')->from('table.metas')->where('type = ?', 'tag')->order('count', \Typecho\Db::SORT_DESC)->limit(3));
            foreach ($rs as $r) {
                $tags[] = (string) $r['name'];
            }
        } catch (\Exception $e) {
        }
        $theme = $cats ? implode('、', $cats) : ($tags ? implode('、', $tags) : '原创内容');

        $presets = array(
            '「{T}」是一个专注「{K}」的原创博客，分享实用教程、深度思考与日常记录，持续更新，欢迎订阅与交流。',
            '欢迎来到「{T}」——这里记录关于「{K}」的实战经验与踩坑笔记，用内容陪你在成长路上少走弯路。',
            '「{T}」致力于输出高质量的「{K}」内容，从入门到进阶，沉淀方法，也分享思考。',
            '这里是「{T}」，一个关于「{K}」的记录与分享空间，写好每一篇，也陪你一起进步。'
        );
        $seed = 0;
        foreach (str_split($title) as $ch) {
            $seed += ord($ch);
        }
        $tpl = $presets[$seed % count($presets)];
        $desc = str_replace(array('{T}', '{K}'), array($title, $theme), $tpl);
        if (mb_strlen($desc) > 80) {
            $desc = mb_substr($desc, 0, 77) . '…';
        }
        return $desc;
    }

    private static function writeAutoSitemap($root, $options)
    {
        try {
            $db = \Typecho\Db::get();
            $urls = array(rtrim((string) $options->siteUrl, '/') . '/');
            $rows = $db->fetchAll($db->select('cid', 'slug', 'created', 'modified', 'type')
                ->from('table.contents')
                ->where('type = ? OR type = ?', 'post', 'page')
                ->where('status = ?', 'publish')
                ->order('created', \Typecho\Db::SORT_DESC)
                ->limit(2000));
            $catSlugs = array();
            $meRows = $db->fetchAll($db->select('mid', 'slug')->from('table.metas'));
            foreach ($meRows as $me) {
                $catSlugs[(int) $me['mid']] = (string) $me['slug'];
            }
            $relMap = array();
            $relRows = $db->fetchAll($db->select('cid', 'mid')->from('table.relationships'));
            foreach ($relRows as $rel) {
                $relMap[(int) $rel['cid']] = (int) $rel['mid'];
            }
            $index = rtrim((string) $options->siteUrl, '/') . '/';
            foreach ($rows as $r) {
                $cid = (int) $r['cid'];
                $time = (int) ($r['modified'] ? $r['modified'] : $r['created']);
                $slug = '';
                if (isset($relMap[$cid], $catSlugs[$relMap[$cid]])) {
                    $slug = $catSlugs[$relMap[$cid]];
                }
                if ($slug === '') {
                    $slug = 'default';
                }
                $args = array(
                    'type' => (string) $r['type'],
                    'cid' => $cid,
                    'slug' => rawurlencode((string) $r['slug']),
                    'category' => rawurlencode($slug),
                    'year' => date('Y', $time),
                    'month' => date('m', $time),
                    'day' => date('d', $time),
                    'page' => 1
                );
                $path = '';
                try {
                    if (\Typecho\Router::get((string) $r['type']) !== null) {
                        $path = \Typecho\Router::url((string) $r['type'], $args);
                    }
                } catch (\Throwable $e) {
                    $path = '';
                }
                if ($path === '' || strpos($path, '{') !== false) {
                    $path = 'archives/' . $cid . '/';
                }
                $urls[] = \Typecho\Common::url($path, $index);
            }
            $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
                . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
            foreach ($urls as $u) {
                $xml .= '  <url><loc>' . htmlspecialchars($u) . '</loc></url>' . "\n";
            }
            $xml .= '</urlset>';
            if (@file_put_contents($root . '/sitemap.xml', $xml) !== false) {
                @chmod($root . '/sitemap.xml', 0644);
            }
        } catch (\Exception $e) {
        }
    }

    private static function sameOriginUrl($url)
    {
        $parts = parse_url((string) $url);
        if (!is_array($parts) || !isset($parts['path'])) {
            return (string) $url;
        }
        $scheme = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
            || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443) ? 'https' : 'http';
        $host = isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : (isset($parts['host']) ? $parts['host'] : '');
        $query = isset($parts['query']) ? '?' . $parts['query'] : '';
        return $scheme . '://' . $host . $parts['path'] . $query;
    }
}

if (!defined('YX_BOOT_HOOK')) {
    define('YX_BOOT_HOOK', 1);
    try {
        \Typecho\Db::get()->query('SET NAMES utf8mb4');
    } catch (\Throwable $e) {
    }
    try {
        \Typecho\Plugin::factory('index.php')->begin = 'TypechoPlugin\YunxiAdmin\Plugin::beginRequest';
    } catch (\Throwable $e) {
    }
}
