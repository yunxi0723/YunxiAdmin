<?php
define('YX_DASH', 1);
define('__ADMIN_DIR__', __TYPECHO_ROOT_DIR__ . __TYPECHO_ADMIN_DIR__);

\Widget\Init::alloc();
\Typecho\Plugin::factory('admin/common.php')->begin($k = 1);

\Widget\Options::alloc()->to($options);
\Widget\User::alloc()->to($user);
\Widget\Security::alloc()->to($security);
\Widget\Menu::alloc()->to($menu);

$plugin = \TypechoPlugin\YunxiAdmin\Plugin::conf();
$db = \Typecho\Db::get();
$VER = \TypechoPlugin\YunxiAdmin\Plugin::VERSION;
$A = $options->pluginUrl . '/YunxiAdmin/assets/';
$icons = '';

$menu->title = '工作台';
include __ADMIN_DIR__ . 'header.php';
include __ADMIN_DIR__ . 'menu.php';

$SORT_DESC = \Typecho\Db::SORT_DESC;

$postsNum = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.contents')->where('type = ? AND status = ?', 'post', 'publish'))->num;
$draftNum = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.contents')->where('type = ? AND status = ?', 'post', 'draft'))->num;
$waitingPost = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.contents')->where('type = ? AND status = ?', 'post', 'waiting'))->num;
$pagesNum = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.contents')->where('type = ? AND status = ?', 'page', 'publish'))->num;
$attachNum = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.contents')->where('type = ?', 'attachment'))->num;
$cmtApproved = (int) $db->fetchObject($db->select('COUNT(coid) AS num')->from('table.comments')->where('status = ?', 'approved'))->num;
$cmtWaiting = (int) $db->fetchObject($db->select('COUNT(coid) AS num')->from('table.comments')->where('status = ?', 'waiting'))->num;
$cmtSpam = (int) $db->fetchObject($db->select('COUNT(coid) AS num')->from('table.comments')->where('status = ?', 'spam'))->num;
$cmtNum = $cmtApproved + $cmtWaiting + $cmtSpam;
$usersNum = (int) $db->fetchObject($db->select('COUNT(uid) AS num')->from('table.users'))->num;

$pendingSub = 0;
$reviewUrl = '';
try {
    $pendingSub = (int) $db->fetchObject($db->select('COUNT(id) AS num')->from('table.wx_submissions')->where('status = ?', 'pending'))->num;
    $reviewUrl = rtrim($options->siteUrl, '/') . '/?wx_route=review';
} catch (\Exception $e) {
}

$cmts = $db->fetchAll($db->select('coid', 'author', 'text', 'created', 'status')->from('table.comments')->order('created', $SORT_DESC)->limit(6));
$posts = $db->fetchAll($db->select('cid', 'title', 'created', 'commentsNum')->from('table.contents')->where('type = ? AND status = ?', 'post', 'publish')->order('created', $SORT_DESC)->limit(6));

$y = (int) date('Y');
$m = (int) date('n');
$mStart = mktime(0, 0, 0, $m, 1, $y);
$mDays = (int) date('t', $mStart);
$mEnd = mktime(0, 0, 0, $m + 1, 1, $y);
$lead = (int) date('w', $mStart);
$todayD = (int) date('j');
$dayRows = $db->fetchAll($db->select('created')->from('table.contents')->where('type = ? AND status = ?', 'post', 'publish')->where('created >= ?', $mStart)->where('created < ?', $mEnd));
$dayMap = array();
foreach ($dayRows as $r) {
    $d = (int) date('j', $r['created']);
    $dayMap[$d] = isset($dayMap[$d]) ? $dayMap[$d] + 1 : 1;
}
$tail = (7 - (($lead + $mDays) % 7)) % 7;

$weekNames = array('日', '一', '二', '三', '四', '五', '六');

$yxWm = array();
$yxWmLoc = array();
$yxFest = array('days' => array(), 'list' => array(), 'note' => '');
try {
    require_once __DIR__ . '/weather/shared/load.php';
    require_once __DIR__ . '/weather/mobile/Controller.php';
    $yxUid = (int) $user->uid;

    $yxWmLoc = \YxWeather\Mobile\Controller::location($yxUid, false);
    if (!$yxWmLoc) {
        $yxWmLoc = \YxWeather\Mobile\Controller::location($yxUid, true);
    }
    $yxWm = \YxWeather\Mobile\Controller::render($yxUid, array('location', 'weather', 'warnings', 'forecast', 'life', 'typhoon', 'traffic', 'trends'), true);
    $yxFest = \YxWeather\Festivals::forMonth($y, $m);
} catch (\Throwable $e) {
    $yxWmLoc = array();
}

function yxWmPart($parts, $key)
{
    if (isset($parts[$key]) && is_string($parts[$key]) && $parts[$key] !== '') {
        return $parts[$key];
    }
    $hero = '<div class="wm-hero" data-wm-scene="hero" data-wm-sky="{&quot;kind&quot;:&quot;sun&quot;,&quot;day&quot;:1}" data-anim="sun" style="background:linear-gradient(180deg,#4a9ce2,#bde0f6)">'
        . '<canvas class="wm-sky"></canvas><div class="wm-hero-tx"><b>正在同步</b><span>读取本账号位置</span><em>正在获取气象数据</em></div></div>';
    if ($key === 'weather') {
        return $hero . '<div class="wm-now"><b>--<sup>°C</sup></b><span>正在同步</span></div>';
    }
    if ($key === 'life') {
        $items = '';
        foreach (array('穿衣', '紫外线', '洗车', '运动', '舒适度', '感冒') as $n) {
            $items .= '<div><b>' . $n . '</b><em>—</em><p>正在同步</p></div>';
        }
        return '<div class="wm-life-scene" data-wm-scene="mini" data-wm-sky="{&quot;kind&quot;:&quot;sun&quot;,&quot;day&quot;:1}" data-anim="sun" style="background:linear-gradient(180deg,#4a9ce2,#bde0f6)">'
            . '<canvas class="wm-sky"></canvas></div><div class="wm-life">' . $items . '</div>';
    }
    if ($key === 'location') {
        return '<div class="wm-none">正在读取位置…</div>';
    }
    return '<div class="wm-none">正在同步…</div>';
}

$sysVer = isset($options->Version) ? $options->Version : '';
$phpVer = PHP_VERSION;
$serverSw = isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : '';
$dbName = '—';
try {
    $dbName = $db->getAdapterName();
} catch (\Exception $e) {
}

if (!function_exists('yxCut')) {
    function yxCut($s, $n)
    {
        $s = trim(strip_tags($s));
        if (mb_strlen($s) > $n) {
            $s = mb_substr($s, 0, $n) . '…';
        }
        return $s;
    }
}

$funcs = array(
    array('write-post.php', 'i-write', '写文章', 'c-green'),
    array('manage-posts.php', 'i-post', '文章', 'c-blue'),
    array('write-page.php', 'i-page', '写页面', 'c-purple'),
    array('manage-comments.php', 'i-cmt', '评论', 'c-orange'),
    array('manage-categories.php', 'i-cat', '分类', 'c-cyan'),
    array('manage-tags.php', 'i-tag', '标签', 'c-pink'),
    array('manage-medias.php', 'i-img', '媒体', 'c-amber'),
    array('manage-users.php', 'i-users', '用户', 'c-blue'),
    array('themes.php', 'i-paint', '外观', 'c-purple'),
    array('plugins.php', 'i-plug', '插件', 'c-cyan'),
    array('options-general.php', 'i-gear', '设置', 'c-orange'),
    array('backup.php', 'i-shield', '备份', 'c-green')
);

$statusName = array('approved' => '已通过', 'waiting' => '待审', 'spam' => '垃圾');

$tagNum = 0;
$catNum = 0;
$lastBackup = '';
$avgWords = 0;
$monthPosts = 0;
$weekPosts = 0;
$topCats = array();
try {
    $tagNum = (int) $db->fetchObject($db->select('COUNT(mid) AS num')->from('table.metas')->where('type = ?', 'tag'))->num;
    $catNum = (int) $db->fetchObject($db->select('COUNT(mid) AS num')->from('table.metas')->where('type = ?', 'category'))->num;

    $wordRows = $db->fetchAll($db->select('text')->from('table.contents')
        ->where('type = ? AND status = ?', 'post', 'publish')->limit(200));
    $sum = 0;
    foreach ($wordRows as $wr) {
        $sum += mb_strlen(strip_tags((string) $wr['text']));
    }
    if ($wordRows) {
        $avgWords = (int) round($sum / count($wordRows));
    }

    $mStartTs = mktime(0, 0, 0, (int) date('n'), 1, (int) date('Y'));
    $monthPosts = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.contents')
        ->where('type = ? AND status = ? AND created >= ?', 'post', 'publish', $mStartTs))->num;

    $wStart = $mStartTs - (6 * 86400);
    $weekPosts = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.contents')
        ->where('type = ? AND status = ? AND created >= ?', 'post', 'publish', $wStart))->num;

    $catRows = $db->fetchAll($db->select('mid', 'name', 'count')->from('table.metas')
        ->where('type = ?', 'category')->order('count', $SORT_DESC)->limit(5));
    foreach ($catRows as $cr) {
        $topCats[] = array('name' => (string) $cr['name'], 'count' => (int) $cr['count']);
    }
} catch (\Exception $e) {
    $topCats = array();
}

$readMinutes = $avgWords > 0 ? max(1, (int) ceil($avgWords / 400)) : 0;

if (!function_exists('yxBytes')) {
    function yxBytes($v)
    {
        $v = trim((string) $v);
        if ($v === '') {
            return 0;
        }
        $u = strtolower(substr($v, -1));
        $n = (float) $v;
        if ($u === 'g') {
            return (int) ($n * 1073741824);
        }
        if ($u === 'm') {
            return (int) ($n * 1048576);
        }
        if ($u === 'k') {
            return (int) ($n * 1024);
        }
        return (int) $n;
    }
}

if (!function_exists('yxFmtBytes')) {
    function yxFmtBytes($b)
    {
        $b = (float) $b;
        if ($b <= 0) {
            return '0 B';
        }
        if ($b >= 1073741824) {
            return number_format($b / 1073741824, 1) . ' GB';
        }
        if ($b >= 1048576) {
            return number_format($b / 1048576, 0) . ' MB';
        }
        if ($b >= 1024) {
            return number_format($b / 1024, 0) . ' KB';
        }
        return (int) $b . ' B';
    }
}

if (!function_exists('yxNice')) {
    function yxNice($max)
    {
        if ($max <= 5) {
            return 5;
        }
        $base = pow(10, floor(log10($max)));
        foreach (array(1, 2, 2.5, 5, 10) as $m2) {
            if ($max <= $m2 * $base) {
                return (int) ($m2 * $base);
            }
        }
        return (int) (10 * $base);
    }
}

if (!function_exists('yxRunChart')) {
    function yxRunChart($keys, $series)
    {
        $n = count($keys);
        if ($n < 2) {
            return '';
        }
        $w = 720;
        $h = 232;
        $pl = 38;
        $pr = 14;
        $pt = 16;
        $pb = 28;
        $iw = $w - $pl - $pr;
        $ih = $h - $pt - $pb;
        $max = 4;
        foreach ($series as $s) {
            foreach ($s['data'] as $v) {
                if ($v > $max) {
                    $max = $v;
                }
            }
        }
        $nice = yxNice($max);
        $colors = array('var(--yx-accent)', 'var(--yx-c-blue)', 'var(--yx-c-green)', 'var(--yx-c-orange)');
        $svg = '<svg viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="网站运行趋势" style="width:100%;height:auto;display:block">';
        $svg .= '<defs><linearGradient id="yxrunfillm" x1="0" y1="0" x2="0" y2="1">'
            . '<stop offset="0%" stop-color="var(--yx-accent)" stop-opacity=".22"/>'
            . '<stop offset="100%" stop-color="var(--yx-accent)" stop-opacity="0"/>'
            . '</linearGradient></defs>';
        for ($g = 0; $g <= 4; $g++) {
            $gy = $pt + $ih - ($ih * $g / 4);
            $svg .= '<line x1="' . $pl . '" y1="' . round($gy, 1) . '" x2="' . ($w - $pr) . '" y2="' . round($gy, 1)
                . '" stroke="var(--yx-line)" stroke-width="1"' . ($g === 0 ? '' : ' stroke-dasharray="3 4"') . '/>';
            $svg .= '<text x="' . ($pl - 7) . '" y="' . round($gy + 3.5, 1) . '" text-anchor="end" font-size="10" fill="var(--yx-text-3)">'
                . round($nice * $g / 4) . '</text>';
        }
        $maxLabels = max(2, (int) floor($iw / 46));
        $step = max(1, (int) ceil(($n - 1) / ($maxLabels - 1)));
        $labelIdx = array();
        for ($li = 0; $li < $n; $li += $step) {
            $labelIdx[] = $li;
        }
        $lastIdx = $n - 1;
        if ($labelIdx[count($labelIdx) - 1] !== $lastIdx) {
            if (($lastIdx - $labelIdx[count($labelIdx) - 1]) < $step * 0.6) {
                array_pop($labelIdx);
            }
            $labelIdx[] = $lastIdx;
        }
        foreach ($labelIdx as $i) {
            $k = $keys[$i];
            $x = $pl + ($iw * $i / ($n - 1));
            $anchor = $i === 0 ? 'start' : ($i === $n - 1 ? 'end' : 'middle');
            $svg .= '<text x="' . round($x, 1) . '" y="' . ($h - 8) . '" text-anchor="' . $anchor . '" font-size="10" fill="var(--yx-text-3)">'
                . date('m-d', strtotime($k)) . '</text>';
        }
        $si = 0;
        foreach ($series as $s) {
            $pts = array();
            foreach ($s['data'] as $i => $v) {
                $x = $pl + ($iw * $i / ($n - 1));
                $y = $pt + $ih - ($nice > 0 ? ($ih * $v / $nice) : 0);
                $pts[] = round($x, 1) . ',' . round($y, 1);
            }
            if ($si === 0) {
                $svg .= '<polygon points="' . $pl . ',' . ($pt + $ih) . ' ' . implode(' ', $pts) . ' ' . ($pl + $iw) . ',' . ($pt + $ih)
                    . '" fill="url(#yxrunfillm)"/>';
            }
            $svg .= '<polyline points="' . implode(' ', $pts) . '" fill="none" stroke="' . $colors[$si % 4]
                . '" stroke-width="' . ($si === 0 ? 2.4 : 1.8) . '" stroke-linecap="round" stroke-linejoin="round" opacity="'
                . ($si === 0 ? 1 : .92) . '"><title>' . htmlspecialchars($s['name']) . ' 近 14 天合计 '
                . array_sum($s['data']) . '</title></polyline>';
            $last = end($s['data']);
            $lx = $pl + $iw;
            $ly = $pt + $ih - ($nice > 0 ? ($ih * $last / $nice) : 0);
            $svg .= '<circle cx="' . $lx . '" cy="' . round($ly, 1) . '" r="3" fill="' . $colors[$si % 4]
                . '" stroke="var(--yx-surface)" stroke-width="1.5"/>';
            if ($si === 0) {
                foreach ($s['data'] as $i => $v) {
                    $x = $pl + ($iw * $i / ($n - 1));
                    $y = $pt + $ih - ($nice > 0 ? ($ih * $v / $nice) : 0);
                    $svg .= '<circle cx="' . round($x, 1) . '" cy="' . round($y, 1) . '" r="2.6" fill="var(--yx-surface)" stroke="'
                        . $colors[0] . '" stroke-width="1.6"><title>' . date('m-d', strtotime($keys[$i])) . ' '
                        . htmlspecialchars($s['name']) . ' ' . $v . '</title></circle>';
                }
            }
            $si++;
        }
        return $svg . '</svg>';
    }
}

$runToday = date('Y-m-d');
$runStart = date('Y-m-d', strtotime('-13 days'));
$runKeys = array();
$runVisit = array();
$runSpider = array();
$runPost = array();
$runCmt = array();
for ($ri = 13; $ri >= 0; $ri--) {
    $rk = date('Y-m-d', strtotime('-' . $ri . ' days'));
    $runKeys[] = $rk;
    $runVisit[$rk] = 0;
    $runSpider[$rk] = 0;
    $runPost[$rk] = 0;
    $runCmt[$rk] = 0;
}

$spiderMain = array('baidu' => 0, 'google' => 0, 'bing' => 0, 'sogou' => 0, 'so' => 0, 'yandex' => 0, 'duck' => 0, 'bytes' => 0);
$spiderOther = array();
$spiderLast = 0;
try {
    $vRows = $db->fetchAll($db->select('day', 'kind', 'hits', 'updated')->from('table.yx_visits')->where('day >= ?', $runStart));
    foreach ($vRows as $vr) {
        $vd = (string) $vr['day'];
        $vk = (string) $vr['kind'];
        $vh = (int) $vr['hits'];
        if ((int) $vr['updated'] > $spiderLast) {
            $spiderLast = (int) $vr['updated'];
        }
        if ($vk === 'visit') {
            if (isset($runVisit[$vd])) {
                $runVisit[$vd] += $vh;
            }
        } else {
            if (isset($runSpider[$vd])) {
                $runSpider[$vd] += $vh;
            }
            if (isset($spiderMain[$vk])) {
                $spiderMain[$vk] += $vh;
            } else {
                if ($vk === '') {
                    $vk = 'other';
                }
                $spiderOther[$vk] = (isset($spiderOther[$vk]) ? $spiderOther[$vk] : 0) + $vh;
            }
        }
    }
} catch (\Exception $e) {
}

try {
    $pRows = $db->fetchAll($db->select('created')->from('table.contents')
        ->where('type = ? AND status = ? AND created >= ?', 'post', 'publish', strtotime('-13 days')));
    foreach ($pRows as $pr) {
        $pd = date('Y-m-d', (int) $pr['created']);
        if (isset($runPost[$pd])) {
            $runPost[$pd]++;
        }
    }
} catch (\Exception $e) {
}

try {
    $cRows = $db->fetchAll($db->select('created')->from('table.comments')->where('created >= ?', strtotime('-13 days')));
    foreach ($cRows as $cr) {
        $cd = date('Y-m-d', (int) $cr['created']);
        if (isset($runCmt[$cd])) {
            $runCmt[$cd]++;
        }
    }
} catch (\Exception $e) {
}

$runSeries = array(
    array('name' => '访客', 'data' => array_values($runVisit)),
    array('name' => '蜘蛛', 'data' => array_values($runSpider)),
    array('name' => '发布', 'data' => array_values($runPost)),
    array('name' => '评论', 'data' => array_values($runCmt))
);
$runTotal = array(
    'visit' => array_sum($runVisit),
    'spider' => array_sum($runSpider),
    'post' => array_sum($runPost),
    'cmt' => array_sum($runCmt)
);
$visitToday = (int) $runVisit[$runToday];
$spiderToday = (int) $runSpider[$runToday];
$spider7 = 0;
for ($si2 = 0; $si2 < 7; $si2++) {
    $spider7 += (int) $runSpider[date('Y-m-d', strtotime('-' . $si2 . ' days'))];
}

$loadAvg = @sys_getloadavg();
$load1 = is_array($loadAvg) && isset($loadAvg[0]) ? round((float) $loadAvg[0], 2) : null;
$cores = 0;
$cpuinfo = is_readable('/proc/cpuinfo') ? @file_get_contents('/proc/cpuinfo') : false;
if ($cpuinfo) {
    $cores = preg_match_all('/^processor\s*:/mi', $cpuinfo);
}
if ($cores < 1) {
    $envCores = getenv('NUMBER_OF_PROCESSORS');
    if ($envCores && (int) $envCores > 0) {
        $cores = (int) $envCores;
    }
}
$coresKnown = $cores >= 1;
if (!$coresKnown) {
    $cores = 1;
}
$memLimit = yxBytes(ini_get('memory_limit'));
$memUse = memory_get_usage(true);
$memPct = $memLimit > 0 ? (int) round($memUse * 100 / $memLimit) : 0;
$memPct = min(100, max(0, $memPct));
$diskFree = @disk_free_space(__DIR__);
$diskTotal = @disk_total_space(__DIR__);
$diskPct = ($diskTotal > 0 && $diskFree !== false) ? (int) round(($diskTotal - $diskFree) * 100 / $diskTotal) : 0;
$diskPct = min(100, max(0, $diskPct));
if ($load1 === null) {
    $loadLv = 'none';
    $loadPct = 0;
} elseif ($coresKnown) {
    $loadPct = min(100, (int) round($load1 * 100 / $cores));
    $loadLv = $loadPct >= 100 ? 'danger' : ($loadPct >= 70 ? 'warn' : 'ok');
} else {
    $loadPct = min(100, (int) round($load1 * 20));
    $loadLv = $load1 >= 5 ? 'danger' : ($load1 >= 2 ? 'warn' : 'ok');
}
$memLv = $memPct >= 90 ? 'danger' : ($memPct >= 70 ? 'warn' : 'ok');
$diskLv = $diskPct >= 90 ? 'danger' : ($diskPct >= 75 ? 'warn' : 'ok');
$srvLv = 'ok';
if ($loadLv === 'danger' || $memLv === 'danger' || $diskLv === 'danger') {
    $srvLv = 'danger';
} elseif ($loadLv === 'warn' || $memLv === 'warn' || $diskLv === 'warn') {
    $srvLv = 'warn';
}
$srvLvText = $srvLv === 'danger' ? '需要关注' : ($srvLv === 'warn' ? '略有压力' : '运行正常');

$extList = array('curl' => '远程请求', 'mbstring' => '中文处理', 'gd' => '图片处理', 'fileinfo' => '文件识别', 'zip' => '备份压缩', 'openssl' => '安全连接', 'pdo_mysql' => '数据库');
$extMiss = array();
foreach ($extList as $ek => $ev) {
    if (!extension_loaded($ek)) {
        $extMiss[] = $ev;
    }
}
$opcacheOn = extension_loaded('Zend OPcache') && ini_get('opcache.enable') ? 1 : 0;

$seoTitle = trim((string) $options->title);
$seoDesc = trim((string) $options->description);
$seoIndex = $postsNum + $pagesNum + $catNum + $tagNum;
$seoHttps = stripos((string) $options->siteUrl, 'https://') === 0;
$seoRewrite = !empty($options->rewrite);
$seoRobots = is_file(rtrim((string) __TYPECHO_ROOT_DIR__, '/') . '/robots.txt');
$seoSitemap = is_file(rtrim((string) __TYPECHO_ROOT_DIR__, '/') . '/sitemap.xml');
$seoDescNum = 0;
try {
    $seoDescNum = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.fields')->where('name = ?', 'description'))->num;
} catch (\Exception $e) {
    $seoDescNum = 0;
}
$seoDescCov = $postsNum > 0 ? min(100, (int) round($seoDescNum * 100 / $postsNum)) : 0;
$seoChecks = array(
    array('站点标题', $seoTitle !== '', 15, $seoTitle !== '' ? yxCut($seoTitle, 14) : '未设置'),
    array('站点描述', mb_strlen($seoDesc) >= 30, 15, $seoDesc !== '' ? mb_strlen($seoDesc) . ' 字' : '未设置'),
    array('内容数量', $postsNum >= 10, 15, $postsNum . ' 篇'),
    array('描述覆盖', $seoDescCov >= 60, 15, $seoDescCov . '%'),
    array('全站 HTTPS', $seoHttps, 10, $seoHttps ? '已启用' : '未启用'),
    array('友好链接', $seoRewrite, 10, $seoRewrite ? '已开启' : '未开启'),
    array('robots.txt', $seoRobots, 10, $seoRobots ? '存在' : '缺失'),
    array('sitemap.xml', $seoSitemap, 10, $seoSitemap ? '存在' : '缺失')
);
$seoScore = 0;
foreach ($seoChecks as $sc) {
    if ($sc[1]) {
        $seoScore += $sc[2];
    }
}
$seoLv = $seoScore >= 80 ? 'ok' : ($seoScore >= 50 ? 'warn' : 'danger');

$dashLive = \TypechoPlugin\YunxiAdmin\Plugin::dashLive();
$advice = $dashLive['advice'];

$spiderMainNames = array('baidu' => '百度', 'google' => '谷歌', 'bing' => '必应', 'sogou' => '搜狗', 'so' => '360', 'yandex' => 'Yandex', 'duck' => 'DuckDuckGo', 'bytes' => '字节');
$spiderTop = array();
foreach ($spiderMain as $sk => $sv) {
    if ($sv > 0) {
        $spiderTop[] = array('k' => $sk, 'n' => isset($spiderMainNames[$sk]) ? $spiderMainNames[$sk] : $sk, 'v' => $sv);
    }
}
usort($spiderTop, function ($a, $b) {
    return $b['v'] - $a['v'];
});
$spiderTop = array_slice($spiderTop, 0, 4);
$spiderMax = 0;
foreach ($spiderTop as $st) {
    if ($st['v'] > $spiderMax) {
        $spiderMax = $st['v'];
    }
}

$spiderAlias = array(
    'YisouSpider' => '神马', 'PetalBot' => '花瓣', 'AspiegelBot' => 'Aspiegel', 'Quark' => '夸克',
    'AhrefsBot' => 'Ahrefs', 'SemrushBot' => 'Semrush', 'MJ12bot' => 'Majestic', 'DotBot' => 'DotBot',
    'ScreamingFrog' => 'Screaming Frog', 'SEOkicksBot' => 'SEOkicks', 'BLEXBot' => 'BLEX',
    'DataForSeoBot' => 'DataForSEO', 'MegaIndex' => 'MegaIndex', 'serpstatbot' => 'Serpstat',
    'LinkpadBot' => 'Linkpad', 'SISTRIX' => 'SISTRIX', 'OnCrawl' => 'OnCrawl', 'Botify' => 'Botify',
    'Lumar' => 'Lumar', 'ClaudeBot' => 'Claude', 'GPTBot' => 'GPT', 'CCBot' => 'CC',
    'PerplexityBot' => 'Perplexity', 'Amazonbot' => 'Amazon', 'Applebot' => 'Apple', 'NaverBot' => 'Naver',
    'facebookexternalhit' => 'Facebook', 'Twitterbot' => 'Twitter', 'LinkedInBot' => 'LinkedIn',
    'Discordbot' => 'Discord', 'TelegramBot' => 'Telegram', 'WhatsApp' => 'WhatsApp', 'Slackbot' => 'Slack',
    'Pinterest' => 'Pinterest', 'redditbot' => 'Reddit', 'vkShare' => 'VK', 'Embedly' => 'Embedly',
    'Iframely' => 'Iframely', 'Feedly' => 'Feedly', 'Feedbin' => 'Feedbin', 'Feedfetcher' => 'FeedFetcher',
    'Superfeedr' => 'Superfeedr', 'W3C_Validator' => 'W3C', 'Wget' => 'Wget', 'curl' => 'curl',
    'pythonrequests' => 'Python', 'Pythonurllib' => 'urllib', 'Gohttpclient' => 'Go-http', 'Java' => 'Java',
    'okhttp' => 'okhttp', 'ApacheHttpClient' => 'Apache', 'libwwwperl' => 'libwww', 'axios' => 'axios',
    'nodefetch' => 'node-fetch', 'undici' => 'undici', 'Scrapy' => 'Scrapy', 'HTTPie' => 'HTTPie',
    'Postman' => 'Postman', 'insomnia' => 'insomnia', 'other' => '其他(未识别)'
);
$spiderOtherList = array();
foreach ($spiderOther as $sk => $sv) {
    $lbl = isset($spiderAlias[$sk]) ? $spiderAlias[$sk] : $sk;
    $spiderOtherList[] = array('n' => $lbl, 'v' => $sv);
}
usort($spiderOtherList, function ($a, $b) {
    return $b['v'] - $a['v'];
});
$spiderOtherMax = 0;
foreach ($spiderOtherList as $so) {
    if ($so['v'] > $spiderOtherMax) {
        $spiderOtherMax = $so['v'];
    }
}
$spiderOtherNum = count($spiderOtherList);
$spiderLastText = $spiderLast > 0 ? date('m-d H:i', $spiderLast) : '暂无记录';
?>

<div class="yd-m">

    <div class="yd-metrics">
        <div class="yd-mc">
            <div class="hd"><span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-post"></use></svg></span><span class="lb">文章总数</span></div>
            <div class="vl yd-num" data-num="<?php echo $postsNum; ?>">0</div>
            <div class="dl">已发布 <b class="up"><?php echo $postsNum; ?></b> · 草稿 <?php echo $draftNum; ?> · 待审 <?php echo $waitingPost; ?></div>
        </div>
        <div class="yd-mc">
            <div class="hd"><span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-cmt"></use></svg></span><span class="lb">评论总数</span></div>
            <div class="vl yd-num" data-num="<?php echo $cmtNum; ?>">0</div>
            <div class="dl">通过 <b class="up"><?php echo $cmtApproved; ?></b> · 待审 <b class="down"><?php echo $cmtWaiting; ?></b> · 垃圾 <?php echo $cmtSpam; ?></div>
        </div>
        <div class="yd-mc">
            <div class="hd"><span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-bell"></use></svg></span><span class="lb">待审评论</span></div>
            <div class="vl yd-num" data-num="<?php echo $cmtWaiting; ?>">0</div>
            <div class="dl"><?php echo $cmtWaiting > 0 ? '有评论等待你的审核' : '评论都已处理完毕'; ?></div>
        </div>
        <div class="yd-mc">
            <div class="hd"><span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-users"></use></svg></span><span class="lb">注册用户</span></div>
            <div class="vl yd-num" data-num="<?php echo $usersNum; ?>">0</div>
            <div class="dl">页面 <b><?php echo $pagesNum; ?></b> · 附件 <b><?php echo $attachNum; ?></b></div>
        </div>
    </div>

    <section class="yd-card">
        <div class="yd-head"><h3>网站运行趋势</h3><span class="sp"></span><span class="yd-range"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-trend"></use></svg>近 14 天</span></div>
        <div class="yd-body">
            <div class="yd-run-legend">
                <span class="yd-run-lg ci-a"><i></i>访客<b><?php echo $runTotal['visit']; ?></b></span>
                <span class="yd-run-lg ci-b"><i></i>蜘蛛<b><?php echo $runTotal['spider']; ?></b></span>
                <span class="yd-run-lg ci-c"><i></i>发布<b><?php echo $runTotal['post']; ?></b></span>
                <span class="yd-run-lg ci-d"><i></i>评论<b><?php echo $runTotal['cmt']; ?></b></span>
                <span class="yd-run-hint">访客 / 蜘蛛数据自本版本启用起累计</span>
            </div>
            <div class="yd-run-chart"><?php echo yxRunChart($runKeys, $runSeries); ?></div>
        </div>
    </section>

    <section class="yd-card" data-dl-week>
        <div class="yd-head">
            <h3>近 7 天数据明细</h3><span class="sp"></span>
            <span class="yd-live" data-dl-time title="每 60 秒自动同步最新数据"><i></i>实时 · <em>刚刚更新</em></span>
        </div>
        <div class="yd-body">
            <?php $wk = $dashLive['week']; ?>
            <table class="yd-tbl">
                <thead>
                    <tr><th>日期</th><th>访客</th><th>蜘蛛</th><th>发布</th><th>评论</th></tr>
                </thead>
                <tbody data-dl-rows>
                    <?php foreach ($wk['rows'] as $r): ?>
                    <tr<?php echo $r['today'] ? ' class="today"' : ''; ?>>
                        <td><?php echo $r['date']; ?> <em><?php echo $r['week']; ?><?php echo $r['today'] ? ' · 今' : ''; ?></em></td>
                        <td class="<?php echo $r['visit'] > 0 ? 'on' : 'z'; ?>"><?php echo $r['visit']; ?></td>
                        <td class="<?php echo $r['spider'] > 0 ? 'on' : 'z'; ?>"><?php echo $r['spider']; ?></td>
                        <td class="<?php echo $r['post'] > 0 ? 'on' : 'z'; ?>"><?php echo $r['post']; ?></td>
                        <td class="<?php echo $r['cmt'] > 0 ? 'on' : 'z'; ?>"><?php echo $r['cmt']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td>合计</td>
                        <td><?php echo $wk['total']['visit']; ?></td>
                        <td><?php echo $wk['total']['spider']; ?></td>
                        <td><?php echo $wk['total']['post']; ?></td>
                        <td><?php echo $wk['total']['cmt']; ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </section>


    <section class="yd-card" data-wm-card="trends">
        <div class="yd-head"><h3>运行指标</h3><span class="sp"></span>
            <span class="yd-range" data-wm-status>等待同步</span>
            <button type="button" class="wm-btn" data-wm-action="trends">刷新</button>
        </div>
        <div class="yd-body">
            <div class="wm-slot" data-wm-slot="trends"><?php echo yxWmPart($yxWm, 'trends'); ?></div>
        </div>
    </section>

    <section class="yd-card">
        <div class="yd-head"><h3>服务器状态</h3><span class="sp"></span><span class="yd-lvx lv-<?php echo $srvLv; ?>"><i></i><?php echo $srvLvText; ?></span></div>
        <div class="yd-body">
            <div class="yd-srv">
                <div class="yd-srv-row">
                    <span class="k">CPU 负载</span>
                    <span class="bar"><i class="<?php echo $loadLv; ?>" style="width:<?php echo $loadPct; ?>%"></i></span>
                    <span class="v"><?php echo $load1 === null ? '—' : $load1; ?></span>
                </div>
                <div class="yd-srv-row">
                    <span class="k">内存占用</span>
                    <span class="bar"><i class="<?php echo $memLv; ?>" style="width:<?php echo $memPct; ?>%"></i></span>
                    <span class="v"><?php echo $memPct; ?>%</span>
                </div>
                <div class="yd-srv-row">
                    <span class="k">磁盘占用</span>
                    <span class="bar"><i class="<?php echo $diskLv; ?>" style="width:<?php echo $diskPct; ?>%"></i></span>
                    <span class="v"><?php echo $diskPct; ?>%</span>
                </div>
                <div class="yd-srv-meta">
                    <span>PHP <?php echo htmlspecialchars($phpVer); ?></span>
                    <span><?php echo $coresKnown ? $cores . ' 核' : '核数未知'; ?></span>
                    <span>OPcache <?php echo $opcacheOn ? '已开' : '未开'; ?></span>
                    <span>上传 <?php echo htmlspecialchars((string) ini_get('upload_max_filesize')); ?></span>
                    <span>余量 <?php echo $diskFree !== false ? yxFmtBytes($diskFree) : '—'; ?></span>
                </div>
                <?php if ($extMiss): ?>
                <div class="yd-srv-tip">缺少扩展：<?php echo htmlspecialchars(implode('、', $extMiss)); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="yd-card">
        <div class="yd-head"><h3>SEO 健康</h3><span class="sp"></span>
            <button type="button" class="yd-seo-auto" data-yx-fix-all title="自动补齐 robots.txt / sitemap.xml / 站点描述 / 文章描述，并开启友好链接">一键优化</button>
            <span class="yd-range"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-search"></use></svg>收录 <?php echo $seoIndex; ?></span></div>
        <div class="yd-body">
            <div class="yd-seo">
                <div class="yd-seo-top">
                    <div class="yd-seo-ring r-<?php echo $seoLv; ?>">
                        <svg viewBox="0 0 36 36" aria-hidden="true">
                            <circle class="bg" cx="18" cy="18" r="15.5" pathLength="100"/>
                            <circle class="fg" cx="18" cy="18" r="15.5" pathLength="100" stroke-dasharray="<?php echo $seoScore; ?> 100"/>
                        </svg>
                        <b><?php echo $seoScore; ?></b>
                    </div>
                    <div class="yd-seo-info">
                        <strong>健康分</strong>
                        <span>收录页面 <b><?php echo $seoIndex; ?></b> · 描述覆盖 <b><?php echo $seoDescCov; ?>%</b></span>
                    </div>
                </div>
                <ul class="yd-seo-list" data-seo-list>
                    <?php foreach ($seoChecks as $sc): ?>
                    <li class="<?php echo $sc[1] ? 'on' : 'off'; ?>">
                        <i class="st"><?php echo $sc[1] ? '✓' : '—'; ?></i>
                        <span class="n"><?php echo htmlspecialchars($sc[0]); ?></span>
                        <span class="d"><?php echo htmlspecialchars((string) $sc[3]); ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </section>

    <section class="yd-card">
        <div class="yd-head"><h3>蜘蛛抓取</h3><span class="sp"></span><span class="yd-range"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-spider"></use></svg>近 7 天 <?php echo $spider7; ?></span></div>
        <div class="yd-body">
            <div class="yd-sp">
                <div class="yd-sp-top">
                    <div class="yd-sp-kpi"><b><?php echo $spiderToday; ?></b><em>今日</em></div>
                    <div class="yd-sp-kpi"><b><?php echo $spider7; ?></b><em>近 7 天</em></div>
                    <div class="yd-sp-kpi"><b><?php echo $runTotal['spider']; ?></b><em>近 14 天</em></div>
                </div>
                <?php if ($spiderTop || $spiderOtherList): ?>
                <?php if ($spiderTop): ?>
                <div class="yd-sp-sec">主流蜘蛛</div>
                <ul class="yd-sp-list">
                    <?php foreach ($spiderTop as $st): ?>
                    <li>
                        <span class="n"><?php echo htmlspecialchars($st['n']); ?></span>
                        <span class="bar"><i style="width:<?php echo $spiderMax > 0 ? max(8, (int) round($st['v'] * 100 / $spiderMax)) : 0; ?>%"></i></span>
                        <span class="c"><?php echo $st['v']; ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
                <?php if ($spiderOtherList): ?>
                <div class="yd-sp-sec">其他蜘蛛明细 <em><?php echo $spiderOtherNum; ?> 种</em></div>
                <ul class="yd-sp-list yd-sp-other">
                    <?php foreach ($spiderOtherList as $so): ?>
                    <li>
                        <span class="n"><?php echo htmlspecialchars($so['n']); ?></span>
                        <span class="bar"><i style="width:<?php echo $spiderOtherMax > 0 ? max(6, (int) round($so['v'] * 100 / $spiderOtherMax)) : 0; ?>%"></i></span>
                        <span class="c"><?php echo $so['v']; ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
                <?php else: ?>
                <p class="yd-sp-empty">暂无抓取记录，前台被访问后自动开始统计</p>
                <?php endif; ?>
                <p class="yd-sp-foot">最近活跃 <?php echo htmlspecialchars($spiderLastText); ?></p>
            </div>
        </div>
    </section>

    <div class="yd-kpis">
        <div class="yd-kpi">
            <span class="ic ci-a"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-users"></use></svg></span>
            <div class="tx"><b><?php echo $visitToday; ?></b><em>今日访客</em></div>
        </div>
        <div class="yd-kpi">
            <span class="ic ci-b"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-spider"></use></svg></span>
            <div class="tx"><b><?php echo $spiderToday; ?></b><em>今日蜘蛛</em></div>
        </div>
        <div class="yd-kpi">
            <span class="ic ci-c"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-globe"></use></svg></span>
            <div class="tx"><b><?php echo $spider7; ?></b><em>近 7 天抓取</em></div>
        </div>
        <div class="yd-kpi">
            <span class="ic ci-d"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-file"></use></svg></span>
            <div class="tx"><b><?php echo $seoIndex; ?></b><em>收录页面</em></div>
        </div>
        <div class="yd-kpi">
            <span class="ic ci-e"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-server"></use></svg></span>
            <div class="tx"><b><?php echo $load1 === null ? '—' : $load1; ?></b><em>CPU 负载</em></div>
        </div>
        <div class="yd-kpi">
            <span class="ic ci-f"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-search"></use></svg></span>
            <div class="tx"><b><?php echo $seoScore; ?></b><em>SEO 健康分</em></div>
        </div>
    </div>

    <section class="yd-card" data-dl-adv>
        <div class="yd-head">
            <h3>优化建议</h3><span class="sp"></span>
            <span class="yd-live" data-dl-time title="每 60 秒自动同步最新状态"><i></i>实时 · <em>刚刚更新</em></span>
            <span class="yd-range"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-alert"></use></svg><b data-dl-pending><?php echo count($advice); ?></b> 项待处理</span>
        </div>
        <div class="yd-body">
            <?php if ($advice): ?>
            <ul class="yd-adv-list" data-dl-list>
                <?php foreach ($advice as $a): ?>
                <li data-pri="<?php echo $a['pri']; ?>">
                    <span class="ic tone-<?php echo $a['tone']; ?>"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#<?php echo $a['icon']; ?>"></use></svg></span>
                    <div class="tx">
                        <strong><?php echo htmlspecialchars($a['title']); ?></strong>
                        <span><?php echo htmlspecialchars($a['desc']); ?></span>
                    </div>
                    <?php if (!empty($a['fix'])): ?>
                    <button type="button" class="yd-adv-go fix" data-yx-fix="<?php echo htmlspecialchars($a['fix'], ENT_QUOTES); ?>" title="后台自动处理，无需手工操作"><?php echo htmlspecialchars($a['action']); ?></button>
                    <?php elseif ($a['url']): ?>
                    <a class="yd-adv-go" href="<?php echo $options->adminUrl($a['url']); ?>"><?php echo htmlspecialchars($a['action']); ?></a>
                    <?php else: ?>
                    <span class="yd-adv-go ghost"><?php echo htmlspecialchars($a['action']); ?></span>
                    <?php endif; ?>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php else: ?>
            <p class="yd-adv-ok" data-dl-list><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-check"></use></svg>各项检查均已通过，保持当前运营节奏即可</p>
            <?php endif; ?>
        </div>
    </section>

    <section class="yd-card">
        <div class="yd-head"><h3>常用功能</h3><span class="sp"></span><a class="yd-link" href="<?php echo $options->adminUrl('write-post.php'); ?>">写第一篇 <svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-plus"></use></svg></a></div>
        <div class="yd-body">
            <div class="yd-func">
                <?php foreach ($funcs as $f): ?>
                <a class="yd-fn <?php echo $f[3]; ?>" href="<?php echo $options->adminUrl($f[0]); ?>">
                    <span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#<?php echo $f[1]; ?>"></use></svg></span>
                    <span class="tx"><?php echo $f[2]; ?></span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="yd-card" data-wm-card="weather">
        <div class="yd-head"><h3>实时天气</h3><span class="sp"></span>
            <span class="yd-range" data-wm-status>等待同步</span>
        </div>
        <div class="yd-body">
            <div class="wm-slot" data-wm-slot="weather"><?php echo yxWmPart($yxWm, 'weather'); ?></div>
            <div class="wm-inline-msg" data-wm-global-msg></div>
        </div>
    </section>

    <section class="yd-card" data-wm-card="location">
        <div class="yd-head"><h3>地方定位</h3><span class="sp"></span>
            <span class="yd-range" data-wm-status>等待同步</span>
        </div>
        <div class="yd-body">
            <div class="wm-slot" data-wm-slot="location"><?php echo yxWmPart($yxWm, 'location'); ?></div>
        </div>
    </section>

    <section class="yd-card" data-wm-card="warnings">
        <div class="yd-head"><h3>气象预警</h3><span class="sp"></span>
            <span class="yd-range" data-wm-status>等待同步</span>
        </div>
        <div class="yd-body">
            <div class="wm-slot" data-wm-slot="warnings"><?php echo yxWmPart($yxWm, 'warnings'); ?></div>
        </div>
    </section>

    <section class="yd-card" data-wm-card="forecast">
        <div class="yd-head"><h3>未来天气</h3><span class="sp"></span>
            <span class="yd-range" data-wm-status>等待同步</span>
        </div>
        <div class="yd-body">
            <div class="wm-slot" data-wm-slot="forecast"><?php echo yxWmPart($yxWm, 'forecast'); ?></div>
        </div>
    </section>

    <section class="yd-card" data-wm-card="life">
        <div class="yd-head"><h3>生活指数</h3><span class="sp"></span>
            <button type="button" class="wm-btn" data-wm-action="weather">同步</button>
        </div>
        <div class="yd-body">
            <div class="wm-slot" data-wm-slot="life"><?php echo yxWmPart($yxWm, 'life'); ?></div>
        </div>
    </section>

    <?php $yxTfHtml = yxWmPart($yxWm, 'typhoon'); ?>
    <?php if (strpos($yxTfHtml, 'tf-hero') !== false): ?>
    <section class="yd-card" data-wm-card="typhoon">
        <div class="yd-head"><h3>台风详情</h3><span class="sp"></span>
            <button type="button" class="wm-btn" data-wm-action="typhoon">刷新</button>
        </div>
        <div class="yd-body">
            <div class="wm-slot" data-wm-slot="typhoon"><?php echo $yxTfHtml; ?></div>
        </div>
    </section>
    <?php endif; ?>

    <section class="yd-card">
        <div class="yd-head"><h3>最新评论</h3><span class="sp"></span><a class="yd-link" href="<?php echo $options->adminUrl('manage-comments.php'); ?>">全部 <svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-chev-r"></use></svg></a></div>
        <div class="yd-body">
            <div class="yd-scroll">
                <table class="yd-table">
                    <thead><tr><th>评论者</th><th>内容</th><th>状态</th><th>时间</th></tr></thead>
                    <tbody>
                        <?php if ($cmts): ?>
                        <?php foreach ($cmts as $c): ?>
                        <tr>
                            <td class="nm"><i></i><?php echo htmlspecialchars($c['author']); ?></td>
                            <td><?php echo \TypechoPlugin\YunxiAdmin\Plugin::emojiPreview($c['text'], 24); ?></td>
                            <td><span class="yd-sh<?php echo $c['status'] === 'approved' ? ' lv3' : ($c['status'] === 'waiting' ? ' lv2' : ''); ?>"><?php echo $statusName[$c['status']]; ?></span></td>
                            <td class="tm"><?php echo date('m-d H:i', (int) $c['created']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr><td colspan="4" class="yd-empty">还没有任何评论</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <section class="yd-card" data-wm-card="calendar">
        <div class="yd-head"><h3>本月节日</h3><span class="sp"></span>
            <button type="button" class="wm-btn" data-wm-action="festivals">刷新</button>
        </div>
        <div class="yd-body">
            <div class="wm-slot" data-wm-slot="calendar"></div>
        </div>
    </section>

    <section class="yd-card">
        <div class="yd-head"><h3>待办事项</h3></div>
        <div class="yd-body">
            <ul class="yd-notice">
                <li>
                    <span class="tx">评论审核队列</span>
                    <span class="yd-bd b-<?php echo $cmtWaiting > 0 ? 'warn' : 'ok'; ?>"><?php echo $cmtWaiting; ?> 条待审</span>
                    <a class="yd-link" href="<?php echo $options->adminUrl('manage-comments.php?status=waiting'); ?>">去处理 <svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-chev-r"></use></svg></a>
                </li>
                <?php if ($reviewUrl !== ''): ?>
                <li>
                    <span class="tx">用户投稿</span>
                    <span class="yd-bd b-<?php echo $pendingSub > 0 ? 'warn' : 'ok'; ?>"><?php echo $pendingSub; ?> 条待审</span>
                    <a class="yd-link" href="<?php echo htmlspecialchars($reviewUrl); ?>" target="_blank" rel="noopener">去审核 <svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-chev-r"></use></svg></a>
                </li>
                <?php endif; ?>
                <li>
                    <span class="tx">垃圾评论</span>
                    <span class="yd-bd b-danger"><?php echo $cmtSpam; ?> 条</span>
                    <a class="yd-link" href="<?php echo $options->adminUrl('manage-comments.php?status=spam'); ?>">查看 <svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-chev-r"></use></svg></a>
                </li>
                <li>
                    <span class="tx">待发布文章</span>
                    <span class="yd-bd b-info"><?php echo $draftNum; ?> 篇草稿</span>
                    <a class="yd-link" href="<?php echo $options->adminUrl('manage-posts.php?status=draft'); ?>">去编辑 <svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-chev-r"></use></svg></a>
                </li>
                <li>
                    <span class="tx">站点数据备份</span>
                    <span class="yd-bd b-accent">建议定期</span>
                    <a class="yd-link" href="<?php echo $options->adminUrl('backup.php'); ?>">去备份 <svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-chev-r"></use></svg></a>
                </li>
            </ul>
        </div>
    </section>

    <section class="yd-card" data-wm-card="traffic">
        <div class="yd-head"><h3>交通播报</h3><span class="sp"></span>
            <button type="button" class="wm-btn" data-wm-action="traffic">刷新</button>
        </div>
        <div class="yd-body">
            <div class="wm-slot" data-wm-slot="traffic"><?php echo yxWmPart($yxWm, 'traffic'); ?></div>
        </div>
    </section>

    <section class="yd-card">
        <div class="yd-head"><h3>最新文章</h3><span class="sp"></span><a class="yd-link" href="<?php echo $options->adminUrl('manage-posts.php'); ?>">全部 <svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-chev-r"></use></svg></a></div>
        <div class="yd-body">
            <ul class="yd-latest">
                <?php if ($posts): ?>
                <?php foreach ($posts as $p): ?>
                <li>
                    <a class="tt" href="<?php echo $options->adminUrl('write-post.php?cid=' . $p['cid']); ?>"><?php echo htmlspecialchars(yxCut($p['title'], 26)); ?></a>
                    <div class="mt">
                        <span class="ct">评论 <?php echo (int) $p['commentsNum']; ?></span>
                        <span class="tm"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-clock"></use></svg><?php echo date('Y-m-d', (int) $p['created']); ?></span>
                    </div>
                </li>
                <?php endforeach; ?>
                <?php else: ?>
                <li class="yd-empty">还没有发布任何文章</li>
                <?php endif; ?>
            </ul>
        </div>
    </section>

    <section class="yd-card">
        <div class="yd-head"><h3>本月日历</h3><span class="sp"></span><span class="yd-range"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-calendar"></use></svg><?php echo $y; ?> 年 <?php echo $m; ?> 月</span></div>
        <div class="yd-body">
            <div class="yd-cal-wk">
                <?php foreach ($weekNames as $w): ?>
                <span><?php echo $w; ?></span>
                <?php endforeach; ?>
            </div>
            <div class="yd-cal">
                <?php for ($i = 0; $i < $lead; $i++): ?>
                <span class="out"></span>
                <?php endfor; ?>
                <?php for ($d = 1; $d <= $mDays; $d++): ?>
                <?php
                $cls = array();
                if (isset($dayMap[$d])) {
                    $cls[] = 'has';
                }
                if ($d === $todayD) {
                    $cls[] = 'today';
                }
                $tip = $y . '年' . $m . '月' . $d . '日';
                if (isset($dayMap[$d])) {
                    $tip .= '：' . $dayMap[$d] . ' 篇发布';
                }
                $fd = class_exists('\\YxWeather\\Mobile\\Controller')
                    ? \YxWeather\Mobile\Controller::dayFestivals($yxFest, $d)
                    : array('cls' => '', 'tip' => '', 'label' => '');
                if ($fd['cls'] !== '') {
                    $cls[] = trim($fd['cls']);
                    $tip .= $fd['tip'];
                }
                ?>
                <span class="<?php echo implode(' ', $cls); ?>" title="<?php echo htmlspecialchars($tip); ?>"><?php echo $d; ?></span>
                <?php endfor; ?>
                <?php for ($i = 0; $i < $tail; $i++): ?>
                <span class="out"></span>
                <?php endfor; ?>
            </div>
            <div class="yd-legend"><i>发布日</i><i>今日</i><i>节日 / 节气</i></div>
        </div>
    </section>

    <section class="yd-card yd-insight">
        <div class="yd-head"><h3>内容洞察</h3><span class="sp"></span><span class="yd-range"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-chart"></use></svg>写作数据</span></div>
        <div class="yd-body">
            <div class="yd-ins-grid">
                <div class="yd-ins">
                    <span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-trend"></use></svg></span>
                    <b><?php echo $monthPosts; ?></b>
                    <em>本月发布</em>
                </div>
                <div class="yd-ins">
                    <span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-fire"></use></svg></span>
                    <b><?php echo $weekPosts; ?></b>
                    <em>近 7 天</em>
                </div>
                <div class="yd-ins">
                    <span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-file"></use></svg></span>
                    <b><?php echo $avgWords; ?></b>
                    <em>平均字数</em>
                </div>
                <div class="yd-ins">
                    <span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-clock"></use></svg></span>
                    <b><?php echo $readMinutes; ?></b>
                    <em>阅读分钟</em>
                </div>
            </div>
            <div class="yd-ins-meta">
                <span><i class="dot"></i>分类 <b><?php echo $catNum; ?></b> 个</span>
                <span><i class="dot"></i>标签 <b><?php echo $tagNum; ?></b> 个</span>
                <span><i class="dot"></i>附件 <b><?php echo $attachNum; ?></b> 个</span>
            </div>
        </div>
    </section>

    <?php if ($topCats): ?>
    <section class="yd-card yd-topcat">
        <div class="yd-head"><h3>分类排行</h3><span class="sp"></span><a class="yd-link" href="<?php echo $options->adminUrl('manage-categories.php'); ?>">管理 <svg viewBox="0 0 24 24" aria-hidden="true"><use href="<?php echo $icons; ?>#i-chev-r"></use></svg></a></div>
        <div class="yd-body">
            <ul class="yd-rank">
                <?php foreach ($topCats as $i => $tc): ?>
                <li>
                    <span class="rk r<?php echo $i + 1; ?>"><?php echo $i + 1; ?></span>
                    <span class="nm"><?php echo htmlspecialchars($tc['name']); ?></span>
                    <span class="bar"><i style="width:<?php echo $topCats[0]['count'] > 0 ? max(6, (int) round($tc['count'] * 100 / $topCats[0]['count'])) : 0; ?>%"></i></span>
                    <span class="ct"><?php echo $tc['count']; ?></span>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </section>
    <?php endif; ?>

    <section class="yd-card yd-sys">
        <div><span>文章总数</span><b><?php echo $postsNum; ?></b></div>
        <div><span>评论总数</span><b><?php echo $cmtNum; ?></b></div>
        <div><span>注册用户</span><b><?php echo $usersNum; ?></b></div>
        <div><span>PHP 版本</span><b><?php echo htmlspecialchars($phpVer); ?></b></div>
        <div><span>Typecho</span><b><?php echo htmlspecialchars($sysVer); ?></b></div>
        <div><span>数据库</span><b><?php echo htmlspecialchars($dbName); ?></b></div>
    </section>

    <section class="yd-about">
        <div class="yd-about-h"><b>YunxiAdmin</b><em>v<?php echo htmlspecialchars($VER); ?></em><span>后台美化 · 天气工作台</span></div>
        <p>50 米街道级定位、实时天气与气象预警、台风动态轨迹与登陆预估、免费交通路况、页面性能看板；电脑端与手机端独立布局。</p>
    </section>

</div>

<script>window.YX_RUN=<?php echo json_encode(array('keys' => $runKeys, 'series' => $runSeries), JSON_UNESCAPED_UNICODE); ?>;</script>

<?php

try {
    if (class_exists('\\YxWeather\\Metrics')) {
        $__yxT0 = isset($_SERVER['REQUEST_TIME_FLOAT'])
            ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : microtime(true);
        \YxWeather\Metrics::record('mobile', 'page', 'dashboard', (microtime(true) - $__yxT0) * 1000, true);
    }
} catch (\Throwable $e) {
}
?>
<script>window.YX_WEATHER_BOOT=<?php echo json_encode(array(
    'end' => 'mobile',
    'accuracy' => (int) ($yxWmLoc['accuracy_m'] ?? 0),
    'stage' => (string) ($yxWmLoc['stage'] ?? ''),
    'policy' => 'gps-first',
    'refresh_ms' => 240000
), JSON_UNESCAPED_UNICODE); ?>;</script>

<?php
include __ADMIN_DIR__ . 'copyright.php';
include __ADMIN_DIR__ . 'common-js.php';
include __ADMIN_DIR__ . 'footer.php';
