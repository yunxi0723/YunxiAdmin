<?php

namespace YxWeather;

class Http
{
    const UA = 'YunxiAdmin-Weather/2.1 (+Typecho admin dashboard)';

    public static function raw($url, $timeout = 6)
    {
        $url = (string) $url;
        if ($url === '' || !preg_match('#^https?://#i', $url)) {
            return '';
        }
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => 3,
                CURLOPT_CONNECTTIMEOUT => min(4, (int) $timeout),
                CURLOPT_TIMEOUT        => (int) $timeout,
                CURLOPT_USERAGENT      => self::UA,
                CURLOPT_HTTPHEADER     => array('Accept: application/json, text/plain, */*'),
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_ENCODING       => ''
            ));
            $body = curl_exec($ch);
            curl_close($ch);
            return is_string($body) ? $body : '';
        }
        $ctx = stream_context_create(array(
            'http' => array(
                'timeout'        => (int) $timeout,
                'user_agent'     => self::UA,
                'follow_location'=> 1,
                'max_redirects'  => 3,
                'header'         => "Accept: application/json, text/plain, */*\r\n"
            ),
            'ssl' => array('verify_peer' => true, 'verify_peer_name' => true)
        ));
        $body = @file_get_contents($url, false, $ctx);
        return is_string($body) ? $body : '';
    }

    public static function json($url, $timeout = 6)
    {
        $raw = self::raw($url, $timeout);
        if ($raw === '') {
            return null;
        }
        $d = json_decode($raw, true);
        if (is_array($d)) {
            return $d;
        }

        $s = strpos($raw, '{');
        $e = strrpos($raw, '}');
        if ($s !== false && $e !== false && $e > $s) {
            $d = json_decode(substr($raw, $s, $e - $s + 1), true);
            if (is_array($d)) {
                return $d;
            }
        }
        return null;
    }

    public static function remember($key, $ttl, $build, $cacheWhen = null)
    {
        $file = sys_get_temp_dir() . '/yxw2-' . preg_replace('/[^A-Za-z0-9_\-]/', '-', $key) . '.json';
        if ($ttl > 0 && is_file($file) && (time() - (int) @filemtime($file)) < $ttl) {
            $cached = json_decode((string) @file_get_contents($file), true);
            if (is_array($cached) && isset($cached['__yxw2'])) {
                return $cached['v'];
            }
        }
        $value = $build();
        $ok = is_callable($cacheWhen) ? (bool) $cacheWhen($value) : ($value !== null && $value !== false);
        if ($ok) {
            @file_put_contents($file, json_encode(array('__yxw2' => 1, 'v' => $value), JSON_UNESCAPED_UNICODE));
        }
        return $value;
    }

    public static function stale($key)
    {
        $file = sys_get_temp_dir() . '/yxw2-' . preg_replace('/[^A-Za-z0-9_\-]/', '-', $key) . '.json';
        if (!is_file($file)) {
            return null;
        }
        $cached = json_decode((string) @file_get_contents($file), true);
        return is_array($cached) && isset($cached['v']) ? $cached['v'] : null;
    }

    public static function num($v, $default = null)
    {
        return is_numeric($v) ? (float) $v : $default;
    }
}
