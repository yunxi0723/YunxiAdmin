<?php

namespace YxWeather;

class TrafficSource
{
    const NATIONWIDE = array('地震', '雪灾', '雷暴雨', '雷暴', '泥石流', '台风');

    private static function tokens($loc)
    {
        $raw = array();
        foreach (array('province', 'city', 'district', 'street') as $k) {
            $v = trim((string) ($loc[$k] ?? ''));
            if ($v !== '') {
                $raw[] = $v;
            }
        }
        if (!empty($loc['place_parts']) && is_array($loc['place_parts'])) {
            foreach ($loc['place_parts'] as $v) {
                $v = trim((string) $v);
                if ($v !== '' && !in_array($v, $raw, true)) {
                    $raw[] = $v;
                }
            }
        }
        $out = array();
        foreach ($raw as $n) {
            $out[] = $n;
            $short = preg_replace('/(特别行政区|自治区|自治州|地区|省|市|区|县|盟|旗|镇|乡|街道)$/u', '', $n);
            if ($short !== '' && mb_strlen($short) >= 2 && $short !== $n) {
                $out[] = $short;
            }
        }
        return array_values(array_unique(array_filter($out, function ($v) {
            return mb_strlen($v) >= 2;
        })));
    }

    private static function isNational($type)
    {
        foreach (self::NATIONWIDE as $k) {
            if (mb_strpos($type, $k) !== false) {
                return true;
            }
        }
        return false;
    }

    private static function place($loc)
    {
        if (!empty($loc['place_text'])) {
            return (string) $loc['place_text'];
        }
        $parts = array();
        foreach (array('province', 'city', 'district', 'street') as $k) {
            $v = trim((string) ($loc[$k] ?? ''));
            if ($v !== '' && !in_array($v, $parts, true)) {
                $parts[] = $v;
            }
        }
        return $parts ? implode(' · ', $parts) : '当前位置';
    }

    private static function n($v, $d = null)
    {
        return is_numeric($v) ? (float) $v : $d;
    }

    public static function local($loc, $weather = null, $allowFetch = true)
    {
        $loc = is_array($loc) ? $loc : array();
        if (empty($loc['province']) && empty($loc['city'])) {
            try {
                $ip = AccountLocation::ipCoarse(AccountLocation::clientIp());
                if (!empty($ip['ok'])) {
                    $loc = array(
                        'province' => (string) ($ip['province'] ?? ''),
                        'city' => (string) ($ip['city'] ?? ''),
                        'district' => (string) ($ip['district'] ?? ''),
                        'street' => '',
                        'stage_text' => 'IP 定位'
                    );
                }
            } catch (\Throwable $e) {
            }
        }
        $stage = (string) ($loc['stage_text'] ?? 'IP 定位');
        $city = trim((string) ($loc['city'] ?? ''));
        if ($city === '') {
            $city = trim((string) ($loc['province'] ?? ''));
        }

        $live = PluginBridge::call('trafficStatus', array(
            $city,
            isset($loc['lat']) ? $loc['lat'] : null,
            isset($loc['lon']) ? $loc['lon'] : null
        ), null);
        $congestion = array();
        $statusText = '';
        $description = '';
        $ratio = array();
        $liveSource = '';
        $events = array();
        if (is_array($live) && !empty($live['status'])) {
            $statusText = (string) ($live['statusText'] ?? '');
            $description = (string) ($live['description'] ?? '');
            $ratio = (array) ($live['ratio'] ?? array());
            $liveSource = (string) ($live['source'] ?? '高德地图');
            foreach ((array) ($live['roads'] ?? array()) as $road) {
                if (!is_array($road)) {
                    continue;
                }
                $congestion[] = array(
                    'name' => (string) ($road['name'] ?? ''),
                    'status' => (int) ($road['status'] ?? 0),
                    'status_text' => (string) ($road['statusText'] ?? ''),
                    'speed' => $road['speed'] ?? null,
                    'direction' => (string) ($road['direction'] ?? '')
                );
            }
            foreach ((array) ($live['events'] ?? array()) as $ev) {
                if (!is_array($ev)) {
                    continue;
                }
                $events[] = array(
                    'type' => (string) ($ev['type'] ?? '交通事件'),
                    'road' => (string) ($ev['road'] ?? ''),
                    'desc' => (string) ($ev['desc'] ?? '')
                );
            }
        }

        $wx = is_array($weather) && !empty($weather['status']) ? $weather : null;
        if ($wx === null && $allowFetch && isset($loc['lat'], $loc['lon'])) {
            $wx = WeatherSource::current((float) $loc['lat'], (float) $loc['lon'],
                $loc, 'traffic-weather', 300);
        }
        $roads = self::roads($loc, $allowFetch);
        $risk = self::risk($wx, $roads, $ratio, $statusText);

        if ($statusText === '') {
            $statusText = $risk['label'];
        }
        if ($description === '') {
            $description = $risk['note'];
        }

        $advice = self::advice($wx, $risk, $roads);
        foreach ($advice as $a) {
            if (empty($events)) {
                $events[] = array('type' => '天气影响', 'road' => '周边路网', 'desc' => $a);
            }
        }

        return array(
            'place' => self::place($loc),
            'stage' => $stage,
            'scope_label' => $stage . ' · 街道范围',
            'date' => date('Y-m-d'),
            'source' => $liveSource ?: 'Open-Meteo + OpenStreetMap',
            'items' => array(),
            'alerts' => array(),
            'events' => $events,
            'status_text' => $statusText,
            'description' => $description,
            'ratio' => $ratio,
            'congestion' => $congestion,
            'live_source' => $liveSource,
            'live' => $liveSource !== '',
            'risk' => $risk,
            'weather' => self::weatherBox($wx),
            'roads' => $roads,
            'hourly' => self::hourly($wx),
            'best' => self::best($wx),
            'advice' => $advice,
            'factors' => $risk['factors'],
            'empty' => false
        );
    }

    private static function weatherBox($w)
    {
        if (!is_array($w) || empty($w['status'])) {
            return array('ok' => false, 'text' => '气象数据暂不可用', 'temp' => null, 'precip' => null,
                'pop' => null, 'vis' => null, 'wind' => null, 'surface' => '—');
        }
        $temp = self::n($w['temperature'] ?? null);
        $precip = self::n($w['precipitation'] ?? null, 0);
        $pop = self::n($w['pop'] ?? null);
        if ($pop === null && !empty($w['hourly'][0]['pop'])) {
            $pop = (float) $w['hourly'][0]['pop'];
        }
        $vis = self::n($w['visibility'] ?? null);
        $wind = self::n($w['wind_speed'] ?? null);
        $text = (string) ($w['weather'] ?? '—');
        $surface = '路面干燥';
        if ($temp !== null && $temp <= 1) {
            $surface = '路面可能结冰';
        } elseif (mb_strpos($text, '雪') !== false) {
            $surface = '积雪 / 湿滑';
        } elseif ($precip >= 0.1 || mb_strpos($text, '雨') !== false) {
            $surface = '路面湿滑';
        }
        return array('ok' => true, 'text' => $text, 'temp' => $temp, 'precip' => $precip,
            'pop' => $pop, 'vis' => $vis, 'wind' => $wind, 'surface' => $surface);
    }

    private static function roads($loc, $allowFetch = true)
    {
        $lat = self::n($loc['lat'] ?? null);
        $lon = self::n($loc['lon'] ?? null);
        if ($lat === null || $lon === null) {
            return array('ok' => false, 'items' => array(), 'count' => 0, 'nearest' => null,
                'source' => '未获取坐标，无法匹配路网');
        }
        $key = 'roads2-' . round($lat, 3) . '-' . round($lon, 3);
        $out = $allowFetch ? Http::remember($key, 21600, function () use ($lat, $lon) {
            $around = '[out:json][timeout:4];way(around:2500,' . round($lat, 4) . ','
                . round($lon, 4) . ')[highway~"^(motorway|trunk|primary|secondary)$"][name];'
                . 'out tags center 40;';
            $j = Http::json('https://overpass-api.de/api/interpreter?data=' . rawurlencode($around), 3);
            if (!is_array($j) || empty($j['elements'])) {
                return null;
            }
            $items = array();
            $seen = array();
            if (is_array($j) && !empty($j['elements'])) {
                foreach ($j['elements'] as $el) {
                    $tags = isset($el['tags']) && is_array($el['tags']) ? $el['tags'] : array();
                    $name = trim((string) ($tags['name'] ?? ''));
                    if ($name === '' || mb_strlen($name) < 2 || isset($seen[$name])) {
                        continue;
                    }
                    $hw = (string) ($tags['highway'] ?? '');
                    $dist = null;
                    if (!empty($el['center']['lat']) && !empty($el['center']['lon'])) {
                        $dist = AccountLocation::distance($lat, $lon,
                            (float) $el['center']['lat'], (float) $el['center']['lon']);
                    }
                    $seen[$name] = true;
                    $items[] = array(
                        'name' => $name,
                        'type' => self::roadType($hw),
                        'highway' => $hw,
                        'distance_km' => $dist,
                        'lanes' => (string) ($tags['lanes'] ?? ''),
                        'maxspeed' => (string) ($tags['maxspeed'] ?? '')
                    );
                    if (count($items) >= 10) {
                        break;
                    }
                }
            }
            usort($items, function ($a, $b) {
                if ($a['distance_km'] === null) {
                    return 1;
                }
                if ($b['distance_km'] === null) {
                    return -1;
                }
                return $a['distance_km'] - $b['distance_km'];
            });
            return array('ok' => !empty($items), 'items' => $items, 'count' => count($items),
                'source' => 'OpenStreetMap Overpass');
        }) : Http::stale($key);
        if (!is_array($out)) {
            $out = array('ok' => false, 'items' => array(), 'count' => 0);
        }
        $seed = trim((string) ($loc['street'] ?? ''));
        if ($seed !== '') {
            $exists = false;
            foreach ((array) $out['items'] as $it) {
                if (mb_strpos((string) $it['name'], $seed) !== false || mb_strpos($seed, (string) $it['name']) !== false) {
                    $exists = true;
                    break;
                }
            }
            if (!$exists) {
                array_unshift($out['items'], array('name' => $seed, 'type' => '所在街道',
                    'highway' => '', 'distance_km' => 0, 'lanes' => '', 'maxspeed' => ''));
            }
        }
        $out['count'] = count($out['items']);
        $out['ok'] = $out['count'] > 0;
        $out['nearest'] = $out['items'] ? $out['items'][0] : null;
        if (empty($out['source'])) {
            $out['source'] = '所在街道 + OpenStreetMap（路网接口暂不可用）';
        }
        return $out;
    }

    private static function roadType($hw)
    {
        $map = array(
            'motorway' => '高速', 'trunk' => '快速路 / 国道',
            'primary' => '主干道', 'secondary' => '次干道'
        );
        return isset($map[$hw]) ? $map[$hw] : '道路';
    }

    private static function risk($w, $roads, $ratio, $liveText)
    {
        $score = 0;
        $factors = array();
        $hour = (int) date('G');
        $wx = self::weatherBox($w);
        if ($wx['ok']) {
            $p = (float) ($wx['precip'] ?? 0);
            $add = (int) round(min(38, $p * 12));
            $score += $add;
            $factors[] = array('name' => '降水', 'value' => $p > 0 ? $p . ' mm/h' : '暂无',
                'level' => $add >= 24 ? 3 : ($add >= 12 ? 2 : ($add > 0 ? 1 : 0)));
            $pop = $wx['pop'] !== null ? (int) $wx['pop'] : null;
            $add = $pop !== null ? (int) round(min(18, $pop * 0.18)) : 0;
            $score += $add;
            $factors[] = array('name' => '降水概率', 'value' => $pop !== null ? $pop . '%' : '—',
                'level' => $add >= 12 ? 2 : ($add > 0 ? 1 : 0));
            $v = $wx['vis'];
            $add = $v !== null && $v < 10 ? (int) round(min(20, (10 - $v) * 3.2)) : 0;
            $score += $add;
            $factors[] = array('name' => '能见度', 'value' => $v !== null ? $v . ' km' : '—',
                'level' => $add >= 12 ? 3 : ($add >= 6 ? 2 : ($add > 0 ? 1 : 0)));
            $wind = $wx['wind'];
            $add = $wind !== null ? (int) round(min(18, max(0, ($wind - 5) * 1.5))) : 0;
            $score += $add;
            $factors[] = array('name' => '风力', 'value' => $wind !== null ? $wind . ' m/s' : '—',
                'level' => $add >= 12 ? 3 : ($add >= 6 ? 2 : ($add > 0 ? 1 : 0)));
            $t = $wx['temp'];
            $add = ($t !== null && ($t <= 1 || $t >= 35)) ? 8 : 0;
            $score += $add;
            $factors[] = array('name' => '气温', 'value' => $t !== null ? $t . '°C' : '—',
                'level' => $add > 0 ? 2 : 0);
        }
        $rush = ($hour >= 7 && $hour <= 9) || ($hour >= 17 && $hour <= 19);
        if ($rush) {
            $score += 8;
        }
        $factors[] = array('name' => '出行时段', 'value' => $rush ? '通勤高峰' : '平峰',
            'level' => $rush ? 2 : 0);
        if ($hour >= 22 || $hour < 6) {
            $score += 4;
        }
        $count = (int) ($roads['count'] ?? 0);
        if ($count >= 8) {
            $score += 4;
        }
        $factors[] = array('name' => '周边路网', 'value' => $count > 0 ? $count . ' 条主次干道' : '未匹配',
            'level' => $count >= 8 ? 1 : 0);
        $jam = isset($ratio['拥堵']) ? (float) $ratio['拥堵'] : null;
        if ($jam !== null) {
            $score += $jam >= 20 ? 10 : ($jam >= 10 ? 5 : 0);
        }
        if (mb_strpos($liveText, '畅通') !== false) {
            $score -= 6;
        }
        $score = max(0, min(100, $score));

        if ($score < 25) {
            $level = 0;
            $label = '通行顺畅';
            $note = '气象条件对道路交通影响较小，可按正常速度通行。';
        } elseif ($score < 45) {
            $level = 1;
            $label = '轻度影响';
            $note = '部分路段受天气影响，建议适当减速并保持车距。';
        } elseif ($score < 65) {
            $level = 2;
            $label = '明显影响';
            $note = '降雨或低能见度导致通行效率下降，主干道可能排队。';
        } else {
            $level = 3;
            $label = '高风险';
            $note = '强降水或大风等不利条件叠加，非必要不建议驾车出行。';
        }
        return array('score' => $score, 'level' => $level, 'label' => $label, 'note' => $note,
            'factors' => $factors);
    }

    private static function hourly($w)
    {
        if (!is_array($w) || empty($w['hourly'])) {
            return array();
        }
        $out = array();
        $hour = (int) date('G');
        foreach ($w['hourly'] as $i => $h) {
            $pop = self::n($h['pop'] ?? null, 0);
            $precip = self::n($h['precipitation'] ?? null, 0);
            $wind = self::n($h['wind'] ?? null, 0);
            $vis = self::n($h['visibility'] ?? null, null);
            $s = min(100, $pop * 0.35 + $precip * 10 + max(0, ($wind - 5) * 1.2)
                + ($vis !== null && $vis < 10 ? (10 - $vis) * 2 : 0));
            $hr = ($hour + $i) % 24;
            if (($hr >= 7 && $hr <= 9) || ($hr >= 17 && $hr <= 19)) {
                $s += 8;
            }
            $s = (int) round(max(0, min(100, $s)));
            $level = $s < 25 ? 0 : ($s < 45 ? 1 : ($s < 65 ? 2 : 3));
            $out[] = array('time' => (string) ($h['time'] ?? ''), 'pop' => (int) $pop,
                'precip' => $precip, 'wind' => $wind, 'score' => $s, 'level' => $level);
        }
        return array_slice($out, 0, 10);
    }

    private static function best($w)
    {
        $hs = self::hourly($w);
        if (count($hs) < 2) {
            return array();
        }
        $best = null;
        $n = count($hs);
        for ($i = 0; $i < $n - 1; $i++) {
            $avg = ($hs[$i]['score'] + $hs[$i + 1]['score']) / 2;
            if ($best === null || $avg < $best['score']) {
                $best = array('start' => $hs[$i]['time'], 'end' => $hs[$i + 1]['time'],
                    'score' => (int) round($avg), 'level' => $hs[$i]['level']);
            }
        }
        if (!$best) {
            return array();
        }
        $best['label'] = $best['score'] < 25 ? '最佳出行时段'
            : ($best['score'] < 45 ? '相对顺畅时段' : '影响最小窗口');
        return $best;
    }

    private static function advice($w, $risk, $roads)
    {
        $wx = self::weatherBox($w);
        $out = array();
        if (!$wx['ok']) {
            return array('气象数据暂不可用，出行前请查看当地交管与气象部门发布的信息。');
        }
        if ($wx['precip'] !== null && $wx['precip'] >= 0.1) {
            $out[] = '正在降雨，路面湿滑，跟车距离建议增加到平时的 1.5 倍。';
        }
        if ($wx['vis'] !== null && $wx['vis'] < 5) {
            $out[] = '能见度不足 5 km，开启雾灯与近光灯，避免急刹和频繁变道。';
        }
        if ($wx['wind'] !== null && $wx['wind'] >= 10) {
            $out[] = '风力较大，高架、跨江大桥与沿海路段注意横风，双手稳握方向盘。';
        }
        if ($wx['temp'] !== null && $wx['temp'] <= 1) {
            $out[] = '气温接近冰点，桥面、隧道口与背阴路段可能结冰，提前减速。';
        }
        if ($risk['level'] >= 2) {
            $out[] = '当前为' . $risk['label'] . '，建议错峰出行或改乘公共交通。';
        }
        $nearest = isset($roads['nearest']) && is_array($roads['nearest']) ? $roads['nearest'] : null;
        if ($nearest) {
            $dist = $nearest['distance_km'];
            $out[] = '最近的主干道为' . $nearest['name'] . '（' . $nearest['type'] . '，'
                . ($dist !== null && $dist > 0 ? '约 ' . $dist . ' km' : '1 km 内') . '），可作为出行参考。';
        }
        if (!$out) {
            $out[] = '当前气象条件对通行影响较小，保持安全车距即可。';
        }
        $out[] = '路况由 Open-Meteo 气象与 OpenStreetMap 路网推算，非交管实时数据。';
        return $out;
    }
}
