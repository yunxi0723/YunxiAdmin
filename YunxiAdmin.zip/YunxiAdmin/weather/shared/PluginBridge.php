<?php

namespace YxWeather;

class PluginBridge
{
    private static $cls = null;
    private static $tried = false;

    public static function cls()
    {
        if (self::$tried) {
            return self::$cls;
        }
        self::$tried = true;
        $name = '\\TypechoPlugin\\YunxiAdmin\\Plugin';
        if (class_exists($name)) {
            self::$cls = $name;
            return self::$cls;
        }
        $file = defined('YX_WEATHER_PLUGIN_DIR')
            ? YX_WEATHER_PLUGIN_DIR . '/Plugin.php'
            : dirname(__DIR__) . '/Plugin.php';
        if (!is_file($file)) {
            return null;
        }
        try {
            @require_once $file;
            if (class_exists($name)) {
                self::$cls = $name;
            }
        } catch (\Throwable $e) {
            self::$cls = null;
        }
        return self::$cls;
    }

    public static function call($method, $args = array(), $default = null)
    {
        $cls = self::cls();
        if (!$cls || !method_exists($cls, $method)) {
            return $default;
        }
        try {
            return call_user_func_array(array($cls, $method), $args);
        } catch (\Throwable $e) {
            return $default;
        }
    }
}
