<?php

namespace YxWeather;

class TrafficScene
{
    private static function e($v)
    {
        return htmlspecialchars((string) ($v === null ? '' : $v), ENT_QUOTES, 'UTF-8');
    }

    public static function html($d)
    {
        if (!is_array($d)) {
            return '<div class="tr-empty">交通天气暂不可用</div>';
        }
        $risk = isset($d['risk']) && is_array($d['risk']) ? $d['risk'] : array(
            'score' => 0, 'level' => 0, 'label' => '—', 'note' => '', 'factors' => array()
        );
        $wx = isset($d['weather']) && is_array($d['weather']) ? $d['weather'] : array('ok' => false);
        $h = self::head($d);
        $h .= self::risk($risk, $wx);
        $h .= self::weather($wx);
        $h .= self::factors($risk['factors'] ?? array());
        $h .= self::live($d);
        $h .= self::roads($d['roads'] ?? array());
        $h .= self::hourly($d);
        $h .= self::advice($d['advice'] ?? array());
        $h .= self::events($d['events'] ?? array());
        $h .= '<div class="tr-note">数据源：' . self::e($d['source'] ?? 'Open-Meteo + OpenStreetMap')
            . ' · 街道范围匹配 · 路况为气象与路网推算，非交管实时发布</div>';
        return $h;
    }

    private static function head($d)
    {
        $h = '<div class="tr-head"><div><b>' . self::e($d['place'] ?? '当前位置') . '</b>'
            . '<span>' . self::e($d['scope_label'] ?? '街道范围') . '</span></div>'
            . '<em>' . self::e($d['date'] ?? date('Y-m-d')) . '</em></div>';
        return $h;
    }

    private static function risk($r, $wx)
    {
        $score = max(0, min(100, (int) ($r['score'] ?? 0)));
        $level = max(0, min(3, (int) ($r['level'] ?? 0)));
        $circ = 2 * M_PI * 34;
        $dash = round($circ * $score / 100, 1);
        $h = '<div class="tr-risk lv' . $level . '">'
            . '<div class="tr-gauge"><svg viewBox="0 0 80 80" aria-hidden="true">'
            . '<circle cx="40" cy="40" r="34" class="tr-g-bg"/>'
            . '<circle cx="40" cy="40" r="34" class="tr-g-fg" stroke-dasharray="' . $dash . ' ' . round($circ, 1)
            . '" transform="rotate(-90 40 40)"/>'
            . '<text x="40" y="45" text-anchor="middle" class="tr-g-num">' . $score . '</text>'
            . '</svg><i>影响指数</i></div>'
            . '<div class="tr-risk-main"><span class="tr-risk-tag">' . self::e($r['label'] ?? '—') . '</span>'
            . '<b>' . self::e($wx['text'] ?? '—') . ' · ' . self::e($wx['surface'] ?? '—') . '</b>'
            . '<p>' . self::e($r['note'] ?? '') . '</p></div>';
        if (!empty($wx['ok'])) {
            $h .= '<div class="tr-risk-side"><em>' . self::e($wx['temp'] !== null ? $wx['temp'] . '°C' : '—') . '</em>'
                . '<i>体感温度</i></div>';
        }
        return $h . '</div>';
    }

    private static function weather($w)
    {
        if (empty($w['ok'])) {
            return '<div class="tr-none">气象数据暂不可用，路况影响无法推算</div>';
        }
        $cells = array(
            array('降水', $w['precip'] !== null ? $w['precip'] . ' mm/h' : '—'),
            array('降水概率', $w['pop'] !== null ? (int) $w['pop'] . '%' : '—'),
            array('能见度', $w['vis'] !== null ? $w['vis'] . ' km' : '—'),
            array('风力', $w['wind'] !== null ? $w['wind'] . ' m/s' : '—'),
            array('路面', $w['surface'] ?? '—')
        );
        $h = '<div class="tr-wx">';
        foreach ($cells as $c) {
            $h .= '<div><i>' . self::e($c[0]) . '</i><b>' . self::e($c[1]) . '</b></div>';
        }
        return $h . '</div>';
    }

    private static function factors($items)
    {
        if (!$items) {
            return '';
        }
        $h = '<div class="tr-factors">';
        foreach ($items as $f) {
            $lv = (int) ($f['level'] ?? 0);
            $h .= '<span class="lv' . $lv . '"><i></i>' . self::e($f['name']) . ' '
                . self::e($f['value']) . '</span>';
        }
        return $h . '</div>';
    }

    private static function live($d)
    {
        $congestion = isset($d['congestion']) && is_array($d['congestion']) ? $d['congestion'] : array();
        $live = !empty($d['live_source']);
        $h = '<div class="tr-sub">实时路况 <em>' . self::e($live ? $d['live_source'] : '未接入交管实时数据') . '</em></div>';
        if ($congestion) {
            $h .= '<div class="tr-roads">';
            foreach ($congestion as $r) {
                $h .= '<span class="s' . (int) ($r['status'] ?? 0) . '"><b>' . self::e($r['name'] ?? '')
                    . '</b><i>' . self::e($r['status_text'] ?? '')
                    . (is_numeric($r['speed'] ?? null) && $r['speed'] > 0 ? ' · ' . self::e($r['speed']) . ' km/h' : '')
                    . (!empty($r['direction']) ? ' · ' . self::e($r['direction']) : '') . '</i></span>';
            }
            return $h . '</div>';
        }
        if (!empty($d['description'])) {
            $h .= '<div class="tr-none">' . self::e($d['description']) . '</div>';
        } else {
            $h .= '<div class="tr-none">当前未接入交管实时路况，下方为气象与路网推算结果</div>';
        }
        return $h;
    }

    private static function roads($r)
    {
        $items = isset($r['items']) && is_array($r['items']) ? $r['items'] : array();
        if (!$items) {
            return '';
        }
        $h = '<div class="tr-sub">周边主次干道 <em>' . count($items) . ' 条 · 2.5 km 内</em></div><div class="tr-road-chips">';
        foreach ($items as $it) {
            $dist = $it['distance_km'];
            $h .= '<span><b>' . self::e($it['name']) . '</b><i>' . self::e($it['type'])
                . ($dist !== null ? ' · ' . ($dist > 0 ? $dist . ' km' : '1 km 内') : '') . '</i></span>';
        }
        return $h . '</div>';
    }

    private static function hourly($d)
    {
        $rows = isset($d['hourly']) && is_array($d['hourly']) ? $d['hourly'] : array();
        if (!$rows) {
            return '';
        }
        $best = isset($d['best']) && is_array($d['best']) ? $d['best'] : array();
        $h = '<div class="tr-sub">未来出行窗口 <em>按小时气象推算</em></div><div class="tr-hours">';
        foreach ($rows as $x) {
            $lv = (int) ($x['level'] ?? 0);
            $bh = max(4, min(34, (int) round((int) $x['score'] * 0.34)));
            $isBest = $best && $x['time'] === ($best['start'] ?? '');
            $h .= '<div class="tr-hour lv' . $lv . ($isBest ? ' best' : '') . '">'
                . '<span>' . self::e($x['time']) . '</span>'
                . '<div class="tr-hbar"><i style="height:' . $bh . 'px"></i></div>'
                . '<b>' . (int) $x['pop'] . '%</b></div>';
        }
        $h .= '</div>';
        if ($best) {
            $h .= '<div class="tr-best"><b>' . self::e($best['label']) . '</b><span>'
                . self::e($best['start']) . ' – ' . self::e($best['end'])
                . ' · 影响指数 ' . (int) $best['score'] . '</span></div>';
        }
        return $h;
    }

    private static function advice($items)
    {
        if (!$items) {
            return '';
        }
        $h = '<div class="tr-sub">出行建议</div><ul class="tr-advice">';
        foreach ($items as $a) {
            $h .= '<li>' . self::e($a) . '</li>';
        }
        return $h . '</ul>';
    }

    private static function events($items)
    {
        if (!$items) {
            return '<div class="tr-sub">事故与管制</div><div class="tr-none">当前没有事故或管制上报</div>';
        }
        $h = '<div class="tr-sub">事件与提示</div>';
        foreach (array_slice($items, 0, 6) as $ev) {
            $h .= '<div class="tr-ev"><b>' . self::e($ev['type'] ?? '交通事件') . '</b><span>'
                . self::e($ev['road'] ?? '') . (!empty($ev['desc']) ? ' · ' . self::e($ev['desc']) : '')
                . '</span></div>';
        }
        return $h;
    }
}
