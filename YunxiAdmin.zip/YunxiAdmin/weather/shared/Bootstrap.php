<?php

namespace YxWeather;

class Bootstrap
{
    public static function init()
    {
        $pluginDir = defined('YX_WEATHER_PLUGIN_DIR') ? YX_WEATHER_PLUGIN_DIR : dirname(__DIR__);
        $root = rtrim(dirname(dirname(dirname($pluginDir))), '/');

        if (!defined('__TYPECHO_ROOT_DIR__')) {
            define('__TYPECHO_ROOT_DIR__', $root);
        }

        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

        if (!@include_once $root . '/config.inc.php') {
            http_response_code(500);
            echo json_encode(array('status' => false, 'message' => '无法载入 Typecho 配置文件'), JSON_UNESCAPED_UNICODE);
            exit;
        }

        if (!defined('__TYPECHO_ROOT_URL__')) {
            $rootReal = realpath($root);
            $dirReal  = realpath($pluginDir);
            $relDir   = ($rootReal && $dirReal && strpos($dirReal, $rootReal) === 0)
                ? ltrim(str_replace('\\', '/', substr($dirReal, strlen($rootReal))), '/')
                : 'usr/plugins/YunxiAdmin';
            try {
                $rootUrl = (string) \Typecho\Request::getInstance()->getRequestRoot();
            } catch (\Throwable $e) {
                $rootUrl = '';
            }
            $suffix = '/' . trim($relDir, '/');
            if ($rootUrl !== '' && substr($rootUrl, -strlen($suffix)) === $suffix) {
                $rootUrl = substr($rootUrl, 0, strlen($rootUrl) - strlen($suffix));
            }
            if ($rootUrl !== '') {
                define('__TYPECHO_ROOT_URL__', $rootUrl);
            }
        }

        \Widget\Init::alloc();

        require_once dirname(__FILE__) . '/load.php';
    }

    public static function guard($write = false)
    {
        try {
            $user = \Widget\User::alloc();
            if (!$user->hasLogin()) {
                http_response_code(401);
                self::out(array('status' => false, 'message' => '登录状态已过期，请重新登录'));
            }
        } catch (\Throwable $e) {
            http_response_code(401);
            self::out(array('status' => false, 'message' => '无法校验登录状态'));
        }
        if ($write && !self::sameSite()) {
            http_response_code(403);
            self::out(array('status' => false, 'message' => '请求来源校验未通过'));
        }
        return true;
    }

    public static function uid()
    {
        try {
            return (int) \Widget\User::alloc()->uid;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    public static function sameSite()
    {
        $allow = array();
        try {
            $h = parse_url((string) \Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
            if ($h) {
                $allow[strtolower($h)] = 1;
            }
        } catch (\Throwable $e) {
        }
        if (!empty($_SERVER['HTTP_HOST'])) {
            $allow[strtolower((string) $_SERVER['HTTP_HOST'])] = 1;
        }
        if (!$allow) {
            return false;
        }
        $origin  = isset($_SERVER['HTTP_ORIGIN']) ? (string) $_SERVER['HTTP_ORIGIN'] : '';
        $referer = isset($_SERVER['HTTP_REFERER']) ? (string) $_SERVER['HTTP_REFERER'] : '';
        foreach (array($origin, $referer) as $u) {
            if ($u === '') {
                continue;
            }
            $h = strtolower((string) parse_url($u, PHP_URL_HOST));
            if ($h !== '' && !isset($allow[$h])) {
                return false;
            }
        }
        return !($origin === '' && $referer === '');
    }

    public static function out($data)
    {
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function err($msg, $code = 400)
    {
        http_response_code($code);
        self::out(array('status' => false, 'message' => $msg));
    }

    public static function action()
    {
        return isset($_GET['action']) ? (string) $_GET['action'] : '';
    }

    public static function throttle($uid, $action, $minGap = 2)
    {
        $key = 'yxw2-throttle-' . $uid . '-' . preg_replace('/[^a-z0-9_]/i', '', $action);
        $file = sys_get_temp_dir() . '/' . $key;
        $now = time();
        $last = is_file($file) ? (int) @filemtime($file) : 0;
        if ($now - $last < $minGap) {
            return false;
        }
        @touch($file);
        return true;
    }
}
