<?php

namespace YxWeather;

class TyphoonScene
{
    private static function e($v)
    {
        return htmlspecialchars((string) ($v === null ? '' : $v), ENT_QUOTES, 'UTF-8');
    }

    public static function html($t, $end = 'desktop')
    {
        if (!is_array($t) || empty($t['status']) || empty($t['detail']['available'])) {
            $msg = is_array($t) && isset($t['message']) ? $t['message'] : '暂无活动台风或详情接口暂不可用';
            return '<div class="tf-empty">' . self::e($msg) . '</div>';
        }
        $d = $t['detail'];
        $mobile = $end === 'mobile';
        $h = self::hero($d, $mobile);
        $h .= self::stats($d);
        $h .= self::map($d);
        $h .= self::landfall($d);
        $h .= self::forecast($d);
        $h .= self::advice($d);
        $h .= '<div class="tf-origin">' . self::e($d['source'] ?? '中央气象台 typhoon.nmc.cn')
            . ' · 轨迹与登陆点为依据官方字段推算，仅供参考</div>';
        return $h;
    }

    private static function hero($d, $mobile)
    {
        $grade = (string) ($d['grade_code'] ?? 'TS');
        $h = '<div class="tf-hero" data-tf-anim data-tf-grade="' . self::e($grade) . '">'
            . '<canvas class="tf-sky"></canvas><div class="tf-veil"></div>'
            . '<div class="tf-hero-top"><span class="tf-badge">' . self::e($d['grade']) . '</span>'
            . '<em>' . self::e($d['status_text']) . '</em></div>'
            . '<div class="tf-hero-main"><h4>' . self::e($d['name']) . '<i>' . self::e($d['en_name']) . '</i></h4>'
            . '<p>编号 ' . self::e($d['number']) . ' · ' . self::e($d['time']) . ' 定位 · 移向 '
            . self::e($d['move_dir']) . ' ' . ($d['move_speed'] !== null ? self::e($d['move_speed']) . ' km/h' : '') . '</p></div>'
            . '<div class="tf-hero-foot"><span>' . self::e($d['center']) . '</span>'
            . '<em>' . self::e($d['impact']['user_note'] ?? '') . '</em></div></div>';
        return $h;
    }

    private static function stats($d)
    {
        $wind = $d['max_wind'] !== null
            ? $d['max_wind'] . ' m/s · ' . $d['max_wind_level'] . ' 级' : '—';
        $items = array(
            array('中心位置', $d['center']),
            array('中心气压', $d['pressure'] !== null ? $d['pressure'] . ' hPa' : '—'),
            array('最大风速', $wind),
            array('移动方向', $d['move_dir']),
            array('移动速度', $d['move_speed'] !== null ? $d['move_speed'] . ' km/h' : '—'),
            array('七级风圈', isset($d['circles']['7']['max']) && $d['circles']['7']['max']
                ? $d['circles']['7']['max'] . ' km' : '—')
        );
        $h = '<div class="tf-stats">';
        foreach ($items as $it) {
            $h .= '<div><i>' . self::e($it[0]) . '</i><b>' . self::e($it[1]) . '</b></div>';
        }
        return $h . '</div>';
    }

    private static function map($d)
    {
        $track = isset($d['track']) && is_array($d['track']) ? $d['track'] : array();
        $proj = self::project($track);
        if (!$proj) {
            return '<div class="tf-map-empty">暂无可绘制的台风轨迹</div>';
        }
        $W = $proj['w'];
        $H = $proj['h'];
        $hist = array();
        $fc = array();
        $cur = null;
        foreach ($proj['pts'] as $p) {
            if ($p['kind'] === 'forecast') {
                $fc[] = $p;
            } else {
                $hist[] = $p;
            }
            if ($p['kind'] === 'current') {
                $cur = $p;
            }
        }
        if (!$cur && $hist) {
            $cur = $hist[count($hist) - 1];
        }
        if ($hist) {
            $fc = array_merge(array($hist[count($hist) - 1]), $fc);
        } elseif ($fc) {
            $hist = array($fc[0]);
        }

        $svg = '<svg class="tf-map" viewBox="0 0 ' . $W . ' ' . $H . '" role="img" aria-label="台风移动轨迹">';
        $svg .= '<defs>'
            . '<linearGradient id="tfSea" x1="0" y1="0" x2="0" y2="1">'
            . '<stop offset="0" stop-color="#0d2238"/><stop offset="1" stop-color="#16394f"/></linearGradient>'
            . '<linearGradient id="tfHist" x1="0" y1="0" x2="1" y2="0">'
            . '<stop offset="0" stop-color="#6fb6e8"/><stop offset="1" stop-color="#b9e2ff"/></linearGradient>'
            . '<filter id="tfGlow"><feGaussianBlur stdDeviation="4" result="b"/>'
            . '<feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>'
            . '</defs>';
        $svg .= '<rect width="' . $W . '" height="' . $H . '" fill="url(#tfSea)"/>';
        for ($i = 1; $i <= 4; $i++) {
            $y = round($H * $i / 5, 1);
            $svg .= '<line x1="0" y1="' . $y . '" x2="' . $W . '" y2="' . $y
                . '" stroke="#5d8aa8" stroke-opacity=".16" stroke-dasharray="3 6"/>';
        }
        for ($i = 1; $i <= 5; $i++) {
            $x = round($W * $i / 6, 1);
            $svg .= '<line x1="' . $x . '" y1="0" x2="' . $x . '" y2="' . $H
                . '" stroke="#5d8aa8" stroke-opacity=".12" stroke-dasharray="3 6"/>';
        }

        if ($cur) {
            $scale = $proj['scale'];
            $circles = isset($d['circles']) && is_array($d['circles']) ? $d['circles'] : array();
            foreach (array('12' => 'r12', '10' => 'r10', '7' => 'r7') as $k => $cls) {
                if (empty($circles[$k]['max'])) {
                    continue;
                }
                $r = max(6, min($W * .9, (float) $circles[$k]['max'] * $scale / 111));
                $svg .= '<circle cx="' . $cur['x'] . '" cy="' . $cur['y'] . '" r="' . round($r, 1)
                    . '" class="tf-ring ' . $cls . '"/>';
            }
        }

        if (count($hist) > 1) {
            $svg .= '<path d="' . self::path($hist, false) . '" class="tf-path-hist" stroke="url(#tfHist)"/>';
        }
        if (count($fc) > 1) {
            $svg .= '<path d="' . self::path($fc, false) . '" class="tf-path-fc" stroke="#ffb04d"/>';
            $svg .= '<circle r="4" class="tf-move-dot"><animateMotion dur="9s" repeatCount="indefinite" path="'
                . self::path($fc, true) . '"/></circle>';
        }

        foreach ($proj['pts'] as $i => $p) {
            if ($p['kind'] === 'forecast') {
                $svg .= '<circle cx="' . $p['x'] . '" cy="' . $p['y'] . '" r="2.6" class="tf-dot fc"><title>'
                    . self::e($p['time'] . ' · ' . $p['grade']) . '</title></circle>';
                if ($i % 2 === 0) {
                    $svg .= '<text x="' . $p['x'] . '" y="' . ($p['y'] - 7)
                        . '" text-anchor="middle" class="tf-lb">' . self::e($p['time']) . '</text>';
                }
            }
        }

        if ($cur) {
            $svg .= '<circle cx="' . $cur['x'] . '" cy="' . $cur['y'] . '" r="15" class="tf-eye-pulse"/>';
            $svg .= '<circle cx="' . $cur['x'] . '" cy="' . $cur['y'] . '" r="6" class="tf-eye"/>'
                . '<circle cx="' . $cur['x'] . '" cy="' . $cur['y'] . '" r="1.8" class="tf-eye-core"/>'
                . '<text x="' . ($cur['x'] + 12) . '" y="' . ($cur['y'] + 4)
                . '" class="tf-lb strong">此刻</text>';
        }

        $lf = isset($d['landfall']) ? $d['landfall'] : array();
        if (!empty($lf['lat']) && !empty($lf['lon']) && ($lf['status'] === 'expected' || $lf['status'] === 'landed')) {
            $lp = self::xy($lf['lat'], $lf['lon'], $proj);
            if ($lp) {
                $svg .= '<g class="tf-land-mark"><circle cx="' . $lp['x'] . '" cy="' . $lp['y']
                    . '" r="9" class="tf-land-halo"/><path d="M' . $lp['x'] . ' ' . $lp['y']
                    . ' l0 -14 l11 4 l-11 4z" class="tf-land-flag"/>'
                    . '<text x="' . ($lp['x'] + 7) . '" y="' . ($lp['y'] - 14)
                    . '" class="tf-lb land">登陆预估</text></g>';
            }
        }

        $svg .= '<text x="10" y="' . ($H - 9) . '" class="tf-lb">历史路径</text>'
            . '<line x1="58" y1="' . ($H - 13) . '" x2="82" y2="' . ($H - 13) . '" class="tf-lg-hist"/>'
            . '<text x="92" y="' . ($H - 9) . '" class="tf-lb">预报路径</text>'
            . '<line x1="130" y1="' . ($H - 13) . '" x2="154" y2="' . ($H - 13) . '" class="tf-lg-fc"/>';
        $svg .= '</svg>';
        return '<div class="tf-map-wrap">' . $svg . '</div>';
    }

    private static function path($pts, $raw)
    {
        $out = '';
        foreach ($pts as $i => $p) {
            $out .= ($i === 0 ? 'M' : 'L') . $p['x'] . ' ' . $p['y'] . ' ';
        }
        return trim($out);
    }

    private static function project($track)
    {
        $lats = array();
        $lons = array();
        foreach ($track as $p) {
            if (!is_numeric($p['lat']) || !is_numeric($p['lon'])) {
                continue;
            }
            $lats[] = (float) $p['lat'];
            $lons[] = (float) $p['lon'];
        }
        if (count($lats) < 2) {
            return null;
        }
        $minLat = min($lats); $maxLat = max($lats);
        $minLon = min($lons); $maxLon = max($lons);
        $padLat = max(0.35, ($maxLat - $minLat) * 0.12);
        $padLon = max(0.35, ($maxLon - $minLon) * 0.12);
        $minLat -= $padLat; $maxLat += $padLat;
        $minLon -= $padLon; $maxLon += $padLon;
        $w = 640; $h = 300; $pad = 18;
        $spanLat = max(0.6, $maxLat - $minLat);
        $spanLon = max(0.6, $maxLon - $minLon);
        $sx = ($w - $pad * 2) / $spanLon;
        $sy = ($h - $pad * 2) / $spanLat;
        $s = min($sx, $sy);
        $ox = $pad + (($w - $pad * 2) - $spanLon * $s) / 2;
        $oy = $pad + (($h - $pad * 2) - $spanLat * $s) / 2;
        $pts = array();
        foreach ($track as $p) {
            if (!is_numeric($p['lat']) || !is_numeric($p['lon'])) {
                continue;
            }
            $pts[] = array(
                'x' => round($ox + ((float) $p['lon'] - $minLon) * $s, 1),
                'y' => round($oy + ($maxLat - (float) $p['lat']) * $s, 1),
                'lat' => (float) $p['lat'], 'lon' => (float) $p['lon'],
                'time' => (string) ($p['time'] ?? ($p['valid_time'] ?? '')),
                'grade' => (string) ($p['grade'] ?? ''),
                'kind' => (string) ($p['kind'] ?? 'forecast')
            );
        }
        return array('w' => $w, 'h' => $h, 'pts' => $pts, 'scale' => $s,
            'minLat' => $minLat, 'maxLat' => $maxLat, 'minLon' => $minLon, 'maxLon' => $maxLon,
            'ox' => $ox, 'oy' => $oy);
    }

    private static function xy($lat, $lon, $p)
    {
        if (!$p || !is_numeric($lat) || !is_numeric($lon)) {
            return null;
        }
        $x = $p['ox'] + ((float) $lon - $p['minLon']) * $p['scale'];
        $y = $p['oy'] + ($p['maxLat'] - (float) $lat) * $p['scale'];
        if ($x < 0 || $x > $p['w'] || $y < 0 || $y > $p['h']) {
            return null;
        }
        return array('x' => round($x, 1), 'y' => round($y, 1));
    }

    private static function landfall($d)
    {
        $lf = isset($d['landfall']) && is_array($d['landfall']) ? $d['landfall'] : array();
        if (!$lf) {
            return '';
        }
        $status = (string) ($lf['status'] ?? 'unknown');
        $cls = in_array($status, array('expected', 'landed'), true) ? 'on' : ($status === 'sea' ? 'sea' : '');
        $place = (string) ($lf['place'] ?? '—');
        $meta = array();
        if (!empty($lf['time'])) {
            $meta[] = (string) $lf['time'];
        }
        if (!empty($lf['hour'])) {
            $meta[] = '+' . (int) $lf['hour'] . 'h';
        }
        if (isset($lf['distance_km']) && $lf['distance_km'] !== null) {
            $meta[] = '距你 ' . (int) $lf['distance_km'] . ' km';
        }
        if (!empty($lf['confidence'])) {
            $meta[] = '置信度 ' . $lf['confidence'];
        }
        $h = '<div class="tf-land ' . $cls . '">'
            . '<span class="tf-land-ico">' . ($status === 'landed' ? '●' : ($status === 'sea' ? '≈' : '◎')) . '</span>'
            . '<div class="tf-land-main"><i>' . self::e($lf['status_text'] ?? '登陆预估') . '</i>'
            . '<b>' . self::e($place) . '</b><em>' . self::e(implode(' · ', $meta)) . '</em></div>';
        if (!empty($lf['confidence_note'])) {
            $h .= '<span class="tf-conf">' . self::e($lf['confidence_note']) . '</span>';
        }
        $h .= '</div>';
        if (!empty($lf['note'])) {
            $h .= '<p class="tf-land-note">' . self::e($lf['note']) . '</p>';
        }
        return $h;
    }

    private static function forecast($d)
    {
        $rows = isset($d['forecast']) && is_array($d['forecast']) ? $d['forecast'] : array();
        if (!$rows) {
            return '';
        }
        $agency = (string) ($d['primary_agency'] ?? '');
        $h = '<div class="tf-sub">预报路径 <em>' . self::e($agency !== '' ? $agency : '官方机构') . ' · 未来 5 天</em></div>';
        $h .= '<div class="tf-fc"><div class="tf-fc-h"><span>时间</span><span>等级</span><span>气压</span><span>风速</span></div>';
        $n = 0;
        foreach ($rows as $r) {
            if ($agency !== '' && (string) $r['agency'] !== $agency) {
                continue;
            }
            if ($n++ >= 8) {
                break;
            }
            $h .= '<div class="tf-fc-r"><span>' . self::e($r['valid_time']) . '</span>'
                . '<span>' . self::e($r['grade']) . '</span>'
                . '<span>' . ($r['pressure'] !== null ? self::e($r['pressure']) . ' hPa' : '—') . '</span>'
                . '<span>' . ($r['wind'] !== null ? self::e($r['wind']) . ' m/s' : '—') . '</span></div>';
        }
        return $h . '</div>';
    }

    private static function advice($d)
    {
        $traffic = isset($d['traffic']['tips']) && is_array($d['traffic']['tips']) ? $d['traffic']['tips'] : array();
        $defense = isset($d['defense']) && is_array($d['defense']) ? $d['defense'] : array();
        $h = '<div class="tf-cols">';
        $h .= '<div class="tf-col"><b>交通影响</b><ul class="tf-list">';
        foreach ($traffic as $tip) {
            $h .= '<li>' . self::e($tip) . '</li>';
        }
        $h .= '</ul></div>';
        $h .= '<div class="tf-col"><b>防御建议</b><ul class="tf-list">';
        foreach ($defense as $tip) {
            $h .= '<li>' . self::e($tip) . '</li>';
        }
        $h .= '</ul></div></div>';
        return $h;
    }
}
