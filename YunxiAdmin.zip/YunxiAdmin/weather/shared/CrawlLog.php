<?php

namespace YxWeather;

class CrawlLog
{
    private static $ensured = false;

    public static function ensure()
    {
        if (self::$ensured) {
            return;
        }
        self::$ensured = true;
        try {
            $db = \Typecho\Db::get();
            $p = $db->getPrefix();
            $mysql = 'CREATE TABLE IF NOT EXISTS `' . $p . 'yx_crawl_urls` ('
                . '`day` date NOT NULL,`path` varchar(255) NOT NULL DEFAULT \'\','
                . '`kind` varchar(24) NOT NULL DEFAULT \'\',`hits` int(10) unsigned NOT NULL DEFAULT 0,'
                . '`updated` int(10) unsigned NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`day`,`path`,`kind`),KEY `updated` (`updated`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';
            $sqlite = 'CREATE TABLE IF NOT EXISTS `' . $p . 'yx_crawl_urls` ('
                . '`day` TEXT NOT NULL,`path` TEXT NOT NULL DEFAULT \'\',`kind` TEXT NOT NULL DEFAULT \'\','
                . '`hits` INTEGER NOT NULL DEFAULT 0,`updated` INTEGER NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`day`,`path`,`kind`))';
            try {
                $db->query($mysql);
            } catch (\Throwable $e) {
                try {
                    $db->query($sqlite);
                } catch (\Throwable $e2) {
                    $db->query(str_replace('utf8mb4', 'utf8', $mysql));
                }
            }
        } catch (\Throwable $e) {
        }
    }

    public static function record($path, $kind)
    {
        $path = substr(trim((string) $path), 0, 255);
        $kind = substr(preg_replace('/[^A-Za-z0-9_\-]/', '', (string) $kind), 0, 24);
        if ($path === '' || $kind === '') {
            return;
        }

        if (preg_match('/\.(css|js|png|jpe?g|gif|ico|svg|webp|woff2?|ttf|eot|map)(\?|$)/i', $path)) {
            return;
        }
        self::ensure();
        try {
            $db = \Typecho\Db::get();
            $t = '`' . $db->getPrefix() . 'yx_crawl_urls`';
            $day = date('Y-m-d');
            $now = time();
            $q = function ($v) { return "'" . str_replace("'", "''", (string) $v) . "'"; };
            $ins = 'INSERT INTO ' . $t . ' (`day`,`path`,`kind`,`hits`,`updated`) VALUES ('
                . $q($day) . ',' . $q($path) . ',' . $q($kind) . ',1,' . $now . ')';
            try {
                $db->query($ins . ' ON DUPLICATE KEY UPDATE `hits`=`hits`+1,`updated`=' . $now);
            } catch (\Throwable $e) {
                $db->query($ins . ' ON CONFLICT(`day`,`path`,`kind`) DO UPDATE SET `hits`=`hits`+1,`updated`=' . $now);
            }
        } catch (\Throwable $e) {
        }
    }

    public static function rows($sinceDay, $limit = 3000)
    {
        self::ensure();
        try {
            $db = \Typecho\Db::get();
            return $db->fetchAll($db->select('day', 'path', 'kind', 'hits')->from('table.yx_crawl_urls')
                ->where('day >= ?', $sinceDay)->order('hits', \Typecho\Db::SORT_DESC)->limit((int) $limit));
        } catch (\Throwable $e) {
            return array();
        }
    }

    public static function kind($ua)
    {
        $k = PluginBridge::call('uaKind', array($ua), null);
        if ($k !== null) {
            return $k === 'visit' ? '' : (string) $k;
        }
        $map = array('baidu' => 'Baiduspider', 'google' => 'Googlebot', 'bing' => 'bingbot',
            'sogou' => 'Sogou', 'so' => '360Spider', 'bytes' => 'Bytespider', 'yandex' => 'YandexBot');
        foreach ($map as $k => $needle) {
            if (stripos((string) $ua, $needle) !== false) {
                return $k;
            }
        }
        return '';
    }
}
