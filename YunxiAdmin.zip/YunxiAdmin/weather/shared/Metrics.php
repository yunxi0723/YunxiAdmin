<?php

namespace YxWeather;

class Metrics
{
    private static $ensured = false;

    public static function ensure()
    {
        if (self::$ensured) {
            return;
        }
        self::$ensured = true;
        try {
            $db = \Typecho\Db::get();
            $p = $db->getPrefix();
            $mysql = 'CREATE TABLE IF NOT EXISTS `' . $p . 'yx_runtime_metrics` ('
                . '`day` date NOT NULL,`device` varchar(12) NOT NULL DEFAULT \'\','
                . '`kind` varchar(12) NOT NULL DEFAULT \'\',`name` varchar(64) NOT NULL DEFAULT \'\','
                . '`hits` int(10) unsigned NOT NULL DEFAULT 0,`ok_hits` int(10) unsigned NOT NULL DEFAULT 0,'
                . '`err_hits` int(10) unsigned NOT NULL DEFAULT 0,`total_ms` bigint(20) unsigned NOT NULL DEFAULT 0,'
                . '`updated` int(10) unsigned NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`day`,`device`,`kind`,`name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';
            $sqlite = 'CREATE TABLE IF NOT EXISTS `' . $p . 'yx_runtime_metrics` ('
                . '`day` TEXT NOT NULL,`device` TEXT NOT NULL DEFAULT \'\',`kind` TEXT NOT NULL DEFAULT \'\','
                . '`name` TEXT NOT NULL DEFAULT \'\',`hits` INTEGER NOT NULL DEFAULT 0,'
                . '`ok_hits` INTEGER NOT NULL DEFAULT 0,`err_hits` INTEGER NOT NULL DEFAULT 0,'
                . '`total_ms` INTEGER NOT NULL DEFAULT 0,`updated` INTEGER NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`day`,`device`,`kind`,`name`))';
            try {
                $db->query($mysql);
            } catch (\Throwable $e) {
                try {
                    $db->query($sqlite);
                } catch (\Throwable $e2) {
                    $db->query(str_replace('utf8mb4', 'utf8', $mysql));
                }
            }
        } catch (\Throwable $e) {
        }
    }

    public static function record($device, $kind, $name, $ms, $ok = true)
    {
        $device = in_array($device, array('desktop', 'mobile'), true) ? $device : 'desktop';
        $kind = in_array($kind, array('page', 'api', 'error'), true) ? $kind : 'api';
        $name = substr((string) $name, 0, 64);
        $ms = max(0, (int) round((float) $ms));
        $ok = (int) (bool) $ok;
        self::ensure();
        try {
            $db = \Typecho\Db::get();
            $t = '`' . $db->getPrefix() . 'yx_runtime_metrics`';
            $day = date('Y-m-d');
            $now = time();
            $q = function ($v) { return "'" . str_replace("'", "''", (string) $v) . "'"; };
            $ins = 'INSERT INTO ' . $t . ' (`day`,`device`,`kind`,`name`,`hits`,`ok_hits`,`err_hits`,`total_ms`,`updated`) VALUES ('
                . $q($day) . ',' . $q($device) . ',' . $q($kind) . ',' . $q($name)
                . ',1,' . $ok . ',' . (1 - $ok) . ',' . $ms . ',' . $now . ')';
            $upd = '`hits`=`hits`+1,`ok_hits`=`ok_hits`+' . $ok . ',`err_hits`=`err_hits`+' . (1 - $ok)
                . ',`total_ms`=`total_ms`+' . $ms . ',`updated`=' . $now;
            try {
                $db->query($ins . ' ON DUPLICATE KEY UPDATE ' . $upd);
            } catch (\Throwable $e) {
                $db->query($ins . ' ON CONFLICT(`day`,`device`,`kind`,`name`) DO UPDATE SET ' . $upd);
            }
        } catch (\Throwable $e) {
        }
    }

    public static function summary($days = 14)
    {
        self::ensure();
        $days = max(7, min(30, (int) $days));
        $keys = array();
        for ($i = $days - 1; $i >= 0; $i--) {
            $keys[] = date('Y-m-d', strtotime('-' . $i . ' days'));
        }
        $blank = array();
        foreach ($keys as $k) {
            $blank[$k] = array('page_ms' => 0, 'page_hits' => 0, 'api_calls' => 0,
                'api_ok' => 0, 'api_err' => 0, 'api_ms' => 0, 'errors' => 0);
        }
        $rows = array();
        try {
            $db = \Typecho\Db::get();
            $rows = $db->fetchAll($db->select('day', 'device', 'kind', 'name', 'hits', 'ok_hits', 'err_hits', 'total_ms')
                ->from('table.yx_runtime_metrics')->where('day >= ?', $keys[0]));
        } catch (\Throwable $e) {
            $rows = array();
        }
        $endpoints = array();
        $devices = array();
        foreach ($rows as $r) {
            $d = (string) $r['day'];
            if (!isset($blank[$d])) {
                continue;
            }
            $hits = (int) $r['hits'];
            $kind = (string) $r['kind'];
            if ($kind === 'api' && (string) $r['name'] === 'article_analysis') {
                continue;
            }
            if ($kind === 'page') {
                $blank[$d]['page_ms'] += (int) $r['total_ms'];
                $blank[$d]['page_hits'] += $hits;
            } elseif ($kind === 'api') {
                $blank[$d]['api_calls'] += $hits;
                $blank[$d]['api_ok'] += (int) $r['ok_hits'];
                $blank[$d]['api_err'] += (int) $r['err_hits'];
                $blank[$d]['api_ms'] += (int) $r['total_ms'];
                $key2 = (string) $r['device'] . ':' . (string) $r['name'];
                if (!isset($endpoints[$key2])) {
                    $endpoints[$key2] = array('device' => (string) $r['device'], 'name' => (string) $r['name'],
                        'calls' => 0, 'ok' => 0, 'ms' => 0);
                }
                $endpoints[$key2]['calls'] += $hits;
                $endpoints[$key2]['ok'] += (int) $r['ok_hits'];
                $endpoints[$key2]['ms'] += (int) $r['total_ms'];
                $dev = (string) $r['device'];
                if (!isset($devices[$dev])) {
                    $devices[$dev] = array('device' => $dev, 'calls' => 0, 'ok' => 0, 'ms' => 0);
                }
                $devices[$dev]['calls'] += $hits;
                $devices[$dev]['ok'] += (int) $r['ok_hits'];
                $devices[$dev]['ms'] += (int) $r['total_ms'];
            } else {
                $blank[$d]['errors'] += $hits;
            }
        }
        $series = array();
        $totalCalls = 0;
        $totalOk = 0;
        $totalErr = 0;
        $totalPageHits = 0;
        $totalPageMs = 0;
        $totalApiMs = 0;
        $peak = null;
        foreach ($keys as $d) {
            $v = $blank[$d];
            $avg = $v['page_hits'] > 0 ? (int) round($v['page_ms'] / $v['page_hits']) : null;
            $apiAvg = $v['api_calls'] > 0 ? (int) round($v['api_ms'] / $v['api_calls']) : null;
            $rate = $v['api_calls'] > 0 ? (int) round($v['api_ok'] * 100 / $v['api_calls']) : null;
            $errRate = $v['api_calls'] > 0 ? round($v['api_err'] * 100 / $v['api_calls'], 1) : null;
            $health = null;
            if ($avg !== null || $v['api_calls'] > 0) {
                $health = 100;
                if ($errRate !== null) {
                    $health -= $errRate * 1.2;
                }
                if ($avg !== null && $avg > 800) {
                    $health -= min(30, ($avg - 800) / 40);
                }
                $health -= min(15, $v['errors'] * 2);
                $health = max(0, min(100, (int) round($health)));
            }
            $series[] = array(
                'date' => $d,
                'label' => date('m-d', strtotime($d)),
                'page_ms' => $avg,
                'page_hits' => $v['page_hits'],
                'api_calls' => $v['api_calls'],
                'api_avg_ms' => $apiAvg,
                'api_success' => $rate,
                'api_err' => $v['api_err'],
                'api_err_rate' => $errRate,
                'errors' => $v['errors'],
                'health' => $health
            );
            $totalCalls += $v['api_calls'];
            $totalOk += $v['api_ok'];
            $totalErr += $v['api_err'];
            $totalPageHits += $v['page_hits'];
            $totalPageMs += $v['page_ms'];
            $totalApiMs += $v['api_ms'];
            if ($v['api_calls'] > 0 && ($peak === null || $v['api_calls'] > $peak['calls'])) {
                $peak = array('label' => date('m-d', strtotime($d)), 'calls' => $v['api_calls']);
            }
        }
        $eps = array();
        $slow = 0;
        foreach ($endpoints as $e) {
            $e['success'] = $e['calls'] > 0 ? (int) round($e['ok'] * 100 / $e['calls']) : null;
            $e['avg_ms'] = $e['calls'] > 0 ? (int) round($e['ms'] / $e['calls']) : null;
            $e['device_text'] = $e['device'] === 'mobile' ? '手机端' : '桌面端';
            $e['level'] = $e['avg_ms'] === null ? 'na' : ($e['avg_ms'] < 300 ? 'fast' : ($e['avg_ms'] < 800 ? 'ok' : 'slow'));
            if ($e['level'] === 'slow') {
                $slow++;
            }
            $eps[] = $e;
        }
        usort($eps, function ($a, $b) { return $b['calls'] - $a['calls']; });

        $devOut = array();
        foreach ($devices as $dev => $v) {
            $devOut[] = array(
                'device' => $dev,
                'device_text' => $dev === 'mobile' ? '手机端' : '桌面端',
                'calls' => $v['calls'],
                'success' => $v['calls'] > 0 ? (int) round($v['ok'] * 100 / $v['calls']) : null,
                'avg_ms' => $v['calls'] > 0 ? (int) round($v['ms'] / $v['calls']) : null
            );
        }

        $pageAvg = $totalPageHits > 0 ? (int) round($totalPageMs / $totalPageHits) : null;
        $apiAvg = $totalCalls > 0 ? (int) round($totalApiMs / $totalCalls) : null;
        $errRate = $totalCalls > 0 ? round($totalErr * 100 / $totalCalls, 1) : null;
        $health = 100;
        if ($errRate !== null) {
            $health -= $errRate * 1.2;
        }
        if ($pageAvg !== null && $pageAvg > 800) {
            $health -= min(30, ($pageAvg - 800) / 40);
        }
        if ($slow > 0) {
            $health -= min(15, $slow * 3);
        }
        $health = max(0, min(100, (int) round($health)));

        return array(
            'status' => true,
            'days' => $days,
            'series' => $series,
            'endpoints' => array_slice($eps, 0, 10),
            'devices' => $devOut,
            'totals' => array(
                'api_calls' => $totalCalls,
                'api_success' => $totalCalls > 0 ? (int) round($totalOk * 100 / $totalCalls) : null,
                'api_err' => $totalErr,
                'api_err_rate' => $errRate,
                'api_avg_ms' => $apiAvg,
                'page_avg_ms' => $pageAvg,
                'page_hits' => $totalPageHits,
                'slow_endpoints' => $slow,
                'health' => $health,
                'errors' => array_sum(array_map(function ($s) { return $s['errors']; }, $series)),
                'peak' => $peak
            ),
            'sample' => $totalPageHits + $totalCalls,
            'note' => ''
        );
    }
}
