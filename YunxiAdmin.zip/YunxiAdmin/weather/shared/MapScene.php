<?php

namespace YxWeather;

class MapScene
{
    public static function html($loc)
    {
        $place = htmlspecialchars((string) ($loc['place_text'] ?? '当前位置'), ENT_QUOTES, 'UTF-8');
        $stage = htmlspecialchars((string) ($loc['stage_text'] ?? 'IP 定位'), ENT_QUOTES, 'UTF-8');

        $buildings = array(
            array(46, 46, 54, 40, 12), array(110, 58, 38, 30, 6), array(158, 42, 66, 46, 16),
            array(238, 54, 44, 34, 8), array(292, 44, 58, 46, 14), array(360, 36, 46, 34, 10),
            array(470, 42, 62, 44, 14), array(542, 52, 46, 34, 8), array(56, 118, 62, 38, 10),
            array(130, 110, 38, 30, 6), array(180, 116, 52, 40, 12), array(244, 108, 34, 28, 5),
            array(296, 100, 58, 48, 18), array(364, 112, 40, 32, 7), array(456, 108, 58, 46, 16),
            array(526, 118, 44, 34, 9), array(48, 210, 42, 32, 7), array(104, 202, 58, 42, 12),
            array(174, 216, 46, 34, 8), array(232, 206, 54, 42, 11), array(298, 216, 38, 30, 6),
            array(348, 204, 60, 46, 15), array(452, 208, 46, 36, 9), array(512, 200, 58, 44, 13),
            array(580, 214, 40, 30, 6)
        );
        $g = '';
        foreach ($buildings as $i => $b) {
            list($x, $y, $w, $h, $rh) = $b;
            $g .= '<g class="yxw-bld">'
                . '<rect x="' . $x . '" y="' . ($y + 3) . '" width="' . $w . '" height="' . $h
                . '" rx="2.5" fill="#c9d3dc" opacity=".55"/>'
                . '<rect x="' . $x . '" y="' . $y . '" width="' . $w . '" height="' . $h
                . '" rx="2.5" fill="#dbe3ea" stroke="#c7d1db" stroke-width=".8"/>'
                . '<rect x="' . ($x + 3) . '" y="' . ($y + 3) . '" width="' . max(6, $w - 6) . '" height="'
                . max(5, $h - 6) . '" rx="1.5" fill="#e8eef3"/>'
                . '<rect x="' . ($x + 5) . '" y="' . ($y + 5) . '" width="' . max(4, $w - 10) . '" height="' . $rh
                . '" rx="1.2" fill="#d3dde6"/>' . '</g>';
        }

        $trees = '';
        foreach (array(
            array(408, 96, 9), array(424, 108, 7), array(392, 116, 6), array(416, 84, 5),
            array(598, 90, 8), array(614, 104, 6), array(586, 106, 5), array(70, 272, 7),
            array(86, 282, 5), array(268, 276, 6), array(412, 272, 7), array(428, 282, 5)
        ) as $t) {
            $trees .= '<circle cx="' . $t[0] . '" cy="' . ($t[1] + 2) . '" r="' . $t[2]
                . '" fill="#a9c9a4" opacity=".55"/><circle cx="' . $t[0] . '" cy="' . $t[1] . '" r="' . $t[2]
                . '" fill="#b7d5b1"/><circle cx="' . ($t[0] - 2) . '" cy="' . ($t[1] - 2) . '" r="' . max(1.5, $t[2] - 3)
                . '" fill="#c8e0c2" opacity=".8"/>';
        }

        $svg = '<svg class="yxw-map-svg" viewBox="0 0 640 320" preserveAspectRatio="xMidYMid slice" aria-hidden="true">'
            . '<defs>'
            . '<linearGradient id="yxwGround" x1="0" y1="0" x2="1" y2="1">'
            . '<stop offset="0" stop-color="#f2f5f7"/><stop offset="1" stop-color="#e6ecef"/></linearGradient>'
            . '<linearGradient id="yxwWater" x1="0" y1="0" x2="1" y2="1">'
            . '<stop offset="0" stop-color="#c4e0ee"/><stop offset="1" stop-color="#a9cfe3"/></linearGradient>'
            . '<filter id="yxwSoft" x="-20%" y="-20%" width="140%" height="140%">'
            . '<feDropShadow dx="0" dy="2" stdDeviation="2.5" flood-color="#7c8b99" flood-opacity=".22"/></filter>'
            . '</defs>'
            . '<rect width="640" height="320" fill="url(#yxwGround)"/>'
            . '<path d="M-20 250 C 90 236, 150 286, 250 272 S 430 214, 520 238 S 620 288, 680 262 L 680 340 L -20 340 Z" fill="url(#yxwWater)"/>'
            . '<path d="M-20 250 C 90 236, 150 286, 250 272 S 430 214, 520 238 S 620 288, 680 262" fill="none" stroke="#93bfd6" stroke-width="2" opacity=".7"/>'
            . '<path d="M0 92 C 120 84, 210 104, 320 96 S 520 74, 640 88 L 640 150 C 520 136, 430 160, 320 152 S 120 140, 0 156 Z" fill="#dcebdd" opacity=".75"/>'
            . '<path d="M330 96 C 336 140, 330 190, 344 250" fill="none" stroke="#e3eaef" stroke-width="20"/>'
            . '<path d="M330 96 C 336 140, 330 190, 344 250" fill="none" stroke="#f7f9fa" stroke-width="14"/>'
            . '<path d="M0 178 L 640 166" fill="none" stroke="#dfe6eb" stroke-width="24"/>'
            . '<path d="M0 178 L 640 166" fill="none" stroke="#fbfcfd" stroke-width="17"/>'
            . '<path d="M0 178 L 640 166" fill="none" stroke="#d9e2e8" stroke-width="2" stroke-dasharray="14 12"/>'
            . '<path d="M444 0 C 450 90, 438 170, 452 320" fill="none" stroke="#dfe6eb" stroke-width="20"/>'
            . '<path d="M444 0 C 450 90, 438 170, 452 320" fill="none" stroke="#fbfcfd" stroke-width="13"/>'
            . '<path d="M444 0 C 450 90, 438 170, 452 320" fill="none" stroke="#d9e2e8" stroke-width="1.6" stroke-dasharray="10 10"/>'
            . '<path d="M0 268 C 160 232, 300 318, 640 246" fill="none" stroke="#e6edf1" stroke-width="12"/>'
            . '<path d="M0 268 C 160 232, 300 318, 640 246" fill="none" stroke="#fbfcfd" stroke-width="7"/>'
            . '<g filter="url(#yxwSoft)">' . $g . '</g>'
            . '<g>' . $trees . '</g>'
            . '</svg>';

        return '<div class="yxw-map" role="img" aria-label="' . $place . '位置示意">' . $svg
            . '<div class="yxw-map-pin"><span class="pulse"></span><span class="pulse d2"></span>'
            . '<span class="dot"></span></div>'
            . '<div class="yxw-map-tx"><b>' . $place . '</b><span>' . $stage . '</span></div>'
            . '</div>';
    }
}
