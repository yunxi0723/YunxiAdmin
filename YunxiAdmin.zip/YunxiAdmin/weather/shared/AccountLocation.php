<?php

namespace YxWeather;

class AccountLocation
{
    const TARGET_M = 50;

    private static $ensured = false;

    public static function ensure()
    {
        if (self::$ensured) {
            return;
        }
        self::$ensured = true;
        try {
            $db = \Typecho\Db::get();
            $p = $db->getPrefix();
            $mysql = 'CREATE TABLE IF NOT EXISTS `' . $p . 'yx_user_location` ('
                . '`uid` int(10) unsigned NOT NULL,'
                . '`lat` double NOT NULL,`lon` double NOT NULL,'
                . '`accuracy` int(10) unsigned NOT NULL DEFAULT 0,'
                . '`stage` varchar(16) NOT NULL DEFAULT \'\','
                . '`source` varchar(48) NOT NULL DEFAULT \'\','
                . '`label` varchar(160) NOT NULL DEFAULT \'\','
                . '`province` varchar(64) NOT NULL DEFAULT \'\','
                . '`city` varchar(64) NOT NULL DEFAULT \'\','
                . '`district` varchar(64) NOT NULL DEFAULT \'\','
                . '`street` varchar(96) NOT NULL DEFAULT \'\','
                . '`ip_check` varchar(240) NOT NULL DEFAULT \'\','
                . '`updated` int(10) unsigned NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`uid`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';
            $sqlite = 'CREATE TABLE IF NOT EXISTS `' . $p . 'yx_user_location` ('
                . '`uid` INTEGER PRIMARY KEY,`lat` REAL NOT NULL,`lon` REAL NOT NULL,'
                . '`accuracy` INTEGER NOT NULL DEFAULT 0,`stage` TEXT NOT NULL DEFAULT \'\','
                . '`source` TEXT NOT NULL DEFAULT \'\',`label` TEXT NOT NULL DEFAULT \'\','
                . '`province` TEXT NOT NULL DEFAULT \'\',`city` TEXT NOT NULL DEFAULT \'\','
                . '`district` TEXT NOT NULL DEFAULT \'\',`street` TEXT NOT NULL DEFAULT \'\','
                . '`ip_check` TEXT NOT NULL DEFAULT \'\',`updated` INTEGER NOT NULL DEFAULT 0)';
            try {
                $db->query($mysql);
            } catch (\Throwable $e) {
                try {
                    $db->query($sqlite);
                } catch (\Throwable $e2) {
                    $db->query(str_replace('utf8mb4', 'utf8', $mysql));
                }
            }
        } catch (\Throwable $e) {
        }
    }

    public static function get($uid)
    {
        self::ensure();
        try {
            $db = \Typecho\Db::get();
            $r = $db->fetchRow($db->select()->from('table.yx_user_location')->where('uid = ?', (int) $uid)->limit(1));
            if (!is_array($r)) {
                return array();
            }
            $r['lat'] = (float) $r['lat'];
            $r['lon'] = (float) $r['lon'];
            $r['accuracy'] = (int) $r['accuracy'];
            $r['updated'] = (int) $r['updated'];
            return $r;
        } catch (\Throwable $e) {
            return array();
        }
    }

    public static function sync($uid, $ip = null)
    {
        $uid = (int) $uid;
        if ($uid < 1) {
            return array();
        }
        $ip = $ip === null ? self::clientIp() : trim((string) $ip);
        $loc = self::get($uid);
        $valid = $ip !== '' && !self::isPrivate($ip);
        $storedIp = is_array($loc) ? trim((string) ($loc['ip_check'] ?? '')) : '';

        if ($loc && $valid && $storedIp === $ip) {
            return $loc;
        }
        if (!$valid) {
            return $loc;
        }

        $geo = self::ipCoarse($ip);
        if (empty($geo['ok'])) {
            return $loc;
        }
        $saved = self::save($uid, array(
            'lat' => $geo['lat'], 'lon' => $geo['lon'], 'accuracy' => 5000,
            'stage' => 'ip', 'source' => 'IP 定位',
            'province' => $geo['province'], 'city' => $geo['city'], 'district' => $geo['district'],
            'ip_check' => $ip
        ));
        if (is_array($saved) && isset($saved['lat'])) {
            return $saved;
        }
        return $loc;
    }

    public static function save($uid, $in)
    {
        $uid = (int) $uid;
        if ($uid < 1) {
            return array('status' => false, 'message' => '无效账号');
        }
        $lat = Http::num(isset($in['lat']) ? $in['lat'] : null, null);
        $lon = Http::num(isset($in['lon']) ? $in['lon'] : null, null);
        if ($lat === null || $lon === null || $lat < -90 || $lat > 90 || $lon < -180 || $lon > 180) {
            return array('status' => false, 'message' => '经纬度无效');
        }
        $stage = isset($in['stage']) ? (string) $in['stage'] : 'gps';
        if (!in_array($stage, array('gps', 'ip', 'manual', 'city'), true)) {
            $stage = 'gps';
        }
        $accuracy = isset($in['accuracy']) && is_numeric($in['accuracy'])
            ? max(0, min(200000, (int) round((float) $in['accuracy']))) : 0;
        if ($accuracy === 0) {
            $accuracy = $stage === 'gps' ? 50 : ($stage === 'manual' ? 30 : 5000);
        }

        $addr = array(
            'province' => isset($in['province']) ? (string) $in['province'] : '',
            'city'     => isset($in['city']) ? (string) $in['city'] : '',
            'district' => isset($in['district']) ? (string) $in['district'] : '',
            'street'   => isset($in['street']) ? (string) $in['street'] : ''
        );

        $rev = self::reverse($lat, $lon);
        if (!empty($rev['ok'])) {
            foreach (array('district', 'street') as $k) {
                if ($addr[$k] === '') {
                    $addr[$k] = (string) $rev[$k];
                }
            }
            foreach (array('province', 'city') as $k) {
                $latin = preg_match('/[A-Za-z]/', $addr[$k]);
                if ($addr[$k] === '' || $latin) {
                    $addr[$k] = (string) ($rev[$k] !== '' ? $rev[$k] : $addr[$k]);
                }
            }
            if (empty($in['source'])) {
                $in['source'] = $rev['source'];
            }
        }
        if ($addr['city'] === '' && !empty($in['city'])) {
            $addr['city'] = (string) $in['city'];
        }

        $label = isset($in['label']) && $in['label'] !== '' ? (string) $in['label'] : self::label($addr);
        $ipCheck = isset($in['ip_check']) ? (string) $in['ip_check'] : '';
        $source = isset($in['source']) ? substr((string) $in['source'], 0, 48) : $stage;

        self::ensure();
        try {
            $db = \Typecho\Db::get();
            $table = '`' . $db->getPrefix() . 'yx_user_location`';
            $q = function ($v) { return "'" . str_replace("'", "''", (string) $v) . "'"; };
            $cols = '(`uid`,`lat`,`lon`,`accuracy`,`stage`,`source`,`label`,`province`,`city`,`district`,`street`,`ip_check`,`updated`)';
            $vals = '(' . $uid . ',' . $lat . ',' . $lon . ',' . $accuracy . ',' . $q($stage) . ',' . $q($source)
                . ',' . $q($label) . ',' . $q($addr['province']) . ',' . $q($addr['city']) . ',' . $q($addr['district'])
                . ',' . $q($addr['street']) . ',' . $q($ipCheck) . ',' . time() . ')';
            $upd = '`lat`=' . $lat . ',`lon`=' . $lon . ',`accuracy`=' . $accuracy . ',`stage`=' . $q($stage)
                . ',`source`=' . $q($source) . ',`label`=' . $q($label) . ',`province`=' . $q($addr['province'])
                . ',`city`=' . $q($addr['city']) . ',`district`=' . $q($addr['district']) . ',`street`=' . $q($addr['street'])
                . ',`ip_check`=' . $q($ipCheck) . ',`updated`=' . time();
            try {
                $db->query('INSERT INTO ' . $table . ' ' . $cols . ' VALUES ' . $vals . ' ON DUPLICATE KEY UPDATE ' . $upd);
            } catch (\Throwable $e) {
                $db->query('INSERT INTO ' . $table . ' ' . $cols . ' VALUES ' . $vals
                    . ' ON CONFLICT(`uid`) DO UPDATE SET ' . $upd);
            }
        } catch (\Throwable $e) {
            return array('status' => false, 'message' => '位置保存失败：' . $e->getMessage());
        }

        return self::decorate(array(
            'uid' => $uid, 'lat' => $lat, 'lon' => $lon, 'accuracy' => $accuracy,
            'stage' => $stage, 'source' => $source, 'label' => $label,
            'province' => $addr['province'], 'city' => $addr['city'],
            'district' => $addr['district'], 'street' => $addr['street'],
            'ip_check' => $ipCheck, 'updated' => time(), 'saved' => true
        ));
    }

    public static function decorate($r)
    {
        if (!is_array($r) || !isset($r['lat'])) {
            return array();
        }
        $acc = (int) (isset($r['accuracy']) ? $r['accuracy'] : 0);
        $stage = (string) (isset($r['stage']) ? $r['stage'] : 'ip');
        $stageText = array(
            'gps'    => '设备定位',
            'ip'     => 'IP 定位',
            'manual' => '手动定位',
            'city'   => '城市定位'
        );
        $ip = trim((string) ($r['ip_check'] ?? ''));
        $r['ip'] = filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '';
        $r['accuracy_m'] = $acc;
        $r['stage_text'] = isset($stageText[$stage]) ? $stageText[$stage] : $stage;
        $r['accuracy_text'] = $acc > 0 && $acc <= 100 ? '±' . $acc . ' m'
            : ($acc > 0 ? '约 ' . round($acc / 1000, 1) . ' km' : '精度未知');
        $r['grade'] = $acc > 0 && $acc <= 50 ? '街道级 · 50 米内'
            : ($acc <= 100 ? '街道级 · 百米内'
                : ($acc <= 1000 ? '街区级' : ($acc <= 10000 ? '区县级' : '城市级')));
        $r['place_parts'] = array_values(array_filter(array(
            (string) ($r['province'] ?? ''), (string) ($r['city'] ?? ''),
            (string) ($r['district'] ?? ''), (string) ($r['street'] ?? '')
        )));
        $r['place_text'] = $r['place_parts'] ? implode(' · ', array_slice($r['place_parts'], 0, 4))
            : (string) ($r['label'] ?? '未知位置');
        $r['street_text'] = trim(implode(' · ', array_filter(array(
            (string) ($r['district'] ?? ''), (string) ($r['street'] ?? '')
        ))));
        if ($r['street_text'] === '') {
            $r['street_text'] = (string) ($r['place_text'] ?? '');
        }
        return $r;
    }

    private static function label($addr)
    {
        $parts = array();
        foreach (array('province', 'city', 'district', 'street') as $k) {
            $v = trim((string) ($addr[$k] ?? ''));
            if ($v !== '' && !in_array($v, $parts, true)) {
                $parts[] = $v;
            }
        }
        return implode(' · ', array_slice($parts, 0, 4));
    }

    public static function reverse($lat, $lon)
    {
        $key = 'rev-' . round((float) $lat, 4) . '-' . round((float) $lon, 4);
        $out = Http::remember($key, 86400 * 3, function () use ($lat, $lon) {
            $base = array('ok' => false, 'province' => '', 'city' => '', 'district' => '',
                'street' => '', 'street_detail' => '', 'road' => '', 'source' => '', 'country' => '');
            $d = Http::json('https://api.bigdatacloud.net/data/reverse-geocode-client?latitude='
                . rawurlencode($lat) . '&longitude=' . rawurlencode($lon) . '&localityLanguage=zh', 6);
            if (is_array($d) && !empty($d['principalSubdivision'])) {
                $base['ok'] = true;
                $base['country'] = (string) ($d['countryName'] ?? '');
                $base['province'] = (string) ($d['principalSubdivision'] ?? '');
                $base['city'] = (string) ($d['city'] ?? '');
                $base['district'] = (string) ($d['locality'] ?? '');
                $base['source'] = 'BigDataCloud 逆地理编码';
                $adm = isset($d['localityInfo']['administrative']) ? $d['localityInfo']['administrative'] : array();
                if (is_array($adm)) {
                    foreach ($adm as $a) {
                        if (!is_array($a)) {
                            continue;
                        }
                        $desc = (string) ($a['description'] ?? '');
                        $name = (string) ($a['name'] ?? '');
                        if (mb_strpos($desc, '街道') !== false || mb_strpos($desc, '镇') !== false) {
                            $base['street'] = $name;
                        } elseif (mb_strpos($desc, '市辖区') !== false && $base['district'] === '') {
                            $base['district'] = $name;
                        }
                    }
                }
                $base['street_detail'] = trim($base['district'] . ' ' . $base['street']);
                return $base;
            }
            $n = Http::json('https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat='
                . rawurlencode($lat) . '&lon=' . rawurlencode($lon) . '&zoom=18&accept-language=zh-CN', 4);
            if (is_array($n) && isset($n['address'])) {
                $a = $n['address'];
                $base['ok'] = true;
                $base['province'] = (string) ($a['state'] ?? '');
                $base['city'] = (string) ($a['city'] ?? ($a['town'] ?? ''));
                $base['district'] = (string) ($a['district'] ?? ($a['county'] ?? ''));
                $base['road'] = trim((string) ($a['road'] ?? '') . (isset($a['house_number']) ? ' ' . $a['house_number'] : ''));
                $base['street'] = (string) ($a['suburb'] ?? ($a['neighbourhood'] ?? ($a['quarter'] ?? ($a['road'] ?? ''))));
                $base['street_detail'] = trim($base['street'] . ' ' . $base['road']);
                $base['source'] = 'OpenStreetMap Nominatim';
                return $base;
            }
            return $base;
        }, function ($v) { return is_array($v) && !empty($v['ok']); });
        return is_array($out) ? $out : array('ok' => false);
    }

    public static function ipCoarse($ip = '')
    {
        $ip = trim((string) $ip);
        if ($ip === '' || self::isPrivate($ip)) {
            $ip = '';
        }
        $key = 'ipcoarse-' . ($ip === '' ? 'auto' : $ip);
        $out = Http::remember($key, 86400, function () use ($ip) {
            $base = array('ok' => false, 'ip' => $ip, 'lat' => null, 'lon' => null,
                'province' => '', 'city' => '', 'district' => '', 'isp' => '', 'source' => '');

            $urls = array(
                'ipwho.is'   => 'https://ipwho.is/' . rawurlencode($ip) . '?lang=zh-CN',
                'ip-api.com' => 'http://ip-api.com/json/' . rawurlencode($ip)
                    . '?fields=status,country,regionName,city,district,lat,lon,isp,query&lang=zh-CN'
            );
            foreach ($urls as $src => $u) {
                $d = Http::json($u, 4);
                if (!is_array($d)) {
                    continue;
                }
                $lat = $src === 'ip-api.com' ? ($d['lat'] ?? null) : ($d['latitude'] ?? null);
                $lon = $src === 'ip-api.com' ? ($d['lon'] ?? null) : ($d['longitude'] ?? null);
                if (($src === 'ip-api.com' && empty($d['status'])) || ($src === 'ipwho.is' && empty($d['success']))) {
                    continue;
                }
                if (!is_numeric($lat) || !is_numeric($lon)) {
                    continue;
                }
                $base['ok'] = true;
                $base['lat'] = (float) $lat;
                $base['lon'] = (float) $lon;
                $base['source'] = $src;
                $base['province'] = (string) ($src === 'ip-api.com' ? ($d['regionName'] ?? '') : ($d['region'] ?? ''));
                $base['city'] = (string) ($d['city'] ?? '');
                $base['district'] = (string) ($d['district'] ?? '');
                $base['isp'] = (string) ($src === 'ip-api.com' ? ($d['isp'] ?? '') : ($d['connection']['isp'] ?? ''));
                if (!empty($d['query'])) {
                    $base['ip'] = (string) $d['query'];
                } elseif ($ip === '' && !empty($d['ip'])) {
                    $base['ip'] = (string) $d['ip'];
                }
                return $base;
            }
            return $base;
        }, function ($v) { return is_array($v) && !empty($v['ok']); });
        return is_array($out) ? $out : array('ok' => false, 'source' => '');
    }

    public static function isPrivate($ip)
    {
        $ip = (string) $ip;
        if ($ip === '' || $ip === 'unknown') {
            return true;
        }
        if (strpos($ip, ':') !== false) {
            $l = strtolower($ip);
            return $l === '::1' || $l === '::' || strpos($l, 'fe80:') === 0
                || strpos($l, 'fc') === 0 || strpos($l, 'fd') === 0;
        }
        $l = ip2long($ip);
        if ($l === false) {
            return true;
        }
        foreach (array(
            array('10.0.0.0', '10.255.255.255'), array('127.0.0.0', '127.255.255.255'),
            array('169.254.0.0', '169.254.255.255'), array('172.16.0.0', '172.31.255.255'),
            array('192.168.0.0', '192.168.255.255'), array('0.0.0.0', '0.255.255.255')
        ) as $r) {
            if ($l >= ip2long($r[0]) && $l <= ip2long($r[1])) {
                return true;
            }
        }
        return false;
    }

    public static function geocodeCity($city)
    {
        $city = trim((string) $city);
        if ($city === '') {
            return array('ok' => false, 'message' => '请输入城市或区域名称');
        }
        $d = Http::json('https://geocoding-api.open-meteo.com/v1/search?name=' . rawurlencode($city)
            . '&count=1&language=zh&format=json', 6);
        if (!is_array($d) || empty($d['results'][0])) {
            return array('ok' => false, 'message' => '无法定位「' . $city . '」，可直接输入经纬度校准');
        }
        $r = $d['results'][0];
        return array(
            'ok' => true, 'lat' => (float) $r['latitude'], 'lon' => (float) $r['longitude'],
            'city' => (string) ($r['name'] ?? $city), 'province' => (string) ($r['admin1'] ?? ''),
            'source' => 'Open-Meteo Geocoding'
        );
    }

    public static function crossCheck($lat, $lon, $clientIp = '')
    {
        $ip = self::ipCoarse($clientIp);
        if (empty($ip['ok'])) {
            return array('ok' => false, 'text' => 'IP 粗定位不可用，未做交叉校正');
        }
        $km = self::distance($lat, $lon, $ip['lat'], $ip['lon']);
        $verdict = $km <= 100 ? 'consistent' : ($km <= 500 ? 'near' : 'divergent');
        $text = 'IP 粗定位指向 ' . ($ip['province'] . ' ' . $ip['city'])
            . '，与浏览器定位相距约 ' . $km . ' km'
            . ($verdict === 'consistent' ? '（一致）'
                : ($verdict === 'near' ? '（同城量级，可参考）' : '（偏差较大，可能存在代理 / VPN / GPS 漂移，建议手动校准）'));
        return array(
            'ok' => true, 'source' => $ip['source'], 'ip' => $ip['ip'],
            'ip_place' => trim($ip['province'] . ' ' . $ip['city']),
            'ip_lat' => $ip['lat'], 'ip_lon' => $ip['lon'],
            'distance_km' => $km, 'verdict' => $verdict, 'text' => $text
        );
    }

    public static function distance($aLat, $aLon, $bLat, $bLon)
    {
        if (!is_numeric($aLat) || !is_numeric($bLat)) {
            return null;
        }
        $r = 6371.0;
        $dLat = deg2rad((float) $bLat - (float) $aLat);
        $dLon = deg2rad((float) $bLon - (float) $aLon);
        $a = sin($dLat / 2) * sin($dLat / 2)
            + cos(deg2rad((float) $aLat)) * cos(deg2rad((float) $bLat)) * sin($dLon / 2) * sin($dLon / 2);
        return (int) round(2 * $r * asin(min(1, sqrt($a))));
    }

    public static function clientIp()
    {
        foreach (array('HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR') as $k) {
            if (empty($_SERVER[$k])) {
                continue;
            }
            $v = trim(explode(',', (string) $_SERVER[$k])[0]);
            if (filter_var($v, FILTER_VALIDATE_IP)) {
                return $v;
            }
        }
        return '';
    }
}
