<?php

namespace YxWeather;

class WeatherSource
{

    public static function current($lat, $lon, $place, $cacheKey, $ttl = 600)
    {
        $lat = round((float) $lat, 4);
        $lon = round((float) $lon, 4);
        $key = $cacheKey . '-' . $lat . '-' . $lon;
        $build = function () use ($lat, $lon, $place) {
            $u = 'https://api.open-meteo.com/v1/forecast?latitude=' . rawurlencode($lat)
                . '&longitude=' . rawurlencode($lon)
                . '&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,'
                . 'precipitation,wind_speed_10m,wind_direction_10m,wind_gusts_10m,surface_pressure,visibility,uv_index,cloud_cover'
                . '&hourly=precipitation,precipitation_probability,visibility,wind_speed_10m'
                . '&daily=weather_code,temperature_2m_max,temperature_2m_min,uv_index_max,'
                . 'precipitation_probability_max,wind_speed_10m_max,sunrise,sunset'
                . '&wind_speed_unit=ms&timezone=auto&forecast_days=5';

            $d = Http::json($u, 8);
            if (!is_array($d) || empty($d['current'])) {
                $d = Http::json($u, 10);
            }
            if (!is_array($d) || empty($d['current'])) {
                return null;
            }
            $c = $d['current'];
            $w = array(
                'status' => true,
                'city' => (string) ($place['city'] ?? ''),
                'province' => (string) ($place['province'] ?? ''),
                'district' => (string) ($place['district'] ?? ''),
                'street' => (string) ($place['street'] ?? ''),
                'place' => (string) ($place['place_text'] ?? ($place['city'] ?? '当前位置')),
                'weather' => self::wmo(isset($c['weather_code']) ? (int) $c['weather_code'] : 0),
                'weather_code' => isset($c['weather_code']) ? (int) $c['weather_code'] : null,
                'temperature' => self::n($c['temperature_2m'] ?? null, 1),
                'feels_like' => self::n($c['apparent_temperature'] ?? null, 1),
                'humidity' => isset($c['relative_humidity_2m']) ? (int) $c['relative_humidity_2m'] : null,
                'precipitation' => self::n($c['precipitation'] ?? null, 1),
                'wind_speed' => self::n($c['wind_speed_10m'] ?? null, 1),
                'wind_gust' => self::n($c['wind_gusts_10m'] ?? null, 1),
                'wind_direction' => isset($c['wind_direction_10m']) ? self::windDir((float) $c['wind_direction_10m']) : '',
                'wind_deg' => isset($c['wind_direction_10m']) ? (int) round((float) $c['wind_direction_10m']) : null,
                'cloud_cover' => isset($c['cloud_cover']) ? (int) round((float) $c['cloud_cover']) : null,
                'wind_power' => isset($c['wind_speed_10m']) ? self::windLevel((float) $c['wind_speed_10m']) : '',
                'visibility' => isset($c['visibility']) ? round((float) $c['visibility'] / 1000, 1) : null,
                'pressure' => isset($c['surface_pressure']) ? (int) round((float) $c['surface_pressure']) : null,
                'uv_index' => self::n($c['uv_index'] ?? null, 1),
                'is_day' => !empty($c['is_day']),
                'report_time' => (string) ($c['time'] ?? date('Y-m-d H:i')),
                'fetched_at' => date('Y-m-d H:i:s'),
                'forecast' => self::forecast($d),
                'hourly' => self::hourly($d),
                'aqi' => null, 'aqi_category' => '', 'pm25' => null, 'pm10' => null,
                'sources' => array('Open-Meteo Forecast (api.open-meteo.com)'),
                'stale' => false
            );

            $aq = Http::json('https://air-quality-api.open-meteo.com/v1/air-quality?latitude=' . rawurlencode($lat)
                . '&longitude=' . rawurlencode($lon)
                . '&current=us_aqi,pm2_5,pm10,ozone,nitrogen_dioxide&timezone=auto', 6);
            if (is_array($aq) && isset($aq['current'])) {
                $a = $aq['current'];
                $w['aqi'] = isset($a['us_aqi']) && is_numeric($a['us_aqi']) ? (int) round((float) $a['us_aqi']) : null;
                $w['aqi_category'] = self::aqiCategory($w['aqi']);
                $w['pm25'] = self::n($a['pm2_5'] ?? null, 1);
                $w['pm10'] = self::n($a['pm10'] ?? null, 1);
                $w['ozone'] = self::n($a['ozone'] ?? null, 1);
                $w['no2'] = self::n($a['nitrogen_dioxide'] ?? null, 1);
                $w['sources'][] = 'Open-Meteo Air Quality (air-quality-api.open-meteo.com)';
            } else {
                $w['aqi_note'] = '空气质量数据暂缺';
            }
            return $w;
        };

        $w = Http::remember($key, $ttl, $build, function ($v) { return is_array($v) && !empty($v['status']); });
        if (!is_array($w) || empty($w['status'])) {
            $old = Http::stale($key);
            if (is_array($old) && !empty($old['status'])) {
                $old['stale'] = true;
                $old['stale_note'] = '数据更新稍有延迟，显示上次结果';
                return $old;
            }
            return array('status' => false, 'message' => '气象数据获取失败，请稍后重试或检查服务器出网');
        }

        foreach (array('city', 'province', 'district', 'street', 'place') as $k) {
            if (isset($place[$k])) {
                $w[$k] = $place[$k];
            }
        }
        return $w;
    }

    public static function stale($lat, $lon, $place, $cacheKey)
    {
        $lat = (float) $lat;
        $lon = (float) $lon;
        $w = Http::stale($cacheKey . '-' . $lat . '-' . $lon);
        if (!is_array($w) || empty($w['status'])) {
            return null;
        }
        if (is_array($place)) {
            foreach (array('city', 'province', 'district', 'street', 'place') as $k) {
                if (isset($place[$k])) {
                    $w[$k] = $place[$k];
                }
            }
        }
        $w['stale'] = true;
        $w['stale_note'] = '显示上次结果，正在后台更新';
        return $w;
    }

    private static function forecast($d)
    {
        $out = array();
        $daily = isset($d['daily']) ? $d['daily'] : array();
        $dates = isset($daily['time']) ? $daily['time'] : array();
        $week = array('日', '一', '二', '三', '四', '五', '六');
        $n = min(count($dates), 5);
        for ($i = 0; $i < $n; $i++) {
            $ts = strtotime((string) $dates[$i]);
            $out[] = array(
                'date' => date('n/j', $ts),
                'week' => '周' . $week[(int) date('w', $ts)],
                'weather_day' => self::wmo(isset($daily['weather_code'][$i]) ? (int) $daily['weather_code'][$i] : 0),
                'temp_min' => isset($daily['temperature_2m_min'][$i]) ? (string) round((float) $daily['temperature_2m_min'][$i]) : '',
                'temp_max' => isset($daily['temperature_2m_max'][$i]) ? (string) round((float) $daily['temperature_2m_max'][$i]) : '',
                'uv_max' => isset($daily['uv_index_max'][$i]) ? round((float) $daily['uv_index_max'][$i], 1) : null,
                'pop_max' => isset($daily['precipitation_probability_max'][$i]) ? (int) $daily['precipitation_probability_max'][$i] : null,
                'wind_max' => isset($daily['wind_speed_10m_max'][$i]) ? round((float) $daily['wind_speed_10m_max'][$i], 1) : null,
                'sunrise' => isset($daily['sunrise'][$i]) ? substr((string) $daily['sunrise'][$i], 11, 5) : '',
                'sunset' => isset($daily['sunset'][$i]) ? substr((string) $daily['sunset'][$i], 11, 5) : ''
            );
        }
        return $out;
    }

    private static function hourly($d)
    {
        $out = array();
        $h = isset($d['hourly']) ? $d['hourly'] : array();
        $times = isset($h['time']) ? $h['time'] : array();
        $now = time();
        foreach ($times as $i => $t) {
            $ts = strtotime((string) $t);
            if ($ts === false || $ts < $now - 3600) {
                continue;
            }
            $out[] = array(
                'time' => date('H:i', $ts),
                'precipitation' => isset($h['precipitation'][$i]) ? round((float) $h['precipitation'][$i], 1) : null,
                'pop' => isset($h['precipitation_probability'][$i]) ? (int) $h['precipitation_probability'][$i] : null,
                'visibility' => isset($h['visibility'][$i]) ? round((float) $h['visibility'][$i] / 1000, 1) : null,
                'wind' => isset($h['wind_speed_10m'][$i]) ? round((float) $h['wind_speed_10m'][$i], 1) : null
            );
            if (count($out) >= 12) {
                break;
            }
        }
        return $out;
    }

    public static function warnings($province = '', $city = '')
    {
        $province = trim((string) $province);
        $city = trim((string) $city);
        if ($province === '' && $city === '') {
            return array('status' => false, 'items' => array(), 'source' => '未获取到地区');
        }
        $key = 'warn-' . md5($province . '|' . $city);
        return Http::remember($key, 300, function () use ($province, $city) {
            return self::warningsLive($province, $city);
        }, function ($v) {
            return is_array($v) && !empty($v['status']);
        });
    }

    public static function warningsStale($province = '', $city = '')
    {
        $province = trim((string) $province);
        $city = trim((string) $city);
        if ($province === '' && $city === '') {
            return null;
        }
        $v = Http::stale('warn-' . md5($province . '|' . $city));
        return is_array($v) ? $v : null;
    }

    private static function warningsLive($province, $city)
    {
        $province = trim((string) $province);
        $city = trim((string) $city);
        $fetchProvince = function () use ($province) {
            if ($province === '') {
                return array();
            }
            $q = 'https://www.nmc.cn/rest/findAlarm?pageNo=1&pageSize=60&signaltype=&signallevel=&province='
                . rawurlencode($province);
            $d = Http::json($q, 7);
            $list = isset($d['data']['page']['list']) ? $d['data']['page']['list'] : null;
            if (!is_array($list)) {
                return array();
            }
            $items = array();
            foreach ($list as $it) {
                if (!is_array($it)) {
                    continue;
                }
                $items[] = array(
                    'title' => (string) ($it['title'] ?? ''),
                    'level' => (string) ($it['signallevel'] ?? ''),
                    'issueTime' => (string) ($it['issuetime'] ?? ''),
                    'content' => (string) ($it['issueContent'] ?? '')
                );
            }
            return $items;
        };

        $r = PluginBridge::call('alerts', array($province, $city), null);
        if (!is_array($r)) {
            $items = $fetchProvince();
            if (!$items) {
                return array('status' => false, 'items' => array(), 'source' => '中央气象台 nmc.cn（暂不可用）');
            }
            return array('status' => true, 'items' => array_slice($items, 0, 20),
                'region' => $province, 'source' => '中央气象台 nmc.cn', 'count' => count($items));
        }
        try {
            $items = isset($r['items']) ? (array) $r['items'] : array();
            $source = (string) ($r['source'] ?? '中央气象台 nmc.cn');
            $count = (int) ($r['count'] ?? count($items));
            if (!$items) {
                $alt = $fetchProvince();
                if ($alt) {
                    $items = $alt;
                    $count = count($alt);
                    $source = '中央气象台 nmc.cn';
                }
            }
            return array(
                'status' => !empty($r['status']) || !empty($items),
                'items' => array_slice($items, 0, 20),
                'region' => (string) ($r['region'] ?? $province),
                'source' => $source,
                'count' => $count
            );
        } catch (\Throwable $e) {
            return array('status' => false, 'items' => array(), 'source' => '预警接口异常');
        }
    }

    public static function life($w)
    {
        $compat = is_array($w) ? $w : array();
        $compat['pop'] = isset($compat['forecast'][0]['pop_max']) ? $compat['forecast'][0]['pop_max'] : null;
        $compat['wind_max'] = isset($compat['forecast'][0]['wind_max']) ? $compat['forecast'][0]['wind_max'] : ($compat['wind_speed'] ?? null);
        $r = PluginBridge::call('lifeIndex', array($compat), array());
        if (is_array($r) && $r) {
            return $r;
        }

        return self::lifeFallback($compat);
    }

    private static function lifeFallback($w)
    {
        if (empty($w['status'])) {
            return array();
        }
        $t = is_numeric($w['temperature'] ?? null) ? (float) $w['temperature'] : null;
        $feel = is_numeric($w['feels_like'] ?? null) ? (float) $w['feels_like'] : $t;
        $rh = is_numeric($w['humidity'] ?? null) ? (float) $w['humidity'] : null;
        $uv = is_numeric($w['uv_index'] ?? null) ? (float) $w['uv_index'] : null;
        $pop = is_numeric($w['pop'] ?? null) ? (int) $w['pop'] : null;
        $aqi = is_numeric($w['aqi'] ?? null) ? (int) $w['aqi'] : null;
        $out = array();
        if ($feel !== null) {
            $out[] = array('key' => 'dress', 'name' => '穿衣', 'level' => $feel >= 28 ? '炎热' : ($feel >= 20 ? '舒适' : ($feel >= 10 ? '凉' : '寒冷')),
                'icon' => 'i-w-sun', 'advice' => '体感 ' . $feel . '°，' . ($feel >= 28 ? '穿轻薄衣物' : ($feel >= 20 ? '着装轻便即可' : ($feel >= 10 ? '加一件外套' : '注意保暖'))));
        }
        if ($uv !== null) {
            $out[] = array('key' => 'uv', 'name' => '紫外线', 'level' => $uv >= 8 ? '很强' : ($uv >= 3 ? '中等' : '弱'),
                'icon' => 'i-sun', 'advice' => $uv >= 8 ? '紫外线很强，注意防晒' : ($uv >= 3 ? '外出适当防晒' : '紫外线较弱'));
        }
        if ($pop !== null) {
            $out[] = array('key' => 'car', 'name' => '洗车', 'level' => $pop >= 60 ? '不宜' : '适宜',
                'icon' => 'i-w-rain', 'advice' => $pop >= 60 ? '今天有降水，不建议洗车' : '今天降水少，适合洗车');
        }
        if ($aqi !== null) {
            $out[] = array('key' => 'air', 'name' => '空气', 'level' => self::aqiCategory($aqi),
                'icon' => 'i-w-cloud', 'advice' => '空气质量' . self::aqiCategory($aqi) . '，' . ($aqi > 100 ? '敏感人群减少户外活动' : '适合开窗通风'));
        }
        if ($rh !== null) {
            $out[] = array('key' => 'comfort', 'name' => '舒适度', 'level' => ($rh >= 80 ? '偏闷' : ($rh <= 30 ? '偏干' : '舒适')),
                'icon' => 'i-heart', 'advice' => '湿度 ' . $rh . '%，' . ($rh >= 80 ? '体感偏闷' : ($rh <= 30 ? '注意补水' : '体感舒适')));
        }
        $out[] = array('key' => 'sport', 'name' => '运动',
            'level' => ($pop !== null && $pop >= 60) ? '较不宜' : '适宜', 'icon' => 'i-run',
            'advice' => ($pop !== null && $pop >= 60) ? '有降水，建议改为室内运动' : '天气条件适合户外运动');
        return $out;
    }

    public static function scene($w)
    {
        $code = isset($w['weather_code']) ? (int) $w['weather_code'] : 0;
        $cloud = isset($w['cloud_cover']) && is_numeric($w['cloud_cover']) ? (int) $w['cloud_cover'] : null;
        if ($cloud === null) {
            $cloud = $code === 0 ? 8 : ($code <= 2 ? 38 : ($code === 3 ? 88 : 94));
        }
        $deg = isset($w['wind_deg']) && is_numeric($w['wind_deg']) ? (int) $w['wind_deg'] : -1;
        if ($deg < 0) {
            $dirs = array('东北' => 45, '东南' => 135, '西北' => 315, '西南' => 225,
                '北' => 0, '东' => 90, '南' => 180, '西' => 270);
            foreach ($dirs as $k => $v) {
                if (strpos((string) ($w['wind_direction'] ?? ''), $k) !== false) { $deg = $v; break; }
            }
        }
        $hour = (int) date('G');
        $minute = (int) date('i');
        if (preg_match('/(\d{2}):(\d{2})/', (string) ($w['report_time'] ?? ''), $m)) {
            $hour = (int) $m[1];
            $minute = (int) $m[2];
        }
        return array(
            'kind' => self::animKind($w['weather'] ?? ''),
            'code' => $code,
            'day' => !empty($w['is_day']) ? 1 : 0,
            'temp' => self::n($w['temperature'] ?? null, 1),
            'feels' => self::n($w['feels_like'] ?? null, 1),
            'rh' => isset($w['humidity']) ? (int) $w['humidity'] : null,
            'rain' => self::n($w['precipitation'] ?? null, 1),
            'wind' => self::n($w['wind_speed'] ?? null, 1),
            'gust' => self::n($w['wind_gust'] ?? null, 1),
            'deg' => $deg < 0 ? 0 : $deg,
            'vis' => self::n($w['visibility'] ?? null, 1),
            'uv' => self::n($w['uv_index'] ?? null, 1),
            'aqi' => isset($w['aqi']) && is_numeric($w['aqi']) ? (int) $w['aqi'] : null,
            'cloud' => $cloud,
            'hour' => $hour,
            'minute' => $minute,
            'season' => (int) date('n'),
            'pressure' => isset($w['pressure']) ? (int) $w['pressure'] : null
        );
    }

    public static function animKind($text)
    {
        $t = (string) $text;
        if (preg_match('/雷/u', $t)) return 'storm';
        if (preg_match('/雪/u', $t)) return 'snow';
        if (preg_match('/雨|雹/u', $t)) return 'rain';
        if (preg_match('/雾|霾|沙|尘/u', $t)) return 'fog';
        if (preg_match('/阴|云/u', $t)) return 'cloud';
        return 'sun';
    }

    private static function n($v, $digits = 1)
    {
        return is_numeric($v) ? round((float) $v, $digits) : null;
    }

    public static function aqiCategory($aqi)
    {
        if ($aqi === null) {
            return '—';
        }
        if ($aqi <= 50) return '优';
        if ($aqi <= 100) return '良';
        if ($aqi <= 150) return '轻度污染';
        if ($aqi <= 200) return '中度污染';
        if ($aqi <= 300) return '重度污染';
        return '严重污染';
    }

    public static function wmo($code)
    {
        $map = array(
            0 => '晴', 1 => '大部晴朗', 2 => '局部多云', 3 => '阴', 45 => '雾', 48 => '雾凇',
            51 => '小毛雨', 53 => '毛毛雨', 55 => '浓毛毛雨', 56 => '冻毛雨', 57 => '浓冻毛雨',
            61 => '小雨', 63 => '中雨', 65 => '大雨', 66 => '冻小雨', 67 => '冻大雨',
            71 => '小雪', 73 => '中雪', 75 => '大雪', 77 => '雪粒',
            80 => '小阵雨', 81 => '阵雨', 82 => '强阵雨', 85 => '小阵雪', 86 => '大阵雪',
            95 => '雷暴', 96 => '雷暴伴小冰雹', 99 => '雷暴伴大冰雹'
        );
        return isset($map[(int) $code]) ? $map[(int) $code] : '多云';
    }

    public static function windDir($deg)
    {
        $dirs = array('北', '东北', '东', '东南', '南', '西南', '西', '西北');
        return $dirs[(int) round(((float) $deg % 360) / 45) % 8] . '风';
    }

    public static function windLevel($ms)
    {
        $limits = array(0.3, 1.6, 3.4, 5.5, 8.0, 10.8, 13.9, 17.2, 20.8, 24.5, 28.5, 32.7);
        $n = 0;
        foreach ($limits as $lim) {
            if ((float) $ms <= $lim) {
                break;
            }
            $n++;
        }
        return $n . '级';
    }
}
