<?php

namespace YxWeather;

class Festivals
{

    private static $solar = array(
        '1-1' => '元旦', '2-14' => '情人节', '3-8' => '妇女节', '3-12' => '植树节',
        '4-1' => '愚人节', '5-1' => '劳动节', '5-4' => '青年节', '6-1' => '儿童节',
        '7-1' => '建党节', '8-1' => '建军节', '9-10' => '教师节', '10-1' => '国庆节',
        '10-31' => '万圣节', '12-24' => '平安夜', '12-25' => '圣诞节'
    );

    private static $lunar = array(
        '1-1' => '春节', '1-15' => '元宵节', '2-2' => '龙抬头',
        '5-5' => '端午节', '7-7' => '七夕节', '7-15' => '中元节',
        '8-15' => '中秋节', '9-9' => '重阳节', '12-8' => '腊八节'
    );

    private static $qingming = array(
        2020 => 4, 2021 => 4, 2022 => 5, 2023 => 5, 2024 => 4, 2025 => 4,
        2026 => 5, 2027 => 5, 2028 => 4, 2029 => 4, 2030 => 5, 2031 => 5,
        2032 => 4, 2033 => 4, 2034 => 5, 2035 => 5, 2036 => 4, 2037 => 4,
        2038 => 5, 2039 => 5, 2040 => 4
    );

    private static $info = array(
        0x04bd8,0x04ae0,0x0a570,0x054d5,0x0d260,0x0d950,0x16554,0x056a0,0x09ad0,0x055d2,
        0x04ae0,0x0a5b6,0x0a4d0,0x0d250,0x1d255,0x0b540,0x0d6a0,0x0ada2,0x095b0,0x14977,
        0x04970,0x0a4b0,0x0b4b5,0x06a50,0x06d40,0x1ab54,0x02b60,0x09570,0x052f2,0x04970,
        0x06566,0x0d4a0,0x0ea50,0x06e95,0x05ad0,0x02b60,0x186e3,0x092e0,0x1c8d7,0x0c950,
        0x0d4a0,0x1d8a6,0x0b550,0x056a0,0x1a5b4,0x025d0,0x092d0,0x0d2b2,0x0a950,0x0b557,
        0x06ca0,0x0b550,0x15355,0x04da0,0x0a5b0,0x14573,0x052b0,0x0a9a8,0x0e950,0x06aa0,
        0x0aea6,0x0ab50,0x04b60,0x0aae4,0x0a570,0x05260,0x0f263,0x0d950,0x05b57,0x056a0,
        0x096d0,0x04dd5,0x04ad0,0x0a4d0,0x0d4d4,0x0d250,0x0d558,0x0b540,0x0b6a0,0x195a6,
        0x095b0,0x049b0,0x0a974,0x0a4b0,0x0b27a,0x06a50,0x06d40,0x0af46,0x0ab60,0x09570,
        0x04af5,0x04970,0x064b0,0x074a3,0x0ea50,0x06b58,0x055c0,0x0ab60,0x096d5,0x092e0,
        0x0c960,0x0d954,0x0d4a0,0x0da50,0x07552,0x056a0,0x0abb7,0x025d0,0x092d0,0x0cab5,
        0x0a950,0x0b4a0,0x0baa4,0x0ad50,0x055d9,0x04ba0,0x0a5b0,0x15176,0x052b0,0x0a930,
        0x07954,0x06aa0,0x0ad50,0x05b52,0x04b60,0x0a6e6,0x0a4e0,0x0d260,0x0ea65,0x0d530,
        0x05aa0,0x076a3,0x096d0,0x04afb,0x04ad0,0x0a4d0,0x1d0b6,0x0d250,0x0d520,0x0dd45,
        0x0b5a0,0x056d0,0x055b2,0x049b0,0x0a577,0x0a4b0,0x0aa50,0x1b255,0x06d20,0x0ada0,
        0x14b63,0x09370,0x049f8,0x04970,0x064b0,0x168a6,0x0ea50,0x06b20,0x1a6c4,0x0aae0,
        0x0a2e0,0x0d2e3,0x0c960,0x0d557,0x0d4a0,0x0da50,0x05d55,0x056a0,0x0a6d0,0x055d4,
        0x052d0,0x0a9b8,0x0a950,0x0b4a0,0x0b6a6,0x0ad50,0x055a0,0x0aba4,0x0a5b0,0x052b0,
        0x0b273,0x06930,0x07337,0x06aa0,0x0ad50,0x14b55,0x04b60,0x0a570,0x054e4,0x0d160,
        0x0e968,0x0d520,0x0daa0,0x16aa6,0x056d0,0x04ae0,0x0a9d4,0x0a2d0,0x0d150,0x0f252,
        0x0d520
    );

    public static function forMonth($year, $month)
    {
        $year = (int) $year;
        $month = max(1, min(12, (int) $month));
        $days = (int) date('t', mktime(0, 0, 0, $month, 1, $year));
        $out = array('year' => $year, 'month' => $month, 'days' => array(), 'list' => array(),
            'note' => '');
        $qm = self::qingmingDay($year);
        for ($d = 1; $d <= $days; $d++) {
            $items = array();
            $key = $month . '-' . $d;
            if (isset(self::$solar[$key])) {
                $items[] = array('name' => self::$solar[$key], 'type' => 'solar', 'date' => $year . '-' . $month . '-' . $d);
            }
            if ($month === 4 && $d === $qm) {
                $items[] = array('name' => '清明节', 'type' => 'term', 'date' => $year . '-4-' . $d);
            }
            if ($year >= 1900 && $year <= 2100) {
                $l = self::solarToLunar($year, $month, $d);
                $lk = $l['month'] . '-' . $l['day'];
                if (!$l['leap'] && isset(self::$lunar[$lk])) {
                    $items[] = array('name' => self::$lunar[$lk], 'type' => 'lunar', 'date' => $year . '-' . $month . '-' . $d);
                }
                if (!$l['leap'] && $l['month'] === 12 && $l['day'] === self::monthDays($l['year'], 12)) {
                    $items[] = array('name' => '除夕', 'type' => 'lunar', 'date' => $year . '-' . $month . '-' . $d);
                }
            }
            if ($items) {
                $out['days'][$d] = $items;
                foreach ($items as $it) {
                    $out['list'][] = $it;
                }
            }
        }
        return $out;
    }

    private static function qingmingDay($year)
    {
        if (isset(self::$qingming[$year])) {
            return self::$qingming[$year];
        }
        $c = (int) substr((string) $year, -2);
        return max(4, min(6, (int) floor($c * 0.2422 + 4.81) - (int) floor(($c - 1) / 4)));
    }

    private static function leapMonth($y)
    {
        return self::$info[$y - 1900] & 0xf;
    }

    private static function leapDays($y)
    {
        if (self::leapMonth($y)) {
            return (self::$info[$y - 1900] & 0x10000) ? 30 : 29;
        }
        return 0;
    }

    private static function monthDays($y, $m)
    {
        return (self::$info[$y - 1900] & (0x10000 >> $m)) ? 30 : 29;
    }

    private static function yearDays($y)
    {
        $sum = 348;
        for ($i = 0x8000; $i > 0x8; $i >>= 1) {
            $sum += (self::$info[$y - 1900] & $i) ? 1 : 0;
        }
        return $sum + self::leapDays($y);
    }

    public static function solarToLunar($y, $m, $d)
    {
        $base = mktime(0, 0, 0, 1, 31, 1900);
        $target = mktime(0, 0, 0, (int) $m, (int) $d, (int) $y);
        $offset = (int) round(($target - $base) / 86400);
        $ly = 1900;
        $temp = 0;
        for (; $ly < 2101 && $offset > 0; $ly++) {
            $temp = self::yearDays($ly);
            $offset -= $temp;
        }
        if ($offset < 0) {
            $offset += $temp;
            $ly--;
        }
        $leap = self::leapMonth($ly);
        $isLeap = false;
        $i = 1;
        for (; $i < 13 && $offset > 0; $i++) {
            if ($leap > 0 && $i === ($leap + 1) && !$isLeap) {
                $i--;
                $isLeap = true;
                $temp = self::leapDays($ly);
            } else {
                $temp = self::monthDays($ly, $i);
            }
            if ($isLeap && $i === ($leap + 1)) {
                $isLeap = false;
            }
            $offset -= $temp;
        }
        if ($offset === 0 && $leap > 0 && $i === $leap + 1) {
            if ($isLeap) {
                $isLeap = false;
            } else {
                $isLeap = true;
                $i--;
            }
        }
        if ($offset < 0) {
            $offset += $temp;
            $i--;
        }
        return array('year' => $ly, 'month' => $i, 'day' => $offset + 1, 'leap' => $isLeap);
    }
}
