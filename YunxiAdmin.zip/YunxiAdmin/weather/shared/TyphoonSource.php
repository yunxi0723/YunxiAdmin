<?php

namespace YxWeather;

class TyphoonSource
{
    const LIST_URL = 'https://typhoon.nmc.cn/weatherservice/typhoon/jsons/list_default';
    const VIEW_URL = 'https://typhoon.nmc.cn/weatherservice/typhoon/jsons/view_';

    private static $grades = array(
        'TD' => '热带低压', 'TS' => '热带风暴', 'STS' => '强热带风暴',
        'TY' => '台风', 'STY' => '强台风', 'SuperTY' => '超强台风'
    );

    private static $dirs = array(
        'N' => '北', 'NNE' => '东北偏北', 'NE' => '东北', 'ENE' => '东北偏东',
        'E' => '东', 'ESE' => '东南偏东', 'SE' => '东南', 'SSE' => '东南偏南',
        'S' => '南', 'SSW' => '西南偏南', 'SW' => '西南', 'WSW' => '西南偏西',
        'W' => '西', 'WNW' => '西北偏西', 'NW' => '西北', 'NNW' => '西北偏北',
        '0' => '少动 / 停滞'
    );

    // 近岸海岸线近似（纬度 => 海岸经度），用于判断预报点是否已进入陆地
    private static $coast = array(
        array(18.2, 109.6), array(19.0, 110.0), array(20.0, 110.3), array(21.0, 110.6),
        array(21.5, 111.2), array(22.0, 113.0), array(22.6, 114.3), array(23.2, 116.2),
        array(23.8, 117.6), array(24.5, 118.4), array(25.2, 119.4), array(26.0, 119.9),
        array(27.0, 120.7), array(28.0, 121.5), array(29.0, 121.9), array(30.0, 122.0),
        array(31.0, 121.9), array(32.0, 121.6), array(33.0, 120.9), array(34.0, 119.9),
        array(35.0, 119.7), array(36.0, 120.6), array(37.0, 119.3), array(38.0, 118.0),
        array(39.0, 117.9), array(40.0, 120.0), array(41.0, 121.3)
    );

    public static function detail($cacheKey, $ttl, $userLat = null, $userLon = null)
    {
        return Http::remember($cacheKey . '-typhoon', $ttl, function () use ($userLat, $userLon) {
            $list = Http::json(self::LIST_URL, 8);
            if (!is_array($list) || empty($list['typhoonList'])) {
                return array('status' => false, 'message' => '中央气象台台风列表暂不可用', 'typhoons' => array());
            }
            $active = array();
            $latest = null;
            foreach ($list['typhoonList'] as $t) {
                if (!is_array($t) || count($t) < 8) {
                    continue;
                }
                $row = array(
                    'id' => (string) ($t[0] ?? ''),
                    'en_name' => (string) ($t[1] ?? ''),
                    'name' => trim((string) ($t[2] ?? '')),
                    'number' => (string) ($t[3] ?? ''),
                    'intl_number' => (string) ($t[5] ?? ''),
                    'meaning' => (string) ($t[6] ?? ''),
                    'status' => (string) ($t[7] ?? '')
                );
                if ($latest === null) {
                    $latest = $row;
                }
                if ($row['status'] === 'start') {
                    $active[] = $row;
                }
            }
            $target = $active ? $active[0] : $latest;
            if (!$target || $target['id'] === '') {
                return array('status' => false, 'message' => '暂无台风记录', 'typhoons' => array());
            }
            $view = Http::json(self::VIEW_URL . rawurlencode($target['id']), 9);
            $one = self::parseOne($view, $target, $userLat, $userLon);
            $out = array(
                'status' => true,
                'source' => '中央气象台 typhoon.nmc.cn（实时台风路径与风圈）',
                'updated' => date('Y-m-d H:i:s'),
                'active_count' => count($active),
                'archived' => !$active,
                'archive_note' => $active ? '' : '当前无编号活动台风，下方展示最近一个台风的归档路径',
                'typhoons' => array_map(function ($r) {
                    return array('id' => $r['id'], 'name' => $r['name'], 'en_name' => $r['en_name'],
                        'number' => $r['number'], 'status' => $r['status']);
                }, array_slice($active ? $active : array($latest), 0, 4)),
                'detail' => $one
            );
            return $out;
        }, function ($v) { return is_array($v) && !empty($v['status']); });
    }

    public static function cached($cacheKey)
    {
        $v = Http::stale($cacheKey . '-typhoon');
        return is_array($v) && !empty($v['status']) ? $v : null;
    }

    private static function parseOne($view, $meta, $userLat, $userLon)
    {
        $t = isset($view['typhoon']) && is_array($view['typhoon']) ? $view['typhoon'] : null;
        if (!$t || !isset($t[8]) || !is_array($t[8]) || !$t[8]) {
            return array('available' => false, 'message' => '该台风详情接口暂无路径数据', 'id' => $meta['id']);
        }
        $points = $t[8];
        $p = end($points);
        $grade = (string) ($p[3] ?? '');
        $lon = Http::num($p[4] ?? null);
        $lat = Http::num($p[5] ?? null);
        $pressure = Http::num($p[6] ?? null);
        $wind = Http::num($p[7] ?? null);
        $moveDir = (string) ($p[8] ?? '');
        $moveSpeed = Http::num($p[9] ?? null);
        $timeStr = (string) ($p[1] ?? '');
        $epoch = isset($p[2]) && is_numeric($p[2]) ? (int) ((float) $p[2] / 1000) : null;

        $circles = self::circles(isset($p[10]) ? $p[10] : array());
        $forecast = self::forecast(isset($p[11]) ? $p[11] : array(), $epoch);
        $history = self::history($points);

        $primaryAgency = '';
        if (isset($p[11]) && is_array($p[11])) {
            foreach (array('中国', 'CMA', '中央气象台', '中国气象局', '北京', '上海', '广州') as $pref) {
                if (isset($p[11][$pref])) {
                    $primaryAgency = $pref;
                    break;
                }
            }
            if ($primaryAgency === '') {
                $keys = array_keys($p[11]);
                $primaryAgency = (string) ($keys[0] ?? '');
            }
        }
        $track = self::track($history, $forecast, $primaryAgency, $lat, $lon,
            self::fmtTime($timeStr, $epoch), $grade);
        $landfall = self::landfall($forecast, $primaryAgency, $lat, $lon, $timeStr, $epoch,
            $userLat, $userLon);

        $dist = null;
        if ($userLat !== null && $userLon !== null && $lat !== null && $lon !== null) {
            $dist = AccountLocation::distance($userLat, $userLon, $lat, $lon);
        }

        $r7 = isset($circles['7']['max']) ? $circles['7']['max'] : null;
        $impact = array(
            'distance_km' => $dist,
            'zone_text' => ($lat !== null && $lon !== null)
                ? '中心 ' . self::coord($lat, 'N') . ' / ' . self::coord($lon, 'E')
                    . ($r7 ? '，七级风圈最大半径 ' . $r7 . ' km' : '')
                : '中心坐标未提供',
            'status' => $dist === null ? 'unknown' : ($r7 && $dist <= $r7 ? 'inside' : ($dist <= ($r7 ? $r7 * 3 : 900) ? 'near' : 'outside')),
            'user_note' => $dist === null ? '未获取到账号定位，无法判断与本站位置的距离'
                : '距账号当前定位约 ' . $dist . ' km',
            'origin' => '依据中央气象台风圈半径与账号定位推算，非官方影响区公告',
            'official_note' => '中央气象台该接口未提供「官方影响区域」字段，此处不填猜测地名'
        );

        $traffic = array(
            'wind_text' => $wind !== null ? '中心最大风速 ' . $wind . ' m/s（约 ' . self::beaufort($wind) . ' 级）' : '风速未提供',
            'tips' => self::trafficTips($grade, $wind, $dist, $r7),
            'origin' => '依据台风等级 / 风圈半径 / 实时距离推算；道路与航班实际管制以官方通报为准',
            'official_note' => '中央气象台该接口未提供航班 / 高铁 / 高速管制字段，需另接交通数据源'
        );

        $d = array(
            'available' => true,
            'id' => $meta['id'],
            'name' => $meta['name'] !== '' ? $meta['name'] : '未命名台风',
            'en_name' => $meta['en_name'],
            'number' => $meta['number'],
            'meaning' => $meta['meaning'],
            'active' => $meta['status'] === 'start',
            'status_text' => $meta['status'] === 'start' ? '活动中（生成 / 临近登陆）' : '已停编 · 历史归档',
            'grade_code' => $grade,
            'grade' => isset(self::$grades[$grade]) ? self::$grades[$grade] : ($grade !== '' ? $grade : '—'),
            'time' => self::fmtTime($timeStr, $epoch),
            'center' => ($lat !== null && $lon !== null)
                ? self::coord($lat, 'N') . ' / ' . self::coord($lon, 'E') : '—',
            'lat' => $lat, 'lon' => $lon,
            'pressure' => $pressure !== null ? (int) round($pressure) : null,
            'max_wind' => $wind,
            'max_wind_level' => $wind !== null ? self::beaufort($wind) : null,
            'move_dir_code' => $moveDir,
            'move_dir' => isset(self::$dirs[$moveDir]) ? self::$dirs[$moveDir] : ($moveDir !== '' ? $moveDir : '—'),
            'move_speed' => $moveSpeed,
            'circles' => $circles,
            'forecast' => $forecast,
            'history' => $history,
            'history_count' => count($points),
            'primary_agency' => $primaryAgency,
            'track' => $track,
            'landfall' => $landfall,
            'landing_probability' => null,
            'landing_probability_note' => '登陆点为依据官方预报路径与近岸陆地判定推算，并非官方登陆概率',
            'impact' => $impact,
            'traffic' => $traffic,
            'defense' => self::defense($grade, $dist, $r7),
            'defense_origin' => '依据当前台风等级与距离生成的通用防御建议，非官方逐条指令'
        );

        $d['fields'] = array(
            array('key' => 'name', 'label' => '台风名称', 'origin' => '官方接口字段', 'available' => true),
            array('key' => 'number', 'label' => '台风编号', 'origin' => '官方接口字段', 'available' => $d['number'] !== ''),
            array('key' => 'grade', 'label' => '当前等级', 'origin' => '官方接口字段', 'available' => $grade !== ''),
            array('key' => 'center', 'label' => '中心位置', 'origin' => '官方接口字段', 'available' => $lat !== null),
            array('key' => 'pressure', 'label' => '中心气压', 'origin' => '官方接口字段', 'available' => $pressure !== null),
            array('key' => 'max_wind', 'label' => '最大风速', 'origin' => '官方接口字段', 'available' => $wind !== null),
            array('key' => 'move_dir', 'label' => '移动方向', 'origin' => '官方接口字段', 'available' => $moveDir !== ''),
            array('key' => 'move_speed', 'label' => '移动速度', 'origin' => '官方接口字段', 'available' => $moveSpeed !== null),
            array('key' => 'circles', 'label' => '七级 / 十级 / 十二级风圈半径', 'origin' => '官方接口字段', 'available' => !empty($circles)),
            array('key' => 'forecast', 'label' => '路径预报', 'origin' => '官方接口字段', 'available' => !empty($forecast)),
            array('key' => 'history', 'label' => '历史路径', 'origin' => '官方接口字段', 'available' => !empty($history)),
            array('key' => 'track', 'label' => '完整移动轨迹', 'origin' => '官方历史 + 预报路径', 'available' => count($track) > 0),
            array('key' => 'landfall', 'label' => '登陆地点与时间预估', 'origin' => '官方路径 + 近岸陆地判定推算', 'available' => $landfall['status'] !== 'unknown'),
            array('key' => 'landing_probability', 'label' => '登陆概率', 'origin' => '数据源未提供', 'available' => false),
            array('key' => 'impact', 'label' => '影响区域', 'origin' => '依据风圈 + 定位推算', 'available' => true),
            array('key' => 'traffic', 'label' => '交通影响', 'origin' => '依据等级 / 距离推算', 'available' => true),
            array('key' => 'defense', 'label' => '防御建议', 'origin' => '依据等级生成的通用建议', 'available' => true)
        );
        return $d;
    }

    private static function track($history, $forecast, $agency, $curLat, $curLon, $curTime, $curGrade)
    {
        $out = array();
        foreach ($history as $h) {
            if ($h['lat'] === null || $h['lon'] === null) {
                continue;
            }
            $out[] = array('time' => $h['time'], 'lat' => $h['lat'], 'lon' => $h['lon'],
                'grade' => $h['grade'], 'kind' => 'history', 'wind' => $h['wind']);
        }
        if ($curLat !== null && $curLon !== null) {
            $out[] = array('time' => $curTime, 'lat' => $curLat, 'lon' => $curLon,
                'grade' => isset(self::$grades[$curGrade]) ? self::$grades[$curGrade] : $curGrade,
                'kind' => 'current', 'wind' => null);
        }
        foreach ($forecast as $f) {
            if ($agency !== '' && $f['agency'] !== $agency) {
                continue;
            }
            if ($f['lat'] === null || $f['lon'] === null) {
                continue;
            }
            $out[] = array('time' => $f['valid_time'], 'lat' => $f['lat'], 'lon' => $f['lon'],
                'grade' => $f['grade'], 'kind' => 'forecast', 'wind' => $f['wind'],
                'hour' => $f['hour'], 'agency' => $f['agency']);
        }
        return array_slice($out, -60);
    }

    private static function landfall($forecast, $agency, $curLat, $curLon, $timeStr, $epoch, $userLat, $userLon)
    {
        $base = array('status' => 'unknown', 'status_text' => '暂无登陆预估', 'time' => '',
            'place' => '', 'lat' => null, 'lon' => null, 'distance_km' => null,
            'confidence' => '一般', 'confidence_note' => '', 'note' => '台风路径预报暂不可用');

        if ($curLat !== null && $curLon !== null && self::isLand($curLat, $curLon)) {
            $dist = ($userLat !== null && $userLon !== null)
                ? AccountLocation::distance($userLat, $userLon, $curLat, $curLon) : null;
            return array_merge($base, array(
                'status' => 'landed', 'status_text' => '已登陆 / 中心位于陆地',
                'time' => self::fmtTime($timeStr, $epoch), 'place' => self::reversePlace($curLat, $curLon),
                'lat' => $curLat, 'lon' => $curLon, 'distance_km' => $dist,
                'confidence' => '已发生', 'confidence_note' => '按实时中心定位判定',
                'note' => '当前台风中心已位于陆地，登陆位置按最新定位显示；如需精确登陆点以中央气象台登陆通报为准。'
            ));
        }

        $pts = array();
        foreach ($forecast as $f) {
            if ($agency !== '' && $f['agency'] !== $agency) {
                continue;
            }
            if ($f['lat'] === null || $f['lon'] === null) {
                continue;
            }
            $pts[] = $f;
        }
        usort($pts, function ($a, $b) { return $a['hour'] - $b['hour']; });

        foreach ($pts as $f) {
            if (!self::isLand($f['lat'], $f['lon'])) {
                continue;
            }
            $agree = self::agreement($forecast, $f);
            $dist = ($userLat !== null && $userLon !== null)
                ? AccountLocation::distance($userLat, $userLon, $f['lat'], $f['lon']) : null;
            return array_merge($base, array(
                'status' => 'expected',
                'status_text' => '预计登陆',
                'time' => (string) $f['valid_time'],
                'hour' => (int) $f['hour'],
                'place' => self::reversePlace($f['lat'], $f['lon']),
                'lat' => $f['lat'], 'lon' => $f['lon'], 'distance_km' => $dist,
                'confidence' => $agree['text'], 'confidence_note' => $agree['note'],
                'note' => '依据中央气象台官方预报路径与近岸陆地判定推算，实际登陆点可能偏移 50–150 km，'
                    . '登陆时间以官方最新通报为准。'
            ));
        }

        return array_merge($base, array(
            'status' => 'sea', 'status_text' => '预计不登陆 / 海上转向',
            'place' => '当前预报路径未进入陆地',
            'lat' => $curLat, 'lon' => $curLon,
            'note' => '依据官方预报路径，未来 5 天未判定到登陆点，可能海上转向或影响其他地区，请关注最新通报。'
        ));
    }

    private static function agreement($forecast, $picked)
    {
        $agencies = array();
        foreach ($forecast as $f) {
            if ($f['lat'] === null || $f['lon'] === null) {
                continue;
            }
            if (abs((int) $f['hour'] - (int) $picked['hour']) > 12) {
                continue;
            }
            if (abs((float) $f['lat'] - (float) $picked['lat']) > 1.5
                || abs((float) $f['lon'] - (float) $picked['lon']) > 1.5) {
                continue;
            }
            $agencies[(string) $f['agency']] = true;
        }
        $n = count($agencies);
        if ($n >= 3) {
            return array('text' => '较高', 'note' => $n . ' 家机构预报点接近');
        }
        if ($n === 2) {
            return array('text' => '中等', 'note' => '2 家机构预报点接近');
        }
        return array('text' => '一般', 'note' => '仅 1 家机构给出该登陆点，存在偏移可能');
    }

    private static function reversePlace($lat, $lon)
    {
        $r = AccountLocation::reverse($lat, $lon);
        if (!empty($r['ok'])) {
            $parts = array();
            foreach (array($r['province'] ?? '', $r['city'] ?? '', $r['district'] ?? '') as $v) {
                $v = trim((string) $v);
                if ($v !== '' && !in_array($v, $parts, true)) {
                    $parts[] = $v;
                }
            }
            if ($parts) {
                return implode(' · ', array_slice($parts, 0, 3));
            }
        }
        return self::coord($lat, 'N') . ' / ' . self::coord($lon, 'E') . ' 近岸';
    }

    private static function isLand($lat, $lon)
    {
        $lat = (float) $lat;
        $lon = (float) $lon;
        if ($lat >= 18.1 && $lat <= 20.2 && $lon >= 108.5 && $lon <= 111.3) {
            return true; // 海南岛
        }
        if ($lat >= 21.8 && $lat <= 25.4 && $lon >= 119.9 && $lon <= 122.1) {
            return true; // 台湾岛
        }
        $coast = self::coastLon($lat);
        if ($coast !== null && $lon >= 105 && $lon <= $coast) {
            return true; // 中国大陆近岸
        }
        foreach (array(
            array(31.0, 34.6, 129.4, 132.2), array(33.0, 35.6, 132.0, 136.2),
            array(34.4, 41.6, 135.8, 142.0)
        ) as $b) {
            if ($lat >= $b[0] && $lat <= $b[1] && $lon >= $b[2] && $lon <= $b[3]) {
                return true; // 日本列岛近似
            }
        }
        if ($lat >= 34.0 && $lat <= 38.7 && $lon >= 125.4 && $lon <= 129.6) {
            return true; // 朝鲜半岛
        }
        if (($lat >= 13.0 && $lat <= 19.0 && $lon >= 120.0 && $lon <= 124.0)
            || ($lat >= 8.5 && $lat <= 23.0 && $lon >= 102.0 && $lon <= 109.6)) {
            return true; // 吕宋岛 / 中南半岛近岸
        }
        return false;
    }

    private static function coastLon($lat)
    {
        $t = self::$coast;
        $n = count($t);
        if ($lat < $t[0][0] || $lat > $t[$n - 1][0]) {
            return null;
        }
        for ($i = 0; $i < $n - 1; $i++) {
            if ($lat >= $t[$i][0] && $lat <= $t[$i + 1][0]) {
                $f = ($lat - $t[$i][0]) / ($t[$i + 1][0] - $t[$i][0]);
                return $t[$i][1] + ($t[$i + 1][1] - $t[$i][1]) * $f;
            }
        }
        return null;
    }

    private static function circles($raw)
    {
        $out = array();
        if (!is_array($raw)) {
            return $out;
        }
        $map = array('30KTS' => '7', '50KTS' => '10', '64KTS' => '12');
        foreach ($raw as $c) {
            if (!is_array($c) || !isset($c[0]) || !isset($map[(string) $c[0]])) {
                continue;
            }
            $quad = array();
            for ($i = 1; $i <= 4; $i++) {
                $quad[] = isset($c[$i]) && is_numeric($c[$i]) ? (int) $c[$i] : null;
            }
            $nums = array_filter($quad, function ($v) { return $v !== null; });
            $k = $map[(string) $c[0]];
            $out[$k] = array(
                'level' => $k . ' 级风圈',
                'kts' => (string) $c[0],
                'quadrants' => array(
                    '东北' => $quad[0], '东南' => $quad[1], '西南' => $quad[2], '西北' => $quad[3]
                ),
                'max' => $nums ? max($nums) : null,
                'min' => $nums ? min($nums) : null
            );
        }
        return $out;
    }

    private static function forecast($raw, $epoch)
    {
        $out = array();
        if (!is_array($raw)) {
            return $out;
        }
        foreach ($raw as $agency => $rows) {
            if (!is_array($rows)) {
                continue;
            }
            foreach ($rows as $f) {
                if (!is_array($f) || count($f) < 6) {
                    continue;
                }
                $hour = (int) ($f[0] ?? 0);
                $valid = $epoch !== null ? date('m-d H:i', $epoch + $hour * 3600) : '+' . $hour . 'h';
                $g = (string) ($f[7] ?? '');
                $out[] = array(
                    'agency' => (string) $agency,
                    'hour' => $hour,
                    'valid_time' => $valid,
                    'lon' => Http::num($f[2] ?? null),
                    'lat' => Http::num($f[3] ?? null),
                    'pressure' => Http::num($f[4] ?? null),
                    'wind' => Http::num($f[5] ?? null),
                    'grade' => isset(self::$grades[$g]) ? self::$grades[$g] : $g
                );
            }
        }
        usort($out, function ($a, $b) { return $a['hour'] - $b['hour']; });
        return array_slice($out, 0, 16);
    }

    private static function history($points)
    {
        $out = array();
        $slice = array_slice($points, -24);
        foreach ($slice as $p) {
            if (!is_array($p) || count($p) < 8) {
                continue;
            }
            $g = (string) ($p[3] ?? '');
            $out[] = array(
                'time' => self::fmtTime((string) ($p[1] ?? ''), isset($p[2]) ? (int) ((float) $p[2] / 1000) : null),
                'lon' => Http::num($p[4] ?? null),
                'lat' => Http::num($p[5] ?? null),
                'pressure' => Http::num($p[6] ?? null),
                'wind' => Http::num($p[7] ?? null),
                'grade' => isset(self::$grades[$g]) ? self::$grades[$g] : $g
            );
        }
        return $out;
    }

    private static function trafficTips($grade, $wind, $dist, $r7)
    {
        $tips = array();
        if ($grade === 'SuperTY' || $grade === 'STY' || ($wind !== null && $wind >= 40)) {
            $tips[] = '强台风级及以上：沿海高速、跨海大桥常见限速或封闭，航班大面积取消风险高，请以官方管制通报为准。';
        } elseif ($grade === 'TY' || ($wind !== null && $wind >= 25)) {
            $tips[] = '台风级：机场进出港航班可能延误，高铁沿海区段可能限速，出行前查询实时班次。';
        } else {
            $tips[] = '当前强度以热带风暴 / 热带低压为主，仍需关注短时强降水导致的道路积水与能见度下降。';
        }
        if ($dist !== null && $r7 && $dist <= $r7) {
            $tips[] = '账号当前定位落在七级风圈半径内，建议减少非必要驾车出行。';
        } elseif ($dist !== null) {
            $outside = $r7 ? max(0, $dist - (int) $r7) : $dist;
            $tips[] = '账号当前定位在七级风圈外约 ' . $outside . ' km，仍需留意外围云系降水。';
        }
        $tips[] = '本卡不接入航班 / 铁路 / 高速实时管制数据，以上为依据气象条件的风险提示，不是官方停运通知。';
        return $tips;
    }

    private static function defense($grade, $dist, $r7)
    {
        $base = array(
            '关注中央气象台最新预警与本地防指通告，提前确认停课、停工、停运安排。',
            '加固门窗、收回阳台杂物与广告牌，检查排水口，低洼处备好挡水板。',
            '储备饮用水、手电、充电宝与常用药品，台风影响期间避免前往海边、山区与临水区域。'
        );
        if ($grade === 'SuperTY' || $grade === 'STY') {
            array_unshift($base, '超强 / 强台风级别：优先服从转移安置安排，切勿在临时建筑、老旧房屋内逗留。');
        }
        if ($dist !== null && $r7 && $dist <= $r7) {
            array_unshift($base, '当前定位已进入七级风圈范围：请立即停止户外活动并远离玻璃幕墙。');
        }
        return $base;
    }

    private static function beaufort($ms)
    {
        $limits = array(0.3, 1.6, 3.4, 5.5, 8.0, 10.8, 13.9, 17.2, 20.8, 24.5, 28.5, 32.7, 37.0, 41.5, 46.2, 51.0, 56.1, 61.3);
        $n = 0;
        foreach ($limits as $l) {
            if ((float) $ms <= $l) {
                break;
            }
            $n++;
        }
        return $n;
    }

    private static function coord($v, $suffix)
    {
        return number_format(abs((float) $v), 1) . '°' . $suffix;
    }

    private static function fmtTime($s, $epoch)
    {
        if (strlen($s) >= 12) {
            return substr($s, 0, 4) . '-' . substr($s, 4, 2) . '-' . substr($s, 6, 2) . ' '
                . substr($s, 8, 2) . ':' . substr($s, 10, 2);
        }
        return $epoch ? date('Y-m-d H:i', $epoch) : (string) $s;
    }
}
