<?php

namespace YxWeather\Desktop;

use YxWeather\AccountLocation;
use YxWeather\WeatherSource;
use YxWeather\TyphoonSource;
use YxWeather\TyphoonScene;
use YxWeather\TrafficSource;
use YxWeather\TrafficScene;
use YxWeather\MapScene;
use YxWeather\Festivals;
use YxWeather\Metrics;

class Controller
{
    const END = 'desktop';
    const WEATHER_TTL = 180;
    const TYPHOON_TTL = 900;
    const TRAFFIC_TTL = 180;
    const ARTICLE_TTL = 1800;
    const REFRESH_MS = 240000;
    const POLICY = 'gps-first';

    private static function e($v)
    {
        return htmlspecialchars((string) ($v === null ? '' : $v), ENT_QUOTES, 'UTF-8');
    }

    private static function skyBg($kind)
    {
        $map = array(
            'sun' => 'linear-gradient(180deg,#4a9ce2,#bde0f6)',
            'cloud' => 'linear-gradient(180deg,#8299b1,#cfdce4)',
            'rain' => 'linear-gradient(180deg,#4e6076,#96aab8)',
            'storm' => 'linear-gradient(180deg,#343c52,#6e768a)',
            'snow' => 'linear-gradient(180deg,#8ca6be,#e0eaf2)',
            'fog' => 'linear-gradient(180deg,#969fa6,#d6dadc)',
            'wind' => 'linear-gradient(180deg,#6096be,#bed6e4)'
        );
        return isset($map[$kind]) ? $map[$kind] : $map['sun'];
    }

    private static function need($parts, $key)
    {
        return $parts === null || in_array($key, $parts, true);
    }

    private static function trendDays()
    {
        $d = isset($_REQUEST['days']) ? (int) $_REQUEST['days'] : 14;
        return max(7, min(30, $d));
    }

    private static function geoLine($s, $withStage = true)
    {
        $l = isset($s['location']) && is_array($s['location']) ? $s['location'] : array();
        $parts = array();
        $street = trim((string) ($l['street_text'] ?? ''));
        if ($street !== '') {
            $parts[] = $street;
        }
        $acc = trim((string) ($l['accuracy_text'] ?? ''));
        if ($acc !== '') {
            $parts[] = $acc;
        }
        if ($withStage && !empty($l['stage_text'])) {
            $parts[] = (string) $l['stage_text'];
        }
        return $parts ? implode(' · ', $parts) : '定位尚未校准';
    }

    public static function location($uid, $autoIp = true)
    {
        $loc = $autoIp
            ? AccountLocation::sync((int) $uid, AccountLocation::clientIp())
            : AccountLocation::get((int) $uid);
        return $loc ? AccountLocation::decorate($loc) : array();
    }

    public static function state($uid, $parts = null, $fast = false)
    {
        $loc = self::location($uid, !$fast);
        if (!$loc && $fast) {
            $loc = self::location($uid, true);
        }
        $s = array('end' => self::END, 'policy' => self::POLICY, 'location' => $loc,
            'weather' => null, 'warnings' => null, 'typhoon' => null, 'traffic' => null,
            'metrics' => null, 'festivals' => null, 'life' => array());
        $wantWeather = self::need($parts, 'weather') || self::need($parts, 'life')
            || self::need($parts, 'traffic') || self::need($parts, 'typhoon')
            || self::need($parts, 'warnings') || self::need($parts, 'forecast');
        if ($wantWeather && $s['location']) {
            $cached = $fast ? WeatherSource::stale(
                $s['location']['lat'], $s['location']['lon'], $s['location'], 'desktop-weather'
            ) : null;
            $s['weather'] = $cached ?: WeatherSource::current(
                $s['location']['lat'], $s['location']['lon'], $s['location'],
                'desktop-weather', self::WEATHER_TTL
            );
            $s['life'] = WeatherSource::life(!empty($s['weather']['status']) ? $s['weather'] : array());
            $warn = $fast ? WeatherSource::warningsStale(
                (string) ($s['location']['province'] ?? ''), (string) ($s['location']['city'] ?? '')
            ) : null;
            if ($fast && !$warn) {
                $s['warnings'] = array('status' => true, 'pending' => true, 'items' => array());
            } else {
                $s['warnings'] = $warn ?: WeatherSource::warnings(
                    (string) ($s['location']['province'] ?? ''), (string) ($s['location']['city'] ?? '')
                );
            }
        }
        if (self::need($parts, 'typhoon')) {
            $s['typhoon'] = $fast
                ? (TyphoonSource::cached('desktop') ?: array('status' => false, 'message' => '台风数据加载中'))
                : TyphoonSource::detail('desktop', self::TYPHOON_TTL,
                    $s['location']['lat'] ?? null, $s['location']['lon'] ?? null);
        }
        if (self::need($parts, 'traffic')) {
            $s['traffic'] = TrafficSource::local($s['location'], $s['weather'], !$fast);
        }
        if (self::need($parts, 'trends')) {
            $s['metrics'] = Metrics::summary(self::trendDays());
        }
        if (self::need($parts, 'calendar')) {
            $s['festivals'] = Festivals::forMonth((int) date('Y'), (int) date('n'));
        }
        return $s;
    }

    public static function render($uid, $parts = null, $fast = false)
    {
        $s = self::state($uid, $parts, $fast);
        $out = array('meta' => array(
            'end' => self::END, 'policy' => self::POLICY,
            'weather_ttl' => self::WEATHER_TTL, 'refresh_ms' => self::REFRESH_MS,
            'server_time' => date('Y-m-d H:i:s'),
            'location_accuracy' => (int) ($s['location']['accuracy_m'] ?? 0)
        ));
        if (self::need($parts, 'location')) $out['location'] = self::renderLocation($s);
        if (self::need($parts, 'weather'))  $out['weather'] = self::renderWeather($s);
        if (self::need($parts, 'warnings')) $out['warnings'] = self::renderWarnings($s);
        if (self::need($parts, 'forecast')) $out['forecast'] = self::renderForecast($s);
        if (self::need($parts, 'life'))     $out['life'] = self::renderLife($s);
        if (self::need($parts, 'typhoon'))  $out['typhoon'] = self::renderTyphoon($s);
        if (self::need($parts, 'traffic'))  $out['traffic'] = self::renderTraffic($s);
        if (self::need($parts, 'trends'))   $out['trends'] = self::renderTrends($s);
        if (self::need($parts, 'calendar')) $out['calendar'] = self::renderFestivals($s);
        return $out;
    }

    private static function renderWeather($s)
    {
        $w = $s['weather'];
        if (!is_array($w) || empty($w['status'])) {
            return '<div class="wx-empty">' . self::e($w['message'] ?? '天气数据暂不可用') . '</div>';
        }
        $kind = WeatherSource::animKind($w['weather'] ?? '');
        $sky = self::e(json_encode(WeatherSource::scene($w), JSON_UNESCAPED_UNICODE));
        $deg = is_numeric($w['temperature'] ?? null) ? round($w['temperature']) : '--';
        $feel = is_numeric($w['feels_like'] ?? null) ? '体感 ' . round($w['feels_like']) . '°' : '';
        $today = !empty($w['forecast'][0]) ? $w['forecast'][0] : array();
        $range = (isset($today['temp_min'], $today['temp_max']) && $today['temp_min'] !== '' && $today['temp_max'] !== '')
            ? $today['temp_min'] . '° / ' . $today['temp_max'] . '°' : '';
        $pills = array();
        if (is_numeric($w['humidity'] ?? null)) $pills[] = '湿度 ' . (int) $w['humidity'] . '%';
        $wind = trim((string) ($w['wind_direction'] ?? '') . ' ' . (string) ($w['wind_power'] ?? ''));
        if ($wind !== '') $pills[] = $wind;
        if (is_numeric($w['aqi'] ?? null)) $pills[] = 'AQI ' . (int) $w['aqi'] . ' ' . ($w['aqi_category'] ?? '');
        if (!$pills) $pills[] = $w['report_time'] ?? '实时';

        $h = '<div class="wxw-hero" data-wx-scene="hero" data-wx-sky="' . $sky
            . '" data-anim="' . self::e($kind) . '" style="background:' . self::skyBg($kind) . '">'
            . '<canvas class="wx-sky"></canvas><div class="wxw-shade"></div>'
            . '<div class="wxw-head"><span>' . self::e($w['place'] ?? '当前位置') . '</span>'
            . '<em>' . self::e($w['report_time'] ?? '') . '</em></div>'
            . '<div class="wxw-geo">' . self::e(self::geoLine($s, false)) . '</div>'
            . '<div class="wxw-main"><div class="wxw-deg">' . self::e($deg) . '<sup>°</sup></div>'
            . '<div class="wxw-txt"><b>' . self::e($w['weather'] ?? '—') . '</b>'
            . '<span>' . self::e(trim($feel . ' ' . $range)) . '</span></div></div>'
            . '<div class="wxw-pills">';
        foreach ($pills as $p) {
            $h .= '<span>' . self::e($p) . '</span>';
        }
        $h .= '</div></div>';

        $facts = array(
            array('湿度', is_numeric($w['humidity'] ?? null) ? $w['humidity'] . '%' : '—'),
            array('风力', $wind ?: '—'),
            array('阵风', is_numeric($w['wind_gust'] ?? null) ? $w['wind_gust'] . ' m/s' : '—'),
            array('降水', is_numeric($w['precipitation'] ?? null) ? $w['precipitation'] . ' mm' : '—'),
            array('能见度', is_numeric($w['visibility'] ?? null) ? $w['visibility'] . ' km' : '—'),
            array('气压', is_numeric($w['pressure'] ?? null) ? $w['pressure'] . ' hPa' : '—'),
            array('紫外线', is_numeric($w['uv_index'] ?? null) ? 'UV ' . $w['uv_index'] : '—'),
            array('空气质量', is_numeric($w['aqi'] ?? null) ? ($w['aqi_category'] ?? '') . ' · ' . $w['aqi'] : '—')
        );
        $h .= '<div class="wxw-facts">';
        foreach ($facts as $f) {
            $h .= '<div><i>' . self::e($f[0]) . '</i><b>' . self::e($f[1]) . '</b></div>';
        }
        $h .= '</div>';

        if (!empty($w['stale_note'])) {
            $h .= '<div class="wx-note">' . self::e($w['stale_note']) . '</div>';
        }
        return $h;
    }

    private static function renderWarnings($s)
    {
        $wn = isset($s['warnings']) && is_array($s['warnings']) ? $s['warnings'] : array();
        $h = '<div class="wxw-warn-card"><div class="wxw-note">' . self::e(self::geoLine($s, false))
            . ' · 预警按区县发布</div>';
        if (!empty($wn['pending'])) {
            $h .= '<div class="wxw-none">预警数据加载中</div>';
        } elseif (!empty($wn['items'])) {
            $h .= '<div class="wxw-warn-scroll">';
            foreach ($wn['items'] as $a) {
                $h .= '<div class="wxw-warn-i"><span class="lv lv-' . self::e($a['level'] ?? 'none') . '">'
                    . self::e($a['level'] ?? '预警') . '</span><div><b>' . self::e($a['title'] ?? '') . '</b>'
                    . '<p>' . self::e($a['content'] ?? '') . '</p><i>' . self::e($a['issueTime'] ?? '') . '</i></div></div>';
            }
            $h .= '</div>';
        } else {
            $h .= '<div class="wxw-none">当前区域暂无生效预警</div>';
        }
        return $h . '</div>';
    }

    private static function renderForecast($s)
    {
        $w = is_array($s['weather']) ? $s['weather'] : array();
        $h = '';
        if (!empty($w['hourly'])) {
            $h .= '<div class="wxw-sub">逐小时<em>' . self::e(self::geoLine($s, false)) . '</em></div>'
                . '<div class="wxw-hour-row">';
            foreach ($w['hourly'] as $x) {
                $pop = isset($x['pop']) && $x['pop'] !== null ? (int) $x['pop'] : 0;
                $bh = max(4, min(30, (int) round($pop * 0.3)));
                $h .= '<div class="wxw-hour"><span>' . self::e($x['time'] ?? '') . '</span>'
                    . '<div class="wxw-bar"><i style="height:' . $bh . 'px"></i></div>'
                    . '<b>' . ($pop > 0 ? $pop . '%' : '—') . '</b></div>';
            }
            $h .= '</div>';
        }
        if (!empty($w['forecast'])) {
            $h .= '<div class="wxw-sub">未来 5 日</div><div class="wxw-day-row">';
            foreach ($w['forecast'] as $f) {
                $h .= '<div class="wxw-day"><b>' . self::e($f['week'] ?? '') . '</b>'
                    . '<span>' . self::e($f['weather_day'] ?? '') . '</span>'
                    . '<em>' . self::e($f['temp_min'] ?? '') . '°<i>' . self::e($f['temp_max'] ?? '') . '°</i></em>'
                    . '<u>降水 ' . (isset($f['pop_max']) ? self::e($f['pop_max']) . '%' : '—') . '</u></div>';
            }
            $h .= '</div>';
        }
        return $h !== '' ? $h : '<div class="wxw-none">预报数据暂不可用</div>';
    }

    private static function renderLocation($s)
    {
        $l = $s['location'];
        if (!$l) {
            return '<div class="wx-empty">定位暂不可用</div>';
        }
        $w = is_array($s['weather']) ? $s['weather'] : array();
        $region = trim(implode(' ', array_filter(array(
            (string) ($l['province'] ?? ''), (string) ($l['city'] ?? '')
        ))));
        $street = trim(implode(' · ', array_filter(array(
            (string) ($l['district'] ?? ''), (string) ($l['street'] ?? '')
        ))));
        if ($street === '') {
            $street = $region !== '' ? $region : (string) ($l['place_text'] ?? '');
        }
        $stamp = !empty($l['updated']) ? date('m-d H:i', (int) $l['updated']) : '—';
        $acc = (int) ($l['accuracy_m'] ?? 0);
        $accText = $acc > 0 && $acc <= 100 ? '±' . $acc . ' m' : ($acc > 0 ? '约 ' . round($acc / 1000, 1) . ' km' : '城市级');
        $temp = is_numeric($w['temperature'] ?? null) ? round($w['temperature']) . '°' : '—';

        $h = '<div class="wxl-map">'
            . '<svg class="wxl-map-svg" viewBox="0 0 640 520" preserveAspectRatio="xMidYMid slice" aria-hidden="true">'
            . '<rect width="640" height="520" fill="#e9eee8"/>'
            . '<path d="M548 0c-42 86 30 156 6 236s-46 104-20 284h106V0z" fill="#cfe4ef"/>'
            . '<path d="M556 0c-30 92 26 150 4 226s-38 112-14 294" fill="none" stroke="#b9d9e8" stroke-width="3"/>'
            . '<g fill="#d5e5cf"><rect x="26" y="24" width="128" height="78" rx="10"/><rect x="352" y="330" width="128" height="84" rx="12"/><rect x="36" y="352" width="96" height="76" rx="12"/></g>'
            . '<g fill="#dde4dc" stroke="#ccd5cb" stroke-width="1.2">'
            . '<rect x="16" y="126" width="118" height="94" rx="5"/><rect x="150" y="126" width="132" height="94" rx="5"/>'
            . '<rect x="298" y="126" width="130" height="94" rx="5"/><rect x="16" y="238" width="118" height="92" rx="5"/>'
            . '<rect x="150" y="238" width="132" height="92" rx="5"/><rect x="298" y="238" width="130" height="92" rx="5"/>'
            . '<rect x="150" y="348" width="132" height="86" rx="5"/><rect x="298" y="348" width="130" height="86" rx="5"/>'
            . '<rect x="150" y="452" width="132" height="58" rx="5"/><rect x="298" y="452" width="130" height="58" rx="5"/>'
            . '</g>'
            . '<g fill="#cad4c9"><rect x="38" y="146" width="46" height="28" rx="3"/><rect x="92" y="146" width="26" height="52" rx="3"/>'
            . '<rect x="172" y="146" width="58" height="34" rx="3"/><rect x="238" y="188" width="26" height="18" rx="3"/>'
            . '<rect x="320" y="146" width="40" height="50" rx="3"/><rect x="368" y="146" width="42" height="28" rx="3"/>'
            . '<rect x="40" y="262" width="58" height="40" rx="3"/><rect x="176" y="262" width="52" height="26" rx="3"/>'
            . '<rect x="236" y="296" width="28" height="20" rx="3"/><rect x="322" y="262" width="62" height="34" rx="3"/>'
            . '<rect x="176" y="370" width="72" height="30" rx="3"/><rect x="326" y="370" width="50" height="42" rx="3"/></g>'
            . '<g stroke="#ffffff" fill="none"><path d="M0 112h560" stroke-width="18"/><path d="M0 222h560" stroke-width="14"/>'
            . '<path d="M0 338h560" stroke-width="16"/><path d="M0 444h560" stroke-width="14"/>'
            . '<path d="M138 0v520" stroke-width="14"/><path d="M286 0v520" stroke-width="12"/><path d="M438 0v520" stroke-width="16"/></g>'
            . '<path d="M-40 500L470-40" stroke="#f4e7c6" stroke-width="26"/>'
            . '<path d="M-40 500L470-40" stroke="#ffffff" stroke-width="18"/>'
            . '<path d="M-40 500L470-40" stroke="#e3c98d" stroke-width="1.4" stroke-dasharray="10 10"/>'
            . '<g fill="#9aa59c" font-size="11" font-family="system-ui,sans-serif">'
            . '<text x="24" y="107">天河路</text><text x="24" y="333">体育西路</text>'
            . '<text x="446" y="330" transform="rotate(-90 446 330)">珠江新城</text>'
            . '<text x="28" y="368" fill="#7f9c7a">城市公园</text></g>'
            . '</svg>'
            . '<div class="wxl-tint"></div>'
            . '<div class="wxl-pin"><span class="pulse"></span><span class="dot"></span></div>'
            . '<div class="wxl-top"><span class="wxl-pin-ico"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-loc"></use></svg></span>'
            . '<div class="wxl-name"><span>' . self::e($region ?: '当前位置') . '</span><b>' . self::e($street) . '</b></div>'
            . '<span class="wxl-acc">' . self::e($accText) . '</span></div>'
            . '<div class="wxl-now"><b>' . self::e($temp) . '</b><span>' . self::e($w['weather'] ?? '天气') . '</span></div>'
            . '<div class="wxl-info">'
            . '<div><i>定位方式</i><b>' . self::e($l['stage_text'] ?: '—') . '</b></div>'
            . '<div><i>街道</i><b>' . self::e($l['street_text'] ?: ($region ?: $l['place_text'])) . '</b></div>'
            . '<div><i>坐标</i><b>' . self::e(number_format($l['lat'], 5)) . ', ' . self::e(number_format($l['lon'], 5)) . '</b></div>'
            . '<div><i>精度 / 更新</i><b>' . self::e($accText . ' · ' . $stamp) . '</b></div>'
            . '</div></div>';
        return $h;
    }

    private static function renderLife($s)
    {
        $w = $s['weather'];
        $kind = WeatherSource::animKind($w['weather'] ?? '');
        $h = '<div class="wx-scene" data-wx-scene="mini" data-wx-sky="'
            . self::e(json_encode(WeatherSource::scene($w), JSON_UNESCAPED_UNICODE))
            . '" data-anim="' . self::e($kind) . '" style="background:' . self::skyBg($kind)
            . '" aria-hidden="true"><canvas class="wx-sky"></canvas></div>'
            . '<div class="wxw-sub">生活指数<em>' . self::e(self::geoLine($s, false)) . '</em></div>';
        $items = $s['life'];
        if (!$items) {
            return $h . '<div class="wx-none">生活指数需要天气数据，当前暂不可用</div>';
        }
        $h .= '<div class="wx-life-grid">';
        foreach ($items as $it) {
            $h .= '<div class="wx-life-i"><span class="tp"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#'
                . self::e($it['icon'] ?? 'i-sun') . '"></use></svg></span>'
                . '<div class="tx"><b>' . self::e($it['name'] ?? '') . '</b><em>' . self::e($it['level'] ?? '') . '</em></div>'
                . '<p>' . self::e($it['advice'] ?? '') . '</p></div>';
        }
        $h .= '</div>';
        return $h;
    }

    private static function renderTyphoon($s)
    {
        return TyphoonScene::html($s['typhoon'], 'desktop');
    }

    private static function renderTraffic($s)
    {
        return TrafficScene::html($s['traffic']);
    }

    private static function renderTrends($s)
    {
        $m = $s['metrics'];
        if (!is_array($m) || empty($m['status'])) {
            return '<div class="wx-none">运行指标暂不可用</div>';
        }
        $t = $m['totals'];
        $days = (int) ($m['days'] ?? 14);
        $health = (int) ($t['health'] ?? 0);
        $hl = $health >= 90 ? '运行稳定' : ($health >= 70 ? '整体良好' : ($health >= 50 ? '需要关注' : '存在异常'));
        $hc = $health >= 90 ? 0 : ($health >= 70 ? 1 : ($health >= 50 ? 2 : 3));

        $h = '<div class="mx" data-mx-root data-mx-days="' . $days . '">';
        $h .= '<div class="mx-top"><div class="mx-health lv' . $hc . '">'
            . '<div class="mx-ring" style="--v:' . $health . '"><b data-mx-count="' . $health . '">' . $health . '</b><i>健康分</i></div>'
            . '<div class="mx-htxt"><b>' . self::e($hl) . '</b><span>近 ' . $days . ' 天 · 样本 '
            . self::e($m['sample']) . ' 条</span></div></div>'
            . '<div class="mx-tabs">';
        foreach (array(7 => '7 天', 14 => '14 天', 30 => '30 天') as $d => $lb) {
            $h .= '<button type="button" data-mx-range="' . $d . '"'
                . ($d === $days ? ' class="on"' : '') . '>' . $lb . '</button>';
        }
        $h .= '</div></div>';

        $kpis = array(
            array('页面首屏均耗时', $t['page_avg_ms'], 'ms', $t['page_avg_ms'] !== null && $t['page_avg_ms'] > 1200 ? '慢' : '目标 < 1.2s'),
            array('接口平均耗时', $t['api_avg_ms'], 'ms', $t['api_avg_ms'] !== null && $t['api_avg_ms'] > 800 ? '偏慢' : '目标 < 800ms'),
            array('接口成功率', $t['api_success'], '%', '调用 ' . $t['api_calls'] . ' 次'),
            array('接口异常率', $t['api_err_rate'], '%', '异常 ' . $t['api_err'] . ' 次'),
            array('异常事件', $t['errors'], '次', '前端捕获'),
            array('慢接口', $t['slow_endpoints'], '个', '均耗时 > 800ms')
        );
        $h .= '<div class="mx-kpis">';
        foreach ($kpis as $k) {
            $v = $k[1];
            $h .= '<div class="mx-kpi"><i>' . self::e($k[0]) . '</i><b>'
                . ($v !== null ? '<span data-mx-count="' . self::e($v) . '">' . self::e($v) . '</span>' . self::e($k[2]) : '暂无')
                . '</b><em>' . self::e($k[3]) . '</em></div>';
        }
        $h .= '</div>';

        $points = array();
        foreach ($m['series'] as $p) {
            $points[] = array(
                'label' => $p['label'], 'page_ms' => $p['page_ms'], 'api_calls' => $p['api_calls'],
                'api_avg_ms' => $p['api_avg_ms'] ?? null, 'rate' => $p['api_success'],
                'errors' => $p['errors'], 'health' => $p['health'] ?? null
            );
        }
        $h .= '<div class="mx-chart-head"><b>页面性能趋势</b><span>悬停查看每日明细</span></div>';
        $h .= '<div class="mx-chart-wrap" data-mx-chart data-mx-series="'
            . self::e(json_encode($points, JSON_UNESCAPED_UNICODE)) . '">'
            . self::metricsChart($m['series'], $points)
            . '<div class="mx-tip" hidden></div></div>';

        $h .= '<div class="mx-sub">接口表现 <em>按调用量排序 · 点击行高亮</em></div><div class="mx-eps">';
        $maxCalls = 1;
        foreach ($m['endpoints'] as $e) {
            $maxCalls = max($maxCalls, (int) $e['calls']);
        }
        foreach ($m['endpoints'] as $e) {
            $pct = (int) round((int) $e['calls'] * 100 / $maxCalls);
            $h .= '<div class="mx-ep lv-' . self::e($e['level']) . '">'
                . '<div class="mx-ep-main"><b>' . self::e($e['name']) . '</b>'
                . '<i>' . self::e($e['device_text']) . '</i></div>'
                . '<div class="mx-ep-bar"><i style="width:' . $pct . '%"></i></div>'
                . '<div class="mx-ep-num"><b>' . (int) $e['calls'] . '</b><i>次</i></div>'
                . '<div class="mx-ep-num"><b>' . ($e['avg_ms'] !== null ? (int) $e['avg_ms'] : '—') . '</b><i>ms</i></div>'
                . '<div class="mx-ep-num"><b>' . ($e['success'] !== null ? (int) $e['success'] : '—') . '</b><i>%</i></div>'
                . '</div>';
        }
        $h .= '</div>';

        if (!empty($m['devices'])) {
            $h .= '<div class="mx-sub">端分布</div><div class="mx-dev">';
            foreach ($m['devices'] as $d) {
                $h .= '<div><i>' . self::e($d['device_text']) . '</i><b data-mx-count="' . (int) $d['calls'] . '">'
                    . (int) $d['calls'] . '</b><em>次 · ' . ($d['avg_ms'] !== null ? (int) $d['avg_ms'] . ' ms' : '—')
                    . ' · 成功 ' . ($d['success'] !== null ? (int) $d['success'] . '%' : '—') . '</em></div>';
            }
            $h .= '</div>';
        }
        $h .= '<div class="mx-note">指标来自本站真实采样：页面首屏由前端 Performance API 上报，接口耗时由服务端记录。'
            . '健康分综合成功率、首屏耗时与慢接口数量计算。</div></div>';
        return $h;
    }

    private static function metricsChart($series, $points = array())
    {
        if (!$series) {
            return '';
        }
        $w = 700; $h = 188; $pl = 42; $pr = 44; $pt = 14; $pb = 26;
        $iw = $w - $pl - $pr; $ih = $h - $pt - $pb; $base = $pt + $ih;
        $n = count($series);
        $maxMs = 0; $maxCalls = 0;
        foreach ($series as $p) {
            if ($p['page_ms'] !== null) $maxMs = max($maxMs, (int) $p['page_ms']);
            $maxCalls = max($maxCalls, (int) $p['api_calls']);
        }
        $topMs = max(20, (int) (ceil($maxMs / 20) * 20));
        $topCalls = max(4, (int) (ceil($maxCalls / 4) * 4));
        $xAt = function ($i) use ($pl, $iw, $n) {
            return $n > 1 ? $pl + $iw * $i / ($n - 1) : $pl + $iw / 2;
        };
        $svg = '<svg viewBox="0 0 ' . $w . ' ' . $h . '" class="wx-chart" role="img" aria-label="页面性能折线图">';
        $svg .= '<defs><linearGradient id="wxLineArea" x1="0" y1="0" x2="0" y2="1">'
            . '<stop offset="0" stop-color="var(--yx-accent)" stop-opacity=".18"/>'
            . '<stop offset="1" stop-color="var(--yx-accent)" stop-opacity="0"/></linearGradient></defs>';
        for ($g = 0; $g <= 4; $g++) {
            $y = round($base - $ih * $g / 4, 1);
            $svg .= '<line x1="' . $pl . '" y1="' . $y . '" x2="' . ($w - $pr) . '" y2="' . $y
                . '" stroke="currentColor" stroke-opacity="' . ($g === 0 ? '.24' : '.10') . '"'
                . ($g === 0 ? '' : ' stroke-dasharray="3 5"') . '/>';
            $svg .= '<text x="' . ($pl - 8) . '" y="' . round($y + 3.5, 1)
                . '" text-anchor="end" font-size="9.5" fill="currentColor" opacity=".55">'
                . (int) round($topMs * $g / 4) . '</text>';
            $svg .= '<text x="' . ($w - $pr + 8) . '" y="' . round($y + 3.5, 1)
                . '" text-anchor="start" font-size="9.5" fill="currentColor" opacity=".45">'
                . (int) round($topCalls * $g / 4) . '</text>';
        }
        $step = max(1, (int) ceil($n / 7));
        $primary = array(); $secondary = array(); $callsDots = '';
        foreach ($series as $i => $p) {
            $x = round($xAt($i), 1);
            $ms = $p['page_ms'] !== null ? (int) $p['page_ms'] : null;
            $calls = (int) $p['api_calls'];
            if ($ms !== null) {
                $primary[] = array('x' => $x, 'y' => round($base - $ih * min(1, $ms / $topMs), 1),
                    'ms' => $ms, 'label' => (string) $p['label'], 'calls' => $calls,
                    'rate' => $p['api_success'] !== null ? (int) $p['api_success'] : null);
            }
            $cy = round($base - $ih * min(1, $calls / $topCalls), 1);
            $secondary[] = $x . ',' . $cy;
            if ($calls > 0) {
                $callsDots .= '<circle cx="' . $x . '" cy="' . $cy . '" r="2" fill="currentColor" opacity=".5"><title>'
                    . self::e($p['label']) . ' · 接口调用 ' . $calls . ' 次</title></circle>';
            }
            if ($i % $step === 0 || $i === $n - 1) {
                $svg .= '<text x="' . $x . '" y="' . ($h - 7)
                    . '" text-anchor="middle" font-size="9.5" fill="currentColor" opacity=".5">'
                    . self::e($p['label']) . '</text>';
            }
        }
        $svg .= '<polyline points="' . implode(' ', $secondary)
            . '" fill="none" stroke="currentColor" stroke-opacity=".42" stroke-width="1.5"'
            . ' stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>';
        if (count($primary) > 1) {
            $area = 'M ' . $primary[0]['x'] . ' ' . $base;
            $line = array();
            foreach ($primary as $q) {
                $area .= ' L ' . $q['x'] . ' ' . $q['y'];
                $line[] = $q['x'] . ',' . $q['y'];
            }
            $area .= ' L ' . $primary[count($primary) - 1]['x'] . ' ' . $base . ' Z';
            $svg .= '<path d="' . $area . '" fill="url(#wxLineArea)"/>';
            $svg .= '<polyline points="' . implode(' ', $line)
                . '" fill="none" stroke="var(--yx-accent)" stroke-width="2.2"'
                . ' stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>';
        } elseif (count($primary) === 1) {
            $q = $primary[0];
            $svg .= '<line x1="' . $pl . '" y1="' . $q['y'] . '" x2="' . $q['x'] . '" y2="' . $q['y']
                . '" stroke="var(--yx-accent)" stroke-opacity=".45" stroke-width="1.4"'
                . ' stroke-dasharray="5 5" vector-effect="non-scaling-stroke"/>';
        }
        $svg .= $callsDots;
        foreach ($primary as $q) {
            $tip = $q['label'] . ' · 首屏 ' . $q['ms'] . ' ms · 接口 ' . $q['calls'] . ' 次'
                . ($q['rate'] !== null ? ' · 成功率 ' . $q['rate'] . '%' : '');
            $svg .= '<circle cx="' . $q['x'] . '" cy="' . $q['y'] . '" r="3.2" fill="var(--yx-surface)"'
                . ' stroke="var(--yx-accent)" stroke-width="1.8" vector-effect="non-scaling-stroke"><title>'
                . self::e($tip) . '</title></circle>';
        }
        if ($primary) {
            $last = $primary[count($primary) - 1];
            $svg .= '<text x="' . ($last['x'] - 7) . '" y="' . ($last['y'] - 9)
                . '" text-anchor="end" font-size="10" font-weight="600" fill="var(--yx-accent)">'
                . $last['ms'] . ' ms</text>';
        } else {
            $svg .= '<text x="' . ($w / 2) . '" y="' . ($h / 2)
                . '" text-anchor="middle" font-size="11" fill="currentColor" opacity=".5">暂无样本</text>';
        }
        $slot = $iw / max(1, $n);
        foreach ($series as $i => $p) {
            $x = $xAt($i);
            $svg .= '<rect class="mx-hit" data-mx-i="' . $i . '" x="' . round($x - $slot / 2, 1)
                . '" y="' . $pt . '" width="' . round($slot, 1) . '" height="' . $ih
                . '" fill="transparent"/>';
        }
        $svg .= '</svg><div class="wx-chart-lg"><span><i class="a"></i>页面首屏耗时 (ms)</span>'
            . '<span><i class="b"></i>接口调用量 (次)</span><span>悬停曲线查看每日明细</span></div>';
        return $svg;
    }

    private static function renderFestivals($s)
    {
        $f = $s['festivals'];
        if (!is_array($f) || empty($f['list'])) {
            return '<div class="wx-none">本月暂无节日 / 节气</div>';
        }
        $h = '<div class="wx-fest-list">';
        foreach ($f['list'] as $it) {
            $h .= '<span class="wx-fest ' . self::e($it['type']) . '"><b>' . self::e($it['name']) . '</b><i>'
                . self::e(substr($it['date'], 5)) . '</i></span>';
        }
        $h .= '</div>';
        return $h;
    }

    public static function dayFestivals($fest, $day)
    {
        if (empty($fest['days'][$day])) {
            return array('cls' => '', 'tip' => '', 'label' => '');
        }
        $names = array();
        foreach ($fest['days'][$day] as $it) {
            $names[] = $it['name'];
        }
        return array('cls' => ' wx-fest-day', 'tip' => ' · ' . implode('、', $names), 'label' => $names[0]);
    }
}
