<?php

namespace YxWeather\Desktop;

use YxWeather\Bootstrap;
use YxWeather\AccountLocation;
use YxWeather\Metrics;

class Endpoint
{

    private static $actions = array(
        'snapshot', 'refresh', 'locate', 'weather', 'typhoon',
        'traffic', 'trends', 'festivals'
    );

    private static $parts = array(
        'snapshot' => array('weather', 'location', 'warnings', 'forecast', 'life', 'typhoon', 'traffic', 'trends', 'calendar'),
        'refresh' => array('weather', 'location', 'warnings', 'forecast', 'life', 'typhoon', 'traffic', 'trends'),
        'locate' => array('weather', 'location', 'warnings', 'forecast', 'life'),
        'weather' => array('weather', 'location', 'warnings', 'forecast', 'life'),
        'typhoon' => array('typhoon'),
        'traffic' => array('traffic'),
        'trends' => array('trends'),
        'festivals' => array('calendar')
    );

    public static function dispatch()
    {
        $action = Bootstrap::action();
        if ($action === '') {
            $action = 'snapshot';
        }
        if (!in_array($action, self::$actions, true)) {
            Bootstrap::err('电脑端接口不支持该操作', 404);
        }
        $write = ($action === 'locate');
        Bootstrap::guard($write);
        $uid = Bootstrap::uid();
        $t0 = microtime(true);
        $ok = true;

        try {
            if ($action === 'locate') {
                $res = self::locate($uid);
                $ok = !empty($res['status']);
            } else {
                $parts = self::$parts[$action];
                $render = Controller::render($uid, $parts);
                $res = array(
                    'status' => true,
                    'html' => $render,
                    'end' => Controller::END,
                    'policy' => Controller::POLICY,
                    'location_strategy' => '按当前登录设备 IP 自动定位并随 IP 变化同步',
                    'weather_ttl' => Controller::WEATHER_TTL,
                    'refresh_ms' => Controller::REFRESH_MS,
                    'server_time' => date('Y-m-d H:i:s'),
                    'account_uid' => $uid,
                    'note' => '定位、天气与交通按当前登录设备 IP 自动同步。'
                );
            }
        } catch (\Throwable $e) {
            $ok = false;
            $res = array('status' => false, 'message' => '电脑端接口异常：' . $e->getMessage());
        }

        Metrics::record('desktop', 'api', $action, (microtime(true) - $t0) * 1000, $ok);
        Bootstrap::out($res);
    }

    private static function locate($uid)
    {
        $stage = isset($_REQUEST['stage']) ? (string) $_REQUEST['stage'] : 'gps';
        if (!in_array($stage, array('gps', 'ip', 'manual', 'city'), true)) {
            $stage = 'gps';
        }
        $in = array('stage' => $stage);
        $city = isset($_REQUEST['city']) ? trim((string) $_REQUEST['city']) : '';

        if ($city !== '') {
            $g = AccountLocation::geocodeCity($city);
            if (empty($g['ok'])) {
                return array('status' => false, 'message' => $g['message'] ?? '城市定位失败');
            }
            $in['lat'] = $g['lat'];
            $in['lon'] = $g['lon'];
            $in['city'] = $g['city'];
            $in['province'] = $g['province'];
            $in['source'] = $g['source'];
            $in['stage'] = 'city';
            $in['accuracy'] = 1000;
        } else {
            $lat = isset($_REQUEST['lat']) ? $_REQUEST['lat'] : null;
            $lon = isset($_REQUEST['lon']) ? $_REQUEST['lon'] : null;
            if (!is_numeric($lat) || !is_numeric($lon)) {

                $ip = AccountLocation::ipCoarse(AccountLocation::clientIp());
                if (empty($ip['ok'])) {
                    return array('status' => false, 'message' => '无法获取坐标，请手动输入城市或经纬度');
                }
                $in['lat'] = $ip['lat'];
                $in['lon'] = $ip['lon'];
                $in['province'] = $ip['province'];
                $in['city'] = $ip['city'];
                $in['district'] = $ip['district'];
                $in['source'] = $ip['source'];
                $in['stage'] = 'ip';
                $in['accuracy'] = 5000;
            } else {
                $in['lat'] = $lat;
                $in['lon'] = $lon;
                $in['accuracy'] = isset($_REQUEST['accuracy']) && is_numeric($_REQUEST['accuracy'])
                    ? $_REQUEST['accuracy'] : ($stage === 'manual' ? 30 : 50);
                $in['source'] = isset($_REQUEST['source']) ? (string) $_REQUEST['source']
                    : ($stage === 'manual' ? '用户手动校准' : '浏览器高精度定位');
            }
        }

        $in['ip_check'] = AccountLocation::clientIp();

        $loc = AccountLocation::save($uid, $in);
        if (empty($loc['lat'])) {
            return array('status' => false, 'message' => $loc['message'] ?? '位置保存失败');
        }
        $render = Controller::render($uid, self::$parts['locate']);
        return array(
            'status' => true,
            'html' => $render,
            'location' => $loc,
            'ip_crosscheck' => AccountLocation::clientIp(),
            'end' => Controller::END,
            'server_time' => date('Y-m-d H:i:s'),
            'note' => '位置已写入统一账号服务，电脑端与手机端下一次刷新都会读到同一份坐标。'
        );
    }
}
