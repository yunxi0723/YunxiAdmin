<?php

namespace YxWeather\Mobile;

use YxWeather\Bootstrap;
use YxWeather\AccountLocation;
use YxWeather\Metrics;

class Endpoint
{
    private static $actions = array(
        'snapshot', 'refresh', 'locate', 'weather', 'typhoon',
        'traffic', 'trends', 'festivals'
    );

    private static $parts = array(
        'snapshot' => array('weather', 'location', 'warnings', 'forecast', 'life', 'typhoon', 'traffic', 'trends'),
        'refresh' => array('weather', 'location', 'warnings', 'forecast', 'life', 'typhoon', 'traffic', 'trends'),
        'locate' => array('weather', 'location', 'warnings', 'forecast', 'life'),
        'weather' => array('weather', 'location', 'warnings', 'forecast', 'life'),
        'typhoon' => array('typhoon'),
        'traffic' => array('traffic'),
        'trends' => array('trends'),
        'festivals' => array('calendar')
    );

    public static function dispatch()
    {
        $action = Bootstrap::action();
        if ($action === '') {
            $action = 'snapshot';
        }
        if (!in_array($action, self::$actions, true)) {
            Bootstrap::err('手机端接口不支持该操作', 404);
        }
        Bootstrap::guard($action === 'locate');
        $uid = Bootstrap::uid();
        $t0 = microtime(true);
        $ok = true;
        try {
            if ($action === 'locate') {
                $res = self::locate($uid);
                $ok = !empty($res['status']);
            } else {

                $parts = self::$parts[$action];
                $render = Controller::render($uid, $parts);
                $res = array(
                    'status' => true,
                    'html' => $render,
                    'end' => Controller::END,
                    'policy' => Controller::POLICY,
                    'location_strategy' => '按当前登录设备 IP 自动定位并随 IP 变化同步',
                    'weather_ttl' => Controller::WEATHER_TTL,
                    'refresh_ms' => Controller::REFRESH_MS,
                    'server_time' => date('Y-m-d H:i:s'),
                    'account_uid' => $uid,
                    'note' => '定位、天气与交通按当前登录设备 IP 自动同步。'
                );
            }
        } catch (\Throwable $e) {
            $ok = false;
            $res = array('status' => false, 'message' => '手机端接口异常：' . $e->getMessage());
        }
        Metrics::record('mobile', 'api', $action, (microtime(true) - $t0) * 1000, $ok);
        Bootstrap::out($res);
    }

    private static function locate($uid)
    {
        $stage = isset($_REQUEST['stage']) ? (string) $_REQUEST['stage'] : 'gps';
        if (!in_array($stage, array('gps', 'ip', 'manual', 'city'), true)) {
            $stage = 'gps';
        }
        $in = array('stage' => $stage);
        $city = isset($_REQUEST['city']) ? trim((string) $_REQUEST['city']) : '';
        if ($city !== '') {
            $g = AccountLocation::geocodeCity($city);
            if (empty($g['ok'])) {
                return array('status' => false, 'message' => $g['message'] ?? '城市定位失败');
            }
            $in = array_merge($in, array('lat' => $g['lat'], 'lon' => $g['lon'], 'city' => $g['city'],
                'province' => $g['province'], 'source' => $g['source'], 'stage' => 'city', 'accuracy' => 1000));
        } elseif (isset($_REQUEST['lat'], $_REQUEST['lon']) && is_numeric($_REQUEST['lat']) && is_numeric($_REQUEST['lon'])) {
            $in['lat'] = $_REQUEST['lat'];
            $in['lon'] = $_REQUEST['lon'];
            $in['accuracy'] = isset($_REQUEST['accuracy']) && is_numeric($_REQUEST['accuracy'])
                ? $_REQUEST['accuracy'] : ($stage === 'manual' ? 30 : 50);
            $in['source'] = isset($_REQUEST['source']) ? (string) $_REQUEST['source']
                : ($stage === 'manual' ? '用户手动校准' : '浏览器 GPS 高精度定位');
        } else {
            $ip = AccountLocation::ipCoarse(AccountLocation::clientIp());
            if (empty($ip['ok'])) {
                return array('status' => false, 'message' => 'GPS 与 IP 定位均不可用，请手动输入城市');
            }
            $in = array_merge($in, array('lat' => $ip['lat'], 'lon' => $ip['lon'], 'province' => $ip['province'],
                'city' => $ip['city'], 'district' => $ip['district'], 'source' => $ip['source'],
                'stage' => 'ip', 'accuracy' => 5000));
        }

        $in['ip_check'] = AccountLocation::clientIp();

        $loc = AccountLocation::save($uid, $in);
        if (empty($loc['lat'])) {
            return array('status' => false, 'message' => $loc['message'] ?? '位置保存失败');
        }
        $render = Controller::render($uid, self::$parts['locate']);
        return array(
            'status' => true,
            'html' => $render,
            'location' => $loc,
            'ip_crosscheck' => AccountLocation::clientIp(),
            'end' => Controller::END,
            'server_time' => date('Y-m-d H:i:s')
        );
    }
}
