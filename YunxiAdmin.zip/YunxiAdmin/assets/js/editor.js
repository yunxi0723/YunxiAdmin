(function () {
    'use strict';

    var ta = null;
    var wrap = null;
    var hlCode = null;
    var preview = null;
    var bar = null;
    var countEl = null;
    var saveEl = null;
    var draftTimer = null;
    var previewTimer = null;
    var previewOn = false;
    var findBox = null;
    var palette = null;
    var palList = null;
    var palInput = null;
    var palIdx = 0;
    var hlTimer = null;
    var phMap = {};
    var phN = 0;
    var helpBox = null;

    function esc(v) {
        return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function svg(p) {
        return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="' + p + '"/></svg>';
    }

    var P = {
        undo: 'M9 14 4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3',
        redo: 'M15 14l5-5-5-5M20 9H10a6 6 0 0 0 0 12h3',
        code: 'M9 8 5 12l4 4M15 8l4 4-4 4',
        codeblock: 'M8 6 4 12l4 6M16 6l4 6-4 6',
        quote: 'M6 17c0-4.5 2-7.5 5.5-9M13.5 17c0-4.5 2-7.5 5.5-9M6.5 17h4M14 17h4',
        ul: 'M9.5 6H20M9.5 12H20M9.5 18H20M4.5 6h.01M4.5 12h.01M4.5 18h.01',
        link: 'M10.5 13.5a4.2 4.2 0 0 0 6 0l2.5-2.5a4.24 4.24 0 0 0-6-6L11.5 6.5M13.5 10.5a4.2 4.2 0 0 0-6 0L5 13a4.24 4.24 0 0 0 6 6l1.5-1.5',
        img: 'M4 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zM4 16l4.5-4.5 3 3 2.5-2.5L19 17M8.8 9.2h.01',
        imgurl: 'M4 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5M4 16l4.5-4.5 3 3 2.5-2.5L19 17M8.8 9.2h.01M13.6 17.6a2 2 0 0 0 2.8 0l3-3a2 2 0 0 0-2.8-2.8l-.6.6M16.4 12.4a2 2 0 0 0-2.8 0l-3 3a2 2 0 0 0 2.8 2.8l.6-.6',
        video: 'M4 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zM10 9.2l5.5 2.8-5.5 2.8z',
        hr: 'M4 12h16',
        more: 'M5.5 12h.01M12 12h.01M18.5 12h.01',
        up: 'M12 15V4M7.5 8.5 12 4l4.5 4.5M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3',
        save: 'M5 4h11l3 3v13H5zM8 4v6h7V4M8 20v-6h8v6',
        table: 'M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zM4 10h16M4 15h16M10 10v9M16 10v9',
        find: 'M11 17a6 6 0 1 0 0-12 6 6 0 0 0 0 12zM20 20l-4.8-4.8',
        full: 'M4 9V5.5A1.5 1.5 0 0 1 5.5 4H9M15 4h3.5A1.5 1.5 0 0 1 20 5.5V9M20 15v3.5a1.5 1.5 0 0 1-1.5 1.5H15M9 20H5.5A1.5 1.5 0 0 1 4 18.5V15',
        eye: 'M2.8 12S6.2 5.8 12 5.8 21.2 12 21.2 12 17.8 18.2 12 18.2 2.8 12 2.8 12zM12 14.6a2.6 2.6 0 1 0 0-5.2 2.6 2.6 0 0 0 0 5.2z',
        task: 'M4.5 6.5 7 9l3.5-4M4.5 17.5 7 20l3.5-4M13 7.5H20M13 18.5H20',
        audio: 'M4 12a8 8 0 1 0 16 0 8 8 0 0 0-16 0M4 12v2.5a3 3 0 0 0 3 3h1.5M16.5 9.5v5',
        file: 'M14 3v5h5M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z',
        help: 'M12 17h.01M9.2 9a3 3 0 1 1 4 2.8c-.8.4-1.2 1-1.2 1.8v.4M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z',
        del: 'M5 7l14 10M19 7 5 17',
        cleartxt: 'M4 20h16M9 15l-3-3a2 2 0 0 1 0-2.8l4-4a2 2 0 0 1 2.8 0l4 4a2 2 0 0 1 0 2.8l-3 3M8 20l5-5',
        sub: 'M5 5h6M8 5v9a3 3 0 1 1-3-3M13 10l4 5M17 10l-4 5',
        sup: 'M5 8h6M8 8v7a3 3 0 1 1-3-3M13 11l4 4M17 11l-4 4',
        align: 'M4 6h16M4 10h10M4 14h16M4 18h7',
        center: 'M4 6h16M7 10h10M6 14h12M9 18h6',
        right: 'M4 6h16M10 10h10M8 14h12M13 18h7',
        color: 'M12 3a9 9 0 1 0 0 18 2.2 2.2 0 0 0 2.2-2.2c0-.6-.2-1.1-.6-1.5a2.1 2.1 0 0 1 1.6-3.5H16a5 5 0 0 0 5-5c0-3.2-4-5.8-9-5.8zM7.5 11.5h.01M10.5 7.5h.01M14.5 7.5h.01',
        mark: 'M4 20h16M6.5 16l4.5-9 4.5 9M7.8 13.2h6.4',
        small: 'M4 7h9M4 12h16M4 17h12',
        big: 'M3 6h9M3 18h9M7.5 6v12M14 8.5a3 3 0 1 1 0 5 3 3 0 0 1 0-5zM17 13.5v5M14.5 16h5',
        indent: 'M4 6h10M4 12h7M4 18h10M17 10l3 2-3 2z',
        outdent: 'M4 6h10M4 12h7M4 18h10M20 10l-3 2 3 2z',
        checklist: 'M4 6h3M4 12h3M4 18h3M10 6h10M10 12h10M10 18h10M15 10l2 2 4-4',
        code2: 'M8 4h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM10 9l-2 3 2 3M14 9l2 3-2 3',
        swap: 'M7 7h11l-3-3M17 17H6l3 3',
        em: 'M6 4h12M6 20h12M14 4l-4 16',
        indent2: 'M4 6h16M4 10h10M4 14h16M4 18h10',
        scrolltop: 'M12 19V5M6 11l6-6 6 6',
        copy: 'M9 9h10a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1V10a1 1 0 0 1 1-1zM5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1',
        paste: 'M9 4h6v3H9zM8 5H6a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-2',
        date: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4',
        tag: 'M4 4h7l9 9-7 7-9-9zM8.5 8.5h.01',
        star: 'M12 3.5l2.6 5.3 5.9.9-4.2 4.1 1 5.8-5.3-2.8-5.3 2.8 1-5.8-4.2-4.1 5.9-.9z',
        book: 'M4 5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2zM19 3v18',
        grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
        refresh: 'M20 11A8 8 0 0 0 6.3 6.3L4 8.5M4 4v4.5h4.5M4 13a8 8 0 0 0 13.7 4.7L20 15.5M20 20v-4.5h-4.5',
        keyboard: 'M3 7h18v10H3zM7 11h.01M11 11h.01M15 11h.01M7 14h6',
        arrowup: 'M12 19V5M6 11l6-6 6 6',
        arrowdown: 'M12 5v14M6 13l6 6 6-6',
        toc: 'M4 6h6M4 12h6M4 18h6M14 6h6M14 12h6M14 18h6',
        note: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 8h.01M11 12h1v4h1',
        space: 'M4 8h16M4 16h16M9 12h6'
    };


    var DESC = {
        undo: '撤销上一步编辑，可连续撤销多次。快捷键 Ctrl/⌘ + Z。',
        redo: '重做被撤销的操作。快捷键 Ctrl/⌘ + Y。',
        h1: '把当前行设为一级标题，是文章的主标题结构。再次点击可取消。',
        h2: '把当前行设为二级标题，用于划分主要章节。再次点击可取消。',
        h3: '把当前行设为三级标题，用于更细的内容分层。再次点击可取消。',
        bold: '把选中文字加粗，或取消加粗。快捷键 Ctrl/⌘ + B。',
        italic: '把选中文字设为斜体，或取消斜体。快捷键 Ctrl/⌘ + I。',
        strike: '给选中文字加删除线，表示已废弃或不再适用的内容。',
        icode: '把选中内容包成行内代码，渲染为等宽字体的小代码片段。快捷键 Ctrl/⌘ + `。',
        cblock: '插入一个带语法高亮的代码块，适合贴代码片段，可指定语言。',
        quote: '把当前行变成引用块，用于引述他人观点或强调一段话。再次点击取消。',
        ul: '插入无序列表（项目符号），适合并列要点。再次点击可取消。',
        ol: '插入有序列表（自动编号），适合有先后顺序的步骤。再次点击可取消。',
        task: '插入任务列表（可勾选的复选框），适合待办清单与进度跟踪。',
        link: '插入超链接。可先选中文字再点击，或直接输入网址，自动补全 https://。快捷键 Ctrl/⌘ + K。',
        image: '打开本地媒体库挑选图片 / 视频 / 文件插入正文。快捷键 Ctrl/⌘ + G。',
        imgurl: '通过图片链接插入图片：粘贴 https:// 外链或站内 /usr/uploads/ 路径，可同时填写图片说明（alt）。',
        video: '插入视频：粘贴 mp4/webm 直链生成播放器，或粘贴 B站 / YouTube / Vimeo 网址自动嵌入播放器。',
        audio: '插入音频播放器，支持 https:// 外链或本站本地文件（如 /usr/uploads/…/xx.mp3）。',
        file: '插入附件下载链接，地址支持本站本地文件（如 /usr/uploads/…/xx.pdf）。',
        upload: '从电脑本地选择文件并上传到本站 usr/uploads，再自动插入正文。不使用任何外部图床。',
        table: '插入一个三列表格，可直接在正文中继续编辑行列。',
        hr: '插入一条水平分割线，用于划分段落层次。',
        more: '插入摘要分割线 <!--more-->，此处之后的内容在首页列表中不显示。',
        find: '全文查找与替换，支持正则表达式与区分大小写。快捷键 Ctrl/⌘ + F。',
        help: '打开完整的插入功能与快捷键对照表。',
        palette: '打开命令面板，输入关键字即可执行任意插入功能。快捷键 Ctrl/⌘ + Shift + A。',
        full: '进入 / 退出全屏编辑，专注写作，按 Esc 退出。',
        preview: '实时预览正文最终渲染效果。快捷键 Ctrl/⌘ + Shift + P。',
        sub: '插入下标文字，用于化学式、注脚编号等场景。',
        sup: '插入上标文字，用于序号、指数、注释标记等场景。',
        alignl: '把选中内容左对齐（部分主题支持）。',
        alignc: '把选中内容居中对齐，用于标题与配图。',
        alignr: '把选中内容右对齐，用于落款与时间标注。',
        color: '为选中文字插入强调色标记，突出重点内容。',
        mark: '为选中文字插入高亮标记，模拟荧光笔效果。',
        small: '把选中文字设为小字号，用于补充说明与脚注。',
        big: '把选中文字设为大字号，用于醒目的提示语。',
        indent: '增加选中行的缩进层级，用于嵌套列表。',
        outdent: '减少选中行的缩进层级，用于还原嵌套列表。',
        checklist: '插入一份可勾选的总览清单，适合发布待办或注意事项。',
        code2: '插入用于标记版权与备注的说明区块。',
        swap: '在选中的两段内容之间交换位置，快速调整语序。',
        em: '把选中文字设为强调体，用于重点词句。',
        date: '插入当前日期与时间，方便标记更新时间。',
        tag: '插入标签占位符，可配合主题的标签云使用。',
        star: '插入一个星号符号，用于强调或分隔条目。',
        book: '插入书籍 / 阅读标记，适合长文目录与参考文献。',
        grid: '插入网格布局占位，适合展示图文卡片。',
        refresh: '重新计算字数统计与阅读时长，刷新编辑区状态。',
        keyboard: '查看当前可用的全部快捷键。',
        cleartxt: '清除选中文字的全部格式（加粗、斜体、颜色等），只保留文字本身。',
        toc: '在正文开头插入目录占位符，方便长文导航。',
        note: '插入一段提示说明块，用于文中的补充说明。',
        space: '在当前行下方插入一个空行，用于分隔内容。',
        delline: '删除当前所在的整行内容。',
        dup: '复制当前行并粘贴到下一行。快捷键 Ctrl/⌘ + Shift + D。',
        up: '把当前行上移一行。快捷键 Alt + ↑。',
        down: '把当前行下移一行。快捷键 Alt + ↓。'
    };

    function btn(label, path, title, actName, cls) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'yx-ed-btn' + (cls ? ' ' + cls : '');
        b.title = title;
        b.setAttribute('data-act', actName);

        var d = DESC[actName] || '';
        if (d) {
            b.setAttribute('data-desc', d);
        }
        b.innerHTML = (path ? svg(path) : '') + (label ? '<span>' + label + '</span>' : '');
        return b;
    }

    function sep() {
        var s = document.createElement('span');
        s.className = 'sep';
        return s;
    }

    function buildBar() {
        bar = document.createElement('div');
        bar.className = 'yx-ed-bar';
        bar.appendChild(btn('', P.undo, '撤销 Ctrl+Z', 'undo'));
        bar.appendChild(btn('', P.redo, '重做 Ctrl+Y', 'redo'));
        bar.appendChild(sep());
        bar.appendChild(btn('H1', '', '一级标题', 'h1'));
        bar.appendChild(btn('H2', '', '二级标题', 'h2'));
        bar.appendChild(btn('H3', '', '三级标题', 'h3'));
        bar.appendChild(sep());
        bar.appendChild(btn('B', '', '加粗 Ctrl+B', 'bold'));
        bar.appendChild(btn('I', '', '斜体 Ctrl+I', 'italic'));
        bar.appendChild(btn('S', '', '删除线', 'strike'));
        bar.appendChild(btn('', P.em, '强调', 'em'));
        bar.appendChild(btn('', P.color, '文字颜色', 'color'));
        bar.appendChild(btn('', P.mark, '高亮标记', 'mark'));
        bar.appendChild(btn('', P.small, '小字号', 'small'));
        bar.appendChild(btn('', P.big, '大字号', 'big'));
        bar.appendChild(btn('', P.sub, '下标', 'sub'));
        bar.appendChild(btn('', P.sup, '上标', 'sup'));
        bar.appendChild(btn('', P.code, '行内代码 Ctrl+`', 'icode'));
        bar.appendChild(btn('', P.codeblock, '代码块', 'cblock'));
        bar.appendChild(btn('', P.cleartxt, '清除格式', 'cleartxt'));
        bar.appendChild(sep());
        bar.appendChild(btn('', P.quote, '引用', 'quote'));
        bar.appendChild(btn('', P.ul, '无序列表', 'ul'));
        bar.appendChild(btn('1.', '', '有序列表', 'ol'));
        bar.appendChild(btn('', P.task, '任务列表', 'task'));
        bar.appendChild(btn('', P.checklist, '总览清单', 'checklist'));
        bar.appendChild(btn('', P.indent, '增加缩进', 'indent'));
        bar.appendChild(btn('', P.outdent, '减少缩进', 'outdent'));
        bar.appendChild(sep());
        bar.appendChild(btn('', P.align, '左对齐', 'alignl'));
        bar.appendChild(btn('', P.center, '居中对齐', 'alignc'));
        bar.appendChild(btn('', P.right, '右对齐', 'alignr'));
        bar.appendChild(sep());
        bar.appendChild(btn('', P.link, '插入超链接 Ctrl+K', 'link'));
        bar.appendChild(btn('', P.img, '本地媒体库 Ctrl+G', 'image'));
        bar.appendChild(btn('', P.imgurl, '插入图片（链接）', 'imgurl'));
        bar.appendChild(btn('', P.video, '插入视频（链接 / 嵌入）', 'video'));
        bar.appendChild(btn('', P.audio, '插入音频（链接）', 'audio'));
        bar.appendChild(btn('', P.file, '插入附件链接', 'file'));
        bar.appendChild(btn('', P.up, '从本地上传并插入', 'upload'));
        bar.appendChild(btn('', P.table, '表格', 'table'));
        bar.appendChild(btn('', P.grid, '网格布局', 'grid'));
        bar.appendChild(btn('', P.hr, '分割线', 'hr'));
        bar.appendChild(btn('', P.more, '摘要分割线 <!--more-->', 'more'));
        bar.appendChild(sep());
        bar.appendChild(btn('', P.date, '插入日期时间', 'date'));
        bar.appendChild(btn('', P.tag, '插入标签', 'tag'));
        bar.appendChild(btn('', P.book, '书籍 / 阅读标记', 'book'));
        bar.appendChild(btn('', P.toc, '插入目录', 'toc'));
        bar.appendChild(btn('', P.note, '插入说明块', 'note'));
        bar.appendChild(btn('', P.copy, '复制当前行', 'dup'));
        bar.appendChild(btn('', P.swap, '上下两段交换', 'swap'));
        bar.appendChild(btn('', P.del, '删除当前行', 'delline'));
        bar.appendChild(btn('', P.arrowup, '上移当前行', 'up'));
        bar.appendChild(btn('', P.arrowdown, '下移当前行', 'down'));
        bar.appendChild(btn('', P.space, '插入空行', 'space'));
        bar.appendChild(btn('', P.refresh, '刷新字数统计', 'refresh'));
        bar.appendChild(sep());
        bar.appendChild(btn('', P.find, '查找替换 Ctrl+F', 'find'));
        bar.appendChild(btn('', P.keyboard, '快捷键一览', 'help'));
        bar.appendChild(btn('⌘', '', '命令面板 Ctrl+Shift+A', 'palette'));
        var sp = document.createElement('span');
        sp.className = 'sp';
        bar.appendChild(sp);
        countEl = document.createElement('span');
        countEl.className = 'yx-ed-count';
        countEl.textContent = '0 字';
        bar.appendChild(countEl);

        saveEl = document.createElement('span');
        saveEl.className = 'yx-ed-save';
        saveEl.hidden = true;
        bar.appendChild(saveEl);
        bar.appendChild(btn('', P.full, '全屏编辑', 'full'));
        bar.appendChild(btn('', P.eye, '预览 Ctrl+Shift+P', 'preview'));
        return bar;
    }

    function buildFind() {
        findBox = document.createElement('div');
        findBox.className = 'yx-ed-find';
        findBox.innerHTML = '<input type="text" class="fi" placeholder="查找（勾选 .* 用正则）">'
            + '<input type="text" class="rp" placeholder="替换为">'
            + '<label class="tg"><input type="checkbox" class="re">.*</label>'
            + '<label class="tg"><input type="checkbox" class="cs">Aa</label>'
            + '<span class="cnt"></span>'
            + '<button type="button" class="yx-ed-btn prev">上一个</button>'
            + '<button type="button" class="yx-ed-btn next">下一个</button>'
            + '<button type="button" class="yx-ed-btn rep">替换</button>'
            + '<button type="button" class="yx-ed-btn repall">全部替换</button>'
            + '<button type="button" class="yx-ed-btn cls">×</button>';
        findBox.style.display = 'none';
        return findBox;
    }

    function buildPalette() {
        palette = document.createElement('div');
        palette.className = 'yx-ed-pal';
        palette.innerHTML = '<div class="yx-ed-pal-box"><input type="text" placeholder="输入命令，回车执行，Esc 关闭…"><div class="yx-ed-pal-list"></div></div>';
        palette.style.display = 'none';
        document.body.appendChild(palette);
        palInput = palette.querySelector('input');
        palList = palette.querySelector('.yx-ed-pal-list');
        palInput.addEventListener('input', function () {
            palIdx = 0;
            renderPal();
        });
        palInput.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                closePal();
            } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                palIdx = Math.min(palIdx + 1, visibleCmds().length - 1);
                renderPal();
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                palIdx = Math.max(palIdx - 1, 0);
                renderPal();
            } else if (e.key === 'Enter') {
                e.preventDefault();
                var cs = visibleCmds();
                var c = cs[palIdx] || cs[0];
                if (c) {
                    closePal();
                    if (typeof c.r === 'function') c.r();
                }
            }
        });
        palette.addEventListener('mousedown', function (e) {
            if (e.target === palette) {
                closePal();
            }
        });
    }

    var CMDS = [
        { n: '插入链接', k: 'Ctrl+K', r: function () { act('link'); } },
        { n: '插入图片 / 视频 / 文件', k: 'Ctrl+G', r: function () { act('image'); } },
        { n: '插入图片（链接）', r: function () { act('imgurl'); } },
        { n: '插入视频（链接 / 嵌入）', r: function () { act('video'); } },
        { n: '插入音频（链接）', r: function () { act('audio'); } },
        { n: '插入附件链接', r: function () { act('file'); } },
        { n: '从本地上传并插入', k: 'Ctrl+U', r: function () { act('upload'); } },
        { n: '一级标题 / 二级标题 / 三级标题', r: function () { act('h1'); } },
        { n: '插入表格', r: function () { act('table'); } },
        { n: '插入代码块', r: function () { act('cblock'); } },
        { n: '插入引用', r: function () { act('quote'); } },
        { n: '插入无序列表', r: function () { act('ul'); } },
        { n: '插入有序列表', r: function () { act('ol'); } },
        { n: '插入任务列表', r: function () { act('task'); } },
        { n: '插入摘要分割线', r: function () { act('more'); } },
        { n: '查找替换', k: 'Ctrl+F', r: function () { act('find'); } },
        { n: '快捷键与插入功能说明', r: function () { act('help'); } },
        { n: '跳转到行', r: gotoLine },
        { n: '复制当前行', k: 'Ctrl+Shift+D', r: function () { lineOp('dup'); } },
        { n: '上移行', k: 'Alt+↑', r: function () { lineOp('up'); } },
        { n: '下移行', k: 'Alt+↓', r: function () { lineOp('down'); } },
        { n: '删除行', k: 'Ctrl+Shift+K', r: function () { lineOp('del'); } },
        { n: '行升序排序', r: function () { lineOp('sortasc'); } },
        { n: '行降序排序', r: function () { lineOp('sortdesc'); } },
        { n: '合并选中行', r: function () { lineOp('join'); } },
        { n: '切换预览', k: 'Ctrl+Shift+P', r: function () { act('preview'); } },
        { n: '全屏编辑', r: function () { act('full'); } },
        { n: '强调文字', r: function () { act('em'); } },
        { n: '文字颜色', r: function () { act('color'); } },
        { n: '高亮标记', r: function () { act('mark'); } },
        { n: '小字号', r: function () { act('small'); } },
        { n: '大字号', r: function () { act('big'); } },
        { n: '下标', r: function () { act('sub'); } },
        { n: '上标', r: function () { act('sup'); } },
        { n: '清除格式', r: function () { act('cleartxt'); } },
        { n: '左对齐', r: function () { act('alignl'); } },
        { n: '居中对齐', r: function () { act('alignc'); } },
        { n: '右对齐', r: function () { act('alignr'); } },
        { n: '总览清单', r: function () { act('checklist'); } },
        { n: '增加缩进', r: function () { act('indent'); } },
        { n: '减少缩进', r: function () { act('outdent'); } },
        { n: '插入日期时间', r: function () { act('date'); } },
        { n: '插入标签', r: function () { act('tag'); } },
        { n: '书籍 / 阅读标记', r: function () { act('book'); } },
        { n: '插入目录', r: function () { act('toc'); } },
        { n: '插入说明块', r: function () { act('note'); } },
        { n: '网格布局', r: function () { act('grid'); } },
        { n: '上下两段交换', r: function () { act('swap'); } },
        { n: '刷新字数统计', r: function () { act('refresh'); } }
    ];

    function visibleCmds() {
        var q = palInput.value.trim().toLowerCase();
        if (!q) return CMDS;
        return CMDS.filter(function (c) {
            return c.n.toLowerCase().indexOf(q) > -1 || (c.k || '').toLowerCase().indexOf(q) > -1;
        });
    }

    function renderPal() {
        var cs = visibleCmds();
        palList.innerHTML = cs.map(function (c, i) {
            return '<button type="button" data-i="' + i + '"' + (i === palIdx ? ' class="on"' : '') + '><span>' + esc(c.n) + '</span><em>' + esc(c.k || '') + '</em></button>';
        }).join('') || '<div class="yx-ed-pal-empty">没有匹配的命令</div>';
        Array.prototype.slice.call(palList.querySelectorAll('button[data-i]')).forEach(function (b) {
            b.addEventListener('click', function () {
                var c = visibleCmds()[parseInt(b.getAttribute('data-i'), 10)];
                closePal();
                if (c && typeof c.r === 'function') c.r();
            });
        });
    }

    function openPal() {
        palette.style.display = '';
        palInput.value = '';
        palIdx = 0;
        renderPal();
        setTimeout(function () {
            palInput.focus();
        }, 30);
    }

    function closePal() {
        palette.style.display = 'none';
        if (ta) ta.focus();
    }

    function toast(msg) {
        var t = document.querySelector('.yx-ed-toast');
        if (!t) {
            t = document.createElement('div');
            t.className = 'yx-ed-toast';
            document.body.appendChild(t);
        }
        t.textContent = msg;
        t.classList.add('show');
        clearTimeout(t._tm);
        t._tm = setTimeout(function () {
            t.classList.remove('show');
        }, 2400);
    }





    var descCard = null;
    var descTimer = null;

    function ensureDescCard() {
        if (descCard) return descCard;
        descCard = document.createElement('div');
        descCard.className = 'yx-ed-desc';
        descCard.setAttribute('role', 'status');
        descCard.innerHTML = '<div class="hd"><span class="ic"></span><b class="tt"></b>'
            + '<button type="button" class="cls" aria-label="关闭">×</button></div>'
            + '<p class="bd"></p>';
        document.body.appendChild(descCard);
        descCard.querySelector('.cls').addEventListener('click', function (e) {
            e.stopPropagation();
            hideDesc();
        });
        return descCard;
    }

    function hideDesc() {
        if (descCard) descCard.classList.remove('on');
        if (descTimer) {
            clearTimeout(descTimer);
            descTimer = null;
        }
    }

    function showBtnDesc(b, sticky) {
        var txt = b.getAttribute('data-desc');
        if (!txt) {
            hideDesc();
            return;
        }

        var card = ensureDescCard();
        var label = b.getAttribute('title') || '';

        var short = label.replace(/\s*Ctrl[^ ]*$/, '').replace(/\s*⌘[^ ]*$/, '').trim();

        card.querySelector('.tt').textContent = short || '功能说明';
        card.querySelector('.bd').textContent = txt;

        var svgEl = b.querySelector('svg');
        card.querySelector('.ic').innerHTML = svgEl ? svgEl.outerHTML : '';


        var r = b.getBoundingClientRect();
        card.style.visibility = 'hidden';
        card.classList.add('on');
        var cw = card.offsetWidth;
        var ch = card.offsetHeight;

        var left = r.left + r.width / 2 - cw / 2;
        var top = r.bottom + 9;


        if (top + ch > window.innerHeight - 10) {
            top = r.top - ch - 9;
            card.classList.add('up');
        } else {
            card.classList.remove('up');
        }

        left = Math.max(10, Math.min(left, window.innerWidth - cw - 10));
        top = Math.max(10, top);

        card.style.left = Math.round(left) + 'px';
        card.style.top = Math.round(top) + 'px';
        card.style.visibility = '';

        if (descTimer) clearTimeout(descTimer);
        descTimer = null;
        if (!sticky) {
            descTimer = setTimeout(hideDesc, 3600);
        }
    }


    document.addEventListener('click', function (e) {
        if (!descCard || !descCard.classList.contains('on')) return;
        if (descCard.contains(e.target)) return;
        if (e.target.closest && e.target.closest('.yx-ed-bar')) return;
        hideDesc();
    }, true);

    function pad2(n) {
        return String(n).length < 2 ? '0' + n : String(n);
    }

    function draftKey() {
        var m = window.location.search.match(/[?&]cid=(\d+)/);
        var base = (window.location.pathname.split('/').pop() || 'post').replace(/\.php$/, '');
        return 'yx-draft-' + base + '-' + (m ? m[1] : 'new');
    }

    function readDraft() {
        var raw = null;
        try {
            raw = localStorage.getItem(draftKey());
        } catch (e) {
            return null;
        }
        if (!raw) return null;
        try {
            var d = JSON.parse(raw);
            return (d && typeof d.text === 'string' && d.text) ? d : null;
        } catch (e) {
            return null;
        }
    }

    function saveDraft() {
        try {
            var titleEl = document.getElementById('title') || document.querySelector('input[name="title"]');
            localStorage.setItem(draftKey(), JSON.stringify({
                text: ta.value,
                title: titleEl ? titleEl.value : '',
                at: Date.now()
            }));
        } catch (e) {
            return;
        }
        if (saveEl) {
            var d = new Date();
            saveEl.hidden = false;
            saveEl.textContent = '本地草稿 ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
            saveEl.title = '内容已自动保存到浏览器，误关页面也不会丢';
        }
    }

    function scheduleDraft() {
        clearTimeout(draftTimer);
        draftTimer = setTimeout(saveDraft, 1500);
    }

    function clearDraft() {
        try {
            localStorage.removeItem(draftKey());
            var alt = draftKey().replace(/-\d+$/, '-new');
            localStorage.removeItem(alt);
        } catch (e) {}
        if (saveEl) {
            saveEl.hidden = true;
            saveEl.textContent = '';
        }
    }

    function checkDraft(host) {
        var d = readDraft();
        if (!d || d.text === ta.value) return;

        var box = document.createElement('div');
        box.className = 'yx-ed-restore';
        var t = new Date(d.at || Date.now());
        box.innerHTML = '<span>发现 ' + pad2(t.getHours()) + ':' + pad2(t.getMinutes())
            + ' 自动保存的本地草稿（' + d.text.length + ' 字），当前正文与之不同</span>'
            + '<button type="button" class="yx-ed-btn primary rs">恢复草稿</button>'
            + '<button type="button" class="yx-ed-btn ig">忽略</button>';
        host.parentNode.insertBefore(box, host);

        box.querySelector('.rs').addEventListener('click', function () {
            ta.value = d.text;
            var titleEl = document.getElementById('title') || document.querySelector('input[name="title"]');
            if (titleEl && d.title && !titleEl.value) titleEl.value = d.title;
            count();
            syncHl();
            box.remove();
            toast('已恢复本地草稿');
        });
        box.querySelector('.ig').addEventListener('click', function () {
            box.remove();
        });
    }

    function lineRange() {
        var v = ta.value;
        var s = v.lastIndexOf('\n', ta.selectionStart - 1) + 1;
        var nl = v.indexOf('\n', ta.selectionEnd);
        var e = nl === -1 ? v.length : nl;
        return [s, e];
    }

    function swapBlock(r, text) {
        var v = ta.value;
        ta.value = v.slice(0, r[0]) + text + v.slice(r[1]);
        ta.setSelectionRange(r[0], r[0] + text.length);
    }

    function lineOp(op) {
        var v = ta.value;
        var r = lineRange();
        var block = v.slice(r[0], r[1]);
        var lines = block.split('\n');
        if (op === 'dup') {
            ta.value = v.slice(0, r[1]) + '\n' + block + v.slice(r[1]);
            ta.setSelectionRange(r[1] + 1, r[1] + 1 + block.length);
        } else if (op === 'del') {
            ta.value = v.slice(0, r[0]) + v.slice(Math.min(r[1] + 1, v.length));
            ta.setSelectionRange(r[0], r[0]);
        } else if (op === 'up') {
            if (r[0] === 0) return;
            var pv = v.lastIndexOf('\n', r[0] - 2) + 1;
            var prev = v.slice(pv, r[0] - 1);
            ta.value = v.slice(0, pv) + block + '\n' + prev + v.slice(r[1]);
            ta.setSelectionRange(r[0] - prev.length - 1, r[0] - 1 + block.length);
        } else if (op === 'down') {
            var nx = v.indexOf('\n', r[1] + 1);
            var ne = nx === -1 ? v.length : nx;
            var next = v.slice(r[1] + 1, ne);
            ta.value = v.slice(0, r[0]) + next + '\n' + block + v.slice(ne);
            ta.setSelectionRange(r[0] + next.length + 1, r[0] + next.length + 1 + block.length);
        } else if (op === 'sortasc' || op === 'sortdesc') {
            lines.sort(function (a, b) {
                return a.localeCompare(b, 'zh-Hans-CN');
            });
            if (op === 'sortdesc') lines.reverse();
            swapBlock(r, lines.join('\n'));
        } else if (op === 'join') {
            swapBlock(r, lines.join(' '));
        }
        ta.focus();
        syncHl();
        count();
    }

    function gotoLine() {
        askLine('跳转行数', '跳转到第几行？', '1', '输入行号', function (raw) {
            if (raw === null) return;
            var n = parseInt(raw, 10);
            if (!n || n < 1) return;
            var v = ta.value;
            var lines = v.split('\n');
            var i = Math.min(n, lines.length) - 1;
            var pos = 0;
            for (var k = 0; k < i; k++) pos += lines[k].length + 1;
            ta.focus();
            ta.setSelectionRange(pos, pos + lines[i].length);
            var lh = parseFloat(getComputedStyle(ta).lineHeight) || 22;
            ta.scrollTop = Math.max(0, i * lh - ta.clientHeight / 2);
            syncHl();
        });
    }

    function insert(text, selStart, selLen) {
        var v = ta.value;
        var s = ta.selectionStart;
        var e = ta.selectionEnd;
        ta.value = v.slice(0, s) + text + v.slice(e);
        var ns = selStart == null ? s + text.length : s + selStart;
        var nl = selLen == null ? 0 : selLen;
        ta.setSelectionRange(ns, ns + nl);
        ta.focus();
        syncHl();
        count();
    }

    function wrapSel(before, after, ph) {
        var s = ta.selectionStart;
        var e = ta.selectionEnd;
        var v = ta.value;
        var sel = v.slice(s, e);
        if (sel.slice(0, before.length) === before && sel.slice(-after.length) === after && sel.length >= before.length + after.length) {
            ta.value = v.slice(0, s) + sel.slice(before.length, sel.length - after.length) + v.slice(e);
            ta.setSelectionRange(s, e - before.length - after.length);
        } else if (sel) {
            ta.value = v.slice(0, s) + before + sel + after + v.slice(e);
            ta.setSelectionRange(s + before.length, s + before.length + sel.length);
        } else {
            var p = ph || '';
            ta.value = v.slice(0, s) + before + p + after + v.slice(e);
            ta.setSelectionRange(s + before.length, s + before.length + p.length);
        }
        ta.focus();
        syncHl();
        count();
    }

    function linePrefix(pre) {
        var v = ta.value;
        var r = lineRange();
        var block = v.slice(r[0], r[1]);
        var lines = block.split('\n');
        var all = lines.every(function (l) {
            return l.indexOf(pre) === 0;
        });
        var out = lines.map(function (l) {
            if (all && pre) return l.slice(pre.length);
            if (!pre) return l.replace(/^(\s*)(#{1,6}\s|[-*+]\s\[[ xX]\]\s|[-*+]\s|\d+\.\s|>\s)/, '$1');
            return pre + l.replace(/^(\s*)(#{1,6}\s|[-*+]\s\[[ xX]\]\s|[-*+]\s|\d+\.\s|>\s)/, '$1');
        }).join('\n');
        swapBlock(r, out);
        ta.focus();
        syncHl();
        count();
    }

    function block(text) {
        var s = ta.selectionStart;
        var v = ta.value;
        var needNl = s > 0 && v.charAt(s - 1) !== '\n';
        insert((needNl ? '\n' : '') + text);
    }

    function heading(n) {
        var r = lineRange();
        var line = ta.value.slice(r[0], r[1]);
        var stripped = line.replace(/^#{1,6}\s*/, '');
        swapBlock(r, new Array(n + 1).join('#') + ' ' + stripped);
        ta.focus();
        syncHl();
        count();
    }

    function attrEsc(v) {
        return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    
    var NO_DESC_ACT = {
        image: 1, imgurl: 1, upload: 1, link: 1, video: 1, audio: 1, file: 1,
        palette: 1, help: 1, find: 1, preview: 1
    };





    var askBox = null;

    function askClose(cancelled) {
        if (!askBox) return;
        askBox.style.display = 'none';
        document.body.classList.remove('yx-lock');
        var cb = askBox._cb;
        askBox._cb = null;
        if (cancelled && cb) cb(null);
    }

    function askShow(title, rows, cb) {
        if (!askBox) {
            askBox = document.createElement('div');
            askBox.className = 'yx-ed-ask';
            askBox.innerHTML = '<div class="yx-ed-ask-box" role="dialog" aria-modal="true">'
                + '<h4></h4><div class="rows"></div>'
                + '<div class="acts"><button type="button" class="yx-ed-btn cancel">取消</button>'
                + '<button type="button" class="yx-ed-btn ok primary">确定</button></div></div>';
            document.body.appendChild(askBox);
            askBox.addEventListener('click', function (e) {
                if (e.target === askBox) askClose(true);
            });
            askBox.querySelector('.cancel').addEventListener('click', function () { askClose(true); });
            askBox.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') {
                    e.preventDefault();
                    askClose(true);
                } else if (e.key === 'Enter') {
                    e.preventDefault();
                    askBox.querySelector('.ok').click();
                }
            });
        }
        askBox._cb = cb;
        askBox.querySelector('h4').textContent = title || '';
        askBox.querySelector('.rows').innerHTML = rows.map(function (r) {
            return '<label class="yx-ed-ask-row"><span>' + esc(r.label) + '</span>'
                + '<input type="text" value="' + attrEsc(r.value) + '"'
                + ' placeholder="' + attrEsc(r.ph) + '"></label>';
        }).join('');
        var inputs = askBox.querySelectorAll('.rows input');
        askBox.querySelector('.ok').onclick = function () {
            var vals = Array.prototype.slice.call(inputs).map(function (i) { return i.value; });
            askClose(false);
            if (cb) cb(vals);
        };
        askBox.style.display = '';
        setTimeout(function () {
            if (inputs.length) {
                inputs[0].focus();
                inputs[0].select();
            }
        }, 30);
    }

    
    function askLine(title, label, def, ph, cb) {
        askShow(title, [{ label: label, value: def, ph: ph }], function (vals) {
            if (vals === null) { cb(null); return; }
            cb(vals.length ? vals[0] : '');
        });
    }

    function normalizeUrl(u) {
        u = String(u || '').trim().replace(/["'<>\\\s]/g, '');
        if (!u) return '';
        if (/^(https?:)?\/\//i.test(u) || /^data:image\//i.test(u) || /^\//.test(u)) return u;
        if (/^mailto:/i.test(u)) return u;
        return 'https://' + u;
    }

    function isHttpUrl(u) {
        return /^(https?:)?\/\//i.test(u) || /^\//.test(u);
    }

    function doLink() {
        var s = ta.selectionStart;
        var e = ta.selectionEnd;
        var sel = ta.value.slice(s, e).trim();
        var selIsUrl = isHttpUrl(sel);
        if (selIsUrl) {
            askLine('插入超链接', '链接文字（留空则直接显示网址）', sel, '可留空', function (text) {
                if (text === null) return;
                insert('[' + String(text || sel).replace(/[\[\]]/g, '') + '](' + sel + ')');
            });
            return;
        }
        askShow('插入超链接', [
            { label: '链接地址（https:// 或站内 / 开头）', value: 'https://', ph: 'https://' },
            { label: '链接文字（可留空）', value: sel, ph: '留空则显示网址' }
        ], function (v) {
            if (!v) return;
            var url = normalizeUrl(v[0]);
            if (!url) {
                toast('链接地址不能为空');
                return;
            }
            var text = String(v[1] || '').trim() || sel || url;
            insert('[' + text.replace(/[\[\]]/g, '') + '](' + url + ')');
        });
    }

    function doImageUrl() {
        askShow('插入图片（链接）', [
            { label: '图片链接（https:// 外链，或站内 /usr/uploads/…）', value: 'https://', ph: 'https://example.com/a.png' },
            { label: '图片说明（用于 alt 与无障碍阅读，可留空）', value: '', ph: '可留空' }
        ], function (v) {
            if (!v) return;
            var url = normalizeUrl(v[0]);
            if (!url) {
                toast('图片链接不能为空');
                return;
            }
            if (!/^https?:\/\//i.test(url) && !/^\//.test(url) && !/^data:image\//i.test(url)) {
                toast('图片链接格式不正确，请检查后重试');
                return;
            }
            var alt = String(v[1] || '').replace(/[\[\]]/g, '').slice(0, 120);
            block('\n![' + alt + '](' + url + ')\n');
            toast('已插入图片链接');
        });
    }

    function parseVideoEmbed(url) {
        var u = String(url || '');
        var m;
        if (/bilibili\.com\/video\//i.test(u)) {
            m = u.match(/\/video\/BV([0-9A-Za-z]+)/i);
            if (m) return 'https://player.bilibili.com/player.html?bvid=BV' + m[1] + '&high_quality=1&danmaku=0';
            m = u.match(/\/video\/av(\d+)/i);
            if (m) return 'https://player.bilibili.com/player.html?aid=' + m[1] + '&high_quality=1&danmaku=0';
        }
        if (/(youtube\.com\/watch|youtu\.be\/|youtube\.com\/embed\/)/i.test(u)) {
            m = u.match(/(?:v=|youtu\.be\/|embed\/)([0-9A-Za-z_-]{6,})/);
            if (m) return 'https://www.youtube.com/embed/' + m[1];
        }
        if (/vimeo\.com\/(\d+)/i.test(u)) {
            m = u.match(/vimeo\.com\/(\d+)/i);
            if (m) return 'https://player.vimeo.com/video/' + m[1];
        }
        return '';
    }

    function isVideoUrl(u) {
        u = String(u || '');
        if (parseVideoEmbed(u)) return true;
        return /\.(mp4|webm|mov|m4v|ogv|ogg)([?#]|$)/i.test(u);
    }

    function videoMarkup(url) {
        var embed = parseVideoEmbed(url);
        if (embed) {
            return '<div style="position:relative;width:100%;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:10px;margin:12px 0">'
                + '<iframe src="' + embed + '" style="position:absolute;top:0;left:0;width:100%;height:100%;border:0" '
                + 'scrolling="no" frameborder="0" allowfullscreen="allowfullscreen" loading="lazy"></iframe></div>';
        }
        return '<video src="' + url + '" controls="controls" preload="metadata" playsinline></video>';
    }

    function doVideoLink() {
        askLine('插入视频',
            '视频链接：mp4/webm 直链，或 B站 / YouTube / Vimeo 播放页网址',
            'https://', 'https://', function (raw) {
                if (raw === null) return;
                var url = normalizeUrl(raw);
                if (!url) {
                    toast('视频链接不能为空');
                    return;
                }
                if (/\.(html?|php|aspx?|jsp)([?#]|$)/i.test(url)) {
                    toast('这不是视频地址：请粘贴 mp4/webm 直链或 B站 / YouTube / Vimeo 播放页');
                    return;
                }
                var embed = parseVideoEmbed(url);
                block('\n' + videoMarkup(url) + '\n');
                toast(embed ? '已嵌入视频播放器' : '已插入视频播放器');
            });
    }

    function doTable() {
        block('\n| 列一 | 列二 | 列三 |\n| --- | --- | --- |\n| 内容 | 内容 | 内容 |\n');
    }

    
    function doMedia(kind) {
        var s = ta.selectionStart;
        var e = ta.selectionEnd;
        var sel = ta.value.slice(s, e);
        var tips = {
            video: '视频地址（支持本站本地文件，如 /usr/uploads/2026/10/xx.mp4）：',
            audio: '音频地址（支持本站本地文件，如 /usr/uploads/2026/10/xx.mp3）：',
            file: '附件地址（支持本站本地文件，如 /usr/uploads/2026/10/xx.pdf）：'
        };
        askLine(kind === 'video' ? '插入视频' : (kind === 'audio' ? '插入音频' : '插入附件'),
            tips[kind] || '地址：', 'https://', 'https:// 或 /usr/uploads/…', function (raw) {
                if (raw === null) return;
                var url = normalizeUrl(raw).replace(/["'<>]/g, '');
                if (!url) {
                    toast('地址不能为空');
                    return;
                }
                var html;
                if (kind === 'video') {
                    html = '<video src="' + url + '" controls="controls" preload="metadata" playsinline></video>';
                } else if (kind === 'audio') {
                    html = '<audio src="' + url + '" controls="controls" preload="metadata"></audio>';
                } else {
                    var label = (sel || '').trim() || url.split('/').pop() || '附件';
                    html = '[' + label + '](' + url + ')';
                }
                block('\n' + html + '\n');
            });
    }

    
    var HELP_ROWS = [
        ['Ctrl/⌘ + B', '加粗 **文字**'],
        ['Ctrl/⌘ + I', '斜体 *文字*'],
        ['Ctrl/⌘ + K', '插入链接'],
        ['Ctrl/⌘ + G', '打开本地媒体库'],
        ['Ctrl/⌘ + U', '从本地上传并插入'],
        ['Ctrl/⌘ + F', '查找替换'],
        ['Ctrl/⌘ + Shift + A', '命令面板'],
        ['Ctrl/⌘ + Shift + P', '预览正文'],
        ['Ctrl/⌘ + Shift + D', '复制当前行'],
        ['Ctrl/⌘ + Shift + K', '删除当前行'],
        ['Alt + ↑ / ↓', '上移 / 下移当前行'],
        ['Ctrl/⌘ + `', '行内代码'],
        ['Esc', '退出全屏 / 关闭弹窗']
    ];

    var HELP_BLOCKS = [
        ['标题', 'H1 一级 / H2 二级 / H3 三级'],
        ['行内样式', '加粗 **文字** · 斜体 *文字* · 删除线 ~~文字~~ · 强调 · 彩色 · 高亮 · 行内代码 `code`'],
        ['字号与上下标', '小字号 <small> · 大字号 <big> · 下标 <sub> · 上标 <sup>'],
        ['块级样式', '代码块 ``` · 引用 > · 无序列表 - · 有序列表 1. · 任务列表 - [ ] · 总览清单'],
        ['缩进与对齐', '增加 / 减少缩进 · 左对齐 / 居中 / 右对齐 · 清除格式'],
        ['媒体插入', '图片 ![说明](地址) · 图片链接 · 视频 <video> 或 B站/YouTube/Vimeo 自动嵌入 · 音频 <audio> · 附件 [名称](地址)'],
        ['结构插入', '表格 · 网格布局 · 目录 · 说明块 · 引用标记 · 标签 · 日期时间 · 分割线 --- · 摘要分割线 <!--more-->'],
        ['行操作', '复制当前行 · 上移 / 下移 · 删除当前行 · 与下一行交换 · 插入空行'],
        ['本地资源', '图片 / 视频直接复制粘贴进编辑器即可自动上传到本站 usr/uploads，不使用外部图床'],
        ['外部链接', '图片 / 视频也可直接粘贴 https:// 链接插入；B站、YouTube、Vimeo 网址会自动转为内嵌播放器'],
        ['查看说明', '点击工具栏任意按钮，会在按钮下方弹出该功能的详细介绍']
    ];

    function buildHelp() {
        var box = document.createElement('div');
        box.className = 'yx-ed-help';
        box.innerHTML = '<div class="yx-ed-help-box" role="dialog" aria-modal="true">'
            + '<div class="hd"><b>插入功能与快捷键</b><span class="sp"></span>'
            + '<button type="button" class="cls" aria-label="关闭">×</button></div>'
            + '<div class="bd">'
            + HELP_BLOCKS.map(function (b) {
                return '<div class="row"><span class="k">' + esc(b[0]) + '</span><span class="v">' + esc(b[1]) + '</span></div>';
            }).join('')
            + '<div class="row keys"><span class="k">快捷键</span><span class="v">'
            + HELP_ROWS.map(function (r) {
                return '<em><kbd>' + esc(r[0]) + '</kbd>' + esc(r[1]) + '</em>';
            }).join('')
            + '</span></div>'
            + '</div></div>';
        document.body.appendChild(box);
        box.addEventListener('click', function (e) {
            if (e.target === box || e.target.classList.contains('cls')) box.style.display = 'none';
        });
        return box;
    }

    function toggleHelp() {
        if (!helpBox) helpBox = buildHelp();
        helpBox.style.display = helpBox.style.display === 'none' ? '' : 'none';
    }

    function mdItem(it) {
        if (it.video) {
            return '\n<video src="' + it.url + '" controls="controls" preload="metadata" playsinline></video>\n';
        }
        if (it.image) {
            return '\n![' + String(it.name || '').replace(/[\[\]]/g, '') + '](' + it.url + ')\n';
        }
        return '\n[' + (it.name || it.url) + '](' + it.url + ')\n';
    }

    function insertItem(it) {
        block(mdItem(it));
    }



    function apiFetch(url, opt) {
        opt = opt || {};
        var headers = opt.headers || {};
        headers['X-YX-Req'] = '1';
        return fetch(url, {
            method: opt.method || 'GET',
            credentials: 'same-origin',
            headers: headers,
            body: opt.body
        }).then(function (r) {
            return r.text().then(function (txt) {
                var d = null;
                try {
                    d = txt ? JSON.parse(txt) : null;
                } catch (e) {
                    d = null;
                }
                if (!r.ok || !d) {
                    var msg = (d && d.message) ? d.message
                        : ('请求失败（HTTP ' + r.status + '）'
                            + (txt ? '：' + String(txt).replace(/\s+/g, ' ').slice(0, 120) : ''));
                    var err = new Error(msg);
                    err.status = r.status;
                    throw err;
                }
                return d;
            });
        });
    }

    function openPicker(tab) {


        if (window.YXPicker && typeof window.YXPicker.open === 'function') {
            window.YXPicker.open({
                tab: tab || 'local',
                onPick: insertItem,
                onPickAll: function (list) {
                    block(list.map(mdItem).join(''));
                    toast('已插入 ' + list.length + ' 个文件');
                }
            });
            return;
        }
        openMiniPicker();
    }

    
    var miniPick = null;

    function miniState(html) {
        var st = miniPick && miniPick.querySelector('.st');
        if (st) {
            st.innerHTML = html || '';
            st.style.display = html ? '' : 'none';
        }
    }

    function closeMiniPicker() {
        if (miniPick) miniPick.style.display = 'none';
        document.body.classList.remove('yx-lock');
    }

    function openMiniPicker() {
        if (!miniPick) buildMiniPicker();
        miniPick.style.display = '';
        document.body.classList.add('yx-lock');
        miniLoad(1);
    }

    function buildMiniPicker() {
        miniPick = document.createElement('div');
        miniPick.className = 'yx-ed-pick';
        miniPick.innerHTML = '<div class="yx-ed-pick-box" role="dialog" aria-modal="true">'
            + '<div class="hd"><b>本地媒体库</b><span class="sp"></span>'
            + '<button type="button" class="yx-ed-btn up">上传图片 / 视频</button>'
            + '<button type="button" class="yx-ed-btn ghost cls" aria-label="关闭">×</button></div>'
            + '<input type="file" class="pickfile" multiple accept="image/*,video/*" hidden>'
            + '<div class="st" style="display:none"></div>'
            + '<div class="grid"></div>'
            + '<div class="ft"><span class="hint">点击任一文件即插入正文</span></div></div>';
        document.body.appendChild(miniPick);
        miniPick.addEventListener('click', function (e) {
            if (e.target === miniPick) closeMiniPicker();
        });
        miniPick.querySelector('.cls').addEventListener('click', closeMiniPicker);
        var pf = miniPick.querySelector('.pickfile');
        miniPick.querySelector('.up').addEventListener('click', function () {
            pf.click();
        });
        pf.addEventListener('change', function () {
            if (pf.files && pf.files.length) handleFiles(pf.files);
            pf.value = '';
        });
        document.addEventListener('keydown', function (e) {
            if (miniPick && miniPick.style.display !== 'none' && e.key === 'Escape') closeMiniPicker();
        });
    }

    function miniLoad(page) {
        var grid = miniPick.querySelector('.grid');
        miniState('<span>加载中…</span>');
        grid.innerHTML = '';
        var done = false;
        var timer = setTimeout(function () {
            if (!done) miniState('<b>加载超时</b><span>请关闭后重试</span>');
        }, 12000);
        apiFetch(window.YX_API + '?action=medias&page=' + page).then(function (d) {
            done = true;
            clearTimeout(timer);
            if (!d || !d.status) {
                miniState('<b>加载失败</b><span>' + esc((d && d.message) || '请刷新页面重试') + '</span>');
                return;
            }
            miniRender(d.items || []);
        }).catch(function (err) {
            done = true;
            clearTimeout(timer);
            miniState('<b>加载失败</b><span>' + esc((err && err.message) || '网络错误') + '</span>');
        });
    }

    function miniRender(list) {
        var grid = miniPick.querySelector('.grid');
        if (!list.length) {
            miniState('<b>这里还没有文件</b><span>点上方「上传图片 / 视频」即可</span>');
            return;
        }
        miniState('');
        grid.innerHTML = list.map(function (it, i) {
            var th;
            if (it.video) {
                th = '<span class="vx">视频</span>';
            } else if (it.image && it.thumb) {
                th = '<img src="' + attrEsc(it.thumb) + '" alt="" loading="lazy">';
            } else {
                th = '<span class="vx">文件</span>';
            }
            return '<div class="it" data-i="' + i + '"><button type="button" class="th">' + th + '</button>'
                + '<span class="nm">' + esc(it.name || '未命名') + '</span></div>';
        }).join('');
        miniPick._list = list;
        Array.prototype.slice.call(grid.querySelectorAll('.it')).forEach(function (box) {
            box.addEventListener('click', function () {
                var it = (miniPick._list || [])[parseInt(box.getAttribute('data-i'), 10)];
                if (!it) return;
                insertItem(it);
                closeMiniPicker();
                toast('已插入 ' + (it.name || '文件'));
            });
        });
    }

    function isVideoFile(f) {
        return /^video\//.test(f.type) || /\.(mp4|webm|mov|m4v|ogg|ogv)$/i.test(f.name || '');
    }

    function uploadFile(file, cb) {
        if (!window.YX_API) {
            toast('接口地址未就绪，请刷新页面后重试');
            return;
        }
        var fd = new FormData();
        fd.append('file', file);
        toast('正在上传 ' + file.name + ' …');
        apiFetch(window.YX_API + '?action=upload', {
            method: 'POST',
            body: fd
        }).then(function (d) {
            if (d && d.status) {
                cb(d);
            } else {
                toast((d && d.message) || '上传失败');
            }
        }).catch(function (err) {
            toast((err && err.message) || '上传失败，请检查网络或 usr/uploads 目录权限');
        });
    }

    function handleFiles(files) {
        var arr = Array.prototype.slice.call(files);
        if (!arr.length) return;
        arr.forEach(function (f, i) {
            if (i > 0) {
                setTimeout(function () { uploadOne(f); }, i * 140);
            } else {
                uploadOne(f);
            }
        });
    }

    function uploadOne(f) {
        uploadFile(f, function (d) {
            insertItem(d);
            var kind = (d && d.video) ? '视频' : ((d && d.image) ? '图片' : '文件');
            toast(kind + '已上传并插入');
        });
    }

    function pickLocalFiles() {
        var inp = document.getElementById('yx-ed-file');
        if (!inp) {
            inp = document.createElement('input');
            inp.type = 'file';
            inp.id = 'yx-ed-file';
            inp.multiple = true;
            inp.accept = 'image/*,video/*,.pdf,.zip,.rar,.7z,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.md,.mp3,.wav,.csv';
            inp.style.display = 'none';
            inp.addEventListener('change', function () {
                if (inp.files && inp.files.length) handleFiles(inp.files);
                inp.value = '';
            });
            document.body.appendChild(inp);
        }
        try {
            inp.click();
        } catch (e) {

            inp.style.display = '';
            toast('请点击输入框旁的「选择文件」继续');
        }
    }

    function isImgUrl(u) {
        return /^https?:\/\/[^\s]+\.(png|jpe?g|gif|webp|bmp|svg)(\?[^\s]*)?$/i.test(u);
    }

    function isUrl(u) {
        return /^https?:\/\/[^\s]+$/i.test(u);
    }

    function nodeMd(node, out) {
        node.childNodes.forEach(function (ch) {
            if (ch.nodeType === 3) {
                out.push(ch.nodeValue.replace(/\s+/g, ' '));
                return;
            }
            if (ch.nodeType !== 1) return;
            var tag = ch.tagName.toLowerCase();
            if (tag === 'br') { out.push('\n'); return; }
            if (tag === 'strong' || tag === 'b') { out.push('**'); nodeMd(ch, out); out.push('**'); return; }
            if (tag === 'em' || tag === 'i') { out.push('*'); nodeMd(ch, out); out.push('*'); return; }
            if (tag === 'del' || tag === 's' || tag === 'strike') { out.push('~~'); nodeMd(ch, out); out.push('~~'); return; }
            if (tag === 'code') { out.push('`' + ch.textContent + '`'); return; }
            if (tag === 'a') {
                var href = ch.getAttribute('href') || '';
                if (!href) { nodeMd(ch, out); return; }
                out.push('[');
                nodeMd(ch, out);
                out.push('](' + href + ')');
                return;
            }
            if (tag === 'img') {
                var src = ch.getAttribute('src') || '';
                if (src) out.push('![](' + src + ')');
                return;
            }
            if (tag === 'hr') { out.push('\n\n---\n\n'); return; }
            if (/^h[1-6]$/.test(tag)) {
                out.push('\n\n' + new Array(parseInt(tag.charAt(1), 10) + 1).join('#') + ' ' + ch.textContent.trim() + '\n\n');
                return;
            }
            if (tag === 'blockquote') {
                var q = [];
                nodeMd(ch, q);
                out.push('\n\n' + q.join('').trim().split('\n').map(function (l) { return '> ' + l; }).join('\n') + '\n\n');
                return;
            }
            if (tag === 'ul' || tag === 'ol') {
                out.push('\n\n');
                var idx = 0;
                ch.childNodes.forEach(function (li) {
                    if (li.nodeType !== 1 || li.tagName.toLowerCase() !== 'li') return;
                    idx++;
                    var sub = [];
                    nodeMd(li, sub);
                    var marker = tag === 'ol' ? (idx + '. ') : '- ';
                    out.push(marker + sub.join('').trim().replace(/\n/g, '\n  ') + '\n');
                });
                out.push('\n');
                return;
            }
            if (tag === 'pre') {
                out.push('\n\n```\n' + ch.textContent.replace(/\n$/, '') + '\n```\n\n');
                return;
            }
            if (tag === 'p' || tag === 'div' || tag === 'section') {
                out.push('\n\n');
                nodeMd(ch, out);
                out.push('\n\n');
                return;
            }
            nodeMd(ch, out);
        });
    }

    function htmlToMd(html) {
        var doc = new DOMParser().parseFromString(html, 'text/html');
        Array.prototype.slice.call(doc.querySelectorAll('script,style,meta,link')).forEach(function (n) {
            n.remove();
        });
        Array.prototype.slice.call(doc.querySelectorAll('span,section,font,figure,figcaption,article,header,footer')).forEach(function (n) {
            while (n.firstChild) n.parentNode.insertBefore(n.firstChild, n);
            n.remove();
        });
        Array.prototype.slice.call(doc.querySelectorAll('[style],[class],[id]')).forEach(function (n) {
            n.removeAttribute('style');
            n.removeAttribute('class');
            n.removeAttribute('id');
        });
        var out = [];
        nodeMd(doc.body, out);
        return out.join('').replace(/\n{3,}/g, '\n\n').trim();
    }

    function cleanPaste(html) {
        var md = htmlToMd(html);
        if (!md) return '';
        if (md.length < 2) return '';
        return md;
    }

    function uploadPaste(payload) {
        return apiFetch(window.YX_API + '?action=imgpaste', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }).then(function (d) {
            if (d && d.status && d.url) return d.url;
            throw new Error((d && d.message) || '上传失败');
        });
    }


    function pasteWeChat(html) {
        var doc = new DOMParser().parseFromString(html, 'text/html');
        var imgs = Array.prototype.slice.call(doc.querySelectorAll('img'));
        var tasks = [];
        imgs.forEach(function (img, i) {
            var real = (img.getAttribute('data-src') || img.getAttribute('src') || '').trim();
            if (!real) { if (img.parentNode) img.parentNode.removeChild(img); return; }
            if (real.indexOf('//') === 0) real = 'https:' + real;
            var alt = img.getAttribute('alt') || img.getAttribute('title') || '';
            var payload = null;
            if (/^data:image\//i.test(real)) {
                payload = { b64: real, name: 'wechat-' + Date.now() + '-' + i + '.png' };
            } else if (/^https?:\/\//i.test(real)) {
                payload = { url: real, name: 'wechat-' + Date.now() + '-' + i + '.png' };
            }
            if (!payload) { if (img.parentNode) img.parentNode.removeChild(img); return; }
            var ph = 'YXIMG' + i + '';
            var tn = doc.createTextNode(ph);
            if (img.parentNode) img.parentNode.replaceChild(tn, img);
            tasks.push(uploadPaste(payload).then(function (url) {
                return { ph: ph, rep: '![' + (alt || '图片') + '](' + url + ')' };
            }).catch(function () {
                return { ph: ph, rep: '' };
            }));
        });
        var md = cleanPaste(doc.body.innerHTML);
        return Promise.all(tasks).then(function (results) {
            results.forEach(function (r) {
                if (r && r.ph) md = md.split(r.ph).join(r.rep);
            });
            return md;
        });
    }

    function onPaste(e) {
        var cd = e.clipboardData;
        if (!cd) return;
        if (cd.files && cd.files.length) {
            e.preventDefault();
            handleFiles(cd.files);
            return;
        }
        var html = cd.getData('text/html');
        var text = (cd.getData('text/plain') || '').trim();
        if (html && /<(p|span|section|strong|em|h\d|img|a|blockquote|li)[\s>]/i.test(html)) {
            e.preventDefault();
            pasteWeChat(html).then(function (md) {
                if (md) insert(md);
                else if (text) insert(text);
            });
            return;
        }
        if (text && isImgUrl(text) && ta.selectionStart === ta.selectionEnd) {
            e.preventDefault();
            insert('\n![](' + text + ')\n');
            return;
        }
        if (text && isVideoUrl(text) && ta.selectionStart === ta.selectionEnd) {
            e.preventDefault();
            insert('\n' + videoMarkup(text) + '\n');
            toast(/iframe/i.test(videoMarkup(text)) ? '已嵌入视频播放器' : '已插入视频播放器');
            return;
        }
        if (text && isUrl(text) && !isImgUrl(text) && ta.selectionStart === ta.selectionEnd) {
            e.preventDefault();
            insert('[' + text + '](' + text.replace(/[()]/g, encodeURIComponent) + ')');
        }
    }

    function protect(html) {
        var key = '\u0001' + (phN++) + '\u0001';
        phMap[key] = html;
        return key;
    }

    function highlight(src) {
        phMap = {};
        phN = 0;
        var t = esc(src);
        t = t.replace(/```([\s\S]*?)```/g, function (m, c) {
            return protect('<span class="hx-cb">' + c + '</span>');
        });
        t = t.replace(/`([^`\n]+)`/g, function (m, c) {
            return protect('<span class="hx-ic">' + c + '</span>');
        });
        t = t.replace(/^(#{1,6})(\s+.*)?$/gm, '<span class="hx-hd">$1$2</span>');
        t = t.replace(/!\[([^\]]*)\]\(([^)\s]+)[^)]*\)/g, '<span class="hx-im">![$1]($2)</span>');
        t = t.replace(/\[([^\]]*)\]\(([^)\s]+)[^)]*\)/g, '<span class="hx-lk">[$1]($2)</span>');
        t = t.replace(/^(\s*)(&gt;.*)$/gm, '$1<span class="hx-bq">$2</span>');
        t = t.replace(/^(\s*)((?:[-*+]|\d+\.)\s)/gm, '$1<span class="hx-li">$2</span>');
        t = t.replace(/\*\*([^*\n]+)\*\*/g, '<span class="hx-b">**$1**</span>');
        t = /(^|[^*\w])\*([^*\n]+)\*(?!\w)/.test(t) ? t.replace(/(^|[^*\w])\*([^*\n]+)\*(?!\w)/g, '$1<span class="hx-i">*$2*</span>') : t;
        t = t.replace(/~~([^~\n]+)~~/g, '<span class="hx-s">~~$1~~</span>');
        t = t.replace(/^(\s*)(-{3,}|\*{3,})$/gm, '<span class="hx-hr">$1$2</span>');
        t = t.replace(/&lt;!--more--&gt;/g, '<span class="hx-more">&lt;!--more--&gt;</span>');
        t = t.replace(/&lt;(video|audio|iframe|div)(\s[^&]*)?&gt;/g, function (m2) {
            return '<span class="hx-tag">' + m2 + '</span>';
        });
        var keys = Object.keys(phMap);
        if (keys.length) {
            var re = new RegExp(keys.map(function (k) {
                return k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            }).join('|'), 'g');
            t = t.replace(re, function (m) {
                return phMap[m] || m;
            });
        }
        return t + '\n';
    }

    function syncHl() {
        if (!hlCode) return;
        clearTimeout(hlTimer);
        var len = ta.value.length;
        hlTimer = setTimeout(function () {
            hlCode.innerHTML = highlight(ta.value);
        }, len > 40000 ? 160 : (len > 12000 ? 90 : 45));
        var pre = hlCode.parentNode;
        pre.scrollTop = ta.scrollTop;
        pre.scrollLeft = ta.scrollLeft;
    }

    function count() {
        var v = ta.value;
        var cjk = (v.match(/[\u4e00-\u9fff\u3040-\u30ff]/g) || []).length;
        var words = (v.replace(/[\u4e00-\u9fff\u3040-\u30ff]/g, ' ').match(/[a-zA-Z0-9_]+/g) || []).length;
        var chars = v.replace(/\s/g, '').length;
        countEl.textContent = chars + ' 字 · ' + (cjk + words) + ' 词';
    }

    function findRegex() {
        var q = findBox.querySelector('.fi').value;
        if (!q) return null;
        var re = findBox.querySelector('.re').checked;
        var cs = findBox.querySelector('.cs').checked;
        var flags = 'g' + (cs ? '' : 'i');
        try {
            return new RegExp(re ? q : q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), flags);
        } catch (err) {
            return null;
        }
    }

    function doFind(dir) {
        var q = findBox.querySelector('.fi').value;
        if (!q) {
            findBox.querySelector('.cnt').textContent = '';
            return;
        }
        var reQ = findRegex();
        if (!reQ) {
            findBox.querySelector('.cnt').textContent = '正则错误';
            return;
        }
        var v = ta.value;
        var matches = [];
        var m;
        while ((m = reQ.exec(v))) {
            matches.push([m.index, m.index + m[0].length]);
            if (!m[0].length) reQ.lastIndex++;
        }
        findBox.querySelector('.cnt').textContent = matches.length ? (matches.length + ' 处') : '无结果';
        if (!matches.length) return;
        var idx = -1;
        if (dir === 0) {
            for (var i = 0; i < matches.length; i++) {
                if (matches[i][0] >= ta.selectionEnd) { idx = i; break; }
            }
            if (idx === -1) idx = 0;
        } else if (dir === 1) {
            for (var j = 0; j < matches.length; j++) {
                if (matches[j][1] > ta.selectionEnd) { idx = j; break; }
            }
            if (idx === -1) idx = 0;
        } else {
            for (var k = matches.length - 1; k >= 0; k--) {
                if (matches[k][0] < ta.selectionStart) { idx = k; break; }
            }
            if (idx === -1) idx = matches.length - 1;
        }
        pick(matches[idx]);
    }

    function pick(p) {
        ta.focus();
        ta.setSelectionRange(p[0], p[1]);
        var lh = parseFloat(getComputedStyle(ta).lineHeight) || 22;
        var line = ta.value.slice(0, p[0]).split('\n').length - 1;
        ta.scrollTop = Math.max(0, line * lh - ta.clientHeight / 2);
        syncHl();
    }

    function doReplace() {
        if (ta.selectionStart === ta.selectionEnd) {
            doFind(1);
            return;
        }
        insert(findBox.querySelector('.rp').value);
    }

    function doReplaceAll() {
        var q = findBox.querySelector('.fi').value;
        var rp = findBox.querySelector('.rp').value;
        if (!q) return;
        var reQ = findRegex();
        if (!reQ) {
            findBox.querySelector('.cnt').textContent = '正则错误';
            return;
        }
        var n = (ta.value.match(reQ) || []).length;
        ta.value = ta.value.replace(reQ, rp);
        count();
        syncHl();
        findBox.querySelector('.cnt').textContent = '已替换 ' + n + ' 处';
    }

    function md2html(src) {
        var lines = esc(src).split('\n');
        var out = [];
        var inUl = false;
        var inOl = false;
        var inQ = false;
        var inCode = false;
        var codeBuf = [];
        function inline(s) {
            s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)[^)]*\)/g, '<img src="$2" alt="$1" loading="lazy">');
            s = s.replace(/\[([^\]]+)\]\(([^)\s]+)[^)]*\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
            s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
            s = s.replace(/\*([^*]+)\*/g, '<em>$1</em>');
            s = s.replace(/~~([^~]+)~~/g, '<del>$1</del>');
            s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
            return s;
        }
        function closeAll() {
            if (inUl) { out.push('</ul>'); inUl = false; }
            if (inOl) { out.push('</ol>'); inOl = false; }
            if (inQ) { out.push('</blockquote>'); inQ = false; }
        }
        lines.forEach(function (l) {
            if (/^```/.test(l)) {
                if (inCode) {
                    out.push('<pre><code>' + codeBuf.join('\n') + '</code></pre>');
                    codeBuf = [];
                    inCode = false;
                } else {
                    closeAll();
                    inCode = true;
                }
                return;
            }
            if (inCode) {
                codeBuf.push(l);
                return;
            }
            if (l === '') {
                closeAll();
                return;
            }
            var h = l.match(/^(#{1,6})\s+(.*)$/);
            if (h) {
                closeAll();
                var lv = h[1].length;
                out.push('<h' + lv + '>' + inline(h[2]) + '</h' + lv + '>');
                return;
            }
            if (/^\s*(-{3,}|\*{3,})\s*$/.test(l)) {
                closeAll();
                out.push('<hr>');
                return;
            }
            var q = l.match(/^(\s*)&gt;\s?(.*)$/);
            if (q) {
                if (!inQ) { closeAll(); out.push('<blockquote>'); inQ = true; }
                out.push('<p>' + inline(q[2]) + '</p>');
                return;
            }
            var ul = l.match(/^\s*[-*+]\s+(.*)$/);
            var ol = l.match(/^\s*\d+\.\s+(.*)$/);
            if (ul || ol) {
                if (inQ) { out.push('</blockquote>'); inQ = false; }
                if (ul && !inUl) { if (inOl) { out.push('</ol>'); inOl = false; } out.push('<ul>'); inUl = true; }
                if (ol && !inOl) { if (inUl) { out.push('</ul>'); inUl = false; } out.push('<ol>'); inOl = true; }
                var body = (ul ? ul[1] : ol[1]).replace(/^\[([ xX])\]\s+/, function (mm, c) {
                    return '<input type="checkbox" disabled' + (c !== ' ' ? ' checked' : '') + '> ';
                });
                out.push('<li>' + inline(body) + '</li>');
                return;
            }
            closeAll();
            out.push('<p>' + inline(l) + '</p>');
        });
        if (inCode) out.push('<pre><code>' + codeBuf.join('\n') + '</code></pre>');
        closeAll();
        return out.join('\n');
    }

    function renderPreview() {
        if (!previewOn) return;
        clearTimeout(previewTimer);
        previewTimer = setTimeout(function () {
            if (previewOn) preview.innerHTML = md2html(ta.value);
        }, 320);
    }

    function togglePreview() {
        var on = preview.classList.toggle('show');
        previewOn = on;
        var pb = bar.querySelector('[data-act=preview]');
        if (pb) pb.classList.toggle('primary', !on);
        if (on) {
            preview.innerHTML = md2html(ta.value);
            wrap.style.display = 'none';
        } else {
            wrap.style.display = '';
            ta.focus();
        }
    }

    function toggleFull() {
        var host = ta.closest('.yx-ed-host');
        host.classList.toggle('yx-ed-full');
        setTimeout(syncHl, 60);
    }

    function act(name) {
        switch (name) {
            case 'undo': ta.focus(); document.execCommand('undo'); break;
            case 'redo': ta.focus(); document.execCommand('redo'); break;
            case 'h1': heading(1); break;
            case 'h2': heading(2); break;
            case 'h3': heading(3); break;
            case 'bold': wrapSel('**', '**', '加粗文字'); break;
            case 'italic': wrapSel('*', '*', '斜体文字'); break;
            case 'strike': wrapSel('~~', '~~', '删除文字'); break;
            case 'icode': wrapSel('`', '`', '代码'); break;
            case 'cblock': block('\n```\n' + (ta.selectionStart === ta.selectionEnd ? '代码' : '') + '\n```\n'); break;
            case 'quote': linePrefix('> '); break;
            case 'ul': linePrefix('- '); break;
            case 'ol': linePrefix('1. '); break;
            case 'task': linePrefix('- [ ] '); break;
            case 'link': doLink(); break;
            case 'image': openPicker('local'); break;
            case 'imgurl': doImageUrl(); break;
            case 'video': doVideoLink(); break;
            case 'audio': doMedia('audio'); break;
            case 'file': doMedia('file'); break;
            case 'upload': pickLocalFiles(); break;
            case 'table': doTable(); break;
            case 'hr': block('\n---\n'); break;
            case 'more': block('\n<!--more-->\n'); break;
            case 'find': findBox.style.display = ''; findBox.querySelector('.fi').focus(); break;
            case 'help': toggleHelp(); break;
            case 'palette': openPal(); break;
            case 'preview': togglePreview(); break;
            case 'full': toggleFull(); break;

            
            case 'em': wrapSel('*', '*', '强调文字'); break;
            case 'color': wrapSel('<span style="color:#c0392b">', '</span>', '彩色文字'); break;
            case 'mark': wrapSel('<mark>', '</mark>', '高亮文字'); break;
            case 'small': wrapSel('<small>', '</small>', '小字'); break;
            case 'big': wrapSel('<big>', '</big>', '大字'); break;
            case 'sub': wrapSel('<sub>', '</sub>', '下标'); break;
            case 'sup': wrapSel('<sup>', '</sup>', '上标'); break;
            case 'cleartxt': clearFormat(); break;
            case 'alignl': wrapSel('<div style="text-align:left">', '</div>', '左对齐'); break;
            case 'alignc': wrapSel('<div style="text-align:center">', '</div>', '居中'); break;
            case 'alignr': wrapSel('<div style="text-align:right">', '</div>', '右对齐'); break;

            
            case 'checklist': block('\n- [ ] 待办一\n- [ ] 待办二\n- [ ] 待办三\n'); break;
            case 'indent': linePrefix('  '); break;
            case 'outdent': linePrefix(''); break;

            
            case 'date': block('\n' + new Date().toLocaleString('zh-CN', {
                year: 'numeric', month: '2-digit', day: '2-digit',
                hour: '2-digit', minute: '2-digit'
            }) + '\n'); break;
            case 'tag': block('\n#标签\n'); break;
            case 'book': block('\n> **参考文献**\n> 1. \n'); break;
            case 'toc': block('\n[TOC]\n'); break;
            case 'note': block('\n> [!NOTE]\n> 这里是补充说明。\n'); break;
            case 'grid': block('\n<div class="grid">\n<div>内容一</div>\n<div>内容二</div>\n</div>\n'); break;
            case 'space': block('\n\n'); break;

            
            case 'dup': lineOp('dup'); break;
            case 'up': lineOp('up'); break;
            case 'down': lineOp('down'); break;
            case 'delline': lineOp('del'); break;
            case 'swap': swapLines(); break;
            case 'refresh': count(); syncHl(); toast('已刷新字数统计'); break;
        }
    }

    
    function clearFormat() {
        var s = ta.selectionStart;
        var e = ta.selectionEnd;
        var v = ta.value;
        var sel = v.slice(s, e);
        if (!sel) {
            toast('请先选中要清除格式的文字');
            return;
        }
        var out = sel
            .replace(/\*\*([^*]+)\*\*/g, '$1')
            .replace(/\*([^*]+)\*/g, '$1')
            .replace(/~~([^~]+)~~/g, '$1')
            .replace(/`([^`]+)`/g, '$1')
            .replace(/<span style="color:[^"]*">([\s\S]*?)<\/span>/g, '$1')
            .replace(/<mark>([\s\S]*?)<\/mark>/g, '$1')
            .replace(/<small>([\s\S]*?)<\/small>/g, '$1')
            .replace(/<big>([\s\S]*?)<\/big>/g, '$1')
            .replace(/<sub>([\s\S]*?)<\/sub>/g, '$1')
            .replace(/<sup>([\s\S]*?)<\/sup>/g, '$1');
        ta.value = v.slice(0, s) + out + v.slice(e);
        ta.setSelectionRange(s, s + out.length);
        ta.focus();
        syncHl();
        count();
        toast('已清除所选文字的格式');
    }

    
    function swapLines() {
        var r = lineRange();
        var lines = ta.value.split('\n');
        var start = ta.value.slice(0, r[0]).split('\n').length - 1;
        if (start >= lines.length - 1) {
            toast('当前已是最后一行');
            return;
        }
        var t = lines[start];
        lines[start] = lines[start + 1];
        lines[start + 1] = t;
        ta.value = lines.join('\n');
        var pos = r[0] + (lines[start + 1] === t ? 0 : 0);
        ta.setSelectionRange(pos, pos);
        ta.focus();
        syncHl();
        count();
        toast('已与下一行交换');
    }

    var PAIRS = { '(': ')', '[': ']', '{': '}', '"': '"', "'": "'", '`': '`', '*': '*', '_': '_' };
    var CLOSERS = { ')': 1, ']': 1, '}': 1 };

    function onKeyDown(e) {
        var mod = e.ctrlKey || e.metaKey;
        if (mod && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
            e.preventDefault();
            openPal();
            return;
        }
        if (mod && !e.shiftKey && (e.key === 'f' || e.key === 'F')) {
            e.preventDefault();
            act('find');
            return;
        }
        if (mod && e.shiftKey && (e.key === 'P' || e.key === 'p')) {
            e.preventDefault();
            togglePreview();
            return;
        }
        if (mod && !e.shiftKey && (e.key === 'k' || e.key === 'K')) {
            e.preventDefault();
            doLink();
            return;
        }
        if (mod && !e.shiftKey && (e.key === 'g' || e.key === 'G')) {
            e.preventDefault();
            openPicker('local');
            return;
        }
        if (mod && !e.shiftKey && (e.key === 'u' || e.key === 'U')) {
            e.preventDefault();
            pickLocalFiles();
            return;
        }
        if (mod && e.shiftKey && (e.key === 'D' || e.key === 'd')) {
            e.preventDefault();
            lineOp('dup');
            return;
        }
        if (mod && e.shiftKey && (e.key === 'K' || e.key === 'k')) {
            e.preventDefault();
            lineOp('del');
            return;
        }
        if (e.altKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
            e.preventDefault();
            lineOp(e.key === 'ArrowUp' ? 'up' : 'down');
            return;
        }
        if (e.key === 'Escape' && ta.closest('.yx-ed-host').classList.contains('yx-ed-full')) {
            toggleFull();
            return;
        }
        if (e.key === 'Tab') {
            e.preventDefault();
            if (ta.selectionStart !== ta.selectionEnd) {
                if (e.shiftKey) {
                    var rr = lineRange();
                    var blk = ta.value.slice(rr[0], rr[1]);
                    swapBlock(rr, blk.split('\n').map(function (l) { return l.replace(/^ {1,2}/, ''); }).join('\n'));
                    syncHl();
                } else {
                    linePrefix('  ');
                }
                return;
            }
            insert('  ');
            return;
        }
        if (e.key === 'Enter' && !e.shiftKey && !mod) {
            var v = ta.value;
            var ls = v.lastIndexOf('\n', ta.selectionStart - 1) + 1;
            var line = v.slice(ls, ta.selectionStart);
            var m = line.match(/^(\s*)([-*+]|\d+)\s(\[[ xX]\]\s)?(.*)$/);
            if (m && ta.selectionStart === ta.selectionEnd && m[4].trim() !== '') {
                e.preventDefault();
                var mark = /^\d+$/.test(m[2]) ? (parseInt(m[2], 10) + 1) + '.' : m[2];
                insert('\n' + m[1] + mark + ' ' + (m[3] ? '[ ] ' : ''));
                return;
            }
            if (m && ta.selectionStart === ta.selectionEnd && m[4].trim() === '') {
                e.preventDefault();
                var cut = ls + m[0].length;
                ta.value = v.slice(0, ls) + v.slice(Math.min(cut, v.length));
                ta.setSelectionRange(ls, ls);
                syncHl();
                count();
                return;
            }
            var ind = line.match(/^\s+/);
            if (ind && ta.selectionStart === ta.selectionEnd && v.charAt(ta.selectionStart - 1) !== '\n' && v.charAt(ta.selectionStart) !== '\n') {
                e.preventDefault();
                insert('\n' + ind[0]);
                return;
            }
        }
        if (PAIRS[e.key] && !mod && !e.altKey) {
            var sv = ta.value;
            var ss = ta.selectionStart;
            var se = ta.selectionEnd;
            e.preventDefault();
            if (ss !== se) {
                var selText = sv.slice(ss, se);
                ta.value = sv.slice(0, ss) + e.key + selText + PAIRS[e.key] + sv.slice(se);
                ta.setSelectionRange(ss + 1, ss + 1 + selText.length);
            } else {
                ta.value = sv.slice(0, ss) + e.key + PAIRS[e.key] + sv.slice(ss);
                ta.setSelectionRange(ss + 1, ss + 1);
            }
            syncHl();
            return;
        }
        if (CLOSERS[e.key] && ta.selectionStart === ta.selectionEnd && ta.value.charAt(ta.selectionStart) === e.key) {
            e.preventDefault();
            ta.setSelectionRange(ta.selectionStart + 1, ta.selectionStart + 1);
            return;
        }
        if (e.key === 'Backspace' && ta.selectionStart === ta.selectionEnd && ta.selectionStart > 0) {
            var before = ta.value.charAt(ta.selectionStart - 1);
            var after = ta.value.charAt(ta.selectionStart);
            if (PAIRS[before] && PAIRS[before] === after) {
                e.preventDefault();
                ta.value = ta.value.slice(0, ta.selectionStart - 1) + ta.value.slice(ta.selectionStart + 1);
                ta.setSelectionRange(ta.selectionStart - 1, ta.selectionStart - 1);
                syncHl();
            }
        }
    }

    function polishCustomField() {
        var cf = document.getElementById('custom-field');
        if (!cf || cf.dataset.yxCf) return;
        cf.dataset.yxCf = '1';

        var intro = document.createElement('p');
        intro.className = 'yx-cf-intro';
        intro.innerHTML = '自定义字段用于给文章附加结构化信息，例如封面图、图片来源、原作者等。'
            + '主题模板会自动读取这些字段：填写「封面图片」后，文章列表与详情页会展示封面缩图，搜索引擎抓取的也是该图；'
            + '「作者」留空则默认为原创文章。模板中通过 <code>$this-&gt;fields()</code> 调用。';
        var head = cf.querySelector('h3') || cf.querySelector('.typecho-label');
        if (head && head.parentNode === cf) {
            head.insertAdjacentElement('afterend', intro);
        } else {
            cf.insertBefore(intro, cf.firstChild);
        }

        Array.prototype.slice.call(cf.querySelectorAll('.description')).forEach(function (d) {
            if (d.querySelector('button')) {
                d.classList.add('yx-cf-foot');
            }
        });
    }

    function polishTemplateSelect() {
        var sel = document.querySelector('select[name="template"]');
        if (!sel || sel.dataset.yxTpl) return;
        sel.dataset.yxTpl = '1';

        var opts = Array.prototype.slice.call(sel.options);
        var usable = opts.filter(function (o) {
            return o.value && o.value !== '';
        });

        var hint = document.createElement('p');
        hint.className = 'yx-tpl-hint';

        if (!usable.length) {
            hint.classList.add('warn');
            hint.innerHTML = '当前主题还没有提供独立页面模板。在主题目录下新建 <code>page-模板名.php</code>'
                + '（如 <code>page-links.php</code>）后，这里就会出现可选模板；不选则使用主题默认模板。';
        } else {
            hint.innerHTML = '共 <b>' + usable.length + '</b> 个可用模板，来自当前主题的 <code>page-*.php</code> 文件。'
                + '选择「默认模板」或留空表示跟随主题的 <code>page.php</code>。';
        }

        var host = sel.parentNode;
        if (host) {
            var anchor = sel.nextSibling;
            var note = host.querySelector('.description');
            if (note) {
                note.insertAdjacentElement('afterend', hint);
            } else if (anchor) {
                host.insertBefore(hint, anchor);
            } else {
                host.appendChild(hint);
            }
        }

        sel.addEventListener('change', function () {
            var txt = sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text.trim() : '';
            if (txt) {
                hint.classList.remove('warn');
                hint.innerHTML = '已选择模板：<b>' + esc(txt) + '</b>。保存后前台独立页面将按该模板渲染。';
            }
        });
    }

    function boot() {
        ta = document.getElementById('text') || document.querySelector('textarea[name="text"]');
        if (!ta || ta.dataset.yxED) return;
        ta.dataset.yxED = '1';
        var p = ta.parentNode;
        var host = document.createElement('div');
        host.className = 'yx-ed-host';
        p.insertBefore(host, ta);
        host.appendChild(buildBar());
        host.appendChild(buildFind());

        wrap = document.createElement('div');
        wrap.className = 'yx-ed-wrap';
        var pre = document.createElement('pre');
        pre.className = 'yx-ed-hl';
        pre.setAttribute('aria-hidden', 'true');
        hlCode = document.createElement('code');
        pre.appendChild(hlCode);
        wrap.appendChild(pre);
        wrap.appendChild(ta);
        ta.classList.add('yx-ed-area', 'yx-ed-hl-on');
        host.appendChild(wrap);

        preview = document.createElement('div');
        preview.className = 'yx-ed-preview';
        host.appendChild(preview);

        buildPalette();

        ta.addEventListener('input', function () {
            count();
            syncHl();
            renderPreview();
            scheduleDraft();
        });
        ta.addEventListener('scroll', function () {
            hlCode.parentNode.scrollTop = ta.scrollTop;
            hlCode.parentNode.scrollLeft = ta.scrollLeft;
        });
        ta.addEventListener('keydown', onKeyDown);
        ta.addEventListener('paste', onPaste);
        ta.addEventListener('drop', function (e) {
            if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
                e.preventDefault();
                handleFiles(e.dataTransfer.files);
            }
        });
        bar.addEventListener('click', function (e) {
            var b = e.target.closest ? e.target.closest('[data-act]') : null;
            if (!b) return;

            if (!NO_DESC_ACT[b.getAttribute('data-act')]) {
                try { showBtnDesc(b, false); } catch (ignore) {}
            }
            var name = b.getAttribute('data-act');

            if (NO_DESC_ACT[name]) {
                hideDesc();
            }
            try {
                act(name);
            } catch (err) {
                if (window.console && console.error) console.error('[YunxiEditor] act:' + name, err);
                toast('操作失败：' + ((err && err.message) || name));
            }
        });

        var descBtn = null;
        bar.addEventListener('mouseover', function (e) {
            var b = e.target.closest ? e.target.closest('[data-act]') : null;
            if (!b || descBtn === b) return;
            descBtn = b;
            showBtnDesc(b, true);
        });
        bar.addEventListener('mouseout', function (e) {
            var b = e.target.closest ? e.target.closest('[data-act]') : null;
            if (!b) return;
            var to = e.relatedTarget;
            if (to && to.closest && to.closest('[data-act]') === b) return;
            if (descBtn === b) descBtn = null;
            hideDesc();
        });
        bar.addEventListener('focusin', function (e) {
            var b = e.target.closest ? e.target.closest('[data-act]') : null;
            if (!b) return;
            descBtn = b;
            showBtnDesc(b, true);
        });
        bar.addEventListener('focusout', function (e) {
            var b = e.target.closest ? e.target.closest('[data-act]') : null;
            if (!b) return;
            if (descBtn === b) descBtn = null;
            hideDesc();
        });
        findBox.querySelector('.fi').addEventListener('input', function () {
            doFind(0);
        });
        findBox.querySelector('.fi').addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                doFind(e.shiftKey ? -1 : 1);
            }
        });
        findBox.querySelector('.prev').addEventListener('click', function () { doFind(-1); });
        findBox.querySelector('.next').addEventListener('click', function () { doFind(1); });
        findBox.querySelector('.rep').addEventListener('click', doReplace);
        findBox.querySelector('.repall').addEventListener('click', doReplaceAll);
        findBox.querySelector('.cls').addEventListener('click', function () {
            findBox.style.display = 'none';
            ta.focus();
        });
        Array.prototype.slice.call(findBox.querySelectorAll('input[type=checkbox]')).forEach(function (c) {
            c.addEventListener('change', function () {
                doFind(0);
            });
        });
        count();
        syncHl();
        polishCustomField();
        polishTemplateSelect();
        checkDraft(host);
        if (ta.form) {
            ta.form.addEventListener('submit', clearDraft);
        }
        window.addEventListener('beforeunload', function () {
            if (ta.value && ta.value.length > 20) saveDraft();
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
}());
