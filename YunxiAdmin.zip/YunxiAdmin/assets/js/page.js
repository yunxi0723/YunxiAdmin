(function () {
    'use strict';

    var $ = function (s, c) {
        return (c || document).querySelector(s);
    };

    var $$ = function (s, c) {
        return Array.prototype.slice.call((c || document).querySelectorAll(s));
    };

    var ICONS = window.YX_ICONS || '';
    var API = window.YX_API || '';

    function icon(name) {
        return '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="' + ICONS + '#' + name + '"></use></svg>';
    }

    function esc(v) {
        return String(v == null ? '' : v).replace(/[&<>"]/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
        });
    }

    var PALETTE = ['#0f6f68', '#1d4ed8', '#7c3aed', '#be185d', '#c2410c', '#b45309', '#4d7c0f', '#0f172a'];

    var SECTIONS = [
        {
            icon: 'i-paint', title: '外观', tip: '主题与配色',
            rows: [
                { label: '默认外观', sub: '新访客初始外观', type: 'seg', name: 'theme',
                    options: [['system', '跟随系统'], ['light', '始终白天'], ['dark', '始终夜间']] },
                { label: '主题色', sub: '导航按钮强调色', type: 'color', name: 'accent' },
                { label: '站点 LOGO', sub: '留空显示管理员头像', type: 'image', name: 'logo' },
                { label: '侧栏背景图', sub: '仅电脑端生效', type: 'image', name: 'bg' },
                { label: '毛玻璃', sub: '背景图叠加磨砂效果', type: 'switch', name: 'bglj', on: '1' }
            ]
        },
        {
            icon: 'i-panel', title: '顶栏', tip: '顶栏信息展示',
            rows: [
                { label: '实时天气', sub: '数据来自 Open-Meteo', type: 'switch', name: 'weather', on: '1' },
                { label: '天气城市', sub: '留空按 IP 自动定位', type: 'text', name: 'weatherCity', ph: '如 杭州' },
                { label: '登录时长', sub: '本次登录持续的时长', type: 'switch', name: 'loginTime', on: '1' },
                { label: '切换动画', sub: '基于 View Transitions', type: 'seg', name: 'animation',
                    options: [['0', '无动画'], ['fade', '淡入'], ['slideup', '上滑'], ['pop', '放大']] }
            ]
        },
        {
            icon: 'i-out', title: '登录页', tip: '登录与注册界面',
            rows: [
                { label: '美化登录页', sub: '重做登录注册界面', type: 'switch', name: 'loginstyle', on: '1' },
                { label: '背景图', sub: '留空使用纯色背景', type: 'image', name: 'dlbg' }
            ]
        },
        {
            icon: 'i-cmt', title: '评论', tip: '评论展示策略',
            rows: [
                { label: '网址管控', sub: '隐藏久远的评论者网址', type: 'select', name: 'urlfilter',
                    options: [['0', '不处理'], ['1', '隐藏评论网址'], ['2', '隐藏 15 天前'], ['3', '隐藏 30 天前'], ['5', '隐藏 60 天前']] },
                { label: '头像源', sub: '评论列表与用户头像', type: 'select', name: 'gravatars',
                    options: [
                        ['weavatar.com/avatar', 'weavatar [建议]'],
                        ['cn.cravatar.com/avatar', 'Cravatar [推荐]'],
                        ['cdn.v2ex.com/gravatar', 'v2ex [建议]'],
                        ['cdn.helingqi.com/avatar', '禾令奇 [建议]'],
                        ['www.gravatar.com/avatar', 'Gravatar www 源'],
                        ['cn.gravatar.com/avatar', 'Gravatar cn 源'],
                        ['secure.gravatar.com/avatar', 'Gravatar secure 源'],
                        ['sdn.geekzu.org/avatar', '极客族'],
                        ['gravatar.loli.net/avatar', 'loli.net 源']
                    ] }
            ]
        },
        {
            icon: 'i-gear', title: '性能', tip: '访问速度',
            rows: [
                { label: '后台加速', sub: '预取后台页面', type: 'seg', name: 'speed',
                    options: [['0', '不加速'], ['1', '加速'], ['2', '超级加速']],
                    tip: '超级加速更耗服务器资源，支持情况：<span id="YxTip"></span>' },
                { label: '屏蔽更新提醒', sub: '隐藏官方更新提示', type: 'switch', name: 'updateNotice', on: '1' }
            ]
        },
        {
            icon: 'i-upload', title: '上传', tip: '编辑器文件插入',
            rows: [
                { type: 'note', label: '上传位置', sub: '图片 / 视频 / 文件的去向',
                    text: '所有图片、视频与附件均直接上传至本站媒体库（usr/uploads），不再使用任何外部图床。' }
            ]
        }
    ];

    function nativeVal(form, name) {
        var list = $$('input[name="' + name + '"], select[name="' + name + '"], textarea[name="' + name + '"]', form);
        if (!list.length) return '';
        var el = list[0];
        if (el.type === 'checkbox' || el.type === 'radio') {
            var on = null;
            list.forEach(function (r) {
                if (r.checked) on = r.value;
            });
            return on === null ? '' : on;
        }
        return el.value;
    }

    function setNative(form, name, val) {
        $$('input[name="' + name + '"], select[name="' + name + '"], textarea[name="' + name + '"]', form).forEach(function (el) {
            if (el.type === 'checkbox' || el.type === 'radio') {
                el.checked = String(el.value) === String(val);
            } else {
                el.value = val;
            }
        });
    }

    function rowHtml(r, form) {
        var h = '<div class="yx-cfg-row"><div class="lb">' + esc(r.label)
            + (r.sub ? '<small>' + esc(r.sub) + '</small>' : '') + '</div><div class="ctl">';
        if (r.type === 'seg') {
            var cur = nativeVal(form, r.name);
            if (cur === '') cur = r.options.length ? r.options[0][0] : '';
            h += '<span class="yx-seg" data-name="' + r.name + '">';
            r.options.forEach(function (o) {
                h += '<button type="button" data-v="' + esc(o[0]) + '"'
                    + (String(cur) === String(o[0]) ? ' class="on"' : '') + '>' + esc(o[1]) + '</button>';
            });
            h += '</span>';
        } else if (r.type === 'switch') {
            var on = nativeVal(form, r.name) === (r.on || '1');
            h += '<label class="yx-sw"><input type="checkbox" data-name="' + r.name + '" data-on="' + esc(r.on || '1') + '"'
                + (on ? ' checked' : '') + '><span class="tr"></span><span class="tx">' + (on ? '已开启' : '已关闭') + '</span></label>';
        } else if (r.type === 'color') {
            h += '<span class="yx-cfg-swatches" data-name="accent">';
            PALETTE.forEach(function (c) {
                h += '<button type="button" data-c="' + c + '" style="background:' + c + '" title="' + c + '"></button>';
            });
            h += '</span><input type="color" data-name="accent" value="' + esc(nativeVal(form, 'accent') || '#0f6f68') + '" aria-label="自定义主题色">';
        } else if (r.type === 'image') {
            h += '<input type="text" data-name="' + r.name + '" value="' + esc(nativeVal(form, r.name)) + '" placeholder="https://" aria-label="' + esc(r.label) + '">'
                + '<button type="button" class="yx-ed-btn" data-pick="' + r.name + '">' + icon('i-img') + '选择</button>'
                + '<span class="yx-cfg-preview"><span class="box"></span></span>';
        } else if (r.type === 'select') {
            var sv = nativeVal(form, r.name);
            h += '<select data-name="' + r.name + '" aria-label="' + esc(r.label) + '">';
            r.options.forEach(function (o) {
                h += '<option value="' + esc(o[0]) + '"'
                    + (String(sv) === String(o[0]) ? ' selected' : '') + '>' + esc(o[1]) + '</option>';
            });
            h += '</select>';
        } else if (r.type === 'note') {
            h += '<span class="yx-cfg-note">' + icon('i-check') + '<span>' + esc(r.text || '') + '</span></span>';
        } else {
            h += '<input type="text" data-name="' + r.name + '" value="' + esc(nativeVal(form, r.name)) + '" placeholder="' + esc(r.ph || '') + '" aria-label="' + esc(r.label) + '">';
        }
        if (r.tip) {
            h += '<span class="tip">' + r.tip + '</span>';
        }
        return h + '</div></div>';
    }

    function syncAccent(c) {
        if (!/^#[0-9a-fA-F]{6}$/.test(c)) return;
        var r = document.documentElement.style;
        r.setProperty('--yx-accent', c);
        r.setProperty('--yx-accent-h', c);
        r.setProperty('--yx-accent-soft', c + '1f');
        r.setProperty('--yx-accent-line', c + '66');
        r.setProperty('--yx-focus', c + '2e');
    }

    function initSettings() {
        var form = document.querySelector('form[action*="plugins-edit"]');
        if (!form) return;

        var panel = document.createElement('div');
        panel.className = 'yx-cfg';
        panel.innerHTML = SECTIONS.map(function (s) {
            return '<div class="yx-cfg-sec"><header>' + icon(s.icon) + '<h3>' + esc(s.title) + '</h3><span>' + esc(s.tip) + '</span></header>'
                + '<div class="yx-cfg-body">' + s.rows.map(function (r) {
                    return rowHtml(r, form);
                }).join('') + '</div></div>';
        }).join('');

        var save = document.createElement('div');
        save.className = 'yx-cfg-save';
        save.innerHTML = '<span class="dirty"><i></i>有未保存的更改</span><button type="button">保存设置</button>';

        $$('.typecho-option', form).forEach(function (n) {
            n.style.display = 'none';
        });
        form.appendChild(panel);
        form.appendChild(save);

        function mark() {
            save.classList.add('show');
        }

        function syncAll() {
            $$('[data-name]', panel).forEach(function (el) {
                var name = el.getAttribute('data-name');
                var val = '';
                if (el.classList.contains('yx-seg')) {
                    var on = $('button.on', el);
                    val = on ? on.getAttribute('data-v') : '';
                } else if (el.type === 'checkbox') {
                    val = el.checked ? el.getAttribute('data-on') : (el.getAttribute('data-on') === '1' ? '0' : '1');
                    var tx = $('.tx', el.parentNode);
                    if (tx) tx.textContent = el.checked ? '已开启' : '已关闭';
                } else if (el.tagName === 'SELECT' || el.type === 'text' || el.type === 'color') {
                    val = el.value;
                }
                if (name && val !== '') {
                    setNative(form, name, val);
                }
            });
        }

        $$('.yx-seg button', panel).forEach(function (b) {
            b.addEventListener('click', function () {
                $$('button', b.parentNode).forEach(function (x) {
                    x.classList.remove('on');
                });
                b.classList.add('on');
                mark();
            });
        });

        $$('.yx-sw input', panel).forEach(function (cb) {
            cb.addEventListener('change', mark);
        });

        $$('.yx-cfg-swatches', panel).forEach(function (sw) {
            var input = $('input[type="color"]', sw.parentNode);
            $$('button', sw).forEach(function (b) {
                b.addEventListener('click', function () {
                    var c = b.getAttribute('data-c');
                    if (input) input.value = c;
                    $$('button', sw).forEach(function (x) {
                        x.classList.remove('on');
                    });
                    b.classList.add('on');
                    syncAccent(c);
                    mark();
                });
            });
            if (input) {
                input.addEventListener('input', function () {
                    $$('button', sw).forEach(function (x) {
                        x.classList.toggle('on', x.getAttribute('data-c') === input.value);
                    });
                    syncAccent(input.value);
                    mark();
                });
            }
            $$('button', sw).forEach(function (b) {
                b.classList.toggle('on', b.getAttribute('data-c') === (input ? input.value : ''));
            });
        });

        function syncPreviews() {
            $$('.yx-cfg-preview', panel).forEach(function (pv) {
                var input = pv.parentNode.querySelector('input[type="text"]');
                var box = $('.box', pv);
                var url = input ? input.value.trim() : '';
                if (url) {
                    box.innerHTML = '<img src="' + esc(url) + '" alt="" onerror="this.parentNode.textContent=\'\\u26A0\';">';
                } else {
                    box.innerHTML = icon('i-img');
                }
            });
        }

        $$('.yx-cfg-row input[type="text"], .yx-cfg-row select', panel).forEach(function (el) {
            el.addEventListener('input', function () {
                mark();
                if (el.getAttribute('data-name') === 'accent') {
                    syncAccent(el.value);
                }
                syncPreviews();
            });
            el.addEventListener('change', mark);
        });

        $$('[data-pick]', panel).forEach(function (b) {
            b.addEventListener('click', function () {
                var input = b.parentNode.querySelector('input[type="text"]');
                if (!window.YXPicker) return;
                window.YXPicker.open({
                    tab: 'local',
                    onPick: function (it) {
                        if (input) {
                            input.value = it.url;
                        }
                        syncPreviews();
                        mark();
                    }
                });
            });
        });

        $('button', save).addEventListener('click', function () {
            syncAll();
            var btn = form.querySelector('button[type="submit"]');
            if (btn) {
                btn.click();
            } else if (form.requestSubmit) {
                form.requestSubmit();
            } else {
                form.submit();
            }
        });

        syncPreviews();
        syncAccent(nativeVal(form, 'accent'));

        var tip = document.getElementById('YxTip');
        if (tip) {
            var ok = window.HTMLScriptElement && HTMLScriptElement.supports && HTMLScriptElement.supports('speculationrules');
            tip.textContent = ok ? '当前浏览器支持' : '不支持，请用普通模式';
            tip.style.background = ok ? 'var(--yx-ok-soft)' : 'var(--yx-danger-soft)';
            tip.style.color = ok ? 'var(--yx-ok)' : 'var(--yx-danger)';
        }
    }

    var GROUP_LABEL = {
        administrator: '管理员', editor: '编辑', author: '作者',
        contributor: '贡献者', subscriber: '关注者'
    };
    var POST_STATUS = {
        publish: ['已发布', 'ok'], draft: ['草稿', 'warn'],
        private: ['私密', 'info'], waiting: ['待审核', 'warn'],
        password: ['密码保护', 'info']
    };

    
    function initProfile() {
        var main = $('.typecho-page-main');
        var panel = $('.typecho-page-main .typecho-content-panel');
        if (!main || !panel) return;

        main.classList.add('yx-profile');


        var side = $('.typecho-page-main > .col-tb-3');
        var ava = side ? $('.profile-avatar', side) : null;
        var avaSrc = ava ? ava.getAttribute('src') : '';
        if (side) side.style.display = 'none';

        var adminBase = (window.YX_CFG && window.YX_CFG.adminUrl) ? window.YX_CFG.adminUrl : '/admin/';


        var formSections = [];
        Array.prototype.slice.call(panel.children).forEach(function (n) {
            if (n.tagName === 'BR') {
                if (n.parentNode) n.parentNode.removeChild(n);
                return;
            }
            if (n.tagName === 'SECTION') formSections.push(n);
        });

        function fieldVal(name) {
            var f = $('input[name="' + name + '"], textarea[name="' + name + '"]', panel);
            return f ? String(f.value || '').trim() : '';
        }

        var syncUser = {
            uid: '',
            name: '',
            screenName: fieldVal('screenName'),
            mail: fieldVal('mail'),
            url: fieldVal('url'),
            group: '',
            registered: ''
        };


        var hero = document.createElement('div');
        hero.className = 'yx-pf-hero';

        var cover = document.createElement('div');
        cover.className = 'yx-pf-cover';
        cover.setAttribute('aria-hidden', 'true');
        hero.appendChild(cover);

        var heroBody = document.createElement('div');
        heroBody.className = 'yx-pf-hero-body';
        hero.appendChild(heroBody);

        var avaBox = document.createElement('div');
        avaBox.className = 'yx-pf-ava';
        heroBody.appendChild(avaBox);

        var meta = document.createElement('div');
        meta.className = 'yx-pf-hero-meta';
        heroBody.appendChild(meta);

        var editBtn = document.createElement('button');
        editBtn.type = 'button';
        editBtn.className = 'yx-pf-hero-edit';
        editBtn.innerHTML = icon('i-write') + '<span>编辑资料</span>';
        editBtn.addEventListener('click', function () { switchPane('form'); });
        heroBody.appendChild(editBtn);

        function pfChip(ic, tx) {
            var c = document.createElement('span');
            c.className = 'yx-pf-chip';
            c.innerHTML = icon(ic) + '<span>' + esc(tx) + '</span>';
            return c;
        }

        function fillHero(u) {
            avaBox.innerHTML = '';
            if (avaSrc) {
                var img = document.createElement('img');
                img.src = avaSrc;
                img.alt = '';
                avaBox.appendChild(img);
            } else {
                avaBox.innerHTML = icon('i-user');
            }

            meta.innerHTML = '';
            var nm = document.createElement('div');
            nm.className = 'nm';
            var strong = document.createElement('strong');
            strong.textContent = u.screenName || u.name || '用户';
            nm.appendChild(strong);
            var group = GROUP_LABEL[u.group] || u.group || '';
            if (group) {
                var b = document.createElement('span');
                b.className = 'yx-pf-badge';
                b.textContent = group;
                nm.appendChild(b);
            }
            meta.appendChild(nm);

            if (u.name) {
                var handle = document.createElement('div');
                handle.className = 'handle';
                handle.textContent = '@' + u.name;
                meta.appendChild(handle);
            }

            if (u.mail || u.url) {
                var bio = document.createElement('div');
                bio.className = 'bio';
                if (u.mail) bio.appendChild(pfChip('i-link', u.mail));
                if (u.url) bio.appendChild(pfChip('i-globe', u.url));
                meta.appendChild(bio);
            }

            var chips = document.createElement('div');
            chips.className = 'chips';
            if (u.uid) chips.appendChild(pfChip('i-user', 'UID ' + u.uid));
            if (u.registered) chips.appendChild(pfChip('i-clock', u.registered + ' 注册'));
            if (chips.children.length) meta.appendChild(chips);
        }


        var statsBar = document.createElement('div');
        statsBar.className = 'yx-pf-stats';

        function renderStats(st) {
            statsBar.innerHTML = '';
            var items = [
                [st.posts, '文章', 'i-post', 'manage-posts.php'],
                [st.pages, '页面', 'i-page', 'manage-pages.php'],
                [st.comments, '评论', 'i-cmt', 'manage-comments.php'],
                [st.attachments, '附件', 'i-file', 'manage-medias.php'],
                [st.drafts, '草稿', 'i-write', 'manage-posts.php?status=draft']
            ];
            items.forEach(function (it) {
                var a = document.createElement('a');
                a.className = 'yx-pf-stat';
                a.href = adminBase + it[3];
                a.innerHTML = '<b>' + esc(it[0] || 0) + '</b>'
                    + '<span>' + icon(it[2]) + esc(it[1]) + '</span>';
                statsBar.appendChild(a);
            });
        }

        // ---- Tab ----
        var tabs = document.createElement('div');
        tabs.className = 'yx-pf-tabs';
        var panes = document.createElement('div');
        panes.className = 'yx-pf-panes';

        function switchPane(name) {
            $$('.yx-pf-tab', tabs).forEach(function (t) {
                t.classList.toggle('on', t.getAttribute('data-tab') === name);
            });
            $$('.yx-pf-pane', panes).forEach(function (p) {
                p.classList.toggle('on', p.getAttribute('data-pane') === name);
            });
        }

        [['notes', 'i-post', '动态'], ['form', 'i-gear', '资料'], ['tools', 'i-panel', '工具']].forEach(function (t, i) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'yx-pf-tab' + (i === 0 ? ' on' : '');
            b.setAttribute('data-tab', t[0]);
            b.innerHTML = '<span class="ic">' + icon(t[1]) + '</span>' + esc(t[2]);
            b.addEventListener('click', function () { switchPane(t[0]); });
            tabs.appendChild(b);
        });

        var paneNotes = document.createElement('div');
        paneNotes.className = 'yx-pf-pane on';
        paneNotes.setAttribute('data-pane', 'notes');
        var notesGrid = document.createElement('div');
        notesGrid.className = 'yx-pf-notes';
        paneNotes.appendChild(notesGrid);

        var paneForm = document.createElement('div');
        paneForm.className = 'yx-pf-pane';
        paneForm.setAttribute('data-pane', 'form');
        formSections.forEach(function (s) { paneForm.appendChild(s); });

        var paneTools = document.createElement('div');
        paneTools.className = 'yx-pf-pane';
        paneTools.setAttribute('data-pane', 'tools');

        panes.appendChild(paneNotes);
        panes.appendChild(paneForm);
        panes.appendChild(paneTools);

        var wrap = document.createElement('div');
        wrap.className = 'yx-pf';
        wrap._pfSwitch = switchPane;
        wrap.appendChild(hero);
        wrap.appendChild(statsBar);
        wrap.appendChild(tabs);
        wrap.appendChild(panes);
        panel.appendChild(wrap);

        function renderNotes(list) {
            notesGrid.innerHTML = '';
            if (!list.length) {
                var empty = document.createElement('div');
                empty.className = 'yx-pf-notes-empty';
                empty.innerHTML = icon('i-post') + '<span>还没有发布过文章，去写第一篇吧</span>';
                notesGrid.appendChild(empty);
                return;
            }
            list.forEach(function (r) {
                var card = document.createElement('a');
                card.className = 'yx-pf-note';
                card.href = adminBase + 'write-post.php?cid=' + r.cid;

                var s = POST_STATUS[r.status] || [r.status || '未知', 'flat'];

                var cov = document.createElement('div');
                cov.className = 'cov';
                var pill = document.createElement('span');
                pill.className = 'st ' + s[1];
                pill.textContent = s[0];
                cov.appendChild(pill);
                var ini = document.createElement('span');
                ini.className = 'ini';
                ini.textContent = String(r.title || '文').trim().charAt(0) || '文';
                cov.appendChild(ini);
                card.appendChild(cov);

                var tt = document.createElement('div');
                tt.className = 'tt';
                tt.textContent = r.title || '无标题';
                card.appendChild(tt);

                var mt = document.createElement('div');
                mt.className = 'mt';
                var d1 = document.createElement('span');
                d1.innerHTML = icon('i-clock') + esc(r.date || '');
                var d2 = document.createElement('span');
                d2.innerHTML = icon('i-cmt') + esc(r.comments || 0);
                mt.appendChild(d1);
                mt.appendChild(d2);
                card.appendChild(mt);

                notesGrid.appendChild(card);
            });
        }

        function renderTools(d, u) {
            paneTools.innerHTML = '';
            paneTools.appendChild(buildProfileActions(u || syncUser, (d && d.stats) || {}));
            if (d && d.perms && d.perms.length) {
                var permCard = document.createElement('section');
                permCard.className = 'yx-pf-card yx-pf-perms-card';
                permCard.innerHTML = '<h3>' + icon('i-shield') + '权限能力</h3>';
                var box = document.createElement('div');
                box.className = 'yx-pf-perms';
                d.perms.forEach(function (p) {
                    var chip = document.createElement('span');
                    chip.className = 'yx-pf-chip';
                    chip.innerHTML = icon('i-check') + '<span>' + esc(p) + '</span>';
                    box.appendChild(chip);
                });
                permCard.appendChild(box);
                paneTools.appendChild(permCard);
            }
        }

        fillHero(syncUser);
        renderStats({});
        renderNotes([]);
        renderTools(null, syncUser);

        if (!API) return;
        fetch(API + '?action=me', { credentials: 'same-origin' }).then(function (r) {
            return r.json();
        }).then(function (d) {
            if (!d || d.status !== true) return;
            var u = d.user || {};
            if (!u.screenName) u.screenName = syncUser.screenName;
            if (!u.mail) u.mail = syncUser.mail;
            if (!u.url) u.url = syncUser.url;
            fillHero(u);
            renderStats(d.stats || {});
            renderNotes(d.recent || []);
            renderTools(d, u);
        }).catch(function () { });
    }

    
    var PROFILE_ACTIONS = [
        { k: 'edit', ic: 'i-write', tx: '编辑昵称', tip: '修改你在前台显示的昵称', act: 'edit-name' },
        { k: 'mail', ic: 'i-link', tx: '更换邮箱', tip: '更新绑定邮箱，用于接收评论通知', act: 'edit-mail' },
        { k: 'url', ic: 'i-globe', tx: '个人主页', tip: '设置你在前台的个人主页地址', act: 'edit-url' },
        { k: 'pwd', ic: 'i-shield', tx: '修改密码', tip: '定期更换密码可提升账户安全', act: 'edit-pwd' },
        { k: 'avatar', ic: 'i-img', tx: '更换头像', tip: '在外观设置中更换站点 LOGO 头像', act: 'avatar' },
        { k: 'theme', ic: 'i-paint', tx: '外观偏好', tip: '切换白天 / 夜间模式与主题色', act: 'theme' },
        { k: 'draft', ic: 'i-file', tx: '我的草稿', tip: '查看所有未发布的草稿', act: 'drafts' },
        { k: 'posts', ic: 'i-post', tx: '我的文章', tip: '管理你发布的全部文章', act: 'posts' },
        { k: 'cmt', ic: 'i-cmt', tx: '我的评论', tip: '查看收到的评论与审核状态', act: 'comments' },
        { k: 'media', ic: 'i-upload', tx: '我的附件', tip: '查看你上传过的所有文件', act: 'media' },
        { k: 'backup', ic: 'i-down', tx: '导出数据', tip: '导出你的内容数据为 CSV 表格', act: 'export' },
        { k: 'logout', ic: 'i-out', tx: '退出登录', tip: '安全退出当前后台会话', act: 'logout', danger: true }
    ];

    function buildProfileActions(u, st) {


        var sec = document.createElement('section');
        sec.className = 'yx-pf-card yx-pf-actions';

        var adminBase = (window.YX_CFG && window.YX_CFG.adminUrl) ? window.YX_CFG.adminUrl : '/admin/';

        function go(p) {
            window.location.href = adminBase + p;
        }

        var map = {
            'edit-name': function () { focusField('screenName', '请在下方"个人资料"中修改昵称'); },
            'edit-mail': function () { focusField('mail', '请在下方"个人资料"中修改邮箱'); },
            'edit-url': function () { focusField('url', '请在下方"个人资料"中修改主页地址'); },
            'edit-pwd': function () { focusField('password', '请在下方"修改密码"中设置新密码'); },
            'avatar': function () { go('options-plugin.php?config=YunxiAdmin'); },
            'theme': function () { go('options-plugin.php?config=YunxiAdmin'); },
            'drafts': function () { go('manage-posts.php?status=draft'); },
            'posts': function () { go('manage-posts.php'); },
            'comments': function () { go('manage-comments.php'); },
            'media': function () { go('manage-medias.php'); },
            'export': function () { exportProfileCsv(u, st); },
            'logout': function () {
                var a = $('a[href*="logout"]');
                if (a) { a.click(); }
                else { window.location.href = adminBase + '?logout=1'; }
            }
        };

        var head = document.createElement('h3');
        head.innerHTML = icon('i-panel') + '<span>个人中心</span>';
        sec.appendChild(head);

        var grid = document.createElement('div');
        grid.className = 'yx-pf-act-grid';

        PROFILE_ACTIONS.forEach(function (a) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'yx-pf-act' + (a.danger ? ' danger' : '');
            b.setAttribute('data-tip', a.tip);

            var ic = document.createElement('span');
            ic.className = 'ic';
            ic.innerHTML = icon(a.ic);
            b.appendChild(ic);

            var tx = document.createElement('span');
            tx.className = 'tx';
            tx.textContent = a.tx;
            b.appendChild(tx);

            b.addEventListener('click', function () {
                var fn = map[a.act];
                if (fn) { try { fn(); } catch (e) { } }
            });
            grid.appendChild(b);
        });

        sec.appendChild(grid);
        return sec;
    }

    function focusField(name, msg) {
        var w = $('.yx-pf');
        if (w && w._pfSwitch) { w._pfSwitch('form'); }
        var el = $('input[name="' + name + '"], textarea[name="' + name + '"]');
        if (el) {
            el.scrollIntoView({ block: 'center', behavior: 'smooth' });
            try { el.focus(); } catch (e) { }
            el.classList.add('yx-pf-flash');
            setTimeout(function () { el.classList.remove('yx-pf-flash'); }, 1600);
        }
        pfToast(msg || '已定位到对应位置');
    }

    function pfToast(msg) {
        var t = $('.yx-pf-toast');
        if (!t) {
            t = document.createElement('div');
            t.className = 'yx-pf-toast';
            document.body.appendChild(t);
        }
        t.textContent = msg;
        t.classList.add('show');
        clearTimeout(t._tm);
        t._tm = setTimeout(function () { t.classList.remove('show'); }, 2200);
    }

    function exportProfileCsv(u, st) {
        var rows = [
            ['项目', '数值'],
            ['昵称', u.screenName || u.name || ''],
            ['用户名', u.name || ''],
            ['邮箱', u.mail || ''],
            ['主页', u.url || ''],
            ['注册时间', u.registered || ''],
            ['已发布文章', st.posts || 0],
            ['草稿', st.drafts || 0],
            ['独立页面', st.pages || 0],
            ['附件', st.attachments || 0],
            ['评论', st.comments || 0]
        ];
        var csv = rows.map(function (r) {
            return '"' + String(r[0]).replace(/"/g, '""') + '","' + String(r[1]).replace(/"/g, '""') + '"';
        }).join('\r\n');
        var blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8;' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'profile-' + (u.name || 'me') + '-' + new Date().toISOString().slice(0, 10) + '.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
        pfToast('已导出个人数据');
    }

    var STATUS_TEXT = [
        ['已通过', 'ok'], ['待审核', 'warn'], ['待审', 'warn'], ['垃圾', 'danger'],
        ['隐藏', 'flat'], ['密码保护', 'info'], ['私密', 'info']
    ];

    var STATUS_KEY = {
        publish: ['已发布', 'ok'],
        draft: ['草稿', 'warn'],
        waiting: ['待审', 'warn'],
        hidden: ['隐藏', 'flat'],
        password: ['密码保护', 'info'],
        private: ['私密', 'info']
    };

    function copyText(text, done) {
        var ok = function () {
            var t = document.createElement('div');
            t.className = 'yx-toast show';
            t.textContent = done || '已复制';
            document.body.appendChild(t);
            setTimeout(function () { t.remove(); }, 1800);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(ok, function () { window.prompt('复制', text); });
        } else {
            window.prompt('复制', text);
        }
    }

    function badgeCell(td) {
        if (!td || td.children.length) return false;
        var t = (td.textContent || '').trim();
        if (!t || t.length > 6) return false;
        for (var i = 0; i < STATUS_TEXT.length; i++) {
            if (t === STATUS_TEXT[i][0]) {
                td.innerHTML = '<span class="yx-st ' + STATUS_TEXT[i][1] + '">' + esc(t) + '</span>';
                return true;
            }
        }
        return false;
    }

    function listBar(iconName, filters, placeholder, onFilter) {
        var bar = document.createElement('div');
        bar.className = 'yx-user-bar yx-list-bar';
        bar.innerHTML = '<span class="st">' + icon(iconName) + '<b class="tt"></b></span>'
            + '<span class="yx-filters"></span>'
            + '<span class="sp"></span>'
            + '<label class="yx-filter">' + icon('i-search')
            + '<input type="search" placeholder="' + esc(placeholder) + '" aria-label="筛选"></label>';
        var fs = $('.yx-filters', bar);
        fs.innerHTML = filters.map(function (f, i) {
            return '<button type="button" data-v="' + esc(f[0]) + '"' + (i === 0 ? ' class="on"' : '') + '>' + esc(f[1]) + '</button>';
        }).join('');

        function fire(v, q) {
            onFilter(v || '', (q || '').trim().toLowerCase());
        }

        $$('button', fs).forEach(function (b) {
            b.addEventListener('click', function () {
                $$('button', fs).forEach(function (x) { x.classList.remove('on'); });
                b.classList.add('on');
                fire(b.getAttribute('data-v'), $('.yx-filter input', bar).value);
            });
        });
        $('.yx-filter input', bar).addEventListener('input', function () {
            var on = $('button.on', fs);
            fire(on ? on.getAttribute('data-v') : '', this.value);
        });
        return bar;
    }

    function mountBar(bar, wrap) {
        if (wrap && wrap.parentNode) {
            wrap.parentNode.insertBefore(bar, wrap);
            return;
        }
        var main = document.querySelector('.yx-main .yx-wrap');
        if (main) main.insertBefore(bar, main.firstChild);
    }

    
    function rowForm() {
        return $('form.operate-form') || ($('.typecho-list-table') && $('.typecho-list-table').closest('form'));
    }

    function nativeDeleteUrl() {
        var a = $('.typecho-list-operate .dropdown-menu a[href*="do=delete"]');
        return a ? (a.getAttribute('href') || '') : '';
    }

    function submitRowDelete(rowEl, delUrl, label) {
        var form = rowForm();
        if (!form || !delUrl) {
            window.alert('删除入口不可用，请刷新页面后重试');
            return;
        }
        if (!window.confirm('确认删除「' + (label || '该条目') + '」？删除后不可恢复。')) {
            return;
        }
        $$('.typecho-list-table input[type="checkbox"], .typecho-list-notable input[type="checkbox"]').forEach(function (c) {
            c.checked = false;
        });
        var cb = rowEl.querySelector('input[type="checkbox"]');
        if (cb) cb.checked = true;
        form.setAttribute('action', delUrl);
        form.submit();
    }

    function opsHeadCell(head, text) {
        if (!head || $('.yx-uops', head)) return;
        var th = document.createElement('th');
        th.className = 'yx-uops';
        th.textContent = text || '操作';
        head.appendChild(th);
    }

    function buildOpsCell(rowEl, editHref, delUrl, label) {
        var td = document.createElement('td');
        td.className = 'yx-uops';
        if (delUrl) {
            var del = document.createElement('button');
            del.type = 'button';
            del.className = 'yx-uop del';
            del.textContent = '删除';
            del.addEventListener('click', function () {
                submitRowDelete(rowEl, delUrl, label);
            });
            td.appendChild(del);
        }
        return td;
    }

    function initContents() {
        var table = $('.typecho-list-table');
        if (!table || table.dataset.yxList) return;
        var body = $('tbody', table);
        if (!body) return;
        table.dataset.yxList = '1';

        var isPage = window.location.href.indexOf('manage-pages.php') > -1;
        var rows = $$('tr', body);
        var cidRe = /(?:write-post|write-page)\.php\?cid=(\d+)/;
        var delUrl = nativeDeleteUrl();

        opsHeadCell($('thead tr', table));

        rows.forEach(function (tr) {
            $$('td', tr).forEach(badgeCell);
            var a = $('a[href*="write-post.php?cid="], a[href*="write-page.php?cid="]', tr);
            if (!a) return;
            var m = String(a.getAttribute('href')).match(cidRe);
            if (m) tr.setAttribute('data-cid', m[1]);
            if ($('.yx-uops', tr)) return;
            tr.appendChild(buildOpsCell(tr, a.getAttribute('href'), delUrl, (a.textContent || '').trim()));
        });

        var filters = [['', '全部'], ['publish', '已发布'], ['draft', '草稿'], ['waiting', '待审'], ['password', '密码'], ['hidden', '隐藏']];
        var bar = listBar(isPage ? 'i-page' : 'i-post', filters, '搜索标题…', function (v, q) {
            var n = 0;
            rows.forEach(function (tr) {
                var st = tr.getAttribute('data-status') || '';
                var txt = (tr.textContent || '').toLowerCase();
                var ok = (!v || st === v) && (!q || txt.indexOf(q) > -1);
                tr.style.display = ok ? '' : 'none';
                if (ok) n++;
            });
            var tt = $('.tt', bar);
            if (tt) tt.textContent = n + ' / ' + rows.length + ' 条';
        });

        var wrap = table.closest('.typecho-table-wrap') || table;
        mountBar(bar, wrap);
        var tt = $('.tt', bar);
        if (tt) tt.textContent = rows.length + ' 条';

        if (!API) return;
        fetch(API + '?action=posts&type=' + (isPage ? 'page' : 'post'), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d || d.status !== true || !d.items) return;
                var map = {};
                d.items.forEach(function (it) { map[String(it.cid)] = it; });
                rows.forEach(function (tr) {
                    var cid = tr.getAttribute('data-cid');
                    var it = map[cid];
                    if (!it) return;
                    tr.setAttribute('data-status', it.status);
                    var info = STATUS_KEY[it.status];
                    if (!info) return;
                    var host = $('a[href*="write-post.php?cid="], a[href*="write-page.php?cid="]', tr);
                    if (host && !$('.yx-st', host.parentNode)) {
                        var b = document.createElement('span');
                        b.className = 'yx-st ' + info[1];
                        b.textContent = info[0];
                        host.parentNode.appendChild(b);
                    }
                });
            }).catch(function () {});
    }

    function emojiSrc(name, base) {
        if (!base) return '';
        if (name.indexOf('a_') === 0) return base + 'pack/a/' + name + '.webp';
        if (name.indexOf('bilibili_') === 0) return base + 'pack/bilibili/' + name + '.webp';
        if (name.indexOf('blobcat') === 0) return base + 'pack/blobcat/' + name + '.webp';
        if (name.indexOf('wb_') === 0) return base + 'weibo/' + name + '.webp';
        if (name.indexOf('tb_') === 0) return base + 'tieba/' + name + '.webp';
        if (name.indexOf('ca_') === 0) return base + 'coolapk/' + name + '.webp';
        var i = name.indexOf('_');
        if (i > 0) return base + name.slice(0, i) + '/' + name + '.svg';
        return base + name + '.svg';
    }

    function emojiNode(code, src) {
        var img = document.createElement('img');
        img.className = 'yx-emoji';
        img.src = src;
        img.alt = code;
        img.title = code;
        img.loading = 'lazy';
        return img;
    }

    function emojiPaint(root) {
        var cfg = window.YX_EMOJI;
        if (!root || !cfg || !cfg.base) return;
        var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
        var texts = [];
        var t;
        while ((t = walker.nextNode())) {
            if (t.nodeValue && t.nodeValue.indexOf('[') > -1) texts.push(t);
        }
        texts.forEach(function (node) {
            var txt = node.nodeValue;
            var re = /\[emoji:([A-Za-z0-9_]+)\]|\[([^\[\]\n]{1,10})\]/g;
            var frag = document.createDocumentFragment();
            var last = 0;
            var m;
            var hit = false;
            while ((m = re.exec(txt))) {
                var img = null;
                if (m[1]) {
                    img = emojiNode('[emoji:' + m[1] + ']', emojiSrc(m[1], cfg.base));
                } else if (m[2] && cfg.wx && Object.prototype.hasOwnProperty.call(cfg.wx, m[2])) {
                    img = emojiNode('[' + m[2] + ']', cfg.base + 'wx/' + cfg.wx[m[2]] + '.webp');
                }
                if (!img) continue;
                hit = true;
                if (m.index > last) frag.appendChild(document.createTextNode(txt.slice(last, m.index)));
                frag.appendChild(img);
                last = re.lastIndex;
            }
            if (!hit) return;
            if (last < txt.length) frag.appendChild(document.createTextNode(txt.slice(last)));
            if (node.parentNode) node.parentNode.replaceChild(frag, node);
        });
    }

    function initComments() {
        var table = $('.typecho-list-table');
        if (!table || table.dataset.yxList) return;
        var body = $('tbody', table);
        if (!body) return;
        table.dataset.yxList = '1';

        var rows = $$('tr', body);
        rows.forEach(function (tr) {
            emojiPaint($('.comment-content', tr) || tr);
        });
        rows.forEach(function (tr) {
            $$('td', tr).forEach(badgeCell);
        });

        var filters = [['', '全部'], ['已通过', '已通过'], ['待审', '待审'], ['垃圾', '垃圾']];
        var bar = listBar('i-cmt', filters, '搜索评论者或内容…', function (v, q) {
            var n = 0;
            rows.forEach(function (tr) {
                var txt = (tr.textContent || '');
                var ok = (!v || txt.indexOf(v) > -1) && (!q || txt.toLowerCase().indexOf(q) > -1);
                tr.style.display = ok ? '' : 'none';
                if (ok) n++;
            });
            var tt = $('.tt', bar);
            if (tt) tt.textContent = n + ' / ' + rows.length + ' 条';
        });

        var wrap = table.closest('.typecho-table-wrap') || table;
        mountBar(bar, wrap);
        var tt = $('.tt', bar);
        if (tt) tt.textContent = rows.length + ' 条';
    }

    function avatarOf(mail) {
        mail = (mail || '').toLowerCase();
        var m = mail.match(/^(\d{5,10})@qq\.com$/);
        if (m) {
            return 'https://q2.qlogo.cn/headimg_dl?dst_uin=' + m[1] + '&spec=640';
        }
        return 'https://weavatar.com/avatar/' + encodeURIComponent(mail) + '?s=80';
    }

    function initUsers() {
        var table = $('.typecho-list-table');
        if (!table) return;
        var head = $('thead tr', table);
        var body = $('tbody', table);
        if (!head || !body) return;

        var rows = $$('tr', body);
        var mails = [];
        rows.forEach(function (tr) {
            var a = $('a[href^="mailto:"]', tr);
            mails.push(a ? a.getAttribute('href').slice(7) : '');
        });

        var delAction = window.YX_USERS_DEL || '';
        var adminBase = (window.YX_CFG && window.YX_CFG.adminUrl) ? window.YX_CFG.adminUrl : '/admin/';

        var th = document.createElement('th');
        th.className = 'yx-ava';
        th.textContent = '头像';
        head.insertBefore(th, head.firstChild);

        var thOp = document.createElement('th');
        thOp.className = 'yx-uops';
        thOp.textContent = '操作';
        head.appendChild(thOp);

        var groupMap = { '管理员': 'administrator', '编辑': 'editor', '贡献者': 'contributor', '关注者': 'subscriber', '访问者': 'visitor' };

        rows.forEach(function (tr, i) {
            var td = document.createElement('td');
            td.className = 'yx-ava';
            if (mails[i]) {
                td.innerHTML = '<img src="' + esc(avatarOf(mails[i])) + '" alt="" loading="lazy" onerror="this.style.visibility=\'hidden\'">';
            }
            tr.insertBefore(td, tr.firstChild);

            $$('td', tr).forEach(function (c) {
                var txt = (c.textContent || '').trim();
                if (groupMap[txt]) {
                    c.innerHTML = '<span class="yx-grp ' + groupMap[txt] + '">' + esc(txt) + '</span>';
                }
            });

            var uid = '';
            var nameLink = $('a[href*="user.php?uid="]', tr);
            if (nameLink) {
                var m = /uid=(\d+)/.exec(nameLink.getAttribute('href') || '');
                if (m) {
                    uid = m[1];
                }
            }

            var opTd = document.createElement('td');
            opTd.className = 'yx-uops';

            if (uid && delAction) {
                var del = document.createElement('button');
                del.type = 'button';
                del.className = 'yx-uop del';
                del.setAttribute('data-uid', uid);
                del.textContent = '删除';
                del.addEventListener('click', function () {
                    deleteUserRow(tr, uid, delAction);
                });
                opTd.appendChild(del);
            }
            tr.appendChild(opTd);
        });


        $$('th', head).forEach(function (t) {
            var lb = (t.textContent || '').trim();
            if (lb === '用户权限' || lb === '用户组') {
                t.textContent = '权限';
            }
        });



        var allTh = $$('th', head);
        $$('col', table).forEach(function (c) {
            c.removeAttribute('width');
            c.style.width = '';
        });
        allTh.forEach(function (t) {
            t.removeAttribute('width');
            t.style.width = '';
            var label = (t.textContent || '').trim();
            if (label === '权限') {
                t.style.width = '96px';
            }
        });
        if (allTh[0]) allTh[0].style.width = '56px';

        var admins = 0;
        rows.forEach(function (tr) {
            if ($('.yx-grp.administrator', tr)) admins++;
        });

        var bar = document.createElement('div');
        bar.className = 'yx-user-bar';
        bar.innerHTML = '<span class="st">' + icon('i-users') + '共 <b>' + rows.length + '</b> 位用户</span>'
            + '<span class="st">' + icon('i-shield') + '管理员 <b>' + admins + '</b> 位</span>'
            + '<span class="sp"></span>'
            + '<label class="yx-filter">' + icon('i-search') + '<input type="search" placeholder="筛选用户"></label>';
        var wrap = table.closest('.typecho-table-wrap') || table;
        wrap.parentNode.insertBefore(bar, wrap);

        $('input', bar).addEventListener('input', function () {
            var q = (this.value || '').trim().toLowerCase();
            rows.forEach(function (tr) {
                tr.style.display = !q || (tr.textContent || '').toLowerCase().indexOf(q) > -1 ? '' : 'none';
            });
        });

        ensureUsersBulk(delAction);
    }

    function deleteUserRow(tr, uid, delAction) {
        var nameLink = $('a[href*="user.php?uid="]', tr);
        var name = nameLink ? (nameLink.textContent || '').trim() : '';
        if (!window.confirm('确认删除用户「' + (name || uid) + '」？删除后不可恢复。')) {
            return;
        }
        $$('.typecho-list-table input[type="checkbox"]').forEach(function (c) {
            c.checked = false;
        });
        var cb = tr.querySelector('input[type="checkbox"]');
        if (cb) {
            cb.checked = true;
        }
        var form = $('form.operate-form') || ($('.typecho-list-table') && $('.typecho-list-table').closest('form'));
        if (!form) {
            window.alert('删除入口不可用，请刷新页面后重试');
            return;
        }
        form.setAttribute('action', delAction);
        form.submit();
    }

    function ensureUsersBulk(delAction) {
        if (!delAction) {
            return;
        }
        var check = function () {
            var host = $$('.typecho-list-operate').pop();
            if (!host) {
                return;
            }
            var nativeBulk = host.querySelector('a[href*="users-edit"]');
            if (host.querySelector('.yx-users-bulk') || (nativeBulk && nativeBulk.offsetParent)) {
                return;
            }
            var bar = document.createElement('div');
            bar.className = 'yx-users-bulk';

            var all = document.createElement('label');
            all.className = 'yx-ub-all';
            all.innerHTML = '<input type="checkbox"> <span>全选</span>';
            bar.appendChild(all);

            var tip = document.createElement('span');
            tip.className = 'yx-ub-tip';
            tip.textContent = '勾选行后点击删除，可批量移除用户';
            bar.appendChild(tip);

            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'yx-ub-del';
            btn.textContent = '删除选中';
            btn.addEventListener('click', function () {
                var picked = 0;
                $$('.typecho-list-table input[type="checkbox"]').forEach(function (c) {
                    if (c.checked) {
                        picked++;
                    }
                });
                if (!picked) {
                    window.alert('请先勾选要删除的用户');
                    return;
                }
                if (!window.confirm('确认删除选中的 ' + picked + ' 位用户？删除后不可恢复。')) {
                    return;
                }
                var form = $('form.operate-form') || ($('.typecho-list-table') && $('.typecho-list-table').closest('form'));
                if (!form) {
                    return;
                }
                form.setAttribute('action', delAction);
                form.submit();
            });
            bar.appendChild(btn);

            host.appendChild(bar);
        };
        if (document.readyState === 'complete') {
            setTimeout(check, 900);
        } else {
            window.addEventListener('load', function () {
                setTimeout(check, 900);
            });
        }
    }

    
    function initCategories() {
        var table = $('.typecho-list-table');
        if (!table || table.dataset.yxMeta) return;
        var body = $('tbody', table);
        if (!body) return;
        table.dataset.yxMeta = '1';

        var delUrl = nativeDeleteUrl();
        opsHeadCell($('thead tr', table));

        var rows = $$('tr', body);
        rows.forEach(function (tr) {
            var editLink = $('a[href*="category.php?mid="]', tr);
            if (!editLink || $('.yx-uops', tr)) return;
            var name = (editLink.textContent || '').trim();
            tr.appendChild(buildOpsCell(tr, editLink.getAttribute('href'), delUrl, name));
        });

        var bar = listBar('i-folder', [['', '全部']], '搜索分类…', function (v, q) {
            var n = 0;
            rows.forEach(function (tr) {
                var ok = !q || (tr.textContent || '').toLowerCase().indexOf(q) > -1;
                tr.style.display = ok ? '' : 'none';
                if (ok) n++;
            });
            var tt = $('.tt', bar);
            if (tt) tt.textContent = n + ' / ' + rows.length + ' 条';
        });
        mountBar(bar, table.closest('.typecho-table-wrap') || table);
        var tt = $('.tt', bar);
        if (tt) tt.textContent = rows.length + ' 条';
    }

    
    function initTags() {
        var list = $('ul.typecho-list-notable.tag-list');
        if (!list || list.dataset.yxTags) return;
        list.dataset.yxTags = '1';

        var delUrl = nativeDeleteUrl();
        var items = $$('li', list).filter(function (li) {
            return !!li.querySelector('input[type="checkbox"]');
        });
        items.forEach(function (li) {
            if (li.querySelector('.yx-tag-ops')) return;
            var nameEl = $('span[rel]', li);
            var name = nameEl ? (nameEl.textContent || '').trim() : '';

            var box = document.createElement('span');
            box.className = 'yx-tag-ops';
            if (delUrl) {
                var del = document.createElement('button');
                del.type = 'button';
                del.className = 'yx-uop del';
                del.textContent = '删除';
                del.addEventListener('click', function () {
                    submitRowDelete(li, delUrl, name);
                });
                box.appendChild(del);
            }
            li.appendChild(box);
        });

        var bar = listBar('i-tag', [['', '全部']], '搜索标签…', function (v, q) {
            var n = 0;
            items.forEach(function (li) {
                var ok = !q || (li.textContent || '').toLowerCase().indexOf(q) > -1;
                li.style.display = ok ? '' : 'none';
                if (ok) n++;
            });
            var tt = $('.tt', bar);
            if (tt) tt.textContent = n + ' / ' + items.length + ' 条';
        });
        mountBar(bar, list);
        var tt = $('.tt', bar);
        if (tt) tt.textContent = items.length + ' 条';
    }

    
    function initMedias() {
        var table = $('.typecho-list-table');
        if (!table || table.dataset.yxMedia) return;
        var body = $('tbody', table);
        if (!body) return;
        table.dataset.yxMedia = '1';

        var delUrl = nativeDeleteUrl();
        opsHeadCell($('thead tr', table));

        var rows = $$('tr', body);
        rows.forEach(function (tr) {
            var editLink = $('a[href*="media.php?cid="]', tr);
            if (!editLink || $('.yx-uops', tr)) return;
            var name = (editLink.textContent || '').trim();
            tr.appendChild(buildOpsCell(tr, editLink.getAttribute('href'), delUrl, name));
        });

        var bar = listBar('i-file', [['', '全部']], '搜索文件名…', function (v, q) {
            var n = 0;
            rows.forEach(function (tr) {
                var ok = !q || (tr.textContent || '').toLowerCase().indexOf(q) > -1;
                tr.style.display = ok ? '' : 'none';
                if (ok) n++;
            });
            var tt = $('.tt', bar);
            if (tt) tt.textContent = n + ' / ' + rows.length + ' 条';
        });
        mountBar(bar, table.closest('.typecho-table-wrap') || table);
        var tt = $('.tt', bar);
        if (tt) tt.textContent = rows.length + ' 条';
    }

    function initMediaGrid() {
        var table = $('.typecho-list-table');
        if (!table || !$('td a[href*="media.php"]', table)) return;
        var wrap = table.closest('.typecho-table-wrap');
        if (!wrap) return;
        var delUrl = nativeDeleteUrl();
        var grid = document.createElement('div');
        grid.className = 'yx-media-grid';
        $$('tbody tr', table).forEach(function (tr) {
            var a = $('td a[href*="media.php"]', tr);
            if (!a) return;
            var img = $('td img', tr);
            var url = img ? img.getAttribute('src') : '';
            var name = (a.textContent || '').trim();

            var cell = document.createElement('div');
            cell.className = 'mi';

            var it = document.createElement('a');
            it.className = 'it';
            it.href = a.getAttribute('href');
            var th = url && img
                ? '<img src="' + esc(url) + '" alt="" loading="lazy">'
                : icon('i-file');
            it.innerHTML = '<span class="th">' + th + '</span>'
                + '<span class="tx"><span class="nm">' + esc(a.textContent) + '</span></span>';
            cell.appendChild(it);

            var ops = document.createElement('div');
            ops.className = 'mi-ops';
            if (delUrl) {
                var del = document.createElement('button');
                del.type = 'button';
                del.className = 'yx-uop del';
                del.textContent = '删除';
                del.addEventListener('click', function () {
                    submitRowDelete(tr, delUrl, name);
                });
                ops.appendChild(del);
            }
            cell.appendChild(ops);

            if (url) {
                var cp = document.createElement('button');
                cp.type = 'button';
                cp.className = 'cp';
                cp.title = '复制链接';
                cp.setAttribute('aria-label', '复制链接');
                cp.innerHTML = icon('i-link');
                cp.addEventListener('click', function () {
                    copyText(url, '链接已复制');
                });
                cell.appendChild(cp);
            }
            grid.appendChild(cell);
        });
        if (grid.children.length) {
            wrap.parentNode.insertBefore(grid, wrap);
        }
    }

    function initPlugins() {
        var table = $('.typecho-list-table');
        if (!table || table.dataset.yxPlg) return;
        table.dataset.yxPlg = '1';

        var rows = $$('tbody tr', table);
        if (!rows.length) return;

        var enabled = 0;
        rows.forEach(function (tr) {
            var tds = $$('td', tr);
            if (!tds.length) return;

            var ops = tds[tds.length - 1];
            if (ops && (ops.textContent || '').indexOf('禁用') > -1) {
                enabled++;
            }

            var desc = tds.length > 1 ? tds[1] : null;
            if (desc && !(desc.textContent || '').trim()) {
                desc.innerHTML = '<span class="yx-desc-none">作者未在插件定义中填写描述信息；'
                    + '可在插件目录的 Plugin.php 头部注释中补充 Description 字段，保存后此处会自动展示完整介绍。</span>';
            }
        });

        var wrap = table.closest('.typecho-table-wrap') || table;
        if ($('.yx-user-bar', wrap.parentNode)) return;
        var bar = document.createElement('div');
        bar.className = 'yx-user-bar';
        bar.innerHTML = '<span class="st">' + icon('i-plug') + '已安装 <b>' + rows.length + '</b> 个插件</span>'
            + '<span class="st">' + icon('i-check') + '启用中 <b>' + enabled + '</b> 个</span>'
            + '<span class="sp"></span>';
        wrap.parentNode.insertBefore(bar, wrap);
    }

    function boot() {
        if (document.querySelector('form[action*="plugins-edit"]')) {
            initSettings();
        }
        if (document.getElementById('personal-YunxiAdmin') || $('.profile-avatar')) {
            initProfile();
        }
        if (window.location.href.indexOf('manage-users.php') > -1) {
            initUsers();
        }
        if (/(^|\/)plugins\.php$/.test(window.location.pathname)) {
            initPlugins();
        }
        if (window.location.href.indexOf('manage-medias.php') > -1) {
            initMedias();
            initMediaGrid();
        }
        if (/manage-posts\.php|manage-pages\.php/.test(window.location.href)) {
            initContents();
        }
        if (window.location.href.indexOf('manage-comments.php') > -1) {
            initComments();
        }
        if (window.location.href.indexOf('manage-categories.php') > -1) {
            initCategories();
        }
        if (window.location.href.indexOf('manage-tags.php') > -1) {
            initTags();
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
