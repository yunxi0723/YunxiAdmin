(function () {
    'use strict';

    var $ = function (s, c) {
        return (c || document).querySelector(s);
    };

    var $$ = function (s, c) {
        return Array.prototype.slice.call((c || document).querySelectorAll(s));
    };

    var SYS = 'system';
    var root = document.documentElement;

    function sysDark() {
        return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    }

    function themeResolve(mode) {
        return mode === SYS ? (sysDark() ? 'dark' : 'light') : mode;
    }

    function themeApply(mode) {
        root.setAttribute('data-theme', themeResolve(mode));
        root.setAttribute('data-theme-mode', mode);
    }

    var THEME_KEY = 'yx-theme';

    function storedTheme() {
        try {
            var v = localStorage.getItem(THEME_KEY);
            return v === 'light' || v === 'dark' ? v : null;
        } catch (e) {
            return null;
        }
    }

    function saveTheme(mode) {
        try {
            if (mode) {
                localStorage.setItem(THEME_KEY, mode);
            } else {
                localStorage.removeItem(THEME_KEY);
            }
        } catch (e) {}
    }

    var YX = {
        theme: {
            get mode() {
                var s = storedTheme();
                if (s) return s;
                var v = root.getAttribute('data-theme-mode');
                return v === 'light' || v === 'dark' ? v : SYS;
            },
            get current() {
                return themeResolve(this.mode);
            },
            toggle: function () {
                var next = this.current === 'dark' ? 'light' : 'dark';
                saveTheme(next);
                root.setAttribute('data-theme-mode', next);
                themeApply(next);
                document.dispatchEvent(new CustomEvent('yx:theme', { detail: { mode: next } }));
            },
            auto: function () {
                saveTheme(null);
                root.setAttribute('data-theme-mode', SYS);
                themeApply(SYS);
                document.dispatchEvent(new CustomEvent('yx:theme', { detail: { mode: SYS } }));
            },
            set: function (mode) {
                saveTheme(mode === SYS ? null : mode);
                root.setAttribute('data-theme-mode', mode);
                themeApply(mode);
                document.dispatchEvent(new CustomEvent('yx:theme', { detail: { mode: mode } }));
            }
        }
    };
    window.YX = window.YX || YX;
    if (!window.YX.theme) {
        window.YX.theme = YX.theme;
    }

    themeApply(YX.theme.mode);

    var mqTheme = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
    var onThemeSys = function () {
        if (!storedTheme()) {
            themeApply(YX.theme.mode);
            document.dispatchEvent(new CustomEvent('yx:theme', { detail: { mode: YX.theme.mode } }));
        }
    };
    if (mqTheme) {
        if (mqTheme.addEventListener) {
            mqTheme.addEventListener('change', onThemeSys);
        } else if (mqTheme.addListener) {
            mqTheme.addListener(onThemeSys);
        }
    }

    function initThemeBtn() {
        var btns = $$('[data-yx-theme-btn]');
        if (!btns.length) return;
        btns.forEach(function (btn) {
            btn.addEventListener('click', function () {
                if (window.YX && YX.theme && YX.theme.toggle) {
                    YX.theme.toggle();
                }
            });
        });
        document.addEventListener('yx:theme', function (e) {
            var mode = (e && e.detail && e.detail.mode) || (window.YX && YX.theme && YX.theme.current) || '';
            btns.forEach(function (btn) {
                btn.setAttribute('data-mode', mode);
            });
        });
    }

    var geoLast = null;

    function pickEsc(v) {
        return String(v == null ? '' : v).replace(/[&<>"]/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
        });
    }

    function pickIcon(name) {
        return '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#' + name + '"></use></svg>';
    }

    function fetchJSON(url, opt, timeout) {
        var ctrl = typeof AbortController === 'function' ? new AbortController() : null;
        var tm = setTimeout(function () {
            if (ctrl) ctrl.abort();
        }, timeout || 10000);
        var o = { credentials: 'same-origin' };
        if (opt) {
            Object.keys(opt).forEach(function (k) {
                o[k] = opt[k];
            });
        }
        if (ctrl) o.signal = ctrl.signal;
        return fetch(url, o).then(function (r) {
            clearTimeout(tm);
            return r.json();
        }).catch(function (e) {
            clearTimeout(tm);
            if (e && e.name === 'AbortError') {
                throw new Error('请求超时，请稍后重试');
            }
            throw e;
        });
    }

    
    function postJSON(url, body) {
        var ctrl = typeof AbortController === 'function' ? new AbortController() : null;
        var tm = setTimeout(function () {
            if (ctrl) ctrl.abort();
        }, 30000);
        var o = {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'X-YX-Req': '1', 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body || ''
        };
        if (ctrl) o.signal = ctrl.signal;
        return fetch(url, o).then(function (r) {
            clearTimeout(tm);
            return r.text().then(function (txt) {
                var d = null;
                try {
                    d = txt ? JSON.parse(txt) : null;
                } catch (e) {
                    d = null;
                }
                if (!d) {
                    throw new Error('服务端返回异常（HTTP ' + r.status + '）');
                }
                if (!r.ok) {
                    throw new Error(d.message || '请求失败');
                }
                return d;
            });
        }).catch(function (e) {
            clearTimeout(tm);
            if (e && e.name === 'AbortError') {
                throw new Error('请求超时，请稍后重试');
            }
            throw e;
        });
    }

    function sysToast(msg) {
        var old = document.querySelector('.yx-toast');
        if (old) old.remove();
        var n = document.createElement('div');
        n.className = 'yx-toast show';
        n.textContent = msg || '';
        document.body.appendChild(n);
        setTimeout(function () {
            if (n.parentNode) n.remove();
        }, 3200);
    }




    function initSeoFix() {
        if (!window.YX_API) return;

        function renderChecks(checks) {
            var ul = document.querySelector('[data-seo-list]');
            if (!ul || !checks || !checks.length) return;
            var h = '';
            checks.forEach(function (c) {
                var pass = !!c[1];
                h += '<li class="' + (pass ? 'on' : 'off') + '">'
                    + '<i class="st">' + (pass ? '✓' : '—') + '</i>'
                    + '<span class="n">' + pickEsc(c[0]) + '</span>'
                    + '<span class="d">' + pickEsc(c[3]) + '</span></li>';
            });
            ul.innerHTML = h;
        }

        function renderScore(score) {
            if (typeof score !== 'number') return;
            var lv = score >= 80 ? 'ok' : (score >= 50 ? 'warn' : 'danger');
            var ring = document.querySelector('.yd-seo-ring');
            if (ring) {
                ring.className = 'yd-seo-ring r-' + lv;
                var fg = ring.querySelector('.fg');
                if (fg) fg.setAttribute('stroke-dasharray', score + ' 100');
                var b = ring.querySelector('b');
                if (b) b.textContent = String(score);
            }
        }

        function run(btn, fix) {
            if (btn.getAttribute('data-yx-fixing') === '1') return;
            var label = (btn.textContent || '').trim() || '自动修复';
            if ((fix === 'spam' || fix === 'cmt') && window.confirm) {
                var ok = true;
                try {
                    ok = window.confirm('确定要执行「' + label + '」吗？此操作由后台自动完成。');
                } catch (e) {
                    ok = true;
                }
                if (!ok) return;
            }
            btn.setAttribute('data-yx-fixing', '1');
            btn.classList.add('busy');
            btn.textContent = '处理中…';
            postJSON(window.YX_API + '?action=seo_fix', 'fix=' + encodeURIComponent(fix))
                .then(function (d) {
                    btn.removeAttribute('data-yx-fixing');
                    btn.classList.remove('busy');
                    btn.textContent = label;
                    if (!d || !d.status) {
                        sysToast((d && d.message) || '修复失败，请稍后重试');
                        return;
                    }
                    if (d.fail && d.fail.length) {
                        sysToast((d.message || '已完成') + '：' + d.fail.join('；'));
                    } else {
                        sysToast(d.message || '已完成');
                    }
                    renderScore(d.score);
                    renderChecks(d.checks);
                    if (typeof window.__yxDashReload === 'function') {
                        window.__yxDashReload();
                    } else if (document.querySelector('[data-dl-adv]')) {

                        setTimeout(function () { window.location.reload(); }, 900);
                    }
                })
                .catch(function (err) {
                    btn.removeAttribute('data-yx-fixing');
                    btn.classList.remove('busy');
                    btn.textContent = label;
                    sysToast((err && err.message) || '修复失败，请检查网络后重试');
                });
        }

        document.addEventListener('click', function (e) {
            var t = e.target && e.target.closest ? e.target.closest('[data-yx-fix],[data-yx-fix-all]') : null;
            if (!t) return;
            e.preventDefault();
            if (t.hasAttribute('data-yx-fix-all')) {
                run(t, 'all');
                return;
            }
            var fix = t.getAttribute('data-yx-fix');
            if (fix) run(t, fix);
        });
    }

    function initDrawer() {
        var burger = $('.yx-mburger');
        var drawer = $('.yx-drawer');
        var scrim = $('.yx-scrim');
        if (!burger || !drawer || !scrim) return;

        function open() {
            drawer.classList.add('open');
            scrim.classList.add('open');
            document.body.classList.add('yx-lock');
        }

        function close() {
            drawer.classList.remove('open');
            scrim.classList.remove('open');
            document.body.classList.remove('yx-lock');
        }

        burger.addEventListener('click', open);
        scrim.addEventListener('click', close);
        var closeBtn = drawer.querySelector('.yx-dclose');
        if (closeBtn) closeBtn.addEventListener('click', close);
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') close();
        });
    }

    function initWeather() {
        var w = $('.yx-weather');
        if (!w) return;
        var btn = w.querySelector('.yx-weather-btn');
        if (btn) {
            btn.addEventListener('click', function (e) {
                e.stopPropagation();
                w.classList.toggle('open');
            });
        }
        document.addEventListener('click', function (e) {
            if (!w.contains(e.target)) w.classList.remove('open');
        });
        var input = w.querySelector('.yx-wp-city-row input');
        var switchBtn = w.querySelector('.yx-wp-city-row button');
        if (input && switchBtn) {
            function wIcon(text) {
                var t = String(text || '');
                if (t.indexOf('雷') > -1) return 'i-w-thunder';
                if (t.indexOf('雪') > -1) return 'i-w-snow';
                if (t.indexOf('雨') > -1) return 'i-w-rain';
                if (/雾|霾|沙|尘/.test(t)) return 'i-w-fog';
                if (/阴|云/.test(t)) return 'i-w-cloud';
                return 'i-w-sun';
            }
            function wPlace(d) {
                var city = d.city || d.province || '';
                if (d.district && city.indexOf(d.district) === -1) {
                    return city ? city + ' · ' + d.district : d.district;
                }
                return city || d.district || '定位中';
            }
            function apply(d) {
                var ICONS = window.YX_ICONS || '';
                var q = function (s) { return w.querySelector(s); };
                var t = q('[data-w-temp]');
                var c = q('[data-w-city]');
                if (t && isFinite(d.temperature)) t.textContent = Math.round(d.temperature) + '°';
                if (c) c.textContent = wPlace(d);
                var loc = q('[data-w-loc]');
                var tm = q('[data-w-time]');
                if (loc) loc.textContent = wPlace(d);
                if (tm) tm.textContent = String(d.report_time || '').slice(11, 16) + ' 更新';
                var big = q('[data-w-temp-big]');
                if (big && isFinite(d.temperature)) big.innerHTML = Math.round(d.temperature) + '<sup>°C</sup>';
                var meta = q('[data-w-meta]');
                if (meta) {
                    var wind = [d.wind_direction, d.wind_power].filter(Boolean).join(' ');
                    meta.textContent = (d.weather || '') + (wind ? ' ' + wind : '');
                }
                var ico = q('[data-w-icon] use');
                if (ico) ico.setAttribute('href', ICONS + '#' + wIcon(d.weather));
                w.removeAttribute('data-empty');
            }
            function sw() {
                var city = input.value.trim();
                if (!city || switchBtn.disabled) return;
                switchBtn.disabled = true;
                var hint = w.querySelector('[data-w-hint]');
                if (hint) hint.textContent = '正在定位…';
                fetchJSON(window.YX_API + '?action=weather&city=' + encodeURIComponent(city), null, 15000)
                    .then(function (j) {
                        switchBtn.disabled = false;
                        var d = (j && j.status && j.weather) ? j.weather : null;
                        if (!d || !d.city) throw new Error('bad');
                        apply(d);
                        if (hint) hint.textContent = '已切换到 ' + d.city + '，可在插件设置中固定';
                        input.value = '';
                        w.classList.remove('open');
                    })
                    .catch(function () {
                        switchBtn.disabled = false;
                        if (hint) hint.textContent = '定位失败，请检查网络或稍后再试';
                    });
            }
            switchBtn.addEventListener('click', sw);
            input.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    sw();
                }
            });
        }
    }

    function initGeo() {
        var card = document.querySelector('[data-geo]');
        if (!card) return;
        var body = card.querySelector('[data-geo-body]');
        var src = card.querySelector('[data-geo-src]');
        if (!body || !window.YX_API) return;

        function retry() {
            body.innerHTML = '<div class="yd-load err"><i></i>网络位置获取失败'
                + '<button type="button" class="yd-retry" data-geo-retry>重新获取</button></div>';
            if (src) src.textContent = '获取失败';
            var rb = body.querySelector('[data-geo-retry]');
            if (rb) {
                rb.addEventListener('click', function () {
                    body.innerHTML = '<div class="yd-load"><i></i>正在解析网络位置…</div>';
                    if (src) src.textContent = '获取中';
                    load();
                });
            }
        }

        function load() {
            fetchJSON(window.YX_API + '?action=geo', null, 25000).then(function (r) {
                if (!r || r.status !== true) {
                    retry();
                    return;
                }
                geoLast = r;
                var v = r.visitor || {};
                var s = r.server || {};
                if (src) {
                    src.textContent = v.ok ? (v.source || '已定位') : '定位失败';
                }
                var h = '<div class="yd-geo-v">'
                    + '<div class="ip">' + pickEsc(v.ip || '—') + '</div>'
                    + '<div class="pl">' + pickEsc(v.place || '未知位置') + '</div>'
                    + '<div class="mt">'
                    + (v.isp ? '<span>' + pickIcon('i-loc') + pickEsc(v.isp) + '</span>' : '')
                    + (v.timezone ? '<span>' + pickIcon('i-clock') + pickEsc(v.timezone) + '</span>' : '')
                    + (s.ip ? '<span>' + pickIcon('i-cloud') + '服务器 ' + pickEsc(s.place || s.ip) + '</span>' : '')
                    + '</div></div>';

                var near = r.nearby || [];
                if (near.length) {
                    h += '<div class="yd-geo-near"><div class="tt">附近热门'
                        + (v.place ? ' · ' + pickEsc(v.place) : '') + '</div><div class="chips">';
                    near.forEach(function (n) {
                        h += '<span class="chip">' + pickIcon('i-loc') + pickEsc(n.name || '')
                            + (n.distance !== null && n.distance !== undefined ? '<em>' + pickEsc(n.distance) + ' km</em>' : '')
                            + '</span>';
                    });
                    h += '</div></div>';
                }

                var peers = r.peers || [];
                if (peers.length) {
                    h += '<div class="yd-geo-peers"><div class="tt">评论者位置（来自评论 · 按距离）</div>'
                        + '<div class="yd-scroll"><table class="yd-table"><thead><tr>'
                        + '<th>IP</th><th>位置</th><th>距离</th><th>评论</th></tr></thead><tbody>';
                    peers.forEach(function (p) {
                        h += '<tr><td class="nm">' + pickEsc(p.ip) + '</td>'
                            + '<td>' + pickEsc(p.place || '—') + '</td>'
                            + '<td>' + (p.distance === null || p.distance === undefined ? '—' : pickEsc(p.distance) + ' km') + '</td>'
                            + '<td>' + pickEsc(p.comments || 0) + '</td></tr>';
                    });
                    h += '</tbody></table></div></div>';
                }
                body.innerHTML = h;
            }).catch(retry);
        }

        load();
    }

    function initAlerts() {
        var card = document.querySelector('[data-alerts]');
        if (!card) return;
        var body = card.querySelector('[data-alerts-body]');
        var src = card.querySelector('[data-alerts-src]');
        if (!body || !window.YX_API) return;

        function hide() {
            card.style.display = 'none';
        }

        function sub(title, iconCls, inner) {
            if (!inner) return '';
            return '<div class="yd-al-sub yd-al-' + iconCls + '">'
                + '<div class="yd-al-sub-h"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-' + iconCls + '"></use></svg>' + title + '</div>'
                + inner + '</div>';
        }

        function weatherHtml(list) {
            if (!list || !list.length) return '';
            var h = '<ul class="yd-alerts-list">';
            list.slice(0, 6).forEach(function (a) {
                h += '<li class="lv-' + pickEsc(a.level || 'none') + '">'
                    + '<span class="lv">' + pickEsc(a.level || '预警') + '</span>'
                    + '<div class="ct"><b>' + pickEsc(a.title || '') + '</b>'
                    + (a.content ? '<p>' + pickEsc(a.content) + '</p>' : '')
                    + '<span class="tm">' + pickEsc(a.issueTime || '') + '</span></div></li>';
            });
            h += '</ul>';
            return h;
        }

        function quakeHtml(list) {
            if (!list || !list.length) return '';
            var h = '<ul class="yd-quakes">';
            list.slice(0, 5).forEach(function (q) {
                var mag = parseFloat(q.magnitude || 0);
                var cls = mag >= 5 ? 's5' : (mag >= 4 ? 's4' : (mag >= 3 ? 's3' : 's2'));
                h += '<li class="qk-' + cls + '">'
                    + '<span class="mag">' + pickEsc(q.magnitude || '') + '</span>'
                    + '<div class="ct"><b>' + pickEsc(q.location || '地震') + '</b>'
                    + '<span class="tm">' + pickEsc(q.time || '') + ' · 深度 ' + pickEsc(q.depth || '?') + 'km'
                    + (q.intensity ? ' · 烈度 ' + pickEsc(q.intensity) : '') + '</span></div></li>';
            });
            h += '</ul>';
            return h;
        }

        function typhoonHtml(list) {
            if (!list || !list.length) return '';
            var h = '<ul class="yd-typhoons">';
            list.slice(0, 4).forEach(function (t) {
                h += '<li>'
                    + '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-typhoon"></use></svg>'
                    + '<div class="ct"><b>' + pickEsc(t.name || '台风')
                    + (t.enName ? ' <em>' + pickEsc(t.enName) + '</em>' : '') + '</b>'
                    + '<span class="tm">' + pickEsc(t.statusText || '活动中') + '</span></div></li>';
            });
            h += '</ul>';
            return h;
        }

        function render(r) {
            if (!r) { hide(); return; }
            var w = weatherHtml(r.items);
            var q = quakeHtml(r.quakes);
            var t = typhoonHtml(r.typhoons);
            if (!w && !q && !t) { hide(); return; }
            card.style.display = '';
            if (src) {
                var regionName = (r.region && r.region !== '') ? r.region : (r.province || r.city || '全国');
                var parts = [regionName];
                if (r.items && r.items.length) parts.push('气象预警 ' + r.items.length);
                if (r.quakes && r.quakes.length) parts.push('地震 ' + r.quakes.length);
                if (r.typhoons && r.typhoons.length) parts.push('台风 ' + r.typhoons.length);
                if (parts.length < 2) parts.push('暂无');
                src.textContent = parts.join(' · ');
            }
            var h = '';
            if (q) h += sub('地震速报', 'quake', q);
            if (t) h += sub('台风动态', 'typhoon', t);
            if (w) h += sub('气象预警', 'alert', w);
            if (!h) { hide(); return; }
            body.innerHTML = h;
        }

        function fail() {
            card.style.display = '';
            if (src) src.textContent = '获取失败';
            body.innerHTML = '<div class="yd-load err"><i></i>预警信息获取失败'
                + '<button type="button" class="yd-retry" data-alerts-retry>重新获取</button></div>';
            var rb = body.querySelector('[data-alerts-retry]');
            if (rb) {
                rb.addEventListener('click', function () {
                    body.innerHTML = '<div class="yd-load"><i></i>正在获取地震 / 台风 / 预警…</div>';
                    load();
                });
            }
        }

        function load() {
            fetchJSON(window.YX_API + '?action=alerts', null, 15000).then(render).catch(fail);
        }

        load();

        if (geoLast) { start(geoLast); return; }
        fetchJSON(window.YX_API + '?action=geo', null, 25000).then(function (r) {
            if (r && r.status === true) {
                geoLast = r;
                start(r);
            }
        }).catch(function () {});

        function start(g) {
            var v = (g && g.visitor) || {};
            var prov = (v.province || '').trim();
            if (!prov) return;
            fetchJSON(window.YX_API + '?action=alerts&province=' + encodeURIComponent(prov), null, 15000).then(render).catch(function () {});
        }
    }

    function initTraffic() {
        var card = document.querySelector('[data-traffic]');
        if (!card) return;
        var body = card.querySelector('[data-traffic-body]');
        var src = card.querySelector('[data-traffic-src]');
        if (!body || !window.YX_API) return;

        function render(d) {
            card.style.display = '';
            if (!d || d.empty || (!d.date && (!d.items || !d.items.length))) {
                body.innerHTML = '<div class="yd-load"><i></i>暂未获取到交通气象预报</div>';
                if (src) src.textContent = '暂无';
                return;
            }
            var h = '';
            h += '<div class="yd-tf-date">' + pickEsc(d.date || '') + ' 发布'
                + ' · <a href="' + pickEsc(d.url || 'https://www.nmc.cn/f/p-423') + '" target="_blank" rel="noopener">完整预报</a></div>';
            if (d.summary) {
                var s = d.summary;
                h += '<p class="yd-tf-sum">' + pickEsc(s.length > 140 ? s.slice(0, 140) + '…' : s) + '</p>';
            }
            if (d.note) h += '<p class="yd-tf-note">' + pickEsc(d.note) + '</p>';
            h += '<div class="yd-tf-grps">';
            (d.items || []).forEach(function (it) {
                var cls = 'oth', t = it.type || '';
                if (/雪|冰|冻/.test(t)) cls = 'snow';
                else if (/雷|暴/.test(t)) cls = 'storm';
                else if (/雨/.test(t)) cls = 'rain';
                else if (/雾|霾|沙|尘/.test(t)) cls = 'fog';
                var roads = it.roads || [];
                h += '<div class="yd-tf-grp yd-tf-' + cls + '">';
                h += '<div class="yd-tf-grp-h"><span class="tg"></span>' + pickEsc(t) + ' <em>' + roads.length + ' 条受影响路段</em></div>';
                h += '<div class="yd-tf-roads">';
                roads.slice(0, 12).forEach(function (r) { h += '<span class="rd">' + pickEsc(r) + '</span>'; });
                if (roads.length > 12) h += '<span class="rd more">+' + (roads.length - 12) + '</span>';
                h += '</div></div>';
            });
            h += '</div>';
            h += '<div class="yd-tf-src">数据来源：' + pickEsc(d.source || '中央气象台 · 交通运输部') + (d.stale ? ' · 缓存' : '') + '</div>';
            body.innerHTML = h;
            if (src) src.textContent = '中国气象局' + (d.stale ? '（缓存）' : '');
        }

        function load() {
            fetchJSON(window.YX_API + '?action=traffic', null, 15000).then(render).catch(function () {
                if (!body.innerHTML || body.querySelector('.yd-load.err')) {
                    card.style.display = '';
                    body.innerHTML = '<div class="yd-load err"><i></i>交通气象预报获取失败'
                        + '<button type="button" class="yd-retry" data-traffic-retry>重新获取</button></div>';
                    var rb = body.querySelector('[data-traffic-retry]');
                    if (rb) {
                        rb.addEventListener('click', function () {
                            body.innerHTML = '<div class="yd-load"><i></i>正在获取交通气象预报…</div>';
                            load();
                        });
                    }
                }
            });
        }

        load();
        setInterval(load, 120000);
    }

    function initNum() {
        function run(el) {
            if (el.dataset.done) {
                return;
            }
            el.dataset.done = '1';
            var target = parseFloat(el.getAttribute('data-num')) || 0;
            var dec = parseInt(el.getAttribute('data-dec'), 10) || 0;
            if (target === 0) {
                el.textContent = (0).toFixed(dec);
                return;
            }
            var dur = 900;
            var t0 = null;
            function step(ts) {
                if (!t0) {
                    t0 = ts;
                }
                var p = Math.min((ts - t0) / dur, 1);
                var eased = 1 - Math.pow(1 - p, 3);
                el.textContent = (target * eased).toFixed(dec);
                if (p < 1) {
                    requestAnimationFrame(step);
                } else {
                    el.textContent = target.toFixed(dec);
                }
            }
            requestAnimationFrame(step);
        }

        var items = $$('.yd-num');
        if (!items.length) {
            return;
        }
        if (!('IntersectionObserver' in window)) {
            items.forEach(run);
            return;
        }
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) {
                    run(en.target);
                    io.unobserve(en.target);
                }
            });
        }, { threshold: 0.35 });
        items.forEach(function (el) {
            io.observe(el);
        });
    }

    
    function initFront() {
        var cfg = window.YX_CFG || {};
        var url = cfg.siteUrl || '';
        var links = document.querySelectorAll('[data-yx-front]');
        Array.prototype.slice.call(links).forEach(function (a) {
            if (url && !a.getAttribute('href')) {
                a.setAttribute('href', url);
            }
            a.addEventListener('click', function (e) {
                var href = a.getAttribute('href') || '';
                if (url && (!href || href === '#' || href.indexOf('http') !== 0)) {
                    e.preventDefault();
                    window.open(url, '_blank', 'noopener');
                }
            });
        });
    }

    function initLogout() {
        var links = document.querySelectorAll('[data-yx-logout]');
        if (!links.length) {
            return;
        }
        var cfgUrl = (window.YX_CFG && window.YX_CFG.logoutUrl) || '';
        Array.prototype.slice.call(links).forEach(function (a) {
            if (cfgUrl && !a.getAttribute('href')) {
                a.setAttribute('href', cfgUrl);
            }
            a.addEventListener('click', function (e) {
                if (e && e.preventDefault) {
                    e.preventDefault();
                }
                if (a.getAttribute('data-yx-logout-going') === '1') {
                    return;
                }
                a.setAttribute('data-yx-logout-going', '1');
                var tx = a.querySelector('.tx');
                if (tx) {
                    tx.textContent = '正在退出…';
                }
                var url = a.getAttribute('href') || '';
                var left = false;
                var done = false;
                function go(to) {
                    if (left || !to) {
                        return;
                    }
                    left = true;
                    window.location.href = to;
                }
                if (!window.fetch || !url) {
                    go(url);
                    return;
                }
                fetch(url, { credentials: 'same-origin', redirect: 'follow' })
                    .then(function () {
                        done = true;

                        go(window.location.href);
                    })
                    .catch(function () {
                        if (!done) {
                            go(url);
                        }
                    });
                setTimeout(function () {
                    if (!done) {
                        go(url);
                    }
                }, 2500);
            });
        });
    }

    function initDrawerFoot() {
        var foot = document.querySelector('.yx-dfoot');
        if (!foot) {
            return;
        }
        var links = foot.querySelectorAll('a');
        Array.prototype.slice.call(links).forEach(function (a) {
            if (a.hasAttribute('data-yx-logout')) {
                return;
            }
            a.addEventListener('click', function () {
                var drawer = document.querySelector('.yx-drawer');
                var scrim = document.querySelector('.yx-scrim');
                if (drawer) {
                    drawer.classList.remove('open');
                }
                if (scrim) {
                    scrim.classList.remove('open');
                }
                document.body.classList.remove('yx-lock');
            });
        });
    }

    function boot() {
        initThemeBtn();
        initDrawer();
        initFront();
        initLogout();
        initSeoFix();
        initDrawerFoot();
        initNum();
        initWeather();
        initGeo();
        initAlerts();
        initTraffic();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();


(function () {
    var nodes = Array.prototype.slice.call(document.querySelectorAll('[data-yx-login]'));
    if (nodes.length) {
        var uid = nodes[0].getAttribute('data-yx-uid') || '0';
        var key = 'yx-login-' + uid;
        var now = Date.now();
        var rec = null;
        try { rec = JSON.parse(localStorage.getItem(key) || 'null'); } catch (e) {}
        if (!rec || typeof rec.at !== 'number' || now - (rec.seen || rec.at) > 43200000) {
            rec = { at: now, seen: now };
        } else {
            rec.seen = now;
        }
        try { localStorage.setItem(key, JSON.stringify(rec)); } catch (e) {}
        function fmt(ms) {
            var s = Math.max(0, Math.floor(ms / 1000));
            var d = Math.floor(s / 86400); s -= d * 86400;
            var h = Math.floor(s / 3600); s -= h * 3600;
            var m = Math.floor(s / 60);
            if (d > 0) return d + '天' + h + '时';
            if (h > 0) return h + '时' + m + '分';
            if (m > 0) return m + '分';
            return '不足1分';
        }
        function tick() {
            var t = new Date(rec.at);
            var tip = '本次登录时间：' + t.getFullYear() + '-' + (t.getMonth() + 1) + '-' + t.getDate()
                + ' ' + t.getHours() + ':' + String(t.getMinutes()).padStart(2, '0');
            nodes.forEach(function (n) {
                var el = n.querySelector('[data-yx-login-txt]');
                if (el) { el.textContent = n.classList.contains('yx-login-mini') ? fmt(Date.now() - rec.at) : '已登录 ' + fmt(Date.now() - rec.at); }
                n.setAttribute('title', tip);
            });
            rec.seen = Date.now();
            try { localStorage.setItem(key, JSON.stringify(rec)); } catch (e) {}
        }
        tick();
        setInterval(tick, 30000);
    }
    var wx = document.querySelector('.yx-weather');
    if (wx) {
        var btn = wx.querySelector('.yx-weather-btn');
        if (btn) {
            btn.addEventListener('click', function (e) { e.stopPropagation(); wx.classList.toggle('open'); });
        }
        document.addEventListener('click', function (e) {
            if (!wx.contains(e.target)) { wx.classList.remove('open'); }
        });
    }
})();
