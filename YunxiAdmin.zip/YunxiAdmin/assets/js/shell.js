(function () {
    'use strict';

    var $ = function (s, c) {
        return (c || document).querySelector(s);
    };

    var $$ = function (s, c) {
        return Array.prototype.slice.call((c || document).querySelectorAll(s));
    };

    var SYS = 'system';
    var root = document.documentElement;

    function sysDark() {
        return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }

    function resolve(mode) {
        return mode === SYS ? (sysDark() ? 'dark' : 'light') : mode;
    }

    function apply(mode) {
        root.setAttribute('data-theme', resolve(mode));
        root.setAttribute('data-theme-mode', mode);
    }

    var THEME_KEY = 'yx-theme';

    function storedTheme() {
        try {
            var v = localStorage.getItem(THEME_KEY);
            return v === 'light' || v === 'dark' ? v : null;
        } catch (e) {
            return null;
        }
    }

    function saveTheme(mode) {
        try {
            if (mode) {
                localStorage.setItem(THEME_KEY, mode);
            } else {
                localStorage.removeItem(THEME_KEY);
            }
        } catch (e) {}
    }

    var YX = {
        theme: {
            get mode() {
                var s = storedTheme();
                if (s) return s;
                var v = root.getAttribute('data-theme-mode');
                return v === 'light' || v === 'dark' ? v : SYS;
            },
            get current() {
                return resolve(this.mode);
            },
            toggle: function () {
                var next = this.current === 'dark' ? 'light' : 'dark';
                saveTheme(next);
                root.setAttribute('data-theme-mode', next);
                apply(next);
                document.dispatchEvent(new CustomEvent('yx:theme', { detail: { mode: next } }));
            },
            auto: function () {
                saveTheme(null);
                root.setAttribute('data-theme-mode', SYS);
                apply(SYS);
                document.dispatchEvent(new CustomEvent('yx:theme', { detail: { mode: SYS } }));
            },
            set: function (mode) {
                saveTheme(mode === SYS ? null : mode);
                root.setAttribute('data-theme-mode', mode);
                apply(mode);
                document.dispatchEvent(new CustomEvent('yx:theme', { detail: { mode: mode } }));
            }
        }
    };

    apply(YX.theme.mode);

    var mq = window.matchMedia('(prefers-color-scheme: dark)');
    var onChange = function () {
        if (!storedTheme()) {
            apply(YX.theme.mode);
            document.dispatchEvent(new CustomEvent('yx:theme', { detail: { mode: YX.theme.mode } }));
        }
    };
    if (mq.addEventListener) {
        mq.addEventListener('change', onChange);
    } else if (mq.addListener) {
        mq.addListener(onChange);
    }

    window.YX = YX;

    var MINE = ['.yx-shell', '.yx-drawer', '.yx-scrim'];

    function isMine(el) {
        return !!el && el.classList && (el.classList.contains('yx-shell')
            || el.classList.contains('yx-drawer')
            || el.classList.contains('yx-scrim'));
    }

    function purgeNative(scope) {
        var root = scope || document;
        $$('.menu-bar', root).forEach(function (el) { el.remove(); });
        $$('#typecho-nav-list', root).forEach(function (el) { el.remove(); });
        $$('a.author, a.exit', root).forEach(function (el) { el.remove(); });
        $$('.operate', root).forEach(function (op) {
            if (op.closest('.typecho-list-operate')) {
                return;
            }
            Array.prototype.slice.call(op.children).forEach(function (child) {
                if (!isMine(child)) {
                    child.remove();
                }
            });
            if (!op.querySelector('.yx-shell, .yx-drawer, .yx-scrim')) {
                op.remove();
            }
        });
    }

    function initNative() {
        if (window.YXKillNative) {
            try {
                window.YXKillNative();
                return;
            } catch (e) {}
        }
        MINE.forEach(function (sel) {
            $$(sel).forEach(function (el) {
                if (el.parentNode !== document.body) {
                    document.body.appendChild(el);
                }
            });
        });
        var head = $('.typecho-head-nav');
        if (head) {
            purgeNative(head);
            if (head.parentNode) {
                head.parentNode.removeChild(head);
            }
        }
        purgeNative(document);
    }

    function lock(on) {
        document.body.classList.toggle('yx-lock', on);
    }

    function initDrawer() {
        var drawer = $('.yx-drawer');
        var scrim = $('.yx-scrim');
        if (!drawer || !scrim) return;

        function open() {
            drawer.classList.add('open');
            scrim.classList.add('open');
            lock(true);
            var first = drawer.querySelector('.yx-dclose');
            if (first) first.focus();
        }

        function close() {
            drawer.classList.remove('open');
            scrim.classList.remove('open');
            lock(false);
        }

        $$('.yx-mburger').forEach(function (b) {
            b.addEventListener('click', open);
        });
        $$('.yx-dclose').forEach(function (b) {
            b.addEventListener('click', close);
        });
        scrim.addEventListener('click', close);
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') close();
        });

        $$('.yx-dbody .yx-mitem').forEach(function (a) {
            a.addEventListener('click', function () {
                if (window.innerWidth < 900) close();
            });
        });

        window.YXDrawer = { open: open, close: close };
    }

    function esc(v) {
        return String(v == null ? '' : v).replace(/[&<>"]/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
        });
    }

    function wIcon(text) {
        var t = String(text || '');
        if (t.indexOf('雷') > -1) return 'i-w-thunder';
        if (t.indexOf('雪') > -1) return 'i-w-snow';
        if (t.indexOf('雨') > -1) return 'i-w-rain';
        if (/雾|霾|沙|尘/.test(t)) return 'i-w-fog';
        if (/阴|云/.test(t)) return 'i-w-cloud';
        return 'i-w-sun';
    }

    function wPlace(d) {
        var city = d.city || d.province || '';
        if (d.district && city.indexOf(d.district) === -1) {
            return city ? city + ' · ' + d.district : d.district;
        }
        return city || d.district || '定位中';
    }

    function wApi(city) {
        var url = window.YX_API + '?action=weather';
        if (city) {
            url += '&city=' + encodeURIComponent(city);
        }
        return fetch(url, { credentials: 'same-origin' }).then(function (r) {
            return r.json();
        }).then(function (j) {
            if (j && j.status && j.weather && j.weather.city) {
                return j.weather;
            }
            throw new Error((j && j.message) || 'weather error');
        });
    }

    function wApply(box, d) {
        var ICONS = window.YX_ICONS || '';
        var chipT = $('[data-w-temp]', box);
        var chipC = $('[data-w-city]', box);
        if (chipT) chipT.textContent = Math.round(d.temperature) + '°';
        if (chipC) chipC.textContent = wPlace(d);

        var panel = $('[data-yx-wp]', box);
        if (!panel) return;

        var cityEl = $('[data-w-loc]', panel);
        var timeEl = $('[data-w-time]', panel);
        var tempEl = $('[data-w-temp-big]', panel);
        var metaEl = $('[data-w-meta]', panel);
        var icoEl = $('[data-w-icon]', panel);
        var gridEl = $('[data-w-grid]', panel);
        var fcEl = $('[data-w-fc]', panel);

        if (cityEl) cityEl.textContent = wPlace(d);
        if (timeEl) timeEl.textContent = (d.report_time || '').slice(11, 16) + ' 更新';
        if (tempEl) tempEl.innerHTML = Math.round(d.temperature) + '<sup>°C</sup>';

        var wind = [d.wind_direction, d.wind_power].filter(Boolean).join(' ');
        if (metaEl) metaEl.innerHTML = esc(d.weather || '') + (wind ? '<br>' + esc(wind) : '');
        if (icoEl) icoEl.innerHTML = '<use href="' + ICONS + '#' + wIcon(d.weather) + '"></use>';

        if (gridEl) {
            var cells = [];
            cells.push(['体感', (typeof d.feels_like === 'number' ? Math.round(d.feels_like) + '°' : '—')]);
            cells.push(['湿度', (typeof d.humidity === 'number' ? d.humidity + '%' : '—')]);
            if (typeof d.aqi === 'number') {
                cells.push(['空气', (d.aqi_category || d.aqi) + ' ' + d.aqi]);
            } else if (typeof d.visibility === 'number') {
                cells.push(['能见度', d.visibility + 'km']);
            } else {
                cells.push(['气压', (typeof d.pressure === 'number' ? d.pressure + 'hPa' : '—')]);
            }
            gridEl.innerHTML = cells.map(function (c) {
                return '<div><i>' + esc(c[0]) + '</i><b>' + esc(c[1]) + '</b></div>';
            }).join('');
        }

        if (fcEl && d.forecast && d.forecast.length) {
            fcEl.innerHTML = d.forecast.slice(0, 3).map(function (f) {
                return '<div><b>' + esc(f.week || f.date || '') + '</b>'
                    + esc(f.weather_day || f.weather || '')
                    + '<br>' + esc(f.temp_min) + '° ~ ' + esc(f.temp_max) + '°</div>';
            }).join('');
        }
    }

    function initWeather() {
        var boxes = $$('.yx-weather');
        if (!boxes.length) return;

        function closeAll() {
            boxes.forEach(function (b) {
                var p = $('[data-yx-wp]', b);
                if (p) p.classList.remove('open');
            });
        }

        function setHint(box, text, err) {
            var h = $('[data-w-hint]', box);
            if (h) {
                h.className = 'yx-wp-hint' + (err ? ' err' : '');
                h.textContent = text;
            }
        }

        boxes.forEach(function (box) {
            var btn = $('.yx-weather-btn', box);
            var panel = $('[data-yx-wp]', box);

            if (btn && panel) {
                btn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    var willOpen = !panel.classList.contains('open');
                    closeAll();
                    if (willOpen) panel.classList.add('open');
                });
                panel.addEventListener('click', function (e) {
                    e.stopPropagation();
                });
            }

            var input = $('.yx-wp-city-row input', box);
            var go = $('.yx-wp-city-row button', box);

            function submit() {
                if (!input) return;
                var city = (input.value || '').trim();
                if (!city) return;
                setHint(box, '正在定位…', false);
                wApi(city).then(function (d) {
                    if (!d || !d.city) throw new Error('bad');
                    boxes.forEach(function (o) { wApply(o, d); });
                    setHint(box, '已切换到 ' + d.city + '，可在插件设置中固定', false);
                    input.value = '';
                }).catch(function () {
                    setHint(box, '定位失败，请检查网络或稍后再试', true);
                });
            }

            if (go) go.addEventListener('click', submit);
            if (input) {
                input.addEventListener('keydown', function (e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        submit();
                    }
                });
            }
        });

        document.addEventListener('click', function (e) {
            var inside = boxes.some(function (b) {
                return b.contains(e.target);
            });
            if (!inside) closeAll();
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeAll();
        });

        var empty = boxes.filter(function (b) {
            return b.getAttribute('data-empty') === '1';
        });

        if (empty.length) {
            empty.forEach(function (b) {
                setHint(b, '正在自动定位…', false);
            });
            wApi('').then(function (d) {
                if (!d || !d.city) throw new Error('bad');
                boxes.forEach(function (o) { wApply(o, d); });
                empty.forEach(function (b) {
                    setHint(b, '已完成 IP 定位，可在插件设置中固定城市', false);
                });
            }).catch(function () {
                empty.forEach(function (b) {
                    setHint(b, '无法获取天气，请检查服务器网络或手动输入城市', true);
                });
            });
        }
    }

    function initLogin() {
        var els = $$('[data-yx-login]');
        if (!els.length) return;

        var el = els[0];
        var uid = el.getAttribute('data-yx-uid') || '0';
        var key = 'yx-login-' + uid;
        var now = Date.now();
        var rec = null;
        var GAP = 12 * 3600 * 1000;

        try {
            rec = JSON.parse(localStorage.getItem(key) || 'null');
        } catch (e) {
            rec = null;
        }

        if (!rec || typeof rec.at !== 'number' || now - (rec.seen || rec.at) > GAP) {
            rec = { at: now, seen: now };
        } else {
            rec.seen = now;
        }

        function save() {
            try {
                localStorage.setItem(key, JSON.stringify(rec));
            } catch (e) {}
        }
        save();

        function fmt(ms) {
            var s = Math.max(0, Math.floor(ms / 1000));
            var d = Math.floor(s / 86400);
            s -= d * 86400;
            var h = Math.floor(s / 3600);
            s -= h * 3600;
            var m = Math.floor(s / 60);
            if (d > 0) return d + ' 天 ' + h + ' 小时';
            if (h > 0) return h + ' 小时 ' + m + ' 分';
            if (m > 0) return m + ' 分钟';
            return '不足 1 分钟';
        }

        function fmtShort(ms) {
            var s = Math.max(0, Math.floor(ms / 1000));
            var d = Math.floor(s / 86400);
            s -= d * 86400;
            var h = Math.floor(s / 3600);
            s -= h * 3600;
            var m = Math.floor(s / 60);
            if (d > 0) return d + '天' + h + '时';
            if (h > 0) return h + '时' + m + '分';
            if (m > 0) return m + '分';
            return '不足1分';
        }

        function tick() {
            var ms = Date.now() - rec.at;
            var t = new Date(rec.at);
            var tip = '本次登录时间：' + t.getFullYear() + '-' + (t.getMonth() + 1) + '-' + t.getDate()
                + ' ' + t.getHours() + ':' + String(t.getMinutes()).padStart(2, '0');
            els.forEach(function (node) {
                var txt = $('[data-yx-login-txt]', node);
                if (txt) {
                    txt.textContent = node.classList.contains('yx-login-mini')
                        ? fmtShort(ms)
                        : '已登录 ' + fmt(ms);
                }
                node.setAttribute('title', tip);
            });
        }

        tick();
        setInterval(function () {
            tick();
            rec.seen = Date.now();
            save();
        }, 30000);

        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) {
                rec.seen = Date.now();
                save();
                tick();
            }
        });
    }

    function initThemeBtn() {
        var btn = document.querySelector('[data-yx-theme-btn]');
        if (!btn) return;
        btn.addEventListener('click', function () {
            if (window.YX && YX.theme && YX.theme.toggle) {
                YX.theme.toggle();
            }
        });
        document.addEventListener('yx:theme', function (e) {
            var mode = (e && e.detail && e.detail.mode) || (window.YX && YX.theme && YX.theme.current) || '';
            btn.setAttribute('data-mode', mode);
        });
    }

    function initToast() {
        document.addEventListener('click', function (e) {
            var el = e.target.closest ? e.target.closest('[data-yx-toast]') : null;
            if (!el) return;
            var old = $('.yx-toast');
            if (old) old.remove();
            var t = document.createElement('div');
            t.className = 'yx-toast';
            t.innerHTML = el.getAttribute('data-yx-toast');
            document.body.appendChild(t);
            requestAnimationFrame(function () {
                t.classList.add('show');
            });
            setTimeout(function () {
                t.classList.remove('show');
                setTimeout(function () {
                    t.remove();
                }, 300);
            }, 3000);
        });
    }

    function initNum() {
        function run(el) {
            if (el.dataset.done) return;
            el.dataset.done = '1';
            var target = parseFloat(el.getAttribute('data-num')) || 0;
            var dec = parseInt(el.getAttribute('data-dec'), 10) || 0;
            if (target === 0) {
                el.textContent = (0).toFixed(dec);
                return;
            }
            var dur = 900;
            var t0 = null;
            function step(ts) {
                if (!t0) t0 = ts;
                var p = Math.min((ts - t0) / dur, 1);
                var eased = 1 - Math.pow(1 - p, 3);
                el.textContent = (target * eased).toFixed(dec);
                if (p < 1) requestAnimationFrame(step);
                else el.textContent = target.toFixed(dec);
            }
            requestAnimationFrame(step);
        }

        var items = $$('.yd-num');
        if (!items.length) return;

        if (!('IntersectionObserver' in window)) {
            items.forEach(run);
            return;
        }

        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) {
                    run(en.target);
                    io.unobserve(en.target);
                }
            });
        }, { threshold: 0.35 });

        items.forEach(function (el) {
            io.observe(el);
        });
    }

    

    var geoLast = null;

    function initGeo() {
        var card = document.querySelector('[data-geo]');
        if (!card) return;
        var body = card.querySelector('[data-geo-body]');
        var src = card.querySelector('[data-geo-src]');
        if (!body || !window.YX_API) return;

        fetchJSON(window.YX_API + '?action=geo', null, 25000).then(function (r) {
            if (!r || r.status !== true) {
                body.innerHTML = '<div class="yd-load">正在获取网络位置，请稍候…</div>';
                if (src) src.textContent = '重试中';
                setTimeout(function () { initGeo(); }, 20000);
                return;
            }
            geoLast = r;
            var v = r.visitor || {};
            var s = r.server || {};
            if (src) {
                src.textContent = v.ok ? (v.source || '已定位') : '定位失败';
            }
            var h = '<div class="yd-geo-v">'
                + '<div class="ip">' + pickEsc(v.ip || '—') + '</div>'
                + '<div class="pl">' + pickEsc(v.place || '未知位置') + '</div>'
                + '<div class="mt">'
                + (v.isp ? '<span>' + pickIcon('i-loc') + pickEsc(v.isp) + '</span>' : '')
                + (v.timezone ? '<span>' + pickIcon('i-clock') + pickEsc(v.timezone) + '</span>' : '')
                + (s.ip ? '<span>' + pickIcon('i-cloud') + '服务器 ' + pickEsc(s.place || s.ip) + '</span>' : '')
                + '</div></div>';

            var near = r.nearby || [];
            if (near.length) {
                h += '<div class="yd-geo-near"><div class="tt">附近热门'
                    + (v.place ? ' · ' + pickEsc(v.place) : '') + '</div><div class="chips">';
                near.forEach(function (n) {
                    h += '<span class="chip">' + pickIcon('i-loc') + pickEsc(n.name || '')
                        + (n.distance !== null && n.distance !== undefined ? '<em>' + pickEsc(n.distance) + ' km</em>' : '')
                        + '</span>';
                });
                h += '</div></div>';
            }

            var peers = r.peers || [];
            if (peers.length) {
                h += '<div class="yd-geo-peers"><div class="tt">评论者位置（来自评论 · 按距离）</div><table class="yd-table"><thead><tr>'
                    + '<th>IP</th><th>位置</th><th>距离</th><th>评论</th></tr></thead><tbody>';
                peers.forEach(function (p) {
                    h += '<tr><td class="nm">' + pickEsc(p.ip) + '</td>'
                        + '<td>' + pickEsc(p.place || '—') + '</td>'
                        + '<td>' + (p.distance === null || p.distance === undefined ? '—' : pickEsc(p.distance) + ' km') + '</td>'
                        + '<td>' + pickEsc(p.comments || 0) + '</td></tr>';
                });
                h += '</tbody></table></div>';
            }
            body.innerHTML = h;
        }).catch(function () {
            body.innerHTML = '<div class="yd-load">正在获取网络位置，请稍候…</div>';
            if (src) src.textContent = '重试中';
            setTimeout(function () { initGeo(); }, 20000);
        });
    }

    function initAlerts() {
        var card = document.querySelector('[data-alerts]');
        if (!card) return;
        var body = card.querySelector('[data-alerts-body]');
        var src = card.querySelector('[data-alerts-src]');
        if (!body || !window.YX_API) return;
        var lastData = null;

        function hide() {
            card.style.display = 'none';
        }

        function sub(title, iconCls, inner) {
            if (!inner) return '';
            return '<div class="yd-al-sub yd-al-' + iconCls + '">'
                + '<div class="yd-al-sub-h"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-' + iconCls + '"></use></svg>' + title + '</div>'
                + inner + '</div>';
        }

        function weatherHtml(list) {
            if (!list || !list.length) return '';
            var h = '<ul class="yd-alerts-list">';
            list.slice(0, 6).forEach(function (a) {
                h += '<li class="lv-' + pickEsc(a.level || 'none') + '">'
                    + '<span class="lv">' + pickEsc(a.level || '预警') + '</span>'
                    + '<div class="ct"><b>' + pickEsc(a.title || '') + '</b>'
                    + (a.content ? '<p>' + pickEsc(a.content) + '</p>' : '')
                    + '<span class="tm">' + pickEsc(a.issueTime || '') + '</span></div></li>';
            });
            h += '</ul>';
            return h;
        }

        function quakeHtml(list) {
            if (!list || !list.length) return '';
            var h = '<ul class="yd-quakes">';
            list.slice(0, 6).forEach(function (q) {
                var mag = parseFloat(q.magnitude || 0);
                var cls = mag >= 5 ? 's5' : (mag >= 4 ? 's4' : (mag >= 3 ? 's3' : 's2'));
                h += '<li class="qk-' + cls + '">'
                    + '<span class="mag">' + pickEsc(q.magnitude || '') + '</span>'
                    + '<div class="ct"><b>' + pickEsc(q.location || '地震') + '</b>'
                    + '<span class="tm">' + pickEsc(q.time || '') + ' · 深度 ' + pickEsc(q.depth || '?') + 'km'
                    + (q.intensity ? ' · 烈度 ' + pickEsc(q.intensity) : '') + '</span></div></li>';
            });
            h += '</ul>';
            return h;
        }

        function typhoonHtml(list) {
            if (!list || !list.length) return '';
            var h = '<ul class="yd-typhoons">';
            list.slice(0, 4).forEach(function (t) {
                h += '<li>'
                    + '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-typhoon"></use></svg>'
                    + '<div class="ct"><b>' + pickEsc(t.name || '台风')
                    + (t.enName ? ' <em>' + pickEsc(t.enName) + '</em>' : '') + '</b>'
                    + '<span class="tm">' + pickEsc(t.statusText || '活动中') + '</span></div></li>';
            });
            h += '</ul>';
            return h;
        }

        
        var tipsExtra = [
            '地震瞬间：蹲下、护头、抓牢稳固家具，远离玻璃窗与吊灯。',
            '晃动停止后有序撤离，走楼梯、不乘电梯，远离外墙与高大广告牌。',
            '台风影响期间减少外出，收好阳台杂物，留意停复课与停运通知。',
            '收到预警短信不必惊慌，按预警级别落实对应防护措施即可。',
            '家中常备应急包：饮水、食物、手电、充电宝、常用药品与证件复印件。',
            '地震后注意余震，远离陡坡、河岸，防范滑坡与泥石流等次生灾害。',
            '高层住户遇震优先躲避在承重墙角或坚固桌下，待晃动停止再撤离。',
            '暴雨洪涝时切断电源、向高处转移，不蹚不明深度的积水与湍急水流。',
            '雷暴天气远离空旷高地、孤立树木与金属构筑物，关闭不必要的电器。',
            '高温预警下减少正午户外作业，及时补水，关注老人儿童与慢病患者。',
            '灾害信息以官方发布为准，不轻信、不转发未经证实的消息。',
            '熟悉就近的应急避难场所与疏散路线，关键时刻能争取宝贵时间。'
        ];
        var tipsAdded = 0;
        function tipsHtml(n, title) {
            if (!n || tipsAdded >= tipsExtra.length) return '';
            var m = Math.min(n, tipsExtra.length - tipsAdded);
            var h = '<div class="yd-al-sub yd-al-tips"><div class="yd-al-sub-h"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-alert"></use></svg>' + (title || '防灾科普') + '</div><ul class="yd-tips">';
            for (var i = 0; i < m; i++) {
                h += '<li>' + pickEsc(tipsExtra[tipsAdded + i]) + '</li>';
            }
            h += '</ul></div>';
            tipsAdded += m;
            return h;
        }

        function renderAll(r) {
            if (!r) { hide(); return; }
            lastData = r;
            var w = weatherHtml(r.items);
            var q = quakeHtml(r.quakes);
            var t = typhoonHtml(r.typhoons);
            if (!w && !q && !t) { hide(); return; }
            card.style.display = '';
            if (src) {
                var regionName = (r.region && r.region !== '') ? r.region : (r.province || r.city || '全国');
                var parts = [regionName];
                if (r.items && r.items.length) parts.push('气象预警 ' + r.items.length);
                if (r.quakes && r.quakes.length) parts.push('地震 ' + r.quakes.length);
                if (r.typhoons && r.typhoons.length) parts.push('台风 ' + r.typhoons.length);
                if (parts.length < 2) parts.push('暂无');
                src.textContent = parts.join(' · ');
            }
            tipsAdded = 0;
            var h = '';
            if (q) h += sub('地震速报', 'quake', q);
            if (t) h += sub('台风动态', 'typhoon', t);
            if (w) h += sub('气象预警', 'alert', w);
            h += tipsHtml(2, '防灾科普');
            body.innerHTML = h;
            fillAlerts();
        }




        function fillAlerts() {
            if (!card || card.style.display === 'none') return;
            var cols = card.closest ? card.closest('.yd-cols') : null;
            if (!cols) return;
            var units = [];
            cols.querySelectorAll(':scope > .yd-card, :scope > .yd-pair').forEach(function (el) {
                if (el.style.display !== 'none') units.push(el);
            });
            if (!units.length) return;


            var groups = [];
            units.forEach(function (el) {
                var left = Math.round(el.getBoundingClientRect().left);
                var g = null;
                for (var i = 0; i < groups.length; i++) {
                    if (Math.abs(groups[i].left - left) < 24) { g = groups[i]; break; }
                }
                if (!g) { g = { left: left, items: [] }; groups.push(g); }
                g.items.push(el);
            });

            function colBottomOf(g) {
                var b = 0;
                g.items.forEach(function (el) {
                    var bb = el.getBoundingClientRect().bottom;
                    if (bb > b) b = bb;
                });
                return b;
            }
            var colBottom = groups.map(colBottomOf);
            var maxBottom = Math.max.apply(null, colBottom);
            var guard = 0;
            while (guard++ < 12) {
                var changed = false;
                for (var gi = 0; gi < groups.length; gi++) {
                    var gap = maxBottom - colBottom[gi];
                    if (gap < 160) continue;
                    var last = groups[gi].items[groups[gi].items.length - 1];
                    var box = last.querySelector ? (last.querySelector('.yd-body') || last) : last;
                    var more = tipsHtml(2, '防灾科普');
                    if (!more) break;
                    var frag = document.createElement('div');
                    frag.innerHTML = more;
                    while (frag.firstChild) box.appendChild(frag.firstChild);
                    colBottom[gi] = colBottomOf(groups[gi]);
                    if (colBottom[gi] > maxBottom) maxBottom = colBottom[gi];
                    changed = true;
                }
                if (!changed) break;
            }
        }

        function render(r) {
            renderAll(r);
        }

        function fail() {
            card.style.display = '';
            if (src) src.textContent = '获取失败';
            body.innerHTML = '<div class="yd-load err"><i></i>预警信息获取失败'
                + '<button type="button" class="yd-retry" data-alerts-retry>重新获取</button></div>';
            var rb = body.querySelector('[data-alerts-retry]');
            if (rb) {
                rb.addEventListener('click', function () {
                    body.innerHTML = '<div class="yd-load"><i></i>正在获取地震 / 台风 / 预警…</div>';
                    load();
                });
            }
        }

        function load() {
            fetchJSON(window.YX_API + '?action=alerts', null, 15000).then(render).catch(fail);
        }

        load();


        var rzTimer = null;
        window.addEventListener('resize', function () {
            if (rzTimer) clearTimeout(rzTimer);
            rzTimer = setTimeout(function () {
                if (lastData) renderAll(lastData);
            }, 350);
        });

        if (geoLast) { start(geoLast); return; }
        fetchJSON(window.YX_API + '?action=geo', null, 25000).then(function (r) {
            if (r && r.status === true) {
                geoLast = r;
                start(r);
            }
        }).catch(function () {});

        function start(g) {
            var v = (g && g.visitor) || {};
            var prov = (v.province || '').trim();
            if (!prov) return;
            fetchJSON(window.YX_API + '?action=alerts&province=' + encodeURIComponent(prov), null, 15000).then(render).catch(function () {});
        }
    }

    function initAvatars() {

        $$('img.yx-ava[data-remote]').forEach(function (img) {
            var u = img.getAttribute('data-remote');
            if (!u || u.indexOf('data:') === 0) return;
            var probe = new Image();
            probe.referrerPolicy = 'no-referrer';
            probe.onload = function () {
                img.src = u;
            };
            probe.src = u;
        });
    }

    function initRailFit() {




        var rail = $('.yx-rail');
        var nav = $('.yx-rail .yx-nav');
        var foot = $('.yx-rail .yx-rail-foot');
        if (!rail || !nav) return;

        var ticking = false;

        function fit() {
            ticking = false;
            var h = rail.clientHeight;
            if (!h) return;

            var head = $('.yx-rail .yx-rail-head');
            var headH = head ? head.offsetHeight : 0;
            var footH = foot ? foot.offsetHeight : 0;
            var navStyle = window.getComputedStyle(nav);
            var padY = parseFloat(navStyle.paddingTop) + parseFloat(navStyle.paddingBottom);


            var avail = h - headH - footH - padY - 2;
            if (avail <= 40) return;

            var items = $$('.yx-mitem', nav);
            if (!items.length) return;

            var secs = $$('.yx-sec', nav);
            var gapTotal = 0;
            secs.forEach(function (s) {
                gapTotal += parseFloat(window.getComputedStyle(s).marginBottom) || 0;
            });

            var itemCount = items.length;
            var cs = window.getComputedStyle(items[0]);
            var cur = parseFloat(cs.getPropertyValue('--yx-rico')) || 22;
            var curPad = parseFloat(cs.getPropertyValue('--yx-rip')) || 8;
            var curSvg = parseFloat(cs.getPropertyValue('--yx-ris')) || 15.5;


            var per = (avail - gapTotal) / itemCount - 2;
            if (per <= 0) return;

            var ico = Math.min(cur, Math.max(12, per));
            var pad = Math.min(curPad, Math.max(2, (per - ico) / 2));

            var svg = Math.min(curSvg, Math.max(10, ico * 0.7045));

            if (Math.abs(ico - cur) < 0.2 && Math.abs(pad - curPad) < 0.2) {
                rail.classList.remove('yx-rail-tight');
                nav.style.removeProperty('--yx-rico');
                nav.style.removeProperty('--yx-rip');
                nav.style.removeProperty('--yx-ris');
                return;
            }

            rail.classList.add('yx-rail-tight');
            nav.style.setProperty('--yx-rico', ico.toFixed(2) + 'px');
            nav.style.setProperty('--yx-rip', pad.toFixed(2) + 'px');
            nav.style.setProperty('--yx-ris', svg.toFixed(2) + 'px');
        }

        function schedule() {
            if (ticking) return;
            ticking = true;
            window.requestAnimationFrame(fit);
        }

        schedule();
        window.addEventListener('resize', schedule);

        if (document.fonts && document.fonts.ready) {
            document.fonts.ready.then(schedule).catch(function () {});
        }
        window.setTimeout(schedule, 300);
    }




    function initTip() {
        var tip = document.createElement('div');
        tip.className = 'yx-tip';
        tip.setAttribute('role', 'tooltip');
        document.body.appendChild(tip);

        var cur = null;
        var hideT = null;

        function place(el) {
            var txt = el.getAttribute('data-tip');
            if (!txt) return false;
            tip.textContent = txt;
            tip.classList.remove('on');
            tip.classList.remove('is-drawer');

            var r = el.getBoundingClientRect();
            if (!r.width && !r.height) return false;

            var isDrawer = !!el.closest('.yx-drawer');
            tip.classList.toggle('is-drawer', isDrawer);


            tip.style.visibility = 'hidden';
            tip.style.opacity = '0';
            var tw = tip.offsetWidth;
            var th = tip.offsetHeight;

            var left;
            var top;

            if (isDrawer) {

                left = r.left + r.width / 2 - tw / 2;
                top = r.top - th - 8;
                if (top < 8) {
                    top = r.bottom + 8;
                }
            } else {

                left = r.right + 12;
                top = r.top + r.height / 2;
                if (left + tw > window.innerWidth - 8) {
                    left = r.left - tw - 12;
                }
            }

            left = Math.max(8, Math.min(left, window.innerWidth - tw - 8));
            top = Math.max(th / 2 + 4, Math.min(top, window.innerHeight - th / 2 - 4));

            tip.style.left = Math.round(left) + 'px';
            tip.style.top = Math.round(top) + 'px';
            tip.style.visibility = '';
            tip.style.opacity = '';


            window.requestAnimationFrame(function () {
                tip.classList.add('on');
            });
            return true;
        }

        function show(el) {
            if (cur === el) return;
            cur = el;
            if (hideT) {
                clearTimeout(hideT);
                hideT = null;
            }
            place(el);
        }

        function hide() {
            cur = null;
            tip.classList.remove('on');
        }

        document.addEventListener('mouseover', function (e) {
            var el = e.target.closest ? e.target.closest('[data-tip]') : null;
            if (!el) return;
            if (el.closest('.yx-rail') || el.closest('.yx-drawer')) {
                show(el);
            }
        }, true);

        document.addEventListener('mouseout', function (e) {
            var el = e.target.closest ? e.target.closest('[data-tip]') : null;
            if (!el) return;
            if (el === cur) hide();
        }, true);

        document.addEventListener('focusin', function (e) {
            var el = e.target.closest ? e.target.closest('[data-tip]') : null;
            if (!el) return;
            if (el.closest('.yx-rail') || el.closest('.yx-drawer')) show(el);
        }, true);

        document.addEventListener('focusout', hide, true);


        window.addEventListener('scroll', hide, true);
        window.addEventListener('resize', hide);
    }

    function initPrefetch() {


        var done = {};
        var count = 0;
        var MAX = 4;

        $$('.yx-nav a, .yx-dbody a').forEach(function (a) {
            var tm = null;
            a.addEventListener('mouseenter', function () {
                if (count >= MAX) return;
                var href = a.href;
                if (!href || done[href] || href.indexOf('http') !== 0) return;
                if (a.origin !== window.location.origin) return;
                if (href === window.location.href) return;
                clearTimeout(tm);
                tm = setTimeout(function () {
                    done[href] = 1;
                    count++;
                    var l = document.createElement('link');
                    l.rel = 'prefetch';
                    l.href = href;
                    document.head.appendChild(l);
                }, 260);
            });
            a.addEventListener('mouseleave', function () {
                clearTimeout(tm);
            });
        });
    }

    var ICONS = window.YX_ICONS || '';

    function pickIcon(name) {
        return '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="' + ICONS + '#' + name + '"></use></svg>';
    }

    function pickEsc(v) {
        return String(v == null ? '' : v).replace(/[&<>"]/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
        });
    }

    var CFG = window.YX_CFG || {};

    function fetchJSON(url, opt, timeout) {
        var ctrl = typeof AbortController === 'function' ? new AbortController() : null;
        var tm = setTimeout(function () {
            if (ctrl) ctrl.abort();
        }, timeout || 10000);
        var o = { credentials: 'same-origin' };
        if (opt) {
            Object.keys(opt).forEach(function (k) {
                o[k] = opt[k];
            });
        }
        if (ctrl) o.signal = ctrl.signal;
        return fetch(url, o).then(function (r) {
            clearTimeout(tm);
            return r.json();
        }).catch(function (e) {
            clearTimeout(tm);
            if (e && e.name === 'AbortError') {
                throw new Error('请求超时，请稍后重试');
            }
            throw e;
        });
    }

    
    function postJSON(url, body) {
        var ctrl = typeof AbortController === 'function' ? new AbortController() : null;
        var tm = setTimeout(function () {
            if (ctrl) ctrl.abort();
        }, 30000);
        var o = {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'X-YX-Req': '1', 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body || ''
        };
        if (ctrl) o.signal = ctrl.signal;
        return fetch(url, o).then(function (r) {
            clearTimeout(tm);
            return r.text().then(function (txt) {
                var d = null;
                try {
                    d = txt ? JSON.parse(txt) : null;
                } catch (e) {
                    d = null;
                }
                if (!d) {
                    throw new Error('服务端返回异常（HTTP ' + r.status + '）');
                }
                if (!r.ok) {
                    throw new Error(d.message || '请求失败');
                }
                return d;
            });
        }).catch(function (e) {
            clearTimeout(tm);
            if (e && e.name === 'AbortError') {
                throw new Error('请求超时，请稍后重试');
            }
            throw e;
        });
    }

    function sysToast(msg) {
        var old = document.querySelector('.yx-toast');
        if (old) old.remove();
        var n = document.createElement('div');
        n.className = 'yx-toast show';
        n.textContent = msg || '';
        document.body.appendChild(n);
        setTimeout(function () {
            if (n.parentNode) n.remove();
        }, 3200);
    }

    var Picker = {
        el: null,
        opt: null,
        tab: 'local',
        page: 1,
        pages: 1,
        items: [],
        shown: [],
        busy: false,
        q: '',
        sel: {},
        cache: {},
        reqSeq: 0,

        build: function () {
            if (this.el) return;
            var self = this;
            var mask = document.createElement('div');
            mask.className = 'yx-pick-mask';
            mask.innerHTML = '<div class="yx-pick" role="dialog" aria-modal="true">'
                + '<div class="yx-pick-head"><h3>本地媒体库</h3>'
                + '<span class="sp"></span>'
                + '<button type="button" class="yx-pick-close" aria-label="关闭" title="关闭（Esc）"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>'
                + '<div class="yx-pick-bar">'
                + '<label class="yx-pick-find">' + pickIcon('i-search') + '<input type="search" placeholder="筛选文件名…" aria-label="筛选"></label>'
                + '<span class="sp"></span>'
                + '<button type="button" class="yx-pick-up" title="上传图片 / 视频到本站（也可直接粘贴到编辑器）">'
                + pickIcon('i-upload') + '<span>上传图片 / 视频</span></button>'
                + '<input type="file" class="yx-pick-file" multiple accept="image/*,video/*" hidden>'
                + '<button type="button" class="yx-ed-btn ins-all" disabled>插入选中</button>'
                + '</div>'
                + '<div class="yx-pick-body">'
                + '<div class="yx-pick-grid"></div>'
                + '<div class="yx-pick-state" style="display:none"></div>'
                + '</div>'
                + '<div class="yx-pick-foot">'
                + '<span class="pg"></span>'
                + '<button type="button" class="pv" aria-label="上一页">' + pickIcon('i-chev-l') + '</button>'
                + '<button type="button" class="nx" aria-label="下一页">' + pickIcon('i-chev-r') + '</button>'
                + '<span class="sp"></span>'
                + '<span class="hint">点击即插入 · 勾选可批量 · 图片视频也可直接粘贴到编辑器</span>'
                + '</div></div>';
            document.body.appendChild(mask);
            this.el = mask;

            mask.addEventListener('click', function (e) {
                if (e.target === mask) self.close();
            });

            $('.yx-pick-close', mask).addEventListener('click', function () {
                self.close();
            });

            $('.yx-pick-find input', mask).addEventListener('input', function () {
                self.q = (this.value || '').trim().toLowerCase();
                self.sel = {};
                self.render();
            });

            $('.yx-pick-foot .pv', mask).addEventListener('click', function () {
                if (self.page > 1 && !self.busy) {
                    self.page--;
                    self.load();
                }
            });
            $('.yx-pick-foot .nx', mask).addEventListener('click', function () {
                if (self.page < self.pages && !self.busy) {
                    self.page++;
                    self.load();
                }
            });

            $('.ins-all', mask).addEventListener('click', function () {
                self.insertSelected();
            });


            var upBtn = $('.yx-pick-up', mask);
            var upFile = $('.yx-pick-file', mask);
            upBtn.addEventListener('click', function () {
                upFile.click();
            });
            upFile.addEventListener('change', function () {
                if (upFile.files && upFile.files.length) {
                    self.uploadAll(upFile.files);
                    upFile.value = '';
                }
            });

            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && mask.classList.contains('show')) self.close();
            });
        },

        open: function (opt) {
            this.opt = opt || {};
            this.tab = 'local';
            this.page = 1;
            this.q = '';
            this.sel = {};
            this.build();
            var self = this;
            requestAnimationFrame(function () {
                self.el.classList.add('show');
            });
            document.body.classList.add('yx-lock');
            $('.yx-pick-find input', this.el).value = '';
            this.load();
        },

        close: function () {
            if (!this.el) return;
            this.el.classList.remove('show');
            document.body.classList.remove('yx-lock');
            this.opt = null;
        },

        state: function (html, clearGrid) {
            var st = $('.yx-pick-state', this.el);
            if (!st) return;
            if (html) {
                st.innerHTML = html;
                st.style.display = '';
                if (clearGrid !== false) {
                    var grid = $('.yx-pick-grid', this.el);
                    if (grid) grid.innerHTML = '';
                }
            } else {
                st.style.display = 'none';
            }
        },

        foot: function () {
            var pg = $('.yx-pick-foot .pg', this.el);
            var pv = $('.yx-pick-foot .pv', this.el);
            var nx = $('.yx-pick-foot .nx', this.el);
            pg.textContent = this.page + ' / ' + Math.max(1, this.pages);
            pv.disabled = this.page <= 1 || this.busy;
            nx.disabled = this.page >= this.pages || this.busy;
        },

        cacheKey: function () {
            return this.tab + ':' + this.page;
        },

        load: function (force) {
            var self = this;
            var key = this.cacheKey();
            var hit = this.cache[key];
            var seq = ++this.reqSeq;

            this.busy = true;
            this.foot();

            if (hit && !force && Date.now() - hit.t < 60000) {
                this.apply(hit.data);
                return;
            }
            if (hit && !force) {
                this.render();
            } else {
                this.state(pickIcon('i-refresh') + '<span>加载中…</span>');
            }

            var url = window.YX_API + '?action=medias&page=' + this.page;
            fetchJSON(url, null, 10000).then(function (d) {
                if (seq !== self.reqSeq) return;
                self.busy = false;
                if (!d || d.status !== true) {
                    self.state(pickIcon('i-alert') + '<span>' + pickEsc((d && d.message) || '加载失败') + '</span>'
                        + '<button type="button" class="lnk">重试</button>');
                    var lnk = $('.yx-pick-state .lnk', self.el);
                    if (lnk) lnk.addEventListener('click', function () { self.load(true); });
                    self.items = [];
                    self.pages = 1;
                    self.foot();
                    return;
                }
                self.cache[key] = { t: Date.now(), data: d };
                self.apply(d);
            }).catch(function (e) {
                if (seq !== self.reqSeq) return;
                self.busy = false;
                self.state(pickIcon('i-alert') + '<span>' + pickEsc((e && e.message) || '网络错误') + '</span>'
                    + '<button type="button" class="lnk">重试</button>');
                var lnk = $('.yx-pick-state .lnk', self.el);
                if (lnk) lnk.addEventListener('click', function () { self.load(true); });
                self.foot();
            });
        },

        apply: function (d) {
            this.items = d.items || [];
            this.pages = d.pages || 1;
            this.busy = false;
            this.render();
        },

        render: function () {
            var self = this;
            var grid = $('.yx-pick-grid', this.el);

            var list = this.items.filter(function (it) {
                if (!self.q) return true;
                return String(it.name || '').toLowerCase().indexOf(self.q) > -1;
            });
            this.shown = list;

            if (!list.length) {
                this.state(pickIcon('i-img') + '<span>' + (this.items.length ? '没有匹配的文件' : '这里还没有文件，点上方「上传图片 / 视频」，或直接把图片视频粘贴到编辑器里') + '</span>');
                this.foot();
                this.syncSel();
                return;
            }
            this.state('');

            grid.innerHTML = list.map(function (it, i) {
                var th;
                if (it.video) {
                    th = '<span class="vx">' + pickIcon('i-video') + '</span>';
                } else if (it.image && it.thumb) {
                    th = '<img src="' + pickEsc(it.thumb) + '" alt="" loading="lazy" decoding="async">';
                } else {
                    th = pickIcon('i-file');
                }
                var on = self.sel[i] ? ' on' : '';
                return '<div class="it' + (it.video ? ' vid' : '') + on + '" data-i="' + i + '">'
                    + '<button type="button" class="th" data-act="pick">' + th + '</button>'
                    + '<span class="tx"><span class="nm">' + pickEsc(it.name || '未命名') + '</span>'
                    + '<span class="mt">' + pickEsc(it.size || '') + (it.time ? ' · ' + pickEsc(it.time) : '') + '</span></span>'
                    + (it.video ? '<span class="vb">视频</span>' : '')
                    + '<button type="button" class="ck" data-act="sel" aria-label="选择">' + pickIcon('i-check') + '</button>'
                    + '<button type="button" class="cp" data-act="copy" aria-label="复制链接">' + pickIcon('i-link') + '</button>'
                    + '</div>';
            }).join('');

            $$('[data-act]', grid).forEach(function (b) {
                b.addEventListener('click', function (e) {
                    var box = b.parentNode;
                    var idx = parseInt(box.getAttribute('data-i'), 10);
                    var it = self.shown[idx];
                    if (!it) return;
                    var act = b.getAttribute('data-act');
                    if (act === 'copy') {
                        e.stopPropagation();
                        self.copy(it.url);
                    } else if (act === 'sel') {
                        e.stopPropagation();
                        if (self.sel[idx]) delete self.sel[idx];
                        else self.sel[idx] = it;
                        box.classList.toggle('on');
                        self.syncSel();
                    } else {
                        self.emit([it]);
                        self.close();
                    }
                });
            });
            this.foot();
            this.syncSel();
        },

        syncSel: function () {
            var n = Object.keys(this.sel).length;
            var b = $('.ins-all', this.el);
            if (b) {
                b.disabled = n === 0;
                b.textContent = n ? '插入选中（' + n + '）' : '插入选中';
                b.classList.toggle('primary', n > 0);
            }
        },

        insertSelected: function () {
            var list = Object.keys(this.sel).map(function (k) { return this.sel[k]; }, this);
            if (!list.length) return;
            this.emit(list);
            this.close();
        },

        emit: function (list) {
            if (!this.opt || typeof this.opt.onPick !== 'function') return;
            var fn = this.opt.onPick;
            if (typeof this.opt.onPickAll === 'function' && list.length > 1) {
                this.opt.onPickAll(list);
                return;
            }
            list.forEach(function (it) { fn(it); });
        },

        
        uploadAll: function (files) {
            var self = this;
            var arr = Array.prototype.slice.call(files);
            if (!arr.length) {
                this.state(pickIcon('i-alert') + '<span>未选择文件</span>');
                return;
            }
            arr.forEach(function (f, i) {
                setTimeout(function () { self.upload(f, i === arr.length - 1); }, i * 120);
            });
        },

        upload: function (file, last) {
            var self = this;
            var isVid = /^video\//.test(file.type) || /\.(mp4|webm|mov|m4v|ogg|ogv)$/i.test(file.name);
            var limit = isVid ? 200 * 1024 * 1024 : 10 * 1024 * 1024;
            if (file.size > limit) {
                this.state(pickIcon('i-alert') + '<span>' + pickEsc(file.name) + ' 超过 ' + (isVid ? '200MB' : '10MB') + ' 限制</span>');
                return;
            }

            this.state(pickIcon('i-upload') + '<span>正在上传 ' + pickEsc(file.name) + ' …</span>', false);
            this.busy = true;
            this.foot();

            var fd = new FormData();
            fd.append('file', file);
            fetchJSON(window.YX_API + '?action=upload', { method: 'POST', body: fd }, 120000).then(function (d) {
                self.busy = false;
                if (!d || d.status !== true) {
                    self.state(pickIcon('i-alert') + '<span>' + pickEsc((d && d.message) || '上传失败') + '</span>');
                    self.foot();
                    return;
                }
                self.cache = {};
                self.page = 1;

                if (self.opt && typeof self.opt.onPick === 'function') {
                    self.opt.onPick(d);
                }
                self.load(true);
            }).catch(function (e) {
                self.busy = false;
                self.state(pickIcon('i-alert') + '<span>' + pickEsc((e && e.message) || '上传失败，请检查网络') + '</span>');
                self.foot();
            });
        },

        copy: function (text) {
            var done = function () {
                var t = document.querySelector('.yx-toast');
                if (t) t.remove();
                var n = document.createElement('div');
                n.className = 'yx-toast show';
                n.textContent = '链接已复制';
                document.body.appendChild(n);
                setTimeout(function () { n.remove(); }, 1600);
            };
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done, function () { window.prompt('复制链接', text); });
            } else {
                window.prompt('复制链接', text);
            }
        }
    };

    window.YXPicker = Picker;

    var Search = {
        el: null,
        idx: 0,
        list: [],
        timer: null,

        menu: function () {
            var seen = {};
            var out = [];
            $$('.yx-nav .yx-mitem, .yx-dbody .yx-mitem').forEach(function (a) {
                var href = a.getAttribute('href') || '';
                if (!href || seen[href]) return;
                seen[href] = 1;
                var use = a.querySelector('use');
                var icon = use ? String(use.getAttribute('href') || '').split('#')[1] : 'i-link';
                out.push({
                    kind: '后台功能',
                    icon: icon || 'i-link',
                    title: (a.querySelector('.yx-lab') ? a.querySelector('.yx-lab').textContent : a.textContent) || '',
                    url: href,
                    meta: ''
                });
            });
            return out;
        },

        build: function () {
            if (this.el) return;
            var self = this;
            var mask = document.createElement('div');
            mask.className = 'yx-gs';
            mask.innerHTML = '<div class="yx-gs-box" role="dialog" aria-modal="true">'
                + '<div class="yx-gs-top">' + pickIcon('i-search') + '<input type="text" placeholder="搜索后台功能、文章、页面、用户、评论…" aria-label="搜索">'
                + '<kbd>Esc</kbd></div>'
                + '<div class="yx-gs-list"></div></div>';
            document.body.appendChild(mask);
            this.el = mask;

            mask.addEventListener('click', function (e) {
                if (e.target === mask) self.close();
            });
            $('input', mask).addEventListener('input', function () {
                self.query(this.value);
            });
            $('input', mask).addEventListener('keydown', function (e) {
                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    self.move(1);
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    self.move(-1);
                } else if (e.key === 'Enter') {
                    e.preventDefault();
                    self.go();
                } else if (e.key === 'Escape') {
                    self.close();
                }
            });
        },

        open: function () {
            var self = this;
            this.build();
            this.el.classList.add('show');
            $('input', this.el).value = '';
            this.query('');
            setTimeout(function () {
                var i = $('input', self.el);
                if (i) i.focus();
            }, 20);
        },

        close: function () {
            if (!this.el) return;
            this.el.classList.remove('show');
        },

        query: function (v) {
            var self = this;
            var q = (v || '').trim();
            var listEl = $('.yx-gs-list', this.el);
            this.idx = 0;
            clearTimeout(this.timer);

            if (!q) {
                this.list = this.menu();
                this.paint();
                return;
            }

            var local = this.menu().filter(function (m) {
                return m.title.toLowerCase().indexOf(q.toLowerCase()) > -1;
            });
            this.list = local;
            this.paint();
            listEl.classList.add('busy');

            this.timer = setTimeout(function () {
                if (!window.YX_API) return;
                fetchJSON(window.YX_API + '?action=search&q=' + encodeURIComponent(q), null, 8000).then(function (d) {
                    if (d && d.status && d.items) {
                        self.list = local.concat(d.items);
                        self.paint();
                    }
                    listEl.classList.remove('busy');
                }).catch(function () {
                    listEl.classList.remove('busy');
                });
            }, 200);
        },

        paint: function () {
            var self = this;
            var listEl = $('.yx-gs-list', this.el);
            if (!this.list.length) {
                listEl.innerHTML = '<div class="yx-gs-empty">没有找到匹配的内容</div>';
                return;
            }
            listEl.innerHTML = this.list.map(function (m, i) {
                return '<a class="yx-gs-it' + (i === self.idx ? ' on' : '') + '" data-i="' + i + '" href="' + pickEsc(m.url) + '">'
                    + '<span class="ic">' + pickIcon(m.icon || 'i-link') + '</span>'
                    + '<span class="tx"><b>' + pickEsc(m.title) + '</b>'
                    + '<em>' + pickEsc(m.meta || '') + '</em></span>'
                    + '<span class="kd">' + pickEsc(m.kind || '') + '</span></a>';
            }).join('');
            $$('.yx-gs-it', listEl).forEach(function (a) {
                a.addEventListener('mouseenter', function () {
                    self.idx = parseInt(a.getAttribute('data-i'), 10);
                    $$('.yx-gs-it', listEl).forEach(function (x) { x.classList.remove('on'); });
                    a.classList.add('on');
                });
                a.addEventListener('click', function () {
                    self.close();
                });
            });
        },

        move: function (d) {
            var items = $$('.yx-gs-it', this.el);
            if (!items.length) return;
            this.idx = Math.min(items.length - 1, Math.max(0, this.idx + d));
            items.forEach(function (x, i) {
                x.classList.toggle('on', i === this.idx);
            }, this);
            if (items[this.idx] && items[this.idx].scrollIntoView) {
                items[this.idx].scrollIntoView({ block: 'nearest' });
            }
        },

        go: function () {
            var items = $$('.yx-gs-it', this.el);
            var a = items[this.idx];
            if (a && a.href) {
                window.location.href = a.href;
            }
        }
    };

    window.YXSearch = Search;

    function initSearch() {
        var btn = document.querySelector('[data-yx-search]');
        if (btn) {
            btn.addEventListener('click', function () {
                Search.open();
            });
        }
        document.addEventListener('keydown', function (e) {
            if (!(e.ctrlKey || e.metaKey) || e.shiftKey || e.altKey) return;
            if (e.key !== 'k' && e.key !== 'K') return;
            var el = document.activeElement;
            var tag = el ? el.tagName : '';
            if (tag === 'INPUT' || tag === 'TEXTAREA' || (el && el.isContentEditable)) return;
            e.preventDefault();
            Search.open();
        });
    }

    initNative();


    function initWx() {
        var card = document.querySelector('[data-wx]');
        if (!card) return;
        var body = card.querySelector('[data-wx-body]');
        var src = card.querySelector('[data-wx-src]');
        if (!body || !window.YX_API) return;

        wApi('').then(function (d) {
            var ICONS = window.YX_ICONS || '';
            if (src) src.textContent = (d.report_time || '').slice(11, 16) + ' 更新 · open-meteo';
            var wind = [d.wind_direction, d.wind_power].filter(Boolean).join(' ');
            var cells = [];
            cells.push(['体感', typeof d.feels_like === 'number' ? Math.round(d.feels_like) + '°' : '—']);
            cells.push(['湿度', typeof d.humidity === 'number' ? d.humidity + '%' : '—']);
            cells.push(['风', wind || '—']);
            cells.push(['能见度', typeof d.visibility === 'number' ? d.visibility + 'km' : '—']);
            cells.push(['气压', typeof d.pressure === 'number' ? Math.round(d.pressure) + 'hPa' : '—']);
            var h = '<div class="yd-wx-now">'
                + '<span class="ico"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="' + ICONS + '#' + wIcon(d.weather) + '"></use></svg></span>'
                + '<span class="tp">' + Math.round(d.temperature) + '<sup>°C</sup></span>'
                + '<span class="ws"><b>' + esc(d.weather || '—') + '</b><i>' + esc(wPlace(d)) + '</i></span>'
                + (typeof d.temp_max === 'number' ? '<span class="hi">' + Math.round(d.temp_min) + '° ~ ' + Math.round(d.temp_max) + '°</span>' : '')
                + '</div>';
            h += '<div class="yd-wx-grid">' + cells.map(function (c) {
                return '<div><i>' + esc(c[0]) + '</i><b>' + esc(c[1]) + '</b></div>';
            }).join('') + '</div>';
            if (d.forecast && d.forecast.length) {
                h += '<div class="yd-wx-fc">' + d.forecast.slice(0, 4).map(function (f) {
                    return '<div><b>' + esc(f.week || '') + '</b><span>' + esc(f.weather_day || '') + '</span><i>' + esc(f.temp_min) + '~' + esc(f.temp_max) + '°</i></div>';
                }).join('') + '</div>';
            }
            body.innerHTML = h;
        }).catch(function () {
            body.innerHTML = '<div class="yd-load">天气数据同步中，稍后自动重试…</div>';
            setTimeout(function () { initWx(); }, 60000);
        });
    }

    

    function initDashLive() {
        var advCard = document.querySelector('[data-dl-adv]');
        var wkCard = document.querySelector('[data-dl-week]');
        if ((!advCard && !wkCard) || !window.YX_API) return;

        var ICONS = window.YX_ICONS || '';
        var busy = false;
        var timer = null;

        function use(href) {
            return '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="' + ICONS + '#' + href + '"></use></svg>';
        }

        function relTime(t) {
            // t: "HH:MM:SS"
            var p = (t || '').split(':');
            if (p.length < 2) return '刚刚更新';
            var then = new Date();
            then.setHours(parseInt(p[0], 10) || 0, parseInt(p[1], 10) || 0, parseInt(p[2], 10) || 0, 0);
            var diff = Math.max(0, Date.now() - then.getTime());
            if (diff < 45000) return '刚刚更新';
            if (diff < 3600000) return Math.floor(diff / 60000) + ' 分钟前更新';
            return (p[0] + ':' + p[1]) + ' 更新';
        }


        function advAction(a) {
            if (a && a.fix) {
                return '<button type="button" class="yd-adv-go fix" data-yx-fix="' + pickEsc(a.fix) + '"'
                    + ' title="后台自动处理，无需手工操作">' + pickEsc(a.action) + '</button>';
            }
            if (a && a.go) {
                return '<a class="yd-adv-go" href="' + pickEsc(a.go) + '">' + pickEsc(a.action) + '</a>';
            }
            return '<span class="yd-adv-go ghost">' + pickEsc(a.action || '自主处理') + '</span>';
        }

        function renderAdv(card, r) {
            var pend = card.querySelector('[data-dl-pending]');
            if (pend) pend.textContent = r.pending || 0;
            var list = card.querySelector('[data-dl-list]');
            if (!list) return;
            if (list.tagName === 'P') {

                if (!r.advice || !r.advice.length) return;
                var ul = document.createElement('ul');
                ul.className = 'yd-adv-list';
                ul.setAttribute('data-dl-list', '');
                list.replaceWith(ul);
                list = ul;
            }
            if (!r.advice || !r.advice.length) {
                list.outerHTML = '<p class="yd-adv-ok" data-dl-list>' + use('i-check') + '各项检查均已通过，保持当前运营节奏即可</p>';
                return;
            }
            var h = '';
            r.advice.forEach(function (a) {
                h += '<li data-pri="' + pickEsc(a.pri) + '">'
                    + '<span class="ic tone-' + pickEsc(a.tone) + '">' + use(pickEsc(a.icon)) + '</span>'
                    + '<div class="tx"><strong>' + pickEsc(a.title) + '</strong>'
                    + '<span>' + pickEsc(a.desc) + '</span></div>'
                    + advAction(a)
                    + '</li>';
            });
            list.innerHTML = h;
        }

        function renderWeek(card, r) {
            var rows = card.querySelector('[data-dl-rows]');
            if (!rows || !r.week || !r.week.rows) return;
            var h = '';
            r.week.rows.forEach(function (x) {
                function cls(v) { return v > 0 ? 'on' : 'z'; }
                h += '<tr' + (x.today ? ' class="today"' : '') + '>'
                    + '<td>' + pickEsc(x.date) + ' <em>' + pickEsc(x.week) + (x.today ? ' · 今' : '') + '</em></td>'
                    + '<td class="' + cls(x.visit) + '">' + x.visit + '</td>'
                    + '<td class="' + cls(x.spider) + '">' + x.spider + '</td>'
                    + '<td class="' + cls(x.post) + '">' + x.post + '</td>'
                    + '<td class="' + cls(x.cmt) + '">' + x.cmt + '</td>'
                    + '</tr>';
            });
            rows.innerHTML = h;
        }

        function render(r) {
            if (advCard) renderAdv(advCard, r);
            if (wkCard) renderWeek(wkCard, r);
            document.querySelectorAll('[data-dl-time] em').forEach(function (em) {
                em.textContent = relTime(r.updated);
            });
        }

        function load() {
            if (busy) return;
            busy = true;
            fetchJSON(window.YX_API + '?action=dash_live', null, 15000).then(function (r) {
                busy = false;
                if (!r || r.status !== true) return;
                render(r);
            }).catch(function () {
                busy = false;
            });
        }

        load();
        timer = setInterval(load, 60000);
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) load();
        });

        window.__yxDashReload = load;


        var collectBtn = document.getElementById('yxCollectBtn');
        if (collectBtn) {
            collectBtn.addEventListener('click', function () {
                var old = collectBtn.textContent;
                collectBtn.disabled = true;
                collectBtn.textContent = '采集中…';
                fetchJSON(window.YX_API + '?action=collect&force=1', null, 60000).then(function (r) {
                    collectBtn.disabled = false;
                    collectBtn.textContent = old;
                    if (r && r.status) {
                        if (!r.skipped) {
                            sysToast('已采集 ' + (r.days || 0) + ' 天 · 访客 ' + (r.visit || 0) + ' · 蜘蛛 ' + (r.spider || 0));
                        } else {
                            sysToast('近 30 分钟已采集，无需重复');
                        }
                    } else {
                        sysToast('采集失败：' + ((r && r.reason) || '未知（请在插件设置填写日志路径）'));
                    }
                    if (window.__yxDashReload) {
                        window.__yxDashReload();
                    }
                }).catch(function () {
                    collectBtn.disabled = false;
                    collectBtn.textContent = old;
                    sysToast('采集请求失败，请检查网络或刷新登录');
                    if (window.__yxDashReload) {
                        window.__yxDashReload();
                    }
                });
            });
        }
    }





    function initSeoFix() {
        if (!window.YX_API) {
            return;
        }

        function renderChecks(checks) {
            var ul = document.querySelector('[data-seo-list]');
            if (!ul || !checks || !checks.length) {
                return;
            }
            var h = '';
            checks.forEach(function (c) {
                var pass = !!c[1];
                h += '<li class="' + (pass ? 'on' : 'off') + '">'
                    + '<i class="st">' + (pass ? '✓' : '—') + '</i>'
                    + '<span class="n">' + pickEsc(c[0]) + '</span>'
                    + '<span class="d">' + pickEsc(c[3]) + '</span></li>';
            });
            ul.innerHTML = h;
        }

        function renderScore(score) {
            if (typeof score !== 'number') {
                return;
            }
            var lv = score >= 80 ? 'ok' : (score >= 50 ? 'warn' : 'danger');
            var ring = document.querySelector('.yd-seo-ring');
            if (ring) {
                ring.className = 'yd-seo-ring r-' + lv;
                var fg = ring.querySelector('.fg');
                if (fg) {
                    fg.setAttribute('stroke-dasharray', score + ' 100');
                }
                var b = ring.querySelector('b');
                if (b) {
                    b.textContent = String(score);
                }
            }
            var icon = document.querySelector('.yd-kpi .ic.ci-f');
            if (icon) {
                var tx = icon.parentNode.querySelector('.tx b');
                if (tx) {
                    tx.textContent = String(score);
                }
            }
        }

        function run(btn, fix) {
            if (btn.getAttribute('data-yx-fixing') === '1') {
                return;
            }
            var label = (btn.textContent || '').trim() || '自动修复';

            if ((fix === 'spam' || fix === 'cmt') && window.confirm) {
                var ok = true;
                try {
                    ok = window.confirm('确定要执行「' + label + '」吗？此操作由后台自动完成。');
                } catch (e) {
                    ok = true;
                }
                if (!ok) {
                    return;
                }
            }
            btn.setAttribute('data-yx-fixing', '1');
            btn.classList.add('busy');
            btn.textContent = '处理中…';

            postJSON(window.YX_API + '?action=seo_fix', 'fix=' + encodeURIComponent(fix))
                .then(function (d) {
                    btn.removeAttribute('data-yx-fixing');
                    btn.classList.remove('busy');
                    btn.textContent = label;
                    if (!d || !d.status) {
                        sysToast((d && d.message) || '修复失败，请稍后重试');
                        return;
                    }
                    if (d.fail && d.fail.length) {
                        sysToast((d.message || '已完成') + '：' + d.fail.join('；'));
                    } else {
                        sysToast(d.message || '已完成');
                    }
                    renderScore(d.score);
                    renderChecks(d.checks);
                    if (typeof window.__yxDashReload === 'function') {
                        window.__yxDashReload();
                    } else if (document.querySelector('[data-dl-adv]')) {
                        setTimeout(function () { window.location.reload(); }, 900);
                    }
                })
                .catch(function (err) {
                    btn.removeAttribute('data-yx-fixing');
                    btn.classList.remove('busy');
                    btn.textContent = label;
                    sysToast((err && err.message) || '修复失败，请检查网络后重试');
                });
        }

        document.addEventListener('click', function (e) {
            var t = e.target && e.target.closest ? e.target.closest('[data-yx-fix],[data-yx-fix-all]') : null;
            if (!t) {
                return;
            }
            e.preventDefault();
            if (t.hasAttribute('data-yx-fix-all')) {
                run(t, 'all');
                return;
            }
            var fix = t.getAttribute('data-yx-fix');
            if (fix) {
                run(t, fix);
            }
        });
    }

    function initTraffic() {
        var card = document.querySelector('[data-traffic]');
        if (!card) return;
        var body = card.querySelector('[data-traffic-body]');
        var src = card.querySelector('[data-traffic-src]');
        if (!body || !window.YX_API) return;

        function render(d) {
            card.style.display = '';
            if (!d || d.empty || (!d.date && (!d.items || !d.items.length))) {
                body.innerHTML = '<div class="yd-tf-empty">暂未获取到交通气象预报，后台会持续抓取</div>';
                if (src) src.textContent = '暂无';
                return;
            }
            var h = '';
            h += '<div class="yd-tf-date">' + pickEsc(d.date || '') + ' 发布'
                + ' · <a href="' + pickEsc(d.url || 'https://www.nmc.cn/f/p-423') + '" target="_blank" rel="noopener">完整预报</a></div>';
            if (d.summary) {
                var s = d.summary;
                h += '<p class="yd-tf-sum">' + pickEsc(s.length > 140 ? s.slice(0, 140) + '…' : s) + '</p>';
            }
            if (d.note) h += '<p class="yd-tf-note">' + pickEsc(d.note) + '</p>';
            h += '<div class="yd-tf-grps">';
            (d.items || []).forEach(function (it) {
                var cls = 'oth', t = it.type || '';
                if (/雪|冰|冻/.test(t)) cls = 'snow';
                else if (/雷|暴/.test(t)) cls = 'storm';
                else if (/雨/.test(t)) cls = 'rain';
                else if (/雾|霾|沙|尘/.test(t)) cls = 'fog';
                var roads = it.roads || [];
                h += '<div class="yd-tf-grp yd-tf-' + cls + '">';
                h += '<div class="yd-tf-grp-h"><span class="tg"></span>' + pickEsc(t) + ' <em>' + roads.length + ' 条受影响路段</em></div>';
                h += '<div class="yd-tf-roads">';
                roads.slice(0, 12).forEach(function (r) { h += '<span class="rd">' + pickEsc(r) + '</span>'; });
                if (roads.length > 12) h += '<span class="rd more">+' + (roads.length - 12) + '</span>';
                h += '</div></div>';
            });
            h += '</div>';
            h += '<div class="yd-tf-src">数据来源：' + pickEsc(d.source || '中央气象台 · 交通运输部') + (d.stale ? ' · 缓存' : '') + '</div>';
            body.innerHTML = h;
            if (src) src.textContent = '中国气象局' + (d.stale ? '（缓存）' : '');
        }

        function load() {

            fetchJSON(window.YX_API + '?action=traffic', null, 15000).then(render).catch(function () {});
        }

        function refreshLive() {

            fetchJSON(window.YX_API + '?action=traffic_live', null, 20000)
                .then(function (d) {
                    if (d && !d.empty && (d.date || (d.items && d.items.length))) {
                        render(d);
                    }
                })
                .catch(function () {});
        }

        load();
        refreshLive();
        setInterval(refreshLive, 120000);
    }

    
    function frontUrl() {
        var cfg = window.YX_CFG || {};
        if (cfg.siteUrl) {
            return cfg.siteUrl;
        }
        return '';
    }

    function initFront() {
        var links = document.querySelectorAll('[data-yx-front]');
        Array.prototype.slice.call(links).forEach(function (a) {

            if (!a.getAttribute('href')) {
                var u = frontUrl();
                if (u) {
                    a.setAttribute('href', u);
                }
            }
            a.addEventListener('click', function (e) {
                var href = a.getAttribute('href') || '';
                var u = frontUrl();

                if (!href || href === '#' || href.indexOf('http') !== 0) {
                    if (!u) {
                        return;
                    }
                    e.preventDefault();
                    window.open(u, '_blank', 'noopener');
                }
            });
        });
    }

    function logoutFallback() {
        var cfg = window.YX_CFG || {};
        return cfg.logoutUrl || '';
    }

    function initLogout() {
        var links = document.querySelectorAll('[data-yx-logout]');
        if (!links.length) {
            return;
        }
        Array.prototype.slice.call(links).forEach(function (a) {
            if (!a.getAttribute('href')) {
                var fb = logoutFallback();
                if (fb) {
                    a.setAttribute('href', fb);
                }
            }
            a.addEventListener('click', function (e) {
                if (e && e.preventDefault) {
                    e.preventDefault();
                }
                if (a.getAttribute('data-yx-logout-going') === '1') {
                    return;
                }
                a.setAttribute('data-yx-logout-going', '1');
                var tx = a.querySelector('.tx');
                if (tx) {
                    tx.textContent = '正在退出…';
                } else {
                    a.setAttribute('aria-busy', 'true');
                }
                var url = a.getAttribute('href') || '';
                var left = false;
                var done = false;
                function leave(to) {
                    if (left || !to) {
                        return;
                    }
                    left = true;
                    window.location.href = to;
                }
                if (!window.fetch || !url) {
                    leave(url);
                    return;
                }
                fetch(url, { credentials: 'same-origin', redirect: 'follow' })
                    .then(function () {
                        done = true;
                        leave(window.location.href);
                    })
                    .catch(function () {
                        if (!done) {
                            leave(url);
                        }
                    });
                setTimeout(function () {
                    if (!done) {
                        leave(url);
                    }
                }, 2500);
            });
        });
    }

    function boot() {
        initNative();
        initDrawer();
        initAvatars();
        initFront();
        initRailFit();
        initTip();
        initWeather();
        initLogin();
        initThemeBtn();
        initLogout();
        initToast();
        initNum();
        initGeo();
        initWx();
        initAlerts();
        initTraffic();
        initDashLive();
        initSeoFix();
        initPrefetch();
        initSearch();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
