






(function () {
    'use strict';

    var END = 'mobile';
    var API = window.YX_WEATHER_MOBILE_API || '';
    var BOOT = window.YX_WEATHER_BOOT || {};
    if (window.YX_WEATHER_END && window.YX_WEATHER_END !== END) {
        return;
    }
    var HAS_API = !!API;

    var REFRESH_MS = 240000;
    var pending = {};
    var timer = null;
    var lastOk = Date.now();
    var msgTimer = null;
    var gpsTried = false;

    var LABELS = {
        snapshot: '工作台快照', refresh: '定时同步', weather: '实时天气',
        typhoon: '台风详情', traffic: '交通影响', trends: '运行趋势',
        festivals: '本月节日'
    };

    var Sky = (function () {
        var PFX = 'wm';
        var DENSITY = 0.62;
        var items = [];
        var raf = 0;
        var last = 0;
        var frozen = false;
        var low = false;
        var watch = null;
        var PAL = {
            sun: { d: [[58, 140, 214], [186, 222, 246]], n: [[9, 17, 42], [38, 54, 96]] },
            cloud: { d: [[126, 151, 177], [206, 219, 228]], n: [[18, 27, 48], [54, 64, 88]] },
            rain: { d: [[74, 94, 116], [150, 168, 182]], n: [[10, 17, 32], [38, 50, 68]] },
            storm: { d: [[52, 60, 82], [110, 118, 138]], n: [[8, 10, 24], [30, 34, 54]] },
            snow: { d: [[140, 166, 190], [224, 234, 242]], n: [[20, 30, 52], [64, 80, 108]] },
            fog: { d: [[150, 160, 166], [214, 218, 220]], n: [[28, 32, 40], [70, 74, 82]] },
            wind: { d: [[96, 150, 190], [190, 214, 228]], n: [[14, 24, 48], [44, 60, 92]] }
        };

        function num(v, d) { var x = parseFloat(v); return isFinite(x) ? x : d; }
        function cl(v, a, b) { return v < a ? a : (v > b ? b : v); }
        function rr(a, b) { return a + Math.random() * (b - a); }
        function col(c, a) { return 'rgba(' + Math.round(c[0]) + ',' + Math.round(c[1]) + ',' + Math.round(c[2]) + ',' + a + ')'; }
        function blend(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }

        function palette(s) {
            var d = s.d, pair = (PAL[d.kind] || PAL.sun)[d.day ? 'd' : 'n'];
            var top = pair[0].slice(), bot = pair[1].slice();
            if (s.temp >= 30) { top = blend(top, [214, 148, 96], .13); bot = blend(bot, [246, 214, 170], .13); }
            if (s.temp <= 4) { top = blend(top, [112, 150, 190], .16); bot = blend(bot, [206, 226, 240], .16); }
            var season = num(d.season, (new Date()).getMonth() + 1);
            if (season >= 3 && season <= 5) { top = blend(top, [126, 186, 142], .05); }
            else if (season >= 9 && season <= 11) { top = blend(top, [214, 172, 108], .06); }
            else if (season === 12 || season <= 2) { top = blend(top, [150, 178, 206], .07); }
            var haze = cl((s.aqi - 60) / 260, 0, .34) + cl((10 - s.vis) / 24, 0, .22);
            if (haze > 0) { top = blend(top, [166, 166, 160], haze); bot = blend(bot, [202, 200, 192], haze * 1.1); }
            return [top, bot];
        }

        function texCloud(rgb, dark) {
            var c = document.createElement('canvas'); c.width = 200; c.height = 96;
            var x = c.getContext('2d');
            var puffs = [[36, 58, 28], [66, 44, 34], [98, 40, 38], [132, 48, 32], [160, 60, 24], [74, 66, 36], [116, 66, 34], [150, 68, 26]];
            puffs.forEach(function (p) {
                var g = x.createRadialGradient(p[0], p[1], 2, p[0], p[1], p[2]);
                g.addColorStop(0, col(rgb, dark ? .92 : .82));
                g.addColorStop(.55, col(rgb, dark ? .68 : .5));
                g.addColorStop(1, col(rgb, 0));
                x.fillStyle = g; x.beginPath(); x.arc(p[0], p[1], p[2], 0, 6.2832); x.fill();
            });
            return c;
        }

        function texGlow(rgb) {
            var c = document.createElement('canvas'); c.width = 160; c.height = 160;
            var x = c.getContext('2d');
            var g = x.createRadialGradient(80, 80, 2, 80, 80, 78);
            g.addColorStop(0, col(rgb, .9)); g.addColorStop(.22, col(rgb, .38));
            g.addColorStop(.6, col(rgb, .1)); g.addColorStop(1, col(rgb, 0));
            x.fillStyle = g; x.fillRect(0, 0, 160, 160); return c;
        }

        function build(s) {
            var d = s.d, area = s.w * s.h, i;
            var f = DENSITY * (s.role === 'hero' ? 1 : .42) * cl(area / (560 * 160), .22, 1.7);
            s.wind = num(d.wind, 0); s.gust = num(d.gust, s.wind);
            s.rain = cl(num(d.rain, 0), 0, 30); s.cloud = cl(num(d.cloud, 50), 0, 100);
            s.vis = num(d.vis, 10); s.aqi = num(d.aqi, 0); s.temp = num(d.temp, 18);
            s.uv = num(d.uv, 3); s.kind = d.kind || 'sun'; s.day = !!d.day;
            var rad = num(d.deg, 0) * Math.PI / 180;
            s.wx = Math.sin(rad) * cl(s.wind / 8, -1.6, 1.6);
            s.P = palette(s);
            s.tex = {
                light: texCloud(s.day ? [236, 242, 248] : [92, 104, 132], false),
                dark: texCloud(s.day ? [112, 126, 146] : [36, 46, 70], true),
                glow: texGlow(s.day ? [255, 226, 158] : [186, 208, 255])
            };
            s.hills = [];
            for (var l = 0; l < 2; l++) {
                var pts = [], seed = 17 + l * 37;
                for (i = 0; i <= 18; i++) { seed = (seed * 9301 + 49297) % 233280; pts.push(seed / 233280); }
                s.hills.push(pts);
            }
            s.stars = [];
            var ns = Math.round(90 * f);
            for (i = 0; i < ns; i++) s.stars.push({ x: rr(0, s.w), y: rr(0, s.h * .72), r: rr(.4, 1.5), p: rr(0, 6.28), v: rr(.6, 2.2) });
            s.clouds = [];
            var nc = cl(Math.round(s.cloud / 11), 2, 10);
            for (i = 0; i < nc; i++) s.clouds.push({ x: rr(-.2, 1.2) * s.w, y: rr(.02, .42) * s.h, sc: rr(.5, 1.25), v: rr(.35, 1.1), a: rr(.45, .95), deep: i % 3 === 0 });
            s.drops = [];
            var nd = Math.round(cl((s.rain * 16 + 24) * f, 10, 280));
            for (i = 0; i < nd; i++) s.drops.push({ x: rr(-s.w * .2, s.w * 1.2), y: rr(-s.h, s.h), l: rr(7, 20), v: rr(.8, 1.5), a: rr(.25, .75) });
            s.splash = [];
            s.flakes = [];
            var nf = Math.round(cl(58 * f, 8, 110));
            for (i = 0; i < nf; i++) s.flakes.push({ x: rr(0, s.w), y: rr(-s.h, s.h), r: rr(1.1, 3.4), sp: rr(-1.2, 1.2), p: rr(0, 6.28), v: rr(.35, 1) });
            s.snowLine = 0;
            s.streaks = [];
            var nst = Math.round(cl(s.wind * 1.5 + 5, 4, 22) * f);
            for (i = 0; i < nst; i++) s.streaks.push({ x: rr(-s.w, s.w), y: rr(.25, .9) * s.h, l: rr(16, 70), v: rr(.5, 1.4), a: rr(.08, .3) });
            s.fog = [];
            for (i = 0; i < 5; i++) s.fog.push({ x: rr(-s.w, s.w), y: rr(.35, .92) * s.h, w: rr(.45, 1.1) * s.w, h: rr(10, 26), v: rr(.4, 1.2), a: rr(.1, .3) });
            s.dust = [];
            var ndu = Math.round(cl((s.aqi - 50) * .5 * f, 0, 90));
            for (i = 0; i < ndu; i++) s.dust.push({ x: rr(0, s.w), y: rr(0, s.h), r: rr(.4, 1.5), v: rr(.1, .5), p: rr(0, 6.28) });
            s.meteor = { t: rr(8, 24), x: 0, y: 0, on: 0 };
            s.bolt = { t: rr(2.5, 7), flash: 0, pts: null };
            s.t = 0;
        }

        function resize(s) {
            var r = s.el.getBoundingClientRect();
            var w = Math.max(1, Math.round(r.width || s.el.clientWidth || 300));
            var h = Math.max(1, Math.round(r.height || s.el.clientHeight || 120));
            var dpr = Math.min(2, window.devicePixelRatio || 1);
            if (w === s.w && h === s.h && dpr === s.dpr) return;
            s.w = w; s.h = h; s.dpr = dpr;
            s.cv.width = Math.round(w * dpr); s.cv.height = Math.round(h * dpr);
            s.cv.style.width = w + 'px'; s.cv.style.height = h + 'px';
            s.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            build(s);
        }

        function drawSky(s, t) {
            var c = s.ctx, g = c.createLinearGradient(0, 0, 0, s.h);
            g.addColorStop(0, col(s.P[0], 1));
            g.addColorStop(.62, col(blend(s.P[0], s.P[1], .55), 1));
            g.addColorStop(1, col(s.P[1], 1));
            c.fillStyle = g; c.fillRect(0, 0, s.w, s.h);
            var h = cl(((num(s.d.hour, 12) + num(s.d.minute, 0) / 60) - 6) / 12, 0, 1);
            var sx = s.w * (.08 + .84 * h), sy = s.h * (.78 - .6 * Math.sin(Math.PI * h));
            if (!s.day) {
                for (var i = 0; i < s.stars.length; i++) {
                    var st = s.stars[i], a = .25 + .55 * Math.abs(Math.sin(t * st.v + st.p));
                    c.fillStyle = 'rgba(255,255,255,' + a.toFixed(2) + ')';
                    c.fillRect(st.x, st.y, st.r, st.r);
                }
                c.save(); c.globalAlpha = .92;
                c.drawImage(s.tex.glow, sx - 52, sy - 52, 104, 104);
                c.fillStyle = '#e8eef8'; c.beginPath(); c.arc(sx, sy, Math.max(7, s.h * .085), 0, 6.2832); c.fill();
                c.fillStyle = col(s.P[0], .95); c.beginPath();
                c.arc(sx + Math.max(4, s.h * .05), sy - Math.max(2, s.h * .02), Math.max(7, s.h * .085), 0, 6.2832); c.fill();
                c.restore();
            } else {
                var pulse = 1 + .04 * Math.sin(t * 1.4);
                c.save(); c.globalAlpha = cl(s.uv / 12 + .35, .35, .95);
                c.drawImage(s.tex.glow, sx - 70 * pulse, sy - 70 * pulse, 140 * pulse, 140 * pulse);
                c.globalAlpha = .9; c.fillStyle = '#fff6da';
                c.beginPath(); c.arc(sx, sy, Math.max(6, s.h * .075), 0, 6.2832); c.fill();
                c.strokeStyle = 'rgba(255,246,214,.32)'; c.lineWidth = 1;
                for (var k = 0; k < 12; k++) {
                    var an = k * Math.PI / 6 + t * .06;
                    var r1 = s.h * .11, r2 = s.h * (.16 + .02 * Math.sin(t * 2 + k));
                    c.beginPath(); c.moveTo(sx + Math.cos(an) * r1, sy + Math.sin(an) * r1);
                    c.lineTo(sx + Math.cos(an) * r2, sy + Math.sin(an) * r2); c.stroke();
                }
                c.restore();
            }
        }

        function drawMeteor(s, dt) {
            if (s.day) return;
            var c = s.ctx, m = s.meteor;
            m.t -= dt;
            if (m.t <= 0 && m.on <= 0) { m.t = rr(14, 32); m.on = .7; m.x = rr(s.w * .2, s.w * .9); m.y = rr(0, s.h * .35); }
            if (m.on > 0) {
                m.on -= dt;
                var g = c.createLinearGradient(m.x - 60, m.y - 30, m.x, m.y);
                g.addColorStop(0, 'rgba(255,255,255,0)');
                g.addColorStop(1, 'rgba(255,255,255,' + cl(m.on * 1.2, 0, .8).toFixed(2) + ')');
                c.strokeStyle = g; c.lineWidth = 1.3;
                c.beginPath(); c.moveTo(m.x - 60, m.y - 30); c.lineTo(m.x, m.y); c.stroke();
            }
        }

        function drawHills(s, t) {
            var c = s.ctx;
            for (var l = 0; l < 2; l++) {
                var pts = s.hills[l], base = s.h * (l === 0 ? .76 : .86);
                c.beginPath(); c.moveTo(0, s.h);
                for (var i = 0; i < pts.length; i++) {
                    var x = (i / (pts.length - 1)) * s.w * 1.15 - s.w * .08 - ((t * (2 + l * 4) * s.wx) % 30);
                    c.lineTo(x, base - pts[i] * s.h * (l === 0 ? .16 : .1));
                }
                c.lineTo(s.w, s.h); c.closePath();
                c.fillStyle = col(blend(s.P[0], l === 0 ? [20, 38, 58] : [10, 22, 38], l === 0 ? .55 : .72), l === 0 ? .36 : .6);
                c.fill();
            }
        }

        function drawFog(s, dt, t) {
            var c = s.ctx, dense = cl((12 - s.vis) / 12, 0, 1);
            for (var i = 0; i < s.fog.length; i++) {
                var f = s.fog[i];
                f.x += (8 + s.wind * 2) * f.v * dt * s.wx * .3 + (6 + s.wind) * dt * .5;
                if (f.x > s.w + f.w / 2) f.x = -f.w / 2;
                var g = c.createLinearGradient(f.x - f.w / 2, 0, f.x + f.w / 2, 0);
                g.addColorStop(0, 'rgba(226,232,236,0)');
                g.addColorStop(.5, col(s.day ? [238, 242, 244] : [136, 146, 160], f.a * (.4 + dense)));
                g.addColorStop(1, 'rgba(226,232,236,0)');
                c.fillStyle = g; c.beginPath();
                c.ellipse(f.x, f.y + Math.sin(t * .5 + i) * 3, f.w / 2, f.h, 0, 0, 6.2832); c.fill();
            }
        }

        function drawClouds(s, dt) {
            var c = s.ctx;
            for (var i = 0; i < s.clouds.length; i++) {
                var q = s.clouds[i];
                q.x += (2.4 + s.wind * 1.3) * q.v * s.wx * dt + (4 + s.wind) * q.v * dt * .25;
                if (q.x > s.w + 140) q.x = -220 * q.sc;
                var heavy = s.kind === 'rain' || s.kind === 'storm' || s.kind === 'snow';
                var tex = (q.deep || heavy) ? s.tex.dark : s.tex.light;
                var w = 190 * q.sc, h = 92 * q.sc;
                c.save(); c.globalAlpha = q.a * (s.day ? 1 : .75);
                c.drawImage(tex, q.x - w / 2, q.y, w, h);
                if (heavy) { c.globalAlpha = q.a * .3; c.drawImage(s.tex.dark, q.x - w / 2, q.y + 6, w, h); }
                c.restore();
            }
        }

        function drawWind(s, dt) {
            var c = s.ctx;
            if (s.wind < 1.5 && s.kind !== 'wind') return;
            c.lineCap = 'round';
            for (var i = 0; i < s.streaks.length; i++) {
                var q = s.streaks[i];
                q.x += (40 + s.wind * 16 + s.gust * 4) * q.v * dt * (s.wx >= 0 ? 1 : -1);
                var lim = s.w + q.l;
                if (q.x > lim) q.x = -q.l;
                if (q.x < -q.l) q.x = lim;
                var g = c.createLinearGradient(q.x, 0, q.x + q.l, 0);
                g.addColorStop(0, 'rgba(255,255,255,0)');
                g.addColorStop(.5, 'rgba(255,255,255,' + q.a.toFixed(2) + ')');
                g.addColorStop(1, 'rgba(255,255,255,0)');
                c.strokeStyle = g; c.lineWidth = 1;
                c.beginPath(); c.moveTo(q.x, q.y);
                c.bezierCurveTo(q.x + q.l * .3, q.y - 6, q.x + q.l * .7, q.y + 6, q.x + q.l, q.y); c.stroke();
            }
        }

        function drawRain(s, dt) {
            var c = s.ctx, k = s.kind === 'storm' ? 1.35 : 1;
            var v = (150 + s.rain * 22 + s.wind * 8) * k, dx = s.wx * 38;
            c.lineCap = 'round'; c.lineWidth = 1;
            c.strokeStyle = s.day ? 'rgba(214,234,248,.62)' : 'rgba(186,210,238,.55)';
            c.beginPath();
            for (var i = 0; i < s.drops.length; i++) {
                var d = s.drops[i];
                d.y += v * d.v * dt; d.x += dx * dt * d.v;
                if (d.y > s.h) {
                    if (Math.random() < .24) s.splash.push({ x: d.x, y: s.h - rr(0, 6), r: 1, life: .42 });
                    d.y = -rr(4, s.h * .5); d.x = rr(-s.w * .2, s.w * 1.2);
                }
                if (d.x > s.w + 30) d.x = -20;
                if (d.x < -30) d.x = s.w + 20;
                c.moveTo(d.x, d.y); c.lineTo(d.x - dx * .06, d.y + d.l * d.v);
            }
            c.stroke();
            c.strokeStyle = 'rgba(255,255,255,.4)'; c.lineWidth = .7; c.beginPath();
            for (i = 0; i < s.drops.length; i += 5) {
                var e = s.drops[i];
                c.moveTo(e.x, e.y); c.lineTo(e.x - dx * .06, e.y + e.l * e.v * .7);
            }
            c.stroke();
            for (i = s.splash.length - 1; i >= 0; i--) {
                var sp = s.splash[i]; sp.life -= dt; sp.r += dt * 22;
                if (sp.life <= 0) { s.splash.splice(i, 1); continue; }
                c.strokeStyle = 'rgba(226,240,250,' + (sp.life * .7).toFixed(2) + ')'; c.lineWidth = .8;
                c.beginPath(); c.ellipse(sp.x, sp.y, sp.r, sp.r * .32, 0, 0, 6.2832); c.stroke();
            }
        }

        function drawSnow(s, dt, t) {
            var c = s.ctx;
            c.strokeStyle = 'rgba(255,255,255,.85)'; c.lineWidth = .9; c.lineCap = 'round';
            for (var i = 0; i < s.flakes.length; i++) {
                var f = s.flakes[i];
                f.y += (18 + 26 * f.v + s.wind * 1.2) * dt;
                f.x += (s.wx * 16 + Math.sin(t * 1.3 + f.p) * 8) * dt;
                f.sp += dt * .4 * f.v;
                if (f.y > s.h + 4) { f.y = -6; f.x = rr(0, s.w); }
                if (f.x > s.w + 8) f.x = -6;
                if (f.x < -8) f.x = s.w + 6;
                var R = f.r;
                c.save(); c.translate(f.x, f.y); c.rotate(f.sp); c.globalAlpha = .55 + .4 * f.v;
                c.beginPath();
                for (var b = 0; b < 6; b++) {
                    var a = b * Math.PI / 3;
                    c.moveTo(0, 0); c.lineTo(Math.cos(a) * R, Math.sin(a) * R);
                    var bx = Math.cos(a) * R * .6, by = Math.sin(a) * R * .6;
                    c.moveTo(bx, by); c.lineTo(bx + Math.cos(a + .5) * R * .32, by + Math.sin(a + .5) * R * .32);
                    c.moveTo(bx, by); c.lineTo(bx + Math.cos(a - .5) * R * .32, by + Math.sin(a - .5) * R * .32);
                }
                c.stroke(); c.restore();
            }
            s.snowLine = Math.min(s.h * .16, s.snowLine + dt * .35);
            if (s.snowLine > .4) {
                var g = c.createLinearGradient(0, s.h - s.snowLine, 0, s.h);
                g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(246,250,255,.82)');
                c.fillStyle = g; c.fillRect(0, s.h - s.snowLine, s.w, s.snowLine);
            }
        }

        function drawHail(s, dt) {
            var c = s.ctx; c.fillStyle = 'rgba(238,246,252,.85)';
            for (var i = 0; i < s.drops.length; i += 3) {
                var d = s.drops[i];
                d.y += (190 + s.wind * 6) * dt * d.v; d.x += s.wx * 22 * dt;
                if (d.y > s.h) { d.y = -8; d.x = rr(0, s.w); }
                c.beginPath(); c.arc(d.x, d.y, 1.8, 0, 6.2832); c.fill();
            }
        }

        function drawBolt(s, dt) {
            var c = s.ctx, b = s.bolt;
            b.t -= dt;
            if (b.t <= 0) {
                b.t = rr(3.2, 9); b.flash = .42;
                var x0 = rr(s.w * .15, s.w * .85), y = s.h * .28, pts = [[x0, y]];
                while (y < s.h * .92) { y += rr(s.h * .06, s.h * .14); x0 += rr(-18, 18); pts.push([x0, y]); }
                b.pts = pts;
            }
            if (b.flash > 0) {
                b.flash -= dt;
                c.fillStyle = 'rgba(226,236,255,' + cl(b.flash * .34, 0, .16).toFixed(3) + ')';
                c.fillRect(0, 0, s.w, s.h);
                if (b.pts) {
                    c.strokeStyle = 'rgba(240,246,255,' + cl(b.flash * 2, 0, .9).toFixed(2) + ')';
                    c.lineWidth = 1.6; c.shadowColor = '#dce8ff'; c.shadowBlur = 12;
                    c.beginPath(); c.moveTo(b.pts[0][0], b.pts[0][1]);
                    for (var i = 1; i < b.pts.length; i++) c.lineTo(b.pts[i][0], b.pts[i][1]);
                    c.stroke(); c.shadowBlur = 0;
                }
            }
        }

        function drawDust(s, dt, t) {
            var c = s.ctx;
            if (!s.dust.length) return;
            c.fillStyle = 'rgba(198,190,168,.42)';
            for (var i = 0; i < s.dust.length; i++) {
                var p = s.dust[i];
                p.x += (6 + s.wind * 2) * dt;
                p.y -= p.v * dt * 6 + Math.sin(t + p.p) * dt * 3;
                if (p.x > s.w + 3) p.x = -3;
                if (p.y < -3) p.y = s.h + 3;
                c.beginPath(); c.arc(p.x, p.y, p.r, 0, 6.2832); c.fill();
            }
        }

        function drawGround(s, t) {
            var c = s.ctx, i, x, yy;
            if (s.kind === 'rain' || s.kind === 'storm') {
                var g = c.createLinearGradient(0, s.h * .82, 0, s.h);
                g.addColorStop(0, 'rgba(180,212,238,0)'); g.addColorStop(1, 'rgba(190,220,244,.3)');
                c.fillStyle = g; c.fillRect(0, s.h * .82, s.w, s.h * .18);
                c.strokeStyle = 'rgba(232,244,255,.16)'; c.lineWidth = 1;
                for (i = 0; i < 7; i++) {
                    c.beginPath();
                    for (x = 0; x <= s.w; x += 12) {
                        yy = s.h * .86 + i * s.h * .02 + Math.sin(x * .045 + t * 2 + i) * 1.1;
                        if (x === 0) c.moveTo(x, yy); else c.lineTo(x, yy);
                    }
                    c.stroke();
                }
            }
            if (s.temp >= 30 && s.day) {
                c.strokeStyle = 'rgba(255,236,200,.14)';
                for (i = 0; i < 5; i++) {
                    c.beginPath();
                    for (x = 0; x <= s.w; x += 10) {
                        yy = s.h * .78 + i * 7 + Math.sin(x * .03 + t * 3 + i) * 2.2;
                        if (x === 0) c.moveTo(x, yy); else c.lineTo(x, yy);
                    }
                    c.stroke();
                }
            }
            if (s.temp <= 2) {
                var v = c.createRadialGradient(s.w / 2, s.h / 2, s.h * .2, s.w / 2, s.h / 2, s.w * .75);
                v.addColorStop(0, 'rgba(210,232,248,0)'); v.addColorStop(1, 'rgba(206,230,248,.24)');
                c.fillStyle = v; c.fillRect(0, 0, s.w, s.h);
            }
            var vg = c.createRadialGradient(s.w / 2, s.h * .45, s.h * .25, s.w / 2, s.h * .5, Math.max(s.w, s.h) * .78);
            vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(4,10,20,.28)');
            c.fillStyle = vg; c.fillRect(0, 0, s.w, s.h);
        }

        function frame(ts) {
            raf = 0;
            if (frozen) return;
            var dt = Math.min(.05, (ts - last) / 1000 || .016);
            last = ts;
            for (var i = 0; i < items.length; i++) {
                var s = items[i];
                if (!s.el.isConnected || s.el.__yxHidden) continue;
                try {
                    resize(s); s.t += dt;
                    drawSky(s, s.t); drawMeteor(s, dt); drawHills(s, s.t);
                    drawFog(s, dt, s.t); drawClouds(s, dt); drawWind(s, dt);
                    if (s.kind === 'rain' || s.kind === 'storm') drawRain(s, dt);
                    if (s.kind === 'snow') drawSnow(s, dt, s.t);
                    if (s.kind === 'rain' && (s.d.code === 66 || s.d.code === 67 || s.d.code === 77)) drawHail(s, dt);
                    if (s.kind === 'storm') drawBolt(s, dt);
                    drawDust(s, dt, s.t); drawGround(s, s.t);
                    if (!s.on) { s.on = true; s.el.classList.add('sky-on'); }
                } catch (e) { }
            }
            if (!low) raf = requestAnimationFrame(frame);
        }

        function kick() {
            if (frozen) return;
            if (!raf) { last = (window.performance && performance.now ? performance.now() : Date.now()) - 16; raf = requestAnimationFrame(frame); }
        }

        function scan() {
            var els = document.querySelectorAll('[data-' + PFX + '-scene]'), seen = [];
            for (var i = 0; i < els.length; i++) {
                var el = els[i];
                if (!el.__sky) {
                    var cv = el.querySelector('canvas.' + PFX + '-sky');
                    if (!cv) { cv = document.createElement('canvas'); cv.className = PFX + '-sky'; el.insertBefore(cv, el.firstChild); }
                    var ctx = cv.getContext('2d');
                    if (!ctx) continue;
                    var d = {};
                    try { d = JSON.parse(el.getAttribute('data-' + PFX + '-sky') || '{}'); } catch (e) { d = {}; }
                    el.__sky = { el: el, cv: cv, ctx: ctx, d: d, role: el.getAttribute('data-' + PFX + '-scene') || 'mini', w: 0, h: 0, dpr: 0 };
                    if (watch) watch.observe(el);
                }
                seen.push(el.__sky);
            }
            items = seen;
            if (items.length) { items.forEach(resize); kick(); }
        }

        function pause(on) {
            frozen = !!on;
            if (frozen) { if (raf) { cancelAnimationFrame(raf); raf = 0; } }
            else kick();
        }

        if (window.IntersectionObserver) {
            watch = new IntersectionObserver(function (es) {
                es.forEach(function (e) { e.target.__yxHidden = !e.isIntersecting; });
            }, { rootMargin: '60px' });
        }
        window.addEventListener('resize', function () { items.forEach(resize); }, { passive: true });
        document.addEventListener('visibilitychange', function () { pause(document.hidden); });
        if (window.MutationObserver) {
            var moTimer = 0;
            var mo = new MutationObserver(function () {
                if (moTimer) { return; }
                moTimer = setTimeout(function () { moTimer = 0; scan(); }, 60);
            });
            mo.observe(document.documentElement, { childList: true, subtree: true });
        }
        window.addEventListener('load', function () { scan(); });
        if (window.ResizeObserver) {
            var ro = new ResizeObserver(function () { items.forEach(resize); });
            var roOld = watch;
            watch = { observe: function (el) { if (roOld) { roOld.observe(el); } ro.observe(el); } };
        }
        return { scan: scan, pause: pause };
    })();


    var Typhoon = (function () {
        var items = [], raf = 0, frozen = false, watch = null;

        function gradeSpeed(g) {
            if (g === 'SuperTY' || g === 'STY') { return 1.5; }
            if (g === 'TY') { return 1.25; }
            if (g === 'STS') { return 1.0; }
            if (g === 'TS') { return 0.8; }
            return 0.55;
        }

        function resize(it) {
            var w = it.el.clientWidth || 0, h = it.el.clientHeight || 0;
            if (!w || !h) { return; }
            var dpr = Math.min(2, window.devicePixelRatio || 1);
            if (it.w === w && it.h === h && it.dpr === dpr) { return; }
            it.w = w; it.h = h; it.dpr = dpr;
            it.cv.width = Math.round(w * dpr);
            it.cv.height = Math.round(h * dpr);
            it.cv.style.width = w + 'px';
            it.cv.style.height = h + 'px';
            it.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        }

        function draw(it, now) {
            var ctx = it.ctx, w = it.w, h = it.h;
            if (!w || !h) { return; }
            var t = now / 1000;
            var g = ctx.createLinearGradient(0, 0, 0, h);
            g.addColorStop(0, '#071a2a');
            g.addColorStop(0.55, '#0b2b3d');
            g.addColorStop(1, '#0e3b4c');
            ctx.fillStyle = g;
            ctx.fillRect(0, 0, w, h);
            var R = Math.min(w * 0.46, h * 1.35);
            var cx = w * 0.5, cy = h * 0.54;
            var glow = ctx.createRadialGradient(cx, cy, R * 0.05, cx, cy, R * 1.1);
            glow.addColorStop(0, 'rgba(150,215,255,.20)');
            glow.addColorStop(0.5, 'rgba(90,160,210,.08)');
            glow.addColorStop(1, 'rgba(5,20,32,0)');
            ctx.fillStyle = glow;
            ctx.fillRect(0, 0, w, h);
            ctx.save();
            ctx.translate(cx, cy);
            var spin = t * 0.9 * it.speed;
            for (var a = 0; a < 3; a++) {
                for (var j = 0; j < 66; j++) {
                    var p = j / 66;
                    var rr = R * (0.10 + p * 0.92);
                    var ang = spin * (1.25 - p * 0.55) + a * (Math.PI * 2 / 3) + p * 4.4;
                    var x = Math.cos(ang) * rr;
                    var y = Math.sin(ang) * rr * 0.52;
                    var alpha = (0.05 + 0.30 * (1 - p)) * (0.72 + 0.28 * Math.sin(t * 2.2 + j * 0.35));
                    ctx.beginPath();
                    ctx.arc(x, y, 1.3 + p * 2.6, 0, 6.283);
                    ctx.fillStyle = 'rgba(214,238,255,' + alpha.toFixed(3) + ')';
                    ctx.fill();
                }
            }
            for (var k = 0; k < 2; k++) {
                var ang2 = spin * 0.6 + k * Math.PI;
                ctx.beginPath();
                ctx.arc(0, 0, R * (0.62 + k * 0.22), ang2, ang2 + 1.5);
                ctx.strokeStyle = 'rgba(205,235,255,' + (0.16 - k * 0.05).toFixed(3) + ')';
                ctx.lineWidth = 5 - k * 1.5;
                ctx.stroke();
            }
            ctx.beginPath();
            ctx.arc(0, 0, R * 0.14, 0, 6.283);
            ctx.fillStyle = 'rgba(4,16,26,.88)';
            ctx.fill();
            ctx.beginPath();
            ctx.arc(0, 0, R * 0.155, 0, 6.283);
            ctx.strokeStyle = 'rgba(190,232,255,.55)';
            ctx.lineWidth = 1.6;
            ctx.stroke();
            ctx.restore();
            ctx.strokeStyle = 'rgba(180,220,245,.18)';
            ctx.lineWidth = 1;
            for (var m = 0; m < 20; m++) {
                var mx = ((m * 97 + t * 40 * it.speed) % (w + 80)) - 40;
                var my = ((m * 53 + t * 26) % h);
                ctx.beginPath();
                ctx.moveTo(mx, my);
                ctx.lineTo(mx + 9, my + 4);
                ctx.stroke();
            }
        }

        function frame(now) {
            raf = 0;
            if (!items.length) { return; }
            for (var i = 0; i < items.length; i++) {
                var it = items[i];
                if (!it.el.__yxHidden) {
                    resize(it);
                    try { draw(it, now); } catch (e) { }
                }
            }
            if (!document.hidden) { raf = requestAnimationFrame(frame); }
        }

        function kick() {
            if (frozen || raf) { return; }
            raf = requestAnimationFrame(frame);
        }

        function scan() {
            var els = document.querySelectorAll('[data-tf-anim]');
            var out = [];
            for (var i = 0; i < els.length; i++) {
                var el = els[i];
                if (!el.__tf) {
                    var cv = el.querySelector('canvas.tf-sky');
                    if (!cv) {
                        cv = document.createElement('canvas');
                        cv.className = 'tf-sky';
                        el.insertBefore(cv, el.firstChild);
                    }
                    var ctx = cv.getContext('2d');
                    if (!ctx) { continue; }
                    el.__tf = { el: el, cv: cv, ctx: ctx, w: 0, h: 0, dpr: 0,
                        speed: gradeSpeed(el.getAttribute('data-tf-grade') || 'TS') };
                    if (watch) { watch.observe(el); }
                }
                out.push(el.__tf);
            }
            items = out;
            items.forEach(resize);
            kick();
        }

        function pause(on) {
            frozen = !!on;
            if (frozen) {
                if (raf) { cancelAnimationFrame(raf); raf = 0; }
            } else {
                kick();
            }
        }

        if (window.IntersectionObserver) {
            watch = new IntersectionObserver(function (es) {
                es.forEach(function (e) { e.target.__yxHidden = !e.isIntersecting; });
            }, { rootMargin: '40px' });
        }
        window.addEventListener('resize', function () { items.forEach(resize); }, { passive: true });

        return { scan: scan, pause: pause };
    })();

    function q(sel, root) { return (root || document).querySelector(sel); }
    function qa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function slot(name) { return q('[data-wm-slot="' + name + '"]'); }
    function closest(el, sel) {
        while (el && el !== document) {
            if (el.matches && el.matches(sel)) { return el; }
            el = el.parentNode;
        }
        return null;
    }

    var Metrics = (function () {
        var series = [], tip = null;

        function scan() {
            var chart = q('[data-mx-chart]');
            if (!chart) { return; }
            tip = chart.querySelector('.mx-tip');
            try { series = JSON.parse(chart.getAttribute('data-mx-series') || '[]'); }
            catch (e) { series = []; }
            countUp();
        }

        function countUp() {
            qa('[data-mx-count]').forEach(function (el) {
                if (el.__mxDone) { return; }
                el.__mxDone = true;
                var to = parseFloat(el.getAttribute('data-mx-count'));
                if (!isFinite(to) || to === 0) { return; }
                var start = null, dur = 680;
                function step(ts) {
                    if (!start) { start = ts; }
                    var p = Math.min(1, (ts - start) / dur);
                    var v = to * (1 - Math.pow(1 - p, 3));
                    el.textContent = to % 1 ? v.toFixed(1) : String(Math.round(v));
                    if (p < 1) { requestAnimationFrame(step); }
                    else { el.textContent = el.getAttribute('data-mx-count'); }
                }
                requestAnimationFrame(step);
            });
        }

        function show(rect) {
            var i = parseInt(rect.getAttribute('data-mx-i'), 10);
            var p = series[i];
            if (!p || !tip) { return; }
            tip.innerHTML = '<b>' + p.label + '</b>'
                + '<span>首屏 ' + (p.page_ms !== null ? p.page_ms + ' ms' : '无样本') + '</span>'
                + '<span>接口均耗时 ' + (p.api_avg_ms !== null ? p.api_avg_ms + ' ms' : '—') + '</span>'
                + '<span>调用 ' + p.api_calls + ' 次 · 成功 ' + (p.rate !== null ? p.rate + '%' : '—') + '</span>'
                + '<span>异常 ' + p.errors + ' 次' + (p.health !== null ? ' · 健康 ' + p.health : '') + '</span>';
            tip.hidden = false;
            var chart = q('[data-mx-chart]');
            var cr = chart.getBoundingClientRect(), rr = rect.getBoundingClientRect();
            var left = rr.left - cr.left + rr.width / 2 - tip.offsetWidth / 2;
            left = Math.max(6, Math.min(cr.width - tip.offsetWidth - 6, left));
            tip.style.left = left + 'px';
            tip.style.top = '8px';
        }

        function hide() {
            if (tip) { tip.hidden = true; }
        }

        document.addEventListener('mouseover', function (e) {
            var r = closest(e.target, '[data-mx-chart] .mx-hit');
            if (r) { show(r); }
        });
        document.addEventListener('mouseout', function (e) {
            if (closest(e.target, '[data-mx-chart] .mx-hit')) { hide(); }
        });
        document.addEventListener('click', function (e) {
            var r = closest(e.target, '[data-mx-chart] .mx-hit');
            if (r) { show(r); }
        });

        return { scan: scan };
    })();

    function url(action, params) {
        return API + (API.indexOf('?') >= 0 ? '&' : '?')
            + 'action=' + encodeURIComponent(action)
            + (params ? '&' + form(params) : '')
            + '&_=' + Date.now();
    }
    function form(params) {
        var out = [];
        Object.keys(params || {}).forEach(function (k) {
            if (params[k] !== null && params[k] !== undefined) {
                out.push(encodeURIComponent(k) + '=' + encodeURIComponent(params[k]));
            }
        });
        return out.join('&');
    }

    function msg(text, isErr) {
        var el = q('[data-wm-global-msg]');
        if (!el) { return; }
        el.textContent = text || '';
        el.className = 'wm-inline-msg' + (isErr ? ' err' : '');
        clearTimeout(msgTimer);
        if (text) {
            msgTimer = setTimeout(function () {
                el.textContent = '';
                el.className = 'wm-inline-msg';
            }, 8000);
        }
    }

    function pause(on) {
        qa('[data-wm-scene]').forEach(function (el) {
            if (on) { el.classList.add('paused'); } else { el.classList.remove('paused'); }
        });
        Sky.pause(on);
        Typhoon.pause(on);
    }

    function apply(d) {
        var h = d.html || {};
        var stamp = d.server_time || (h.meta && h.meta.server_time) || '';
        Object.keys(h).forEach(function (k) {
            if (k === 'meta' || typeof h[k] !== 'string') { return; }
            var el = slot(k);
            if (!el) { return; }
            el.innerHTML = h[k];
            var card = closest(el, '[data-wm-card]');
            qa('[data-wm-status]', card || el.parentNode).forEach(function (s) {
                s.textContent = stamp ? stamp + ' 更新' : '已更新';
            });
        });
        if (d.refresh_ms && d.refresh_ms >= 60000 && d.refresh_ms <= 3600000) {
            REFRESH_MS = d.refresh_ms;
        }
        pause(document.hidden);
        Sky.scan();
        Typhoon.scan();
        Metrics.scan();
    }

    function check(d) {
        if (!d || d.status !== true) {
            throw new Error((d && d.message) || '接口未返回有效数据');
        }
        if (d.end && d.end !== END) {
            throw new Error('响应来自 ' + d.end + ' 端，已忽略（两端互不触发）');
        }
        return d;
    }

    function get(action, params) {
        return fetch(url(action, params), {
            method: 'GET', credentials: 'same-origin', cache: 'no-store',
            headers: { 'Accept': 'application/json' }
        }).then(function (r) { return r.json(); });
    }

    function post(action, params) {
        return fetch(url(action), {
            method: 'POST', credentials: 'same-origin', cache: 'no-store',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            body: form(params)
        }).then(function (r) { return r.json(); });
    }

    function busy(on, action, target) {
        if (on) { pending[action] = true; } else { delete pending[action]; }
        if (target) {
            if (on) { target.classList.add('loading'); } else { target.classList.remove('loading'); }
        }
        qa('[data-wm-action="' + action + '"]').forEach(function (b) { b.disabled = on; });
    }

    function run(action, target, quiet) {
        if (pending[action]) { return Promise.resolve(); }
        busy(true, action, quiet ? null : target);
        return get(action).then(function (d) {
            check(d);
            apply(d);
            lastOk = Date.now();
            if (!quiet) {
                msg((LABELS[action] || action) + ' 已同步' + (d.server_time ? ' · ' + d.server_time : ''));
            }
        }).catch(function (e) {
            if (!quiet) {
                msg((LABELS[action] || action) + '失败：' + (e && e.message ? e.message : '网络异常'), true);
            }
        }).then(function () { busy(false, action, quiet ? null : target); });
    }

    function loadTrends(days) {
        if (pending.trends) { return; }
        var root = q('[data-mx-root]');
        if (root) { root.classList.add('loading'); }
        pending.trends = true;
        get('trends', { days: days }).then(function (d) {
            check(d);
            apply(d);
            lastOk = Date.now();
        }).catch(function (e) {
            msg('运行指标加载失败：' + (e && e.message ? e.message : '网络异常'), true);
        }).then(function () {
            delete pending.trends;
            var r2 = q('[data-mx-root]');
            if (r2) { r2.classList.remove('loading'); }
        });
    }

    function locate(params, target) {
        if (pending.locate || pending.refresh) { return; }
        busy(true, 'locate', target);
        msg('正在更新位置…');
        post('locate', params).then(function (d) {
            check(d);
            apply(d);
            lastOk = Date.now();
            var acc = d.location && typeof d.location.accuracy_m !== 'undefined'
                ? d.location.accuracy_m : null;
            msg((d.note || '位置已更新') + (acc !== null ? ' 当前误差 ±' + acc + ' m' : ''));
            setTimeout(function () {
                run('typhoon', null, true);
                run('traffic', null, true);
            }, 600);
        }).catch(function (e) {
            msg('定位失败：' + (e && e.message ? e.message : '网络异常') + '，可用城市 / 坐标手动校准', true);
        }).then(function () { busy(false, 'locate', target); });
    }

    function geoErrorText(e) {
        if (!e) { return '未知原因'; }
        if (e.code === 1) { return '定位权限被拒绝'; }
        if (e.code === 2) { return '设备暂时无法提供位置'; }
        if (e.code === 3) { return '定位超时'; }
        return '浏览器返回错误 ' + e.code;
    }

    
    function requestGps(silent) {
        if (!navigator.geolocation) {
            if (!silent) { msg('当前浏览器不支持高精度定位（需 HTTPS），请改用城市 / 坐标校准', true); }
            return;
        }
        gpsTried = true;
        if (!silent) { msg('正在获取设备位置…'); }
        navigator.geolocation.getCurrentPosition(function (pos) {
            var c = pos.coords || {};
            locate({
                stage: 'gps',
                lat: Number(c.latitude).toFixed(6),
                lon: Number(c.longitude).toFixed(6),
                accuracy: Math.round(Number(c.accuracy) || 50),
                source: '设备定位'
            });
        }, function (err) {
            if (silent) {
                msg('未获得设备定位，当前显示 IP 城市定位');
            } else {
                msg('定位未成功（' + geoErrorText(err) + '），可点「精确定位」重试。', true);
            }
        }, { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 });
    }

    
    function autoGps() {
        var acc = typeof BOOT.accuracy === 'number' ? BOOT.accuracy : 5000;
        if (gpsTried || !navigator.geolocation || (acc > 0 && acc <= 50)) { return; }
        if (navigator.permissions && navigator.permissions.query) {
            try {
                navigator.permissions.query({ name: 'geolocation' }).then(function (p) {
                    if (p && p.state === 'denied') {
                        msg('定位权限已被拒绝，当前显示 IP 粗定位；可点「GPS 精确定位」重新授权。');
                    } else {
                        requestGps(true);
                    }
                }).catch(function () { requestGps(true); });
                return;
            } catch (e) {  }
        }
        requestGps(true);
    }

    function cityCalibrate() {
        var input = q('[data-wm-city]');
        var v = input ? String(input.value || '').trim() : '';
        if (!v) { msg('请先输入城市 / 区域名，例如「佛山」', true); return; }
        locate({ stage: 'city', city: v });
    }

    function coordCalibrate() {
        var lat = q('[data-wm-lat]'), lon = q('[data-wm-lon]');
        var a = lat ? parseFloat(lat.value) : NaN, b = lon ? parseFloat(lon.value) : NaN;
        if (!isFinite(a) || !isFinite(b) || a < -90 || a > 90 || b < -180 || b > 180) {
            msg('经纬度无效：纬度 -90~90，经度 -180~180', true);
            return;
        }
        locate({ stage: 'manual', lat: a, lon: b, accuracy: 30, source: '用户手动校准' });
    }

    function slotFor(a) {
        var map = {
            weather: 'weather', refresh: 'weather', snapshot: 'weather',
            typhoon: 'typhoon', traffic: 'traffic', trends: 'trends',
            festivals: 'calendar'
        };
        return slot(map[a] || '');
    }

    function onClick(e) {
        var t = e.target;
        var rg = closest(t, '[data-mx-range]');
        if (rg) {
            var days = parseInt(rg.getAttribute('data-mx-range'), 10);
            if (days) { loadTrends(days); }
            return;
        }
        var act = closest(t, '[data-wm-action]');
        if (act && !act.disabled) {
            var a = act.getAttribute('data-wm-action');
            if (a === 'ip') { locate({ stage: 'ip' }, slot('location')); }
            else if (a === 'gps') { requestGps(false); }
            else { run(a, slotFor(a) || slot('weather')); }
            return;
        }
        if (closest(t, '[data-wm-gps]')) { requestGps(false); return; }
        if (closest(t, '[data-wm-city-go]')) { cityCalibrate(); return; }
        if (closest(t, '[data-wm-coord]')) { coordCalibrate(); }
    }

    function onKey(e) {
        if (e.key !== 'Enter') { return; }
        if (closest(e.target, '[data-wm-city]')) { e.preventDefault(); cityCalibrate(); }
        if (closest(e.target, '[data-wm-lat]') || closest(e.target, '[data-wm-lon]')) {
            e.preventDefault(); coordCalibrate();
        }
    }

    
    function pullRefresh() {
        var y0 = null, pulled = false;
        document.addEventListener('touchstart', function (e) {
            y0 = window.scrollY <= 0 && e.touches.length === 1 ? e.touches[0].clientY : null;
            pulled = false;
        }, { passive: true });
        document.addEventListener('touchmove', function (e) {
            if (y0 === null || e.touches.length !== 1) { return; }
            if (e.touches[0].clientY - y0 > 72 && window.scrollY <= 0) {
                pulled = true;
                msg('松开即可刷新');
            }
        }, { passive: true });
        document.addEventListener('touchend', function () {
            if (pulled) { run('refresh', slot('weather'), true); }
            y0 = null; pulled = false;
        }, { passive: true });
    }

    function schedule() {
        clearTimeout(timer);
        timer = setTimeout(function () {
            if (!document.hidden) { run('refresh', null, true); }
            schedule();
        }, REFRESH_MS);
    }

    
    function stagger() {
        run('weather', slot('weather'), true);
        [[250, 'trends'], [500, 'festivals'], [900, 'typhoon'], [1300, 'traffic']]
            .forEach(function (j) {
                setTimeout(function () { run(j[1], slotFor(j[1]), true); }, j[0]);
            });
    }

    function boot() {
        document.addEventListener('click', onClick);
        document.addEventListener('keydown', onKey);
        document.addEventListener('visibilitychange', function () {
            pause(document.hidden);
            if (!document.hidden && Date.now() - lastOk > REFRESH_MS) {
                run('refresh', slot('weather'), true);
            }
        });
        pause(document.hidden);
        Sky.scan();
        Typhoon.scan();
        Metrics.scan();
        setTimeout(function () { Sky.scan(); Typhoon.scan(); }, 400);
        setTimeout(function () { Sky.scan(); Typhoon.scan(); }, 1600);
        pullRefresh();
        if (HAS_API) {
            var pw = run('weather', null, true);
            setTimeout(function () { run('typhoon', null, true); }, 800);
            setTimeout(function () { run('traffic', null, true); }, 1200);
            if (pw && pw.then) {
                pw.then(autoGps, autoGps);
            } else {
                autoGps();
            }
            schedule();
        }
    }

    if (window.YX_WEATHER_PREVIEW) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function () { Sky.scan(); Typhoon.scan(); Metrics.scan(); });
        } else {
            Sky.scan();
            Typhoon.scan();
            Metrics.scan();
        }
    } else if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
