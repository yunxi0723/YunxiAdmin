(function () {
    'use strict';

    var COLORS = ['var(--yx-accent)', 'var(--yx-c-blue)', 'var(--yx-c-green)', 'var(--yx-c-orange)'];
    var PL = 38;
    var PR = 14;
    var PT = 16;
    var PB = 28;

    function esc(s) {
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function niceMax(max) {
        if (max <= 5) {
            return 5;
        }
        var base = Math.pow(10, Math.floor(Math.log(max) / Math.LN10));
        var ms = [1, 2, 2.5, 5, 10];
        for (var i = 0; i < ms.length; i++) {
            if (max <= ms[i] * base) {
                return Math.round(ms[i] * base);
            }
        }
        return Math.round(10 * base);
    }

    function r1(n) {
        return Math.round(n * 10) / 10;
    }

    function draw(box, data) {
        var keys = data.keys || [];
        var series = data.series || [];
        var n = keys.length;
        if (n < 2 || !series.length) {
            return;
        }
        var w = Math.max(240, Math.round(box.clientWidth));
        var h = Math.max(170, Math.round(box.clientHeight));
        var iw = w - PL - PR;
        var ih = h - PT - PB;
        if (iw < 40 || ih < 40) {
            return;
        }
        var max = 4;
        for (var s = 0; s < series.length; s++) {
            var d = series[s].data || [];
            for (var i = 0; i < d.length; i++) {
                if (d[i] > max) {
                    max = d[i];
                }
            }
        }
        var nice = niceMax(max);
        var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + w + ' ' + h + '" width="' + w + '" height="' + h
            + '" role="img" aria-label="网站运行趋势" style="display:block">';
        svg += '<defs><linearGradient id="yxrunfill" x1="0" y1="0" x2="0" y2="1">'
            + '<stop offset="0%" stop-color="var(--yx-accent)" stop-opacity=".22"/>'
            + '<stop offset="100%" stop-color="var(--yx-accent)" stop-opacity="0"/>'
            + '</linearGradient></defs>';
        var g;
        var gy;
        for (g = 0; g <= 4; g++) {
            gy = PT + ih - (ih * g / 4);
            svg += '<line x1="' + PL + '" y1="' + r1(gy) + '" x2="' + (w - PR) + '" y2="' + r1(gy)
                + '" stroke="var(--yx-line)" stroke-width="1"' + (g === 0 ? '' : ' stroke-dasharray="3 4"') + '/>';
            svg += '<text x="' + (PL - 7) + '" y="' + r1(gy + 3.5) + '" text-anchor="end" font-size="10" fill="var(--yx-text-3)">'
                + Math.round(nice * g / 4) + '</text>';
        }
        var x;
        var anchor;
        var md;
        var maxLabels = Math.max(2, Math.floor(iw / 46));
        var step = Math.max(1, Math.ceil((n - 1) / (maxLabels - 1)));
        var idx = [];
        for (i = 0; i < n; i += step) {
            idx.push(i);
        }
        var lastIdx = n - 1;
        if (idx[idx.length - 1] !== lastIdx) {
            if ((lastIdx - idx[idx.length - 1]) < step * 0.6) {
                idx.pop();
            }
            idx.push(lastIdx);
        }
        for (var k = 0; k < idx.length; k++) {
            i = idx[k];
            x = PL + (iw * i / (n - 1));
            anchor = i === 0 ? 'start' : (i === n - 1 ? 'end' : 'middle');
            md = keys[i].replace(/^(\d{4})-/, '');
            svg += '<text x="' + r1(x) + '" y="' + (h - 8) + '" text-anchor="' + anchor + '" font-size="10" fill="var(--yx-text-3)">'
                + esc(md) + '</text>';
        }
        for (s = 0; s < series.length; s++) {
            d = series[s].data || [];
            var pts = [];
            var px;
            var py;
            for (i = 0; i < d.length; i++) {
                px = PL + (iw * i / (n - 1));
                py = PT + ih - (nice > 0 ? (ih * d[i] / nice) : 0);
                pts.push(r1(px) + ',' + r1(py));
            }
            if (s === 0) {
                svg += '<polygon points="' + PL + ',' + (PT + ih) + ' ' + pts.join(' ') + ' ' + (PL + iw) + ',' + (PT + ih)
                    + '" fill="url(#yxrunfill)"/>';
            }
            svg += '<polyline points="' + pts.join(' ') + '" fill="none" stroke="' + COLORS[s % 4]
                + '" stroke-width="' + (s === 0 ? 2.4 : 1.8) + '" stroke-linecap="round" stroke-linejoin="round" opacity="'
                + (s === 0 ? 1 : 0.92) + '"><title>' + esc(series[s].name) + ' 近 14 天合计 ' + d.reduce(function (a, b) {
                    return a + (Number(b) || 0);
                }, 0) + '</title></polyline>';
            var last = Number(d[d.length - 1]) || 0;
            var lx = PL + iw;
            var ly = PT + ih - (nice > 0 ? (ih * last / nice) : 0);
            svg += '<circle cx="' + lx + '" cy="' + r1(ly) + '" r="3" fill="' + COLORS[s % 4]
                + '" stroke="var(--yx-surface)" stroke-width="1.5"/>';
            if (s === 0) {
                for (i = 0; i < d.length; i++) {
                    x = PL + (iw * i / (n - 1));
                    var y = PT + ih - (nice > 0 ? (ih * d[i] / nice) : 0);
                    svg += '<circle cx="' + r1(x) + '" cy="' + r1(y) + '" r="2.6" fill="var(--yx-surface)" stroke="'
                        + COLORS[0] + '" stroke-width="1.6"><title>' + esc(keys[i]) + ' ' + esc(series[s].name) + ' '
                        + (Number(d[i]) || 0) + '</title></circle>';
                }
            }
        }
        svg += '</svg>';
        box.innerHTML = svg;
    }

    function boot() {
        var box = document.querySelector('.yd-run-chart');
        if (!box || !window.YX_RUN) {
            return;
        }
        var lastW = 0;
        var lastH = 0;
        var timer = 0;
        function render() {
            var w = box.clientWidth;
            var h = box.clientHeight;
            if (w === lastW && h === lastH) {
                return;
            }
            lastW = w;
            lastH = h;
            draw(box, window.YX_RUN);
        }
        render();
        if (typeof ResizeObserver === 'function') {
            var ro = new ResizeObserver(function () {
                if (timer) {
                    return;
                }
                timer = setTimeout(function () {
                    timer = 0;
                    render();
                }, 120);
            });
            ro.observe(box);
        } else {
            window.addEventListener('resize', function () {
                if (timer) {
                    return;
                }
                timer = setTimeout(function () {
                    timer = 0;
                    render();
                }, 150);
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
