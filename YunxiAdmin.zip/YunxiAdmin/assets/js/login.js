



(function () {
    'use strict';

    var L = window.YX_LOGIN || { logo: '', site: 'Typecho', icons: '' };
    var ICONS = L.icons || '';

    function ico(id) {
        if (!ICONS) { return ''; }
        return '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="' + ICONS + '#' + id + '"></use></svg>';
    }

    document.addEventListener('DOMContentLoaded', function () {
        var body = document.body;
        body.classList.add('yx-login');

        var wrap = document.querySelector('.typecho-login-wrap') || document.querySelector('.typecho-login');
        if (!wrap) { return; }

        var yxl = document.createElement('div');
        yxl.className = 'yxl';

        var brand = document.createElement('div');
        brand.className = 'yxl-brand';
        brand.innerHTML = ''
            + '<div class="yxl-logo-row">'
            +   '<img class="yxl-logo" src="' + (L.logo || '') + '" alt="YunxiAdmin" onerror="this.style.display=\'none\'">'
            +   '<div class="t"><b>YunxiAdmin</b><i>云奚小屋</i></div>'
            + '</div>'
            + '<p class="yxl-slogan">后台，<br>也可以很优雅。</p>'
            + '<p class="yxl-desc">由云奚小屋独立打造的全新后台框架。白天模式、天气定位、数据看板、现代 Markdown 编辑器、本地媒体上传、命令面板，一应俱全。</p>'
            + '<ul class="yxl-feats">'
            +   '<li>' + ico('i-loc') + '<span><b>天气定位</b> 顶栏与看板实时天气</span></li>'
            +   '<li>' + ico('i-grid') + '<span><b>数据看板</b> 核心数据一目了然</span></li>'
            +   '<li>' + ico('i-write') + '<span><b>现代编辑器</b> 分屏实时预览</span></li>'
            +   '<li>' + ico('i-upload') + '<span><b>本地媒体</b> 图片视频文件直传</span></li>'
            +   '<li>' + ico('i-grid') + '<span><b>命令面板</b> ⌘K 快速跳转</span></li>'
            + '</ul>'
            + '<div class="yxl-brand-foot">© ' + new Date().getFullYear() + ' ' + (L.site || 'YunxiAdmin') + ' · 由云奚小屋独立打造</div>';

        var formSide = document.createElement('div');
        formSide.className = 'yxl-form';
        formSide.appendChild(wrap);

        yxl.appendChild(brand);
        yxl.appendChild(formSide);

        while (body.firstChild) { body.removeChild(body.firstChild); }
        body.appendChild(yxl);
    });
})();
