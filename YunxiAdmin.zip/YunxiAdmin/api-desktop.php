<?php

define('YX_WEATHER_PLUGIN_DIR', __DIR__);
require_once __DIR__ . '/weather/shared/Bootstrap.php';

\YxWeather\Bootstrap::init();
require_once __DIR__ . '/weather/desktop/Controller.php';
require_once __DIR__ . '/weather/desktop/Endpoint.php';

\YxWeather\Desktop\Endpoint::dispatch();
