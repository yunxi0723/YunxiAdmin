<?php

define('YX_WEATHER_PLUGIN_DIR', __DIR__);
require_once __DIR__ . '/weather/shared/Bootstrap.php';

\YxWeather\Bootstrap::init();
require_once __DIR__ . '/weather/mobile/Controller.php';
require_once __DIR__ . '/weather/mobile/Endpoint.php';

\YxWeather\Mobile\Endpoint::dispatch();
