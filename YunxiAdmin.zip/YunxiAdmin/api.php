<?php

$yxRoot = dirname(dirname(dirname(__DIR__)));
define('__TYPECHO_ROOT_DIR__', $yxRoot);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (!@include_once $yxRoot . '/config.inc.php') {
    http_response_code(500);
    echo json_encode(array('status' => false, 'message' => '无法载入 Typecho 配置文件，请检查插件目录位置'), JSON_UNESCAPED_UNICODE);
    exit;
}

if (!defined('__TYPECHO_ROOT_URL__')) {
    $yxRootReal = realpath($yxRoot);
    $yxDirReal = realpath(__DIR__);
    $yxRelDir = ($yxRootReal && $yxDirReal && strpos($yxDirReal, $yxRootReal) === 0)
        ? ltrim(str_replace('\\', '/', substr($yxDirReal, strlen($yxRootReal))), '/')
        : 'usr/plugins/YunxiAdmin';
    try {
        $yxRootUrl = (string) \Typecho\Request::getInstance()->getRequestRoot();
    } catch (\Throwable $e) {
        $yxRootUrl = '';
    }
    $yxSuffix = '/' . trim($yxRelDir, '/');
    if ($yxRootUrl !== '' && substr($yxRootUrl, -strlen($yxSuffix)) === $yxSuffix) {
        $yxRootUrl = substr($yxRootUrl, 0, strlen($yxRootUrl) - strlen($yxSuffix));
    }
    if ($yxRootUrl !== '') {
        define('__TYPECHO_ROOT_URL__', $yxRootUrl);
    }
}

\Widget\Init::alloc();

function yxOut($data)
{
    $json = @json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) {
        $json = '{"status":false,"message":"\u5185\u5bb9\u7f16\u7801\u5f02\u5e38"}';
    }
    echo $json;
    exit;
}

function yxErr($msg, $code = 400)
{
    http_response_code($code);
    yxOut(array('status' => false, 'message' => $msg));
}

function yxLogged()
{
    $user = \Widget\User::alloc();
    try {
        if ($user->hasLogin()) {
            return true;
        }
    } catch (\Throwable $e) {

    }

    return false;
}

function yxSameSite()
{

    $allow = array();
    $siteHost = parse_url((string) \Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
    if ($siteHost) {
        $allow[strtolower($siteHost)] = 1;
    }
    if (!empty($_SERVER['HTTP_HOST'])) {
        $allow[strtolower((string) $_SERVER['HTTP_HOST'])] = 1;
    }
    if (!$allow) {
        return false;
    }

    $origin = isset($_SERVER['HTTP_ORIGIN']) ? (string) $_SERVER['HTTP_ORIGIN'] : '';
    $referer = isset($_SERVER['HTTP_REFERER']) ? (string) $_SERVER['HTTP_REFERER'] : '';

    foreach (array($origin, $referer) as $u) {
        if ($u === '') {
            continue;
        }
        $h = strtolower((string) parse_url($u, PHP_URL_HOST));
        if ($h === '') {
            continue;
        }
        if (!isset($allow[$h])) {
            return false;
        }
    }

    if ($origin === '' && $referer === '') {
        return false;
    }

    return true;
}

function yxAllowedExt()
{
    return array(

        'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'avif', 'ico',

        'mp3', 'mp4', 'm4a', 'wav', 'ogg', 'webm', 'mov',

        'pdf', 'txt', 'md', 'zip', 'rar', '7z', 'gz'
    );
}

function yxSafeExt($ext, $name = '')
{
    $ext = strtolower(trim((string) $ext));
    if (!in_array($ext, yxAllowedExt(), true)) {
        yxErr(
            '不允许上传该类型文件（' . ($ext === '' ? '无扩展名' : '.' . $ext) . '）。'
            . '仅支持：' . implode(' / ', yxAllowedExt()),
            400
        );
    }
    return $ext;
}

function yxContentLooksSafe($data, $ext)
{
    if (!is_string($data) || $data === '') {
        return false;
    }

    $imageExts = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'avif', 'ico');
    if (in_array($ext, $imageExts, true)) {
        if (@getimagesizefromstring($data) === false) {
            return false;
        }

        if (stripos($data, '<?php') !== false || stripos($data, '<?=') !== false) {
            return false;
        }
        return true;
    }

    if (in_array($ext, array('txt', 'md'), true)) {
        if (stripos($data, '<?php') !== false || stripos($data, '<?=') !== false) {
            return false;
        }
        return true;
    }

    $head = substr($data, 0, 4096);
    if (stripos($head, '<?php') !== false) {
        return false;
    }
    return true;
}

function yxUploadErrText($code)
{
    $code = (int) $code;
    if ($code === UPLOAD_ERR_OK) {
        return '';
    }
    if ($code === UPLOAD_ERR_INI_SIZE || $code === UPLOAD_ERR_FORM_SIZE) {
        $max = (string) ini_get('upload_max_filesize');
        return '文件超过服务器上传限制（php.ini upload_max_filesize = ' . $max . '），请压缩后重试';
    }
    if ($code === UPLOAD_ERR_PARTIAL) {
        return '文件只上传了一部分，请检查网络后重试';
    }
    if ($code === UPLOAD_ERR_NO_FILE) {
        return '没有收到文件，请重新选择';
    }
    if ($code === UPLOAD_ERR_NO_TMP_DIR) {
        return '服务器缺少临时目录，请联系主机商开启';
    }
    if ($code === UPLOAD_ERR_CANT_WRITE) {
        return '写入临时文件失败，请检查服务器磁盘权限';
    }
    if ($code === UPLOAD_ERR_EXTENSION) {
        return '上传被服务器扩展拦截，请联系主机商调整配置';
    }
    return '上传失败（错误码 ' . $code . '）';
}

function yxUploadFile()
{
    if (empty($_FILES['file']) || !is_array($_FILES['file'])) {
        yxErr('没有收到文件，请重新选择', 400);
    }
    $f = $_FILES['file'];
    if (!isset($f['error'])) {
        yxErr('上传数据不完整', 400);
    }

    if (is_array($f['error'])) {
        $f = array(
            'name' => isset($f['name'][0]) ? $f['name'][0] : 'file',
            'type' => isset($f['type'][0]) ? $f['type'][0] : '',
            'tmp_name' => isset($f['tmp_name'][0]) ? $f['tmp_name'][0] : '',
            'error' => isset($f['error'][0]) ? $f['error'][0] : UPLOAD_ERR_NO_FILE,
            'size' => isset($f['size'][0]) ? $f['size'][0] : 0
        );
    }
    $msg = yxUploadErrText($f['error']);
    if ($msg !== '') {
        yxErr($msg, 400);
    }
    if (empty($f['tmp_name']) || !is_uploaded_file($f['tmp_name'])) {
        yxErr('上传数据无效（post_max_size 可能过小），请检查 php.ini 设置', 400);
    }
    yxOut(yxSaveLocal($f));
}

$options = \Widget\Options::alloc();
$user = \Widget\User::alloc();
$db = \Typecho\Db::get();
$plugin = \TypechoPlugin\YunxiAdmin\Plugin::conf();

$action = isset($_GET['action']) ? (string) $_GET['action'] : '';

$yxNoAuth = array('weather', 'geo', 'alerts', 'traffic', 'traffic_live');
if (!in_array($action, $yxNoAuth, true) && !yxLogged()) {
    yxErr('登录状态已过期，请刷新页面重试', 401);
}

$yxWriteActions = array(
    'upload', 'local', 'imgpaste', 'seo_fix', 'collect',
    'posts', 'users', 'medias'
);
if (in_array($action, $yxWriteActions, true) && !yxSameSite()) {
    yxErr('拒绝跨站请求', 403);
}

function yxCacheDir()
{
    $dir = sys_get_temp_dir() . '/yx-api';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
        return '';
    }
    return $dir;
}

function yxCacheSweep($max = 400)
{
    $dir = yxCacheDir();
    if ($dir === '') {
        return;
    }
    $files = @glob($dir . '/yx-*.json');
    if (!is_array($files) || count($files) <= $max) {
        return;
    }

    @usort($files, function ($a, $b) {
        return (int) @filemtime($a) - (int) @filemtime($b);
    });
    $excess = count($files) - $max;
    for ($i = 0; $i < $excess; $i++) {
        @unlink($files[$i]);
    }
}

function yxSiteTag()
{
    static $tag = null;
    if ($tag === null) {
        try {
            $tag = md5((string) \Widget\Options::alloc()->siteUrl);
        } catch (\Throwable $e) {
            $tag = md5((string) getcwd());
        }
    }
    return $tag;
}

function yxCacheRemember($key, $ttl, $build)
{
    if ($ttl <= 0) {
        return $build();
    }
    $dir = yxCacheDir();
    if ($dir === '') {
        return $build();
    }
    $file = $dir . '/yx-' . md5($key . '|' . yxSiteTag()) . '.json';
    if (is_file($file) && (time() - (int) filemtime($file)) < $ttl) {
        $cached = json_decode((string) @file_get_contents($file), true);
        if (is_array($cached)) {
            return $cached;
        }
    }
    $data = $build();
    if (is_array($data)) {

        if (mt_rand(1, 10) === 1) {
            yxCacheSweep();
        }
        @file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    return $data;
}

function yxCacheFlush()
{
    $dir = yxCacheDir();
    if ($dir === '') {
        return;
    }
    $files = @glob($dir . '/yx-*.json');
    if (!is_array($files)) {
        return;
    }
    foreach ($files as $f) {
        @unlink($f);
    }
}

function yxSize($bytes)
{
    $bytes = (int) $bytes;
    if ($bytes < 1024) {
        return $bytes . 'B';
    }
    if ($bytes < 1048576) {
        return round($bytes / 1024) . 'KB';
    }
    return round($bytes / 1048576, 1) . 'MB';
}

function yxCutText($s, $n)
{
    $s = trim(strip_tags((string) $s));
    $s = preg_replace('/\s+/', ' ', $s);
    if (mb_strlen($s) > $n) {
        $s = mb_substr($s, 0, $n) . '…';
    }
    return $s;
}

function yxSaveLocal($f)
{
    global $db, $user, $options;

    if ($f['size'] > 200 * 1024 * 1024) {
        yxErr('文件超过 200MB 限制', 400);
    }

    $uploads = __TYPECHO_ROOT_DIR__ . '/usr/uploads';
    $sub = '/' . date('Y') . '/' . date('m');
    if (!is_dir($uploads . $sub) && !@mkdir($uploads . $sub, 0755, true)) {
        yxErr('创建上传目录失败，请检查 usr/uploads 权限', 500);
    }

    $ext = yxSafeExt(pathinfo($f['name'], PATHINFO_EXTENSION), $f['name']);
    $base = preg_replace('/[^a-zA-Z0-9_-]/', '', pathinfo($f['name'], PATHINFO_FILENAME));
    if ($base === '') {
        $base = 'file';
    }
    $fname = $base . '-' . dechex(mt_rand(0x100000, 0xffffff)) . '.' . $ext;
    $dest = $uploads . $sub . '/' . $fname;

    $probe = @file_get_contents($f['tmp_name'], false, null, 0, 8192);
    $probe = is_string($probe) ? $probe : '';
    if (!yxContentLooksSafe($probe, $ext)) {
        @unlink($f['tmp_name']);
        yxErr('文件内容与类型不符，已拒绝保存', 400);
    }

    if (!@move_uploaded_file($f['tmp_name'], $dest)) {
        yxErr('保存文件失败，请检查目录权限', 500);
    }
    @chmod($dest, 0644);

    $mime = (!empty($f['type'])) ? $f['type'] : 'application/octet-stream';
    $isImg = strpos($mime, 'image/') === 0;
    $isVid = strpos($mime, 'video/') === 0;
    if (!$isImg && !$isVid) {
        $ext2 = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        if (preg_match('/^(png|jpe?g|gif|webp|bmp|svg|avif|ico)$/', $ext2)) {
            $isImg = true;
            $mime = 'image/' . ($ext2 === 'jpg' ? 'jpeg' : $ext2);
        } elseif (preg_match('/^(mp4|webm|ogg|ogv|mov|m4v|flv|avi|mkv)$/', $ext2)) {
            $isVid = true;
            $mime = 'video/' . $ext2;
        }
    }

    $rel = '/usr/uploads/' . ltrim($sub, '/') . '/' . $fname;
    $db->query($db->insert('table.contents')->rows(array(
        'title' => $f['name'],
        'slug' => $fname,
        'created' => time(),
        'modified' => time(),
        'text' => json_encode(array('name' => $f['name'], 'size' => $f['size'], 'path' => $rel, 'mime' => $mime)),
        'authorId' => (int) $user->uid,
        'type' => 'attachment',
        'status' => 'publish',
        'password' => null,
        'commentsNum' => 0,
        'allowComment' => '0',
        'allowPing' => '0',
        'allowFeed' => '0',
        'parent' => 0
    )));

    $url = \Typecho\Common::url($rel, $options->siteUrl);
    yxCacheFlush();

    return array(
        'status' => true,
        'url' => $url,
        'thumb' => $isImg ? $url : '',
        'name' => $f['name'],
        'size' => yxSize($f['size']),
        'mime' => $mime,
        'image' => $isImg,
        'video' => $isVid
    );
}

function yxOptSet($name, $value)
{
    global $db;
    $old = $db->fetchRow($db->select('name')->from('table.options')->where('name = ? AND user = ?', $name, 0)->limit(1));
    if ($old) {
        $db->query($db->update('table.options')->rows(array('value' => (string) $value))
            ->where('name = ? AND user = ?', $name, 0));
        return;
    }
    $db->query($db->insert('table.options')->rows(array(
        'name' => $name,
        'user' => 0,
        'value' => (string) $value
    )));
}

function yxFixRes($changed, $msg, $failed)
{
    return array('changed' => $changed, 'failed' => $failed, 'msg' => $msg);
}

function yxNoop()
{
    return yxFixRes(false, '', false);
}

function yxFixHttps()
{
    global $options;
    $url = (string) $options->siteUrl;
    if (stripos($url, 'https://') === 0) {
        return yxNoop();
    }
    if (stripos($url, 'http://') !== 0) {
        return yxFixRes(false, '站点地址格式无法自动转换', true);
    }
    yxOptSet('siteUrl', 'https://' . substr($url, 7));
    return yxFixRes(true, '站点地址已切换为 HTTPS（请确认服务器已部署证书）', false);
}

function yxFixRewrite()
{
    global $options;
    if (!empty($options->rewrite)) {
        return yxNoop();
    }
    if (defined('__TYPECHO_REWRITE__')) {
        return yxFixRes(false, '已由服务器配置固定，无需开启', false);
    }
    yxOptSet('rewrite', '1');

    $tip = '（Nginx 请在 server 段配置 try_files $uri $uri/ /index.php?$args）';
    $root = rtrim((string) __TYPECHO_ROOT_DIR__, '/');
    $ht = $root . '/.htaccess';
    if (!is_file($ht) && is_writable($root)) {
        $base = parse_url((string) $options->siteUrl, PHP_URL_PATH);
        $base = ($base && $base !== '/') ? rtrim($base, '/') . '/' : '/';
        $rule = ($base === '/') ? 'index.php/$1' : ltrim($base, '/') . 'index.php/$1';
        $body = "<IfModule mod_rewrite.c>\nRewriteEngine On\n"
            . "RewriteBase " . $base . "\n"
            . "RewriteCond %{REQUEST_FILENAME} !-f\n"
            . "RewriteCond %{REQUEST_FILENAME} !-d\n"
            . "RewriteRule ^(.*)$ " . $rule . " [L]\n"
            . "</IfModule>\n";
        if (@file_put_contents($ht, $body) !== false) {
            $tip = '（已自动写入 .htaccess）';
        }
    }
    return yxFixRes(true, '已开启地址重写（伪静态）' . $tip, false);
}

function yxPlainText($text, $len)
{
    $text = (string) $text;
    if (strpos($text, '<!--markdown-->') === 0) {
        $text = substr($text, 15);
    }
    $text = preg_replace('/```[\s\S]*?```/u', ' ', $text);
    $text = preg_replace('/`([^`]*)`/u', '$1', $text);
    $text = preg_replace('/!\[[^\]]*\]\([^)]*\)/u', ' ', $text);
    $text = preg_replace('/\[([^\]]*)\]\([^)]*\)/u', '$1', $text);
    $text = preg_replace('/<!--[\s\S]*?-->/u', ' ', $text);
    $text = preg_replace('/^\s*#{1,6}\s+/mu', '', $text);
    $text = preg_replace('/^\s*>\s?/mu', '', $text);
    $text = preg_replace('/^\s*[-*+]\s+/mu', '', $text);
    $text = strip_tags($text);
    $text = preg_replace('/[*_~|#]+/u', ' ', $text);
    $text = preg_replace('/[\r\n\t　 ]+/u', ' ', $text);
    $text = trim($text);
    if ($len > 0 && mb_strlen($text) > $len) {
        $text = mb_substr($text, 0, $len - 1) . '…';
    }
    return $text;
}

function yxFixSiteDesc()
{
    global $options;
    $desc = trim((string) $options->description);
    if (mb_strlen($desc) >= 30) {
        return yxFixRes(false, '站点描述已存在（' . mb_strlen($desc) . ' 字），无需修改', false);
    }
    $new = \TypechoPlugin\YunxiAdmin\Plugin::presetSiteDesc($options);
    if ($new === '') {
        return yxFixRes(false, '生成站点描述失败', true);
    }
    yxOptSet('description', $new);
    return yxFixRes(true, '已写入预设博客描述（' . mb_strlen($new) . ' 字）', false);
}

function yxFixPostDesc()
{
    global $db;
    $missing = array();
    try {
        $have = array();
        $rs = $db->fetchAll($db->select('cid')->from('table.fields')->where('name = ?', 'description'));
        foreach ($rs as $r) {
            $have[(int) $r['cid']] = 1;
        }
        $rows = $db->fetchAll($db->select('cid', 'title', 'text')->from('table.contents')
            ->where('type = ? AND status = ?', 'post', 'publish'));
        foreach ($rows as $r) {
            if (!isset($have[(int) $r['cid']])) {
                $missing[] = $r;
            }
        }
    } catch (\Exception $e) {
        return yxFixRes(false, '读取文章失败：' . $e->getMessage(), true);
    }
    if (!$missing) {
        return yxNoop();
    }

    $n = 0;
    foreach ($missing as $r) {
        $text = yxPlainText($r['text'], 100);
        if ($text === '') {
            $text = yxPlainText($r['title'], 100);
        }
        if ($text === '') {
            $text = '暂无描述';
        }
        try {
            $db->query($db->insert('table.fields')->rows(array(
                'cid' => (int) $r['cid'],
                'name' => 'description',
                'type' => 'str',
                'str_value' => $text,
                'int_value' => 0,
                'float_value' => 0
            )));
            $n++;
        } catch (\Exception $e) {
        }
    }
    if (!$n) {
        return yxFixRes(false, '写入描述失败，请稍后重试', true);
    }
    return yxFixRes(true, '已为 ' . $n . ' 篇文章补齐 SEO 描述', false);
}

function yxFixRobots()
{
    global $options;
    $root = rtrim((string) __TYPECHO_ROOT_DIR__, '/');
    $file = $root . '/robots.txt';
    if (is_file($file)) {
        return yxNoop();
    }
    if (!is_writable($root)) {
        return yxFixRes(false, '网站根目录不可写，无法创建 robots.txt', true);
    }
    $site = rtrim((string) $options->siteUrl, '/') . '/';
    $body = "User-agent: *\n"
        . "Allow: /\n"
        . "Disallow: /admin/\n"
        . "Disallow: /usr/plugins/\n"
        . "Disallow: /usr/themes/\n"
        . "\n"
        . "Sitemap: " . $site . "sitemap.xml\n";
    if (@file_put_contents($file, $body) === false) {
        return yxFixRes(false, '写入 robots.txt 失败，请检查根目录权限', true);
    }
    @chmod($file, 0644);
    return yxFixRes(true, '已生成 robots.txt', false);
}

function yxFixSitemap()
{
    global $db, $options;
    $root = rtrim((string) __TYPECHO_ROOT_DIR__, '/');
    $file = $root . '/sitemap.xml';
    if (is_file($file)) {
        return yxNoop();
    }
    if (!is_writable($root)) {
        return yxFixRes(false, '网站根目录不可写，无法生成 sitemap.xml', true);
    }

    $index = (string) $options->index;
    if ($index === '') {
        $index = rtrim((string) $options->siteUrl, '/') . '/';
    }

    $urls = array();
    $urls[] = array(
        'loc' => rtrim((string) $options->siteUrl, '/') . '/',
        'time' => time(),
        'freq' => 'daily',
        'pri' => '1.0'
    );

    $rows = array();
    try {
        $rows = $db->fetchAll($db->select('cid', 'slug', 'created', 'modified', 'type')
            ->from('table.contents')
            ->where('type = ? OR type = ?', 'post', 'page')
            ->where('status = ?', 'publish')
            ->order('created', \Typecho\Db::SORT_DESC)
            ->offset(0)->limit(5000));
    } catch (\Exception $e) {
    }

    $catSlugs = array();
    try {
        $meRows = $db->fetchAll($db->select('mid', 'slug')->from('table.metas'));
        foreach ($meRows as $me) {
            $catSlugs[(int) $me['mid']] = (string) $me['slug'];
        }
        $relRows = $db->fetchAll($db->select('cid', 'mid')->from('table.relationships'));
        $relMap = array();
        foreach ($relRows as $rel) {
            $relMap[(int) $rel['cid']] = (int) $rel['mid'];
        }
    } catch (\Exception $e) {
        $relMap = array();
    }

    foreach ($rows as $r) {
        $cid = (int) $r['cid'];
        $time = (int) ($r['modified'] ? $r['modified'] : $r['created']);
        $slug = '';
        if (isset($relMap[$cid], $catSlugs[$relMap[$cid]])) {
            $slug = $catSlugs[$relMap[$cid]];
        }
        if ($slug === '') {
            $slug = 'default';
        }
        $type = (string) $r['type'];
        $args = array(
            'type' => $type,
            'cid' => $cid,
            'slug' => rawurlencode((string) $r['slug']),
            'category' => rawurlencode($slug),
            'directory' => rawurlencode($slug),
            'year' => date('Y', $time),
            'month' => date('m', $time),
            'day' => date('d', $time),
            'page' => 1
        );
        $path = '';
        try {
            if (\Typecho\Router::get($type) !== null) {
                $path = \Typecho\Router::url($type, $args);
            }
        } catch (\Throwable $e) {
            $path = '';
        }
        if ($path === '' || strpos($path, '{') !== false) {
            $path = 'archives/' . $cid . '/';
        }
        $urls[] = array(
            'loc' => \Typecho\Common::url($path, $index),
            'time' => $time,
            'freq' => $type === 'page' ? 'monthly' : 'weekly',
            'pri' => $type === 'page' ? '0.6' : '0.8'
        );
    }

    try {
        $cats = $db->fetchAll($db->select('mid', 'slug')->from('table.metas')
            ->where('type = ?', 'category')->offset(0)->limit(200));
    } catch (\Exception $e) {
        $cats = array();
    }
    foreach ($cats as $c) {
        $path = '';
        try {
            if (\Typecho\Router::get('category') !== null) {
                $path = \Typecho\Router::url('category', array(
                    'mid' => (int) $c['mid'],
                    'slug' => rawurlencode((string) $c['slug']),
                    'directory' => rawurlencode((string) $c['slug']),
                    'page' => 1
                ));
            }
        } catch (\Throwable $e) {
            $path = '';
        }
        if ($path === '' || strpos($path, '{') !== false) {
            $path = 'category/' . rawurlencode((string) $c['slug']) . '/';
        }
        $urls[] = array(
            'loc' => \Typecho\Common::url($path, $index),
            'time' => time(),
            'freq' => 'weekly',
            'pri' => '0.5'
        );
    }

    $xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        . "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
    foreach ($urls as $u) {
        $xml .= "  <url>\n"
            . "    <loc>" . htmlspecialchars($u['loc'], ENT_XML1 | ENT_COMPAT, 'UTF-8') . "</loc>\n"
            . "    <lastmod>" . gmdate('Y-m-d\TH:i:s+00:00', $u['time']) . "</lastmod>\n"
            . "    <changefreq>" . $u['freq'] . "</changefreq>\n"
            . "    <priority>" . $u['pri'] . "</priority>\n"
            . "  </url>\n";
    }
    $xml .= "</urlset>\n";

    if (@file_put_contents($file, $xml) === false) {
        return yxFixRes(false, '写入 sitemap.xml 失败，请检查根目录权限', true);
    }
    @chmod($file, 0644);
    return yxFixRes(true, '已生成 sitemap.xml（' . count($urls) . ' 条网址）', false);
}

function yxRecountComments($cid)
{
    global $db;
    try {
        $n = (int) $db->fetchObject($db->select('COUNT(coid) AS num')->from('table.comments')
            ->where('cid = ? AND status = ?', $cid, 'approved'))->num;
        $db->query($db->update('table.contents')->rows(array('commentsNum' => $n))->where('cid = ?', $cid));
    } catch (\Exception $e) {
    }
}

function yxFixWaiting()
{
    global $db;
    try {
        $n = (int) $db->fetchObject($db->select('COUNT(coid) AS num')->from('table.comments')->where('status = ?', 'waiting'))->num;
        if ($n <= 0) {
            return yxNoop();
        }
        $db->query($db->update('table.comments')->rows(array('status' => 'approved'))->where('status = ?', 'waiting'));
    } catch (\Exception $e) {
        return yxFixRes(false, '操作失败：' . $e->getMessage(), true);
    }
    return yxFixRes(true, '已放行 ' . $n . ' 条待审评论', false);
}

function yxFixSpam()
{
    global $db;
    try {
        $n = (int) $db->fetchObject($db->select('COUNT(coid) AS num')->from('table.comments')->where('status = ?', 'spam'))->num;
        if ($n <= 0) {
            return yxNoop();
        }
        $cids = array();
        $rs = $db->fetchAll($db->select('cid')->from('table.comments')->where('status = ?', 'spam'));
        foreach ($rs as $r) {
            $cids[(int) $r['cid']] = 1;
        }
        $db->query($db->delete('table.comments')->where('status = ?', 'spam'));
        foreach (array_keys($cids) as $cid) {
            yxRecountComments((int) $cid);
        }
    } catch (\Exception $e) {
        return yxFixRes(false, '操作失败：' . $e->getMessage(), true);
    }
    return yxFixRes(true, '已清空 ' . $n . ' 条垃圾评论', false);
}

function yxSeoChecks()
{
    global $db, $options;
    $title = trim((string) $options->title);
    $desc = trim((string) $options->description);
    $https = stripos((string) $options->siteUrl, 'https://') === 0;
    $rewrite = !empty($options->rewrite);
    $root = rtrim((string) __TYPECHO_ROOT_DIR__, '/');
    $robots = is_file($root . '/robots.txt');
    $sitemap = is_file($root . '/sitemap.xml');

    $posts = 0;
    $descNum = 0;
    try {
        $posts = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.contents')
            ->where('type = ? AND status = ?', 'post', 'publish'))->num;
    } catch (\Exception $e) {
    }
    try {
        $descNum = (int) $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.fields')
            ->where('name = ?', 'description'))->num;
    } catch (\Exception $e) {
    }
    $cov = $posts > 0 ? min(100, (int) round($descNum * 100 / $posts)) : 0;

    return array(
        array('站点标题', $title !== '', 15, $title !== '' ? yxCutText($title, 14) : '未设置'),
        array('站点描述', mb_strlen($desc) >= 30, 15, $desc !== '' ? mb_strlen($desc) . ' 字' : '未设置'),
        array('内容数量', $posts >= 10, 15, $posts . ' 篇'),
        array('描述覆盖', $cov >= 60, 15, $cov . '%'),
        array('全站 HTTPS', $https, 10, $https ? '已启用' : '未启用'),
        array('友好链接', $rewrite, 10, $rewrite ? '已开启' : '未开启'),
        array('robots.txt', $robots, 10, $robots ? '存在' : '缺失'),
        array('sitemap.xml', $sitemap, 10, $sitemap ? '存在' : '缺失')
    );
}

function yxSeoScore()
{
    $s = 0;
    foreach (yxSeoChecks() as $c) {
        if ($c[1]) {
            $s += (int) $c[2];
        }
    }
    return $s;
}

function yxSeoFix($fix)
{
    global $user;

    $all = array(
        'https'    => array('yxFixHttps',     '全站 HTTPS',   1),
        'cmt'      => array('yxFixWaiting',   '待审评论',     1),
        'spam'     => array('yxFixSpam',      '垃圾评论',     1),
        'rewrite'  => array('yxFixRewrite',   '友好链接',     1),
        'desc'     => array('yxFixSiteDesc',  '站点描述',     1),
        'desccov'  => array('yxFixPostDesc',  '文章描述',     1),
        'robots'   => array('yxFixRobots',    'robots.txt',   1),
        'sitemap'  => array('yxFixSitemap',   'sitemap.xml',  1)
    );

    if ($fix === 'all') {
        $keys = array_keys($all);
    } elseif (isset($all[$fix])) {
        $keys = array($fix);
    } else {
        return array('status' => false, 'message' => '未知的修复项');
    }

    $done = array();
    $fail = array();

    foreach ($keys as $k) {
        if (!empty($all[$k][2]) && !$user->pass('administrator', true)) {
            $fail[] = $all[$k][1] . '：需要管理员权限';
            continue;
        }
        try {
            $r = call_user_func($all[$k][0]);
        } catch (\Throwable $e) {
            $r = array('changed' => false, 'failed' => true, 'msg' => $e->getMessage());
        }
        if (!empty($r['failed'])) {
            $fail[] = $all[$k][1] . '：' . $r['msg'];
        } elseif (!empty($r['changed'])) {
            $done[] = $all[$k][1] . '：' . $r['msg'];
        }
    }

    yxCacheFlush();

    $msg = '';
    if ($done) {
        $msg = '已完成 ' . count($done) . ' 项修复';
    }
    if ($fail) {
        $msg = ($msg !== '' ? $msg . '，' : '') . count($fail) . ' 项未能自动处理';
    }
    if ($msg === '') {
        $msg = '各项检查均已通过，无需修复';
    }

    return array(
        'status' => true,
        'message' => $msg,
        'done' => $done,
        'fail' => $fail,
        'score' => yxSeoScore(),
        'checks' => yxSeoChecks()
    );
}

function yxIpInCidr($ip, $cidr)
{
    $parts = explode('/', $cidr);
    if (count($parts) !== 2) {
        return false;
    }
    $net = $parts[0];
    $bits = (int) $parts[1];

    $ipBin = @inet_pton($ip);
    $netBin = @inet_pton($net);
    if ($ipBin === false || $netBin === false || strlen($ipBin) !== strlen($netBin)) {
        return false;
    }

    $bytes = intdiv($bits, 8);
    $rem = $bits % 8;

    if ($bytes > 0 && substr($ipBin, 0, $bytes) !== substr($netBin, 0, $bytes)) {
        return false;
    }
    if ($rem === 0) {
        return true;
    }
    $mask = chr((0xFF << (8 - $rem)) & 0xFF);
    return (substr($ipBin, $bytes, 1) & $mask) === (substr($netBin, $bytes, 1) & $mask);
}

function yxIsPrivateIp($ip)
{
    $ip = trim((string) $ip);
    if ($ip === '') {
        return true;
    }

    $ip = trim($ip, '[]');
    if (strpos($ip, '%') !== false) {
        $ip = substr($ip, 0, strpos($ip, '%'));
    }

    if (stripos($ip, '::ffff:') === 0) {
        $v4 = substr($ip, 7);
        if (filter_var($v4, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $ip = $v4;
        }
    }

    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return true;
    }

    $isV4 = (bool) filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4);

    if ($isV4) {

        $long = ip2long($ip);
        if ($long === false) {
            return true;
        }

        $v4Blocks = array(
            '0.0.0.0/8',
            '10.0.0.0/8',
            '100.64.0.0/10',
            '127.0.0.0/8',
            '169.254.0.0/16',
            '172.16.0.0/12',
            '192.0.0.0/24',
            '192.0.2.0/24',       // TEST-NET-1
            '192.168.0.0/16',
            '198.18.0.0/15',
            '198.51.100.0/24',    // TEST-NET-2
            '203.0.113.0/24',     // TEST-NET-3
            '224.0.0.0/4',
            '240.0.0.0/4'
        );

        foreach ($v4Blocks as $cidr) {
            if (yxIpInCidr($ip, $cidr)) {
                return true;
            }
        }
        return false;
    }

    /* IPv6 */
    $v6Blocks = array(
        '::1/128',
        '::/128',
        'fe80::/10',
        'fc00::/7',
        'ff00::/8',
        '64:ff9b::/96',       // NAT64
        '2001:db8::/32'
    );

    foreach ($v6Blocks as $cidr) {
        if (yxIpInCidr($ip, $cidr)) {
            return true;
        }
    }
    return false;
}

function yxFetchRemoteImage($u)
{
    $parts = @parse_url($u);
    if (!$parts || empty($parts['host']) || empty($parts['scheme'])) {
        return false;
    }
    if (!in_array(strtolower($parts['scheme']), array('http', 'https'), true)) {
        return false;
    }

    $host = $parts['host'];

    if (filter_var($host, FILTER_VALIDATE_IP)) {
        $ip = $host;
    } else {
        $ip = @gethostbyname($host);
        if (!$ip || $ip === $host) {
            return false;
        }
    }
    if (yxIsPrivateIp($ip)) {
        return false;
    }

    if (!function_exists('curl_init')) {
        return false;
    }

    $port = isset($parts['port']) ? (int) $parts['port'] : (strtolower($parts['scheme']) === 'https' ? 443 : 80);

    $ch = curl_init($u);
    curl_setopt_array($ch, array(
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,

        CURLOPT_RESOLVE => array($host . ':' . $port . ':' . $ip),
        CURLOPT_HTTPHEADER => array('User-Agent: YunxiAdmin', 'Accept: image/*')
    ));
    $data = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $ctype = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    curl_close($ch);

    if (!is_string($data)) {
        return false;
    }
    $size = strlen($data);
    if ($code !== 200 || $size < 16 || $size > 20 * 1024 * 1024) {
        return false;
    }
    if (!preg_match('#^image/#i', $ctype)) {
        return false;
    }

    if (@getimagesizefromstring($data) === false) {
        return false;
    }

    $ext = 'png';
    if (preg_match('#image/(\w+)#i', $ctype, $m)) {
        $e = strtolower($m[1]);
        $ext = ($e === 'jpeg') ? 'jpg' : $e;
    }

    if (!in_array($ext, array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'avif', 'ico'), true)) {
        $ext = 'png';
    }
    return array('data' => $data, 'mime' => $ctype, 'ext' => $ext);
}

function yxStoreBytes($data, $name, $mimeHint = '')
{
    global $db, $user, $options;

    $len = strlen($data);
    if ($len > 200 * 1024 * 1024) {
        yxErr('文件超过 200MB 限制', 400);
    }

    $uploads = __TYPECHO_ROOT_DIR__ . '/usr/uploads';
    $sub = '/' . date('Y') . '/' . date('m');
    if (!is_dir($uploads . $sub) && !@mkdir($uploads . $sub, 0755, true)) {
        yxErr('创建上传目录失败，请检查 usr/uploads 权限', 500);
    }

    $ext = yxSafeExt(pathinfo($name, PATHINFO_EXTENSION), $name);
    $base = preg_replace('/[^a-zA-Z0-9_-]/', '', pathinfo($name, PATHINFO_FILENAME));
    if ($base === '') {
        $base = 'file';
    }
    $fname = $base . '-' . dechex(mt_rand(0x100000, 0xffffff)) . '.' . $ext;
    $dest = $uploads . $sub . '/' . $fname;

    if (!yxContentLooksSafe($data, $ext)) {
        yxErr('文件内容与类型不符，已拒绝保存', 400);
    }

    if (@file_put_contents($dest, $data) === false) {
        yxErr('保存文件失败，请检查目录权限', 500);
    }
    @chmod($dest, 0644);

    $mime = $mimeHint ?: 'application/octet-stream';
    $isImg = strpos($mime, 'image/') === 0;
    $isVid = strpos($mime, 'video/') === 0;
    if (!$isImg && !$isVid) {
        $ext2 = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (preg_match('/^(png|jpe?g|gif|webp|bmp|svg|avif|ico)$/', $ext2)) {
            $isImg = true;
            $mime = 'image/' . ($ext2 === 'jpg' ? 'jpeg' : $ext2);
        } elseif (preg_match('/^(mp4|webm|ogg|ogv|mov|m4v|flv|avi|mkv)$/', $ext2)) {
            $isVid = true;
            $mime = 'video/' . $ext2;
        }
    }

    $rel = '/usr/uploads/' . ltrim($sub, '/') . '/' . $fname;
    $db->query($db->insert('table.contents')->rows(array(
        'title' => $name,
        'slug' => $fname,
        'created' => time(),
        'modified' => time(),
        'text' => json_encode(array('name' => $name, 'size' => $len, 'path' => $rel, 'mime' => $mime)),
        'authorId' => (int) $user->uid,
        'type' => 'attachment',
        'status' => 'publish',
        'password' => null,
        'commentsNum' => 0,
        'allowComment' => '0',
        'allowPing' => '0',
        'allowFeed' => '0',
        'parent' => 0
    )));

    $url = \Typecho\Common::url($rel, $options->siteUrl);
    yxCacheFlush();

    return array(
        'status' => true,
        'url' => $url,
        'thumb' => $isImg ? $url : '',
        'name' => $name,
        'size' => yxSize($len),
        'mime' => $mime,
        'image' => $isImg,
        'video' => $isVid
    );
}

switch ($action) {

    case 'posts':
        $type = (isset($_GET['type']) && $_GET['type'] === 'page') ? 'page' : 'post';
        $admin = $user->pass('administrator', true);
        $select = $db->select('cid', 'title', 'status', 'commentsNum', 'created', 'authorId')
            ->from('table.contents')
            ->where('type = ?', $type);
        if (!$admin) {
            $select->where('authorId = ?', $user->uid);
        }
        $rows = $db->fetchAll(
            $select->order('created', \Typecho\Db::SORT_DESC)
                ->limit(300)
        );
        $items = array();
        foreach ($rows as $r) {
            if (!$admin && (int) $r['authorId'] !== (int) $user->uid) {
                continue;
            }
            $items[] = array(
                'cid' => (int) $r['cid'],
                'title' => (string) $r['title'],
                'status' => (string) $r['status'],
                'commentsNum' => (int) $r['commentsNum'],
                'date' => date('Y-m-d', (int) $r['created'])
            );
        }
        yxOut(array('status' => true, 'items' => $items));
        break;

    case 'search':
        $q = trim(isset($_GET['q']) ? (string) $_GET['q'] : '');
        if ($q === '') {
            yxOut(array('status' => true, 'items' => array()));
            break;
        }
        $like = '%' . str_replace(array('%', '_'), array('\\%', '\\_'), $q) . '%';
        try {
            if (stripos((string) $db->getAdapterName(), 'mysql') === false) {
                $like = '%' . $q . '%';
            }
        } catch (\Throwable $e) {
            $like = '%' . $q . '%';
        }
        $items = array();

        $select = $db->select('cid', 'title', 'type', 'status', 'created')
            ->from('table.contents')
            ->where('type = ? OR type = ?', 'post', 'page');
        if (!$user->pass('administrator', true)) {
            $select->where('status = ?', 'publish');
        }
        $rows = $db->fetchAll(
            $select->where('title LIKE ?', $like)
                ->order('created', \Typecho\Db::SORT_DESC)
                ->limit(8)
        );
        foreach ($rows as $r) {
            $items[] = array(
                'kind' => $r['type'] === 'page' ? '页面' : '文章',
                'icon' => $r['type'] === 'page' ? 'i-page' : 'i-post',
                'title' => (string) $r['title'],
                'url' => \Typecho\Common::url('write-' . ($r['type'] === 'page' ? 'page' : 'post') . '.php?cid=' . (int) $r['cid'], $options->adminUrl),
                'meta' => date('Y-m-d', (int) $r['created'])
            );
        }

        if ($user->pass('administrator', true)) {
            $rows = $db->fetchAll(
                $db->select('uid', 'name', 'screenName', 'mail')
                    ->from('table.users')
                    ->where('name LIKE ? OR screenName LIKE ? OR mail LIKE ?', $like, $like, $like)
                    ->order('uid', \Typecho\Db::SORT_ASC)
                    ->limit(5)
            );
            foreach ($rows as $r) {
                $items[] = array(
                    'kind' => '用户',
                    'icon' => 'i-user',
                    'title' => (string) ($r['screenName'] ?: $r['name']),
                    'url' => \Typecho\Common::url('user.php?uid=' . (int) $r['uid'], $options->adminUrl),
                    'meta' => (string) $r['mail']
                );
            }
        }

        if ($user->pass('contributor', true)) {
            $rows = $db->fetchAll(
                $db->select('coid', 'author', 'text', 'created')
                    ->from('table.comments')
                    ->where('author LIKE ? OR text LIKE ?', $like, $like)
                    ->order('created', \Typecho\Db::SORT_DESC)
                    ->limit(5)
            );
            foreach ($rows as $r) {
                $items[] = array(
                    'kind' => '评论',
                    'icon' => 'i-cmt',
                    'title' => (string) $r['author'] . '：' . yxCutText((string) $r['text'], 30),
                    'url' => \Typecho\Common::url('manage-comments.php', $options->adminUrl),
                    'meta' => date('Y-m-d', (int) $r['created'])
                );
            }
        }

        yxOut(array('status' => true, 'items' => $items));
        break;

    case 'users':
        if (!$user->pass('administrator', true)) {
            yxErr('无权限', 403);
        }

        $postCnt = array();
        foreach ($db->fetchAll($db->select('authorId', 'COUNT(cid) AS num')->from('table.contents')
            ->where('type = ? AND status = ?', 'post', 'publish')->group('authorId')) as $pr) {
            $postCnt[(int) $pr['authorId']] = (int) $pr['num'];
        }
        $rows = array();
        foreach ($db->fetchAll($db->select('uid', 'name', 'screenName', 'mail', 'group')->from('table.users')->order('uid', \Typecho\Db::SORT_ASC)) as $r) {
            $rows[] = array(
                'uid' => (int) $r['uid'],
                'name' => (string) $r['screenName'],
                'mail' => (string) $r['mail'],
                'group' => (string) $r['group'],
                'posts' => isset($postCnt[(int) $r['uid']]) ? $postCnt[(int) $r['uid']] : 0
            );
        }
        yxOut(array('status' => true, 'users' => $rows));
        break;

    case 'medias':
        $page = max(1, (int) (isset($_GET['page']) ? $_GET['page'] : 1));
        $size = 24;
        yxOut(yxCacheRemember('medias-' . $page, 30, function () use ($db, $options, $page, $size) {
            $offset = ($page - 1) * $size;

            $countSelect = $db->select('COUNT(cid) AS num')->from('table.contents')->where('type = ?', 'attachment');
            $total = (int) $db->fetchObject($countSelect)->num;
            $select = $db->select('cid', 'title', 'created', 'authorId', 'text')->from('table.contents')->where('type = ?', 'attachment');
            $rows = $db->fetchAll($select->order('created', \Typecho\Db::SORT_DESC)->offset($offset)->limit($size));
            $items = array();
            foreach ($rows as $r) {
                $att = json_decode(isset($r['text']) ? (string) $r['text'] : '', true);
                if (!is_array($att) || empty($att['path'])) {
                    continue;
                }
                $p = ltrim((string) $att['path'], '/');

                $url = (0 === strpos($p, 'usr/uploads/'))
                    ? \Typecho\Common::url($p, $options->siteUrl)
                    : \Typecho\Common::url($p, $options->siteUrl . 'usr/uploads/');
                $mime = isset($att['mime']) ? (string) $att['mime'] : '';
                $isImg = strpos($mime, 'image/') === 0;
                $isVid = strpos($mime, 'video/') === 0;
                $items[] = array(
                    'name' => (string) (($att['name'] ?? '') ?: ($r['title'] ?? '')),
                    'url' => $url,
                    'thumb' => $isImg ? $url : '',
                    'size' => yxSize(isset($att['size']) ? $att['size'] : 0),
                    'time' => date('Y-m-d', (int) $r['created']),
                    'mime' => $mime,
                    'image' => $isImg,
                    'video' => $isVid
                );
            }
            return array(
                'status' => true,
                'items' => $items,
                'page' => $page,
                'pages' => max(1, (int) ceil($total / $size)),
                'total' => $total
            );
        }));
        break;

    case 'upload':
        yxUploadFile();
        break;

    case 'local':
        yxUploadFile();
        break;

    case 'imgpaste':
        $raw = @file_get_contents('php://input');
        $json = $raw ? @json_decode($raw, true) : null;
        if (!is_array($json)) {
            yxErr('请求格式错误', 400);
        }
        $name = isset($json['name']) ? preg_replace('/[^\w.\-]/u', '', (string) $json['name']) : '';
        if ($name === '') {
            $name = 'paste-' . date('YmdHis') . '.png';
        }
        $data = null;
        $mime = '';
        if (isset($json['b64']) && is_string($json['b64']) && $json['b64'] !== '') {
            $b = $json['b64'];
            if (preg_match('#^data:([\w/+.-]+);base64,(.*)$#s', $b, $m)) {
                $mime = $m[1];
                $b = $m[2];
            }
            $data = base64_decode($b, true);
            if ($data === false || $data === '') {
                yxErr('图片数据解码失败', 400);
            }
            if ($mime && preg_match('#^image/(\w+)$#', $mime, $mm)) {
                $ext = ($mm[1] === 'jpeg') ? 'jpg' : $mm[1];
                if (strpos($name, '.') === false) {
                    $name = pathinfo($name, PATHINFO_FILENAME) . '.' . $ext;
                }
            }
        } elseif (isset($json['url']) && is_string($json['url']) && $json['url'] !== '') {
            $u = trim($json['url']);
            if (!preg_match('#^https?://#i', $u)) {
                yxErr('仅支持 http/https 图片地址', 400);
            }
            $dl = yxFetchRemoteImage($u);
            if (!$dl) {
                yxErr('远程图片抓取失败', 400);
            }
            $data = $dl['data'];
            $mime = $dl['mime'];
            if (strpos($name, '.') === false) {
                $name = pathinfo($name, PATHINFO_FILENAME) . '.' . ($dl['ext'] ?: 'png');
            }
        } else {
            yxErr('缺少图片数据（b64 或 url）', 400);
        }
        yxOut(yxStoreBytes($data, $name, $mime));
        break;

    case 'me':
        $uid = (int) $user->uid;
        $row = $db->fetchRow($db->select('uid', 'name', 'screenName', 'mail', 'url', 'group', 'created')
            ->from('table.users')->where('uid = ?', $uid)->limit(1));
        if (!$row) {
            yxErr('用户不存在', 404);
        }
        $cnt = function ($type, $status = null) use ($db, $uid) {
            $q = $db->select('COUNT(cid) AS num')->from('table.contents')->where('type = ? AND authorId = ?', $type, $uid);
            if ($status !== null) {
                $q->where('status = ?', $status);
            }
            return (int) $db->fetchObject($q)->num;
        };
        $comments = 0;
        $cids = $db->fetchAll($db->select('cid')->from('table.contents')->where('type = ? AND authorId = ?', 'post', $uid));
        if ($cids) {
            $idList = array_map(function ($c) { return (int) $c['cid']; }, $cids);
            if ($idList) {
                $comments = (int) $db->fetchObject(
                    $db->select('COUNT(coid) AS num')->from('table.comments')->where('cid IN ?', $idList)
                )->num;
            }
        }
        $recent = array();
        foreach ($db->fetchAll($db->select('cid', 'title', 'status', 'created', 'commentsNum')->from('table.contents')
            ->where('type = ? AND authorId = ?', 'post', $uid)->order('created', \Typecho\Db::SORT_DESC)->limit(5)) as $r) {
            $recent[] = array(
                'cid' => (int) $r['cid'],
                'title' => (string) $r['title'],
                'status' => (string) $r['status'],
                'date' => date('Y-m-d', (int) $r['created']),
                'comments' => (int) $r['commentsNum']
            );
        }
        $g = (string) $row['group'];
        $permMap = array(
            'administrator' => array('站点设置', '主题外观', '插件管理', '用户管理', '内容管理', '备份还原'),
            'editor'        => array('内容管理', '评论管理', '分类标签', '文件管理'),
            'author'        => array('发布文章', '上传文件', '管理自己的文章'),
            'contributor'   => array('撰写文章', '上传文件'),
            'subscriber'    => array('基本账户功能')
        );
        yxOut(array(
            'status' => true,
            'user' => array(
                'uid' => (int) $row['uid'],
                'name' => (string) $row['name'],
                'screenName' => (string) ($row['screenName'] ?: $row['name']),
                'mail' => (string) $row['mail'],
                'url' => (string) (isset($row['url']) ? $row['url'] : ''),
                'group' => $g,
                'registered' => date('Y-m-d', (int) $row['created'])
            ),
            'stats' => array(
                'posts' => $cnt('post', 'publish'),
                'drafts' => $cnt('post', 'draft'),
                'pages' => $cnt('page'),
                'attachments' => $cnt('attachment'),
                'comments' => $comments
            ),
            'recent' => $recent,
            'perms' => isset($permMap[$g]) ? $permMap[$g] : array('基本账户功能')
        ));
        break;

    case 'seo_fix':
        require_once dirname(__FILE__) . '/Plugin.php';
        yxOut(yxSeoFix(isset($_REQUEST['fix']) ? (string) $_REQUEST['fix'] : 'all'));
        break;

    case 'dash_live':

        require_once dirname(__FILE__) . '/Plugin.php';
        yxOut(\TypechoPlugin\YunxiAdmin\Plugin::dashLive());
        break;

    case 'collect':

        require_once dirname(__FILE__) . '/Plugin.php';
        $force = isset($_GET['force']) && filter_var($_GET['force'], FILTER_VALIDATE_BOOLEAN);
        yxOut(\TypechoPlugin\YunxiAdmin\Plugin::collectVisitsFromLog($force));
        break;

    case 'weather':
        require_once dirname(__FILE__) . '/Plugin.php';
        $city = isset($_GET['city']) ? trim((string) $_GET['city']) : '';
        $w = \TypechoPlugin\YunxiAdmin\Plugin::weatherByCity($city);
        yxOut(array('status' => !empty($w['city']), 'weather' => $w));
        break;

    case 'geo':
        require_once dirname(__FILE__) . '/Plugin.php';
        yxOut(\TypechoPlugin\YunxiAdmin\Plugin::geoInfo());
        break;

    case 'alerts':
        require_once dirname(__FILE__) . '/Plugin.php';
        $province = isset($_GET['province']) ? trim((string) $_GET['province']) : '';
        $city = isset($_GET['city']) ? trim((string) $_GET['city']) : '';
        yxOut(\TypechoPlugin\YunxiAdmin\Plugin::alerts($province, $city));
        break;

    case 'traffic':

        require_once dirname(__FILE__) . '/Plugin.php';
        yxOut(\TypechoPlugin\YunxiAdmin\Plugin::trafficForecast(false));
        break;

    case 'traffic_live':

        require_once dirname(__FILE__) . '/Plugin.php';
        yxOut(\TypechoPlugin\YunxiAdmin\Plugin::trafficForecast(true));
        break;

    default:
        yxErr('未知操作', 404);
}
